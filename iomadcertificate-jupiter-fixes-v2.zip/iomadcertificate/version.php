<?php
// This file is part of the Certificate module for Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * IOMAD certificate activity
 *
 * @package   mod_iomadcertificate
 * @copyright 2021 Derick Turner
 * @author    Derick Turner
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

// This plugin is based on code originally created as mod_certificate by Mark Nelson <markn@moodle.com>.

defined('MOODLE_INTERNAL') || die();

$plugin->release  = '5.1.5 (Build: 20260608) + Jupiter certificate fixes 2';    // Human-friendly version name.
$plugin->version  = 2026090501;   // The (date) version of this plugin.
$plugin->requires = 2025100600;   // Requires this Moodle version.
$plugin->component = 'mod_iomadcertificate';
$plugin->dependencies = ['local_iomad' => 2026010100];
$plugin->supported = [501, 501];
$plugin->maturity = MATURITY_STABLE;
