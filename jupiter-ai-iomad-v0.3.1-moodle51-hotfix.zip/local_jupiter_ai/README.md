# Jupiter AI Tutor v0.3.1

Security-first foundation for Jupiter The Scholar on Iomad/Moodle.

## Included
- Course-level learner authorisation.
- Server-side active-assessment lock for in-progress Moodle quizzes.
- First-line assessment/answer-seeking detection.
- Provider abstraction with **no live AI provider connected**.
- Privacy-minimised audit: no raw learner prompts; SHA-256 input hash + policy metadata only.
- Moodle Privacy API export/delete support.
- AI transparency notice.
- High-privacy defaults.

## Intentionally not included yet
- OpenAI/Anthropic/Gemini/Bedrock connection.
- Raw conversation storage.
- Parent access to AI conversations.
- AI grading or automated educational decisions.
- Copy/paste browser controls. These require an accessibility-aware implementation and server-side offloading detection rather than relying on JavaScript alone.

## Next controlled build
v0.2.x should add:
1. authorised lesson-context assembler;
2. provider interface implementation with verified enterprise/API data controls;
3. input moderation + output validation;
4. progressive-hint state machine requiring learner effort;
5. assessment-content fingerprinting;
6. rate limits / abuse controls;
7. retention policy and admin audit reporting;
8. accessibility-aware quiz paste/offloading controls.


## v0.1.1
- Fixes Moodle XMLDB warnings for `reasoncode` and `inputhash` CHAR fields.
- Adds an upgrade step so already-installed v0.1.0 databases are normalized explicitly.
- No AI behaviour or provider changes.


## v0.2.0 — controlled context and policy gateway
- Minimum-authorised lesson context assembler.
- Explicitly excludes profiles, email, parent data, grades, logs and other learners.
- Never grounds on quiz content.
- Jupiter-controlled progressive coaching instructions.
- Prompt-injection and sensitive-data first-line blocking.
- Deterministic output guard scaffold.
- Per-session request throttling.
- Provider remains disabled intentionally: no learner content is sent externally until a provider/data-processing choice is approved.


## v0.2.1
- Fixes PHP namespace resolution for Moodle global `core_text`.
- Replaces the plain form with a proper chatbot-style learner interface.
- Preserves all server-side assessment, privacy, authorization and policy controls.
- Provider remains disabled until the controlled provider stage.


## v0.3.0 — Investor MVP floating assistant
- Floating Jupiter AI launcher on authorised course/activity pages.
- Side-drawer chat keeps the learner on the lesson.
- AJAX messages without full-page reload.
- Conversation continuity uses browser sessionStorage, capped at 20 messages.
- Raw chat is not persisted to Moodle DB; existing minimal hashed audit remains.
- Login, capability, module visibility and assessment state are revalidated server-side for every message.
- Active assessment locks the composer.
- Provider remains disabled until explicitly approved/configured.


## v0.3.1 — Moodle 5.1 compatibility hotfix
- Fixes AJAX external API imports to Moodle 5.1 `core_external` namespace.
- Migrates deprecated `local_jupiter_ai_before_footer()` callback to `core\hook\output\before_footer_html_generation`.
- Does not inject the floating assistant during installation/upgrade/CLI.
- No database schema change and no provider change.
