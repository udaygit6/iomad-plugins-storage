import Ajax from 'core/ajax';
import Notification from 'core/notification';

const esc = value => {
    const d = document.createElement('div');
    d.textContent = value ?? '';
    return d.innerHTML;
};
const storageKey = (courseid, cmid) => `jupiter_ai_chat_${courseid}_${cmid || 0}`;
const loadHistory = key => {
    try {
        const data = JSON.parse(sessionStorage.getItem(key) || '[]');
        return Array.isArray(data) ? data.slice(-20) : [];
    } catch (e) {
        return [];
    }
};
const saveHistory = (key, history) => {
    try {
        sessionStorage.setItem(key, JSON.stringify(history.slice(-20)));
    } catch (e) {}
};
const bubble = (role, text) =>
    `<div class="jupiter-ai-row ${role}"><div class="jupiter-ai-bubble">${esc(text)}</div></div>`;

export const init = (courseid, cmid, assessmentlocked, labels) => {
    if (document.getElementById('jupiter-ai-launcher')) return;

    const key = storageKey(courseid, cmid);
    let history = loadHistory(key);
    const root = document.createElement('div');
    root.id = 'jupiter-ai-floating-root';
    root.innerHTML = `
      <button id="jupiter-ai-launcher" class="btn btn-primary" type="button"
              aria-controls="jupiter-ai-drawer" aria-expanded="false">
        <span aria-hidden="true">✦</span> ${esc(labels.title)}
      </button>
      <section id="jupiter-ai-drawer" class="jupiter-ai-drawer" aria-hidden="true" aria-label="${esc(labels.title)}">
        <header class="jupiter-ai-drawer-header">
          <div><strong>${esc(labels.title)}</strong><small>${esc(labels.subtitle)}</small></div>
          <button id="jupiter-ai-close" type="button" class="btn btn-link" aria-label="${esc(labels.close)}">×</button>
        </header>
        <div id="jupiter-ai-drawer-chat" class="jupiter-ai-chat"></div>
        <div class="jupiter-ai-drawer-notice">${esc(labels.notice)}</div>
        <form id="jupiter-ai-drawer-form" class="jupiter-ai-composer">
          <div class="jupiter-ai-composer-inner">
            <textarea id="jupiter-ai-drawer-question" class="form-control" rows="2" maxlength="3000"
                      placeholder="${esc(labels.placeholder)}" aria-label="${esc(labels.ask)}"></textarea>
            <button class="btn btn-primary" type="submit">${esc(labels.send)}</button>
          </div>
        </form>
      </section>`;
    document.body.appendChild(root);

    const launcher=root.querySelector('#jupiter-ai-launcher');
    const drawer=root.querySelector('#jupiter-ai-drawer');
    const close=root.querySelector('#jupiter-ai-close');
    const chat=root.querySelector('#jupiter-ai-drawer-chat');
    const form=root.querySelector('#jupiter-ai-drawer-form');
    const question=root.querySelector('#jupiter-ai-drawer-question');
    const send=form.querySelector('button');

    const render=()=>{
        chat.innerHTML = history.length ?
            history.map(m=>bubble(m.role,m.text)).join('') :
            bubble('assistant', assessmentlocked ? labels.locked : labels.welcome);
        if (assessmentlocked && history.length) chat.innerHTML += bubble('assistant', labels.locked);
        chat.scrollTop=chat.scrollHeight;
    };
    render();

    if (assessmentlocked) {
        question.disabled=true;
        send.disabled=true;
    }

    launcher.addEventListener('click',()=>{
        drawer.classList.add('open');
        drawer.setAttribute('aria-hidden','false');
        launcher.setAttribute('aria-expanded','true');
        if (!assessmentlocked) question.focus();
    });
    close.addEventListener('click',()=>{
        drawer.classList.remove('open');
        drawer.setAttribute('aria-hidden','true');
        launcher.setAttribute('aria-expanded','false');
        launcher.focus();
    });

    form.addEventListener('submit', async e=>{
        e.preventDefault();
        const text=question.value.trim();
        if (!text || assessmentlocked) return;

        history.push({role:'user',text});
        saveHistory(key,history);
        question.value='';
        render();
        question.disabled=true;
        send.disabled=true;

        try {
            const response=await Ajax.call([{
                methodname:'local_jupiter_ai_chat',
                args:{courseid,cmid,question:text}
            }])[0];
            history.push({role:'assistant',text:response.text});
            saveHistory(key,history);
            render();
        } catch (error) {
            Notification.exception(error);
        } finally {
            question.disabled=false;
            send.disabled=false;
            question.focus();
        }
    });
};
