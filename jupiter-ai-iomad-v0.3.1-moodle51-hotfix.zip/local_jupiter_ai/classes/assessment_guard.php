<?php
namespace local_jupiter_ai;

defined('MOODLE_INTERNAL') || die();

final class assessment_guard {
    /**
     * Fail closed for any in-progress Moodle quiz attempt in this course.
     */
    public static function has_active_assessment(int $userid, int $courseid): bool {
        global $DB;

        if (!get_config('local_jupiter_ai', 'blockduringassessment')) {
            return false;
        }

        $sql = "SELECT 1
                  FROM {quiz_attempts} qa
                  JOIN {quiz} q ON q.id = qa.quiz
                 WHERE qa.userid = :userid
                   AND q.course = :courseid
                   AND qa.state = :state";

        return $DB->record_exists_sql($sql, [
            'userid' => $userid,
            'courseid' => $courseid,
            'state' => 'inprogress',
        ]);
    }
}
