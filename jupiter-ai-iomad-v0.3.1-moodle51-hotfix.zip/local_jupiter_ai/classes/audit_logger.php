<?php
namespace local_jupiter_ai;

defined('MOODLE_INTERNAL') || die();

final class audit_logger {
    public static function log(int $userid, int $courseid, int $cmid, string $input, array $policy): void {
        global $DB;

        // Deliberately do not store raw learner prompt text in v0.1.0.
        $record = (object)[
            'userid' => $userid,
            'courseid' => $courseid,
            'cmid' => $cmid,
            'eventtype' => 'request',
            'decision' => substr($policy['decision'] ?? 'block', 0, 40),
            'reasoncode' => substr($policy['reasoncode'] ?? 'unknown', 0, 80),
            'inputhash' => hash('sha256', $input),
            'inputchars' => \core_text::strlen($input),
            'timecreated' => time(),
        ];
        $DB->insert_record('local_jupiter_ai_audit', $record);
    }
}
