<?php
namespace local_jupiter_ai;

defined('MOODLE_INTERNAL') || die();

final class context_assembler {
    /**
     * Assemble only minimum, already-authorised learning context.
     * Never includes profile, email, grades, parent data, logs, or other users.
     */
    public static function build(int $userid, int $courseid, int $cmid = 0): array {
        $course = get_course($courseid);
        $context = \context_course::instance($courseid);
        require_capability('local/jupiter_ai:use', $context);

        $out = [
            'courseid' => $courseid,
            'course' => format_string($course->fullname, true, ['context' => $context]),
            'moduleid' => 0,
            'module' => '',
            'content' => '',
        ];

        if (!$cmid) {
            return $out;
        }

        $modinfo = get_fast_modinfo($course, $userid);
        $cm = $modinfo->get_cm($cmid);
        if (!$cm->uservisible) {
            throw new \moodle_exception('nopermissions', 'error');
        }

        // Assessment content is never sent as tutor grounding.
        if ($cm->modname === 'quiz') {
            throw new \moodle_exception('assessmentcontextblocked', 'local_jupiter_ai');
        }

        $out['moduleid'] = $cmid;
        $out['module'] = format_string($cm->name, true, ['context' => $cm->context]);

        // Safe MVP: module description only. We deliberately do not scrape the whole course.
        $raw = '';
        if (!empty($cm->content)) {
            $raw = $cm->content;
        } else if (!empty($cm->description)) {
            $raw = $cm->description;
        }

        $plain = trim(html_to_text($raw, 0, false));
        $out['content'] = \core_text::substr($plain, 0, 12000);

        return $out;
    }
}
