<?php
namespace local_jupiter_ai\external;

defined('MOODLE_INTERNAL') || die();

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_value;

final class chat extends external_api {
    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'courseid' => new external_value(PARAM_INT, 'Course id'),
            'cmid' => new external_value(PARAM_INT, 'Optional course module id', VALUE_DEFAULT, 0),
            'question' => new external_value(PARAM_RAW_TRIMMED, 'Learner question'),
        ]);
    }

    public static function execute(int $courseid, int $cmid, string $question): array {
        global $USER;

        $params = self::validate_parameters(self::execute_parameters(), [
            'courseid' => $courseid, 'cmid' => $cmid, 'question' => $question
        ]);
        $courseid = $params['courseid'];
        $cmid = $params['cmid'];
        $question = $params['question'];

        $course = get_course($courseid);
        require_login($course);
        $context = \context_course::instance($courseid);
        self::validate_context($context);
        require_capability('local/jupiter_ai:use', $context);

        if (!get_config('local_jupiter_ai', 'enabled')) {
            throw new \moodle_exception('aidisabled', 'local_jupiter_ai');
        }

        if ($cmid) {
            $modinfo = get_fast_modinfo($course, $USER->id);
            $cm = $modinfo->get_cm($cmid);
            if (!$cm->uservisible) {
                throw new \moodle_exception('nopermissions', 'error');
            }
        }

        \local_jupiter_ai\rate_limiter::check();
        $active = \local_jupiter_ai\assessment_guard::has_active_assessment((int)$USER->id, $courseid);
        $policy = \local_jupiter_ai\policy_engine::classify($question, $active);
        \local_jupiter_ai\audit_logger::log((int)$USER->id, $courseid, $cmid, $question, $policy);

        if ($active || $policy['decision'] === \local_jupiter_ai\policy_engine::BLOCK ||
            $policy['decision'] === \local_jupiter_ai\policy_engine::COACH_ONLY) {
            return ['text'=>$policy['message'], 'decision'=>$policy['decision'], 'reasoncode'=>$policy['reasoncode']];
        }

        $safecontext = \local_jupiter_ai\context_assembler::build((int)$USER->id, $courseid, $cmid);
        $safecontext['system'] = \local_jupiter_ai\coaching_engine::instructions($policy);

        $provider = new \local_jupiter_ai\provider\disabled_provider();
        $response = $provider->generate($safecontext, $question, $policy);
        $guarded = \local_jupiter_ai\output_guard::validate((string)$response['text'], $policy);

        return ['text'=>$guarded['text'], 'decision'=>'foundation', 'reasoncode'=>'provider_disabled'];
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'text' => new external_value(PARAM_TEXT, 'Safe assistant response'),
            'decision' => new external_value(PARAM_ALPHANUMEXT, 'Policy decision'),
            'reasoncode' => new external_value(PARAM_ALPHANUMEXT, 'Reason code'),
        ]);
    }
}
