<?php
namespace local_jupiter_ai;

defined('MOODLE_INTERNAL') || die();

final class floating_assistant {
    public static function attach(): void {
        global $PAGE, $USER, $COURSE, $CFG;

        // Never inject during install/upgrade/CLI or on non-course pages.
        if (CLI_SCRIPT || during_initial_install() || !empty($CFG->upgraderunning)) {
            return;
        }
        if (!isloggedin() || isguestuser() || empty($COURSE->id) || (int)$COURSE->id === SITEID) {
            return;
        }
        if (!get_config('local_jupiter_ai', 'enabled')) {
            return;
        }

        $context = \context_course::instance($COURSE->id);
        if (!has_capability('local/jupiter_ai:use', $context)) {
            return;
        }

        $cmid = !empty($PAGE->cm) ? (int)$PAGE->cm->id : 0;
        $locked = assessment_guard::has_active_assessment((int)$USER->id, (int)$COURSE->id);

        $labels = [
            'title' => get_string('aitutor', 'local_jupiter_ai'),
            'subtitle' => get_string('chatsubtitle', 'local_jupiter_ai'),
            'close' => get_string('closechat', 'local_jupiter_ai'),
            'notice' => get_string('transparencynoticeshort', 'local_jupiter_ai'),
            'placeholder' => get_string('chatplaceholder', 'local_jupiter_ai'),
            'ask' => get_string('asklabel', 'local_jupiter_ai'),
            'send' => get_string('sendbutton', 'local_jupiter_ai'),
            'welcome' => get_string('chatwelcome_v030', 'local_jupiter_ai'),
            'locked' => get_string('assessmentlocked', 'local_jupiter_ai'),
        ];

        $PAGE->requires->js_call_amd('local_jupiter_ai/assistant', 'init', [
            (int)$COURSE->id,
            $cmid,
            $locked,
            $labels,
        ]);
    }
}
