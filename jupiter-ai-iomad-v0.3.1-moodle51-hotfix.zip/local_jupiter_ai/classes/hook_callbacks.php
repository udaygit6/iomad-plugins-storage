<?php
namespace local_jupiter_ai;

defined('MOODLE_INTERNAL') || die();

final class hook_callbacks {
    public static function before_footer_html_generation(
        \core\hook\output\before_footer_html_generation $hook
    ): void {
        floating_assistant::attach();
    }
}
