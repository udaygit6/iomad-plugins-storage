<?php
namespace local_jupiter_ai;

defined('MOODLE_INTERNAL') || die();

final class output_guard {
    public static function validate(string $output, array $policy): array {
        $text = trim($output);
        if ($text === '') {
            return ['ok' => false, 'text' => get_string('outputblocked', 'local_jupiter_ai')];
        }

        // Never allow provider/system leakage markers through.
        if (preg_match('/\b(system prompt|developer message|hidden instruction|api[_ -]?key|bearer token)\b/i', $text)) {
            return ['ok' => false, 'text' => get_string('outputblocked', 'local_jupiter_ai')];
        }

        // In coach-only mode, reject obvious final-answer framing.
        if (($policy['decision'] ?? '') === policy_engine::COACH_ONLY &&
            preg_match('/\b(the (correct|final) answer is|answer\s*[:\-]\s*[A-D]\b)/i', $text)) {
            return ['ok' => false, 'text' => get_string('outputcoachfallback', 'local_jupiter_ai')];
        }

        return ['ok' => true, 'text' => $text];
    }
}
