<?php
namespace local_jupiter_ai;

defined('MOODLE_INTERNAL') || die();

final class policy_engine {
    public const ALLOW = 'allow';
    public const COACH_ONLY = 'coach_only';
    public const BLOCK = 'block';

    /**
     * Conservative first-line classifier. This is not the only future safeguard:
     * provider moderation and output validation must also run server-side.
     */
    public static function classify(string $input, bool $assessmentactive): array {
        $text = \core_text::strtolower(trim($input));

        if ($assessmentactive) {
            return [
                'decision' => self::BLOCK,
                'reasoncode' => 'active_assessment',
                'message' => get_string('policy_activeassessment', 'local_jupiter_ai'),
            ];
        }

        if ($text === '') {
            return [
                'decision' => self::BLOCK,
                'reasoncode' => 'empty',
                'message' => get_string('policy_empty', 'local_jupiter_ai'),
            ];
        }

        $answerpatterns = [
            '/\b(give|tell|show|write|generate)\b.{0,35}\b(answer|solution|response)\b/u',
            '/\bjust\s+(give|tell)\s+me\b/u',
            '/\bdo\s+(this|it|my\s+(work|homework|quiz|test|assessment))\s+for\s+me\b/u',
            '/\bcomplete\s+(this|it)\s+for\s+me\b/u',
            '/\bwhich\s+(answer|option)\s+is\s+(correct|right)\b/u',
            '/\banswer\s*[:\-]\s*[a-d]\b/u',
        ];

        foreach ($answerpatterns as $pattern) {
            if (preg_match($pattern, $text)) {
                return [
                    'decision' => self::COACH_ONLY,
                    'reasoncode' => 'answer_seeking',
                    'message' => get_string('policy_coachonly', 'local_jupiter_ai'),
                ];
            }
        }

        // Likely copied multiple-choice assessment content.
        $optionhits = preg_match_all('/(?:^|\s)(?:a|b|c|d)[\)\.\:]\s+/mu', $text);
        if ($optionhits >= 3 || (\core_text::strlen($text) > 700 && preg_match('/\b(question|quiz|test|assessment)\b/u', $text))) {
            return [
                'decision' => self::COACH_ONLY,
                'reasoncode' => 'likely_assessment_content',
                'message' => get_string('policy_assessmentcontent', 'local_jupiter_ai'),
            ];
        }

        // High-risk personal data should not be sent to a provider.
        if (preg_match('/\b(password|passcode|api key|credit card|bank account|national insurance|passport number)\b/u', $text)) {
            return [
                'decision' => self::BLOCK,
                'reasoncode' => 'sensitive_data',
                'message' => get_string('policy_sensitive', 'local_jupiter_ai'),
            ];
        }

        // Common prompt-injection attempts never weaken Jupiter policy.
        if (preg_match('/\b(ignore|forget|bypass|override)\b.{0,40}\b(instruction|rule|policy|restriction|system prompt)\b/u', $text)) {
            return [
                'decision' => self::COACH_ONLY,
                'reasoncode' => 'prompt_injection',
                'message' => get_string('policy_injection', 'local_jupiter_ai'),
            ];
        }

        return [
            'decision' => self::ALLOW,
            'reasoncode' => 'lesson_help',
            'message' => get_string('policy_allowedfoundation', 'local_jupiter_ai'),
        ];
    }
}
