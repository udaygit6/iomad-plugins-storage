<?php
namespace local_jupiter_ai\privacy;

defined('MOODLE_INTERNAL') || die();

use core_privacy\local\metadata\collection;
use core_privacy\local\request\approved_contextlist;
use core_privacy\local\request\contextlist;
use core_privacy\local\request\transform;

final class provider implements
    \core_privacy\local\metadata\provider,
    \core_privacy\local\request\plugin\provider {

    public static function get_metadata(collection $collection): collection {
        $collection->add_database_table(
            'local_jupiter_ai_audit',
            [
                'userid' => 'privacy:metadata:audit:userid',
                'courseid' => 'privacy:metadata:audit:courseid',
                'cmid' => 'privacy:metadata:audit:cmid',
                'eventtype' => 'privacy:metadata:audit:eventtype',
                'decision' => 'privacy:metadata:audit:decision',
                'reasoncode' => 'privacy:metadata:audit:reasoncode',
                'inputhash' => 'privacy:metadata:audit:inputhash',
                'inputchars' => 'privacy:metadata:audit:inputchars',
                'timecreated' => 'privacy:metadata:audit:timecreated',
            ],
            'privacy:metadata:audit'
        );
        return $collection;
    }

    public static function get_contexts_for_userid(int $userid): contextlist {
        $contextlist = new contextlist();
        $sql = "SELECT DISTINCT ctx.id
                  FROM {local_jupiter_ai_audit} a
                  JOIN {context} ctx
                    ON ctx.contextlevel = :contextlevel
                   AND ctx.instanceid = a.courseid
                 WHERE a.userid = :userid";
        $contextlist->add_from_sql($sql, [
            'contextlevel' => CONTEXT_COURSE,
            'userid' => $userid,
        ]);
        return $contextlist;
    }

    public static function export_user_data(approved_contextlist $contextlist) {
        global $DB;

        $userid = $contextlist->get_user()->id;
        foreach ($contextlist->get_contexts() as $context) {
            if ($context->contextlevel !== CONTEXT_COURSE) {
                continue;
            }
            $records = $DB->get_records('local_jupiter_ai_audit', [
                'userid' => $userid,
                'courseid' => $context->instanceid,
            ], 'timecreated ASC');

            $data = [];
            foreach ($records as $record) {
                $data[] = [
                    'eventtype' => $record->eventtype,
                    'decision' => $record->decision,
                    'reasoncode' => $record->reasoncode,
                    'inputchars' => $record->inputchars,
                    'timecreated' => transform::datetime($record->timecreated),
                ];
            }
            \core_privacy\local\request\writer::with_context($context)
                ->export_data([get_string('pluginname', 'local_jupiter_ai')], (object)['audit' => $data]);
        }
    }

    public static function delete_data_for_all_users_in_context(\context $context) {
        global $DB;
        if ($context->contextlevel === CONTEXT_COURSE) {
            $DB->delete_records('local_jupiter_ai_audit', ['courseid' => $context->instanceid]);
        }
    }

    public static function delete_data_for_user(approved_contextlist $contextlist) {
        global $DB;
        $userid = $contextlist->get_user()->id;
        foreach ($contextlist->get_contexts() as $context) {
            if ($context->contextlevel === CONTEXT_COURSE) {
                $DB->delete_records('local_jupiter_ai_audit', [
                    'userid' => $userid,
                    'courseid' => $context->instanceid,
                ]);
            }
        }
    }
}
