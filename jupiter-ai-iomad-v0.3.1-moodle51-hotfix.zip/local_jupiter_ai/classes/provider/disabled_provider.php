<?php
namespace local_jupiter_ai\provider;

defined('MOODLE_INTERNAL') || die();

final class disabled_provider implements provider_interface {
    public function generate(array $context, string $learnerinput, array $policy): array {
        return [
            'ok' => false,
            'text' => get_string('provider_notconnected', 'local_jupiter_ai'),
        ];
    }
}
