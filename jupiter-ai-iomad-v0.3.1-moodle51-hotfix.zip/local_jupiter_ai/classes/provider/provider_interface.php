<?php
namespace local_jupiter_ai\provider;

defined('MOODLE_INTERNAL') || die();

interface provider_interface {
    /**
     * Generate a controlled educational response.
     * Providers must receive only the minimum authorised context assembled server-side.
     */
    public function generate(array $context, string $learnerinput, array $policy): array;
}
