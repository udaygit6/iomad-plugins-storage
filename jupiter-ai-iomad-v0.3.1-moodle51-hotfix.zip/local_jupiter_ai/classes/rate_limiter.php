<?php
namespace local_jupiter_ai;

defined('MOODLE_INTERNAL') || die();

final class rate_limiter {
    public static function check(): void {
        global $SESSION;
        $now = time();
        $key = 'jupiter_ai_rate';
        $events = $SESSION->{$key} ?? [];
        $events = array_values(array_filter($events, static fn($t) => ($now - (int)$t) < 60));
        if (count($events) >= 10) {
            throw new \moodle_exception('ratelimited', 'local_jupiter_ai');
        }
        $events[] = $now;
        $SESSION->{$key} = $events;
    }
}
