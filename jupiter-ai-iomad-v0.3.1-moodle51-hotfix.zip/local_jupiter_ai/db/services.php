<?php
defined('MOODLE_INTERNAL') || die();

$functions = [
    'local_jupiter_ai_chat' => [
        'classname' => 'local_jupiter_ai\external\chat',
        'methodname' => 'execute',
        'description' => 'Return a policy-controlled Jupiter AI Tutor response.',
        'type' => 'read',
        'ajax' => true,
        'capabilities' => 'local/jupiter_ai:use',
    ],
];
