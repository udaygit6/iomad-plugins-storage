<?php
defined('MOODLE_INTERNAL') || die();

function xmldb_local_jupiter_ai_upgrade($oldversion) {
    global $DB;

    $dbman = $DB->get_manager();

    if ($oldversion < 2026090502) {
        $table = new xmldb_table('local_jupiter_ai_audit');

        $reasoncode = new xmldb_field(
            'reasoncode', XMLDB_TYPE_CHAR, '80', null, null, null, null, 'decision'
        );
        if ($dbman->field_exists($table, $reasoncode)) {
            $dbman->change_field_notnull($table, $reasoncode);
            $dbman->change_field_default($table, $reasoncode);
        }

        $inputhash = new xmldb_field(
            'inputhash', XMLDB_TYPE_CHAR, '64', null, null, null, null, 'reasoncode'
        );
        if ($dbman->field_exists($table, $inputhash)) {
            $dbman->change_field_notnull($table, $inputhash);
            $dbman->change_field_default($table, $inputhash);
        }

        upgrade_plugin_savepoint(true, 2026090502, 'local', 'jupiter_ai');
    }

    return true;
}
