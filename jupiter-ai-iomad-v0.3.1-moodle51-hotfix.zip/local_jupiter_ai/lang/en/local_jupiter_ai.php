<?php
$string['pluginname'] = 'Jupiter AI Tutor';
$string['aitutor'] = 'Jupiter AI Tutor';
$string['settingsheading'] = 'Jupiter AI Tutor';
$string['securityheading'] = 'Safety and privacy foundation';
$string['securityheading_desc'] = 'Jupiter-controlled educational AI. Safety rules are enforced server-side before any future AI provider is called.';
$string['enabled'] = 'Enable Jupiter AI Tutor foundation';
$string['enabled_desc'] = 'Shows the controlled tutor entry point to authorised learners.';
$string['blockduringassessment'] = 'Lock AI during active assessments';
$string['blockduringassessment_desc'] = 'Fail closed while the learner has an in-progress Moodle quiz attempt in the course.';
$string['storeprompttext'] = 'Store raw learner prompts';
$string['storeprompttext_desc'] = 'Reserved for future governance. Keep OFF. v0.1.0 does not store raw prompt text even if changed.';
$string['provider'] = 'AI provider';
$string['provider_desc'] = 'v0.1.0 deliberately ships without a live model. Provider connection is the next controlled stage.';
$string['provider_disabled'] = 'Disabled — safety foundation only';
$string['aidisabled'] = 'Jupiter AI Tutor is disabled.';
$string['transparencynotice'] = 'I am an AI learning assistant, not a human teacher. I am designed to coach your thinking rather than complete assessed work for you. Jupiter applies safety and privacy controls to every request.';
$string['assessmentlocked'] = 'AI Tutor is temporarily unavailable while you have an active assessment attempt in this course. Finish and submit the assessment first.';
$string['asklabel'] = 'What would you like help understanding?';
$string['askhelp'] = 'Ask about the lesson or concept. Do not paste quiz/test questions or personal information.';
$string['askbutton'] = 'Ask Jupiter AI';
$string['policy_activeassessment'] = 'I cannot help while an assessment attempt is active. Finish and submit it first, then I can help you review the underlying concept.';
$string['policy_empty'] = 'Please enter a learning question.';
$string['policy_coachonly'] = 'I will not provide a final answer or complete assessed work for you. Tell me what you have tried or which part you do not understand, and I can give you a hint or explain the concept.';
$string['policy_assessmentcontent'] = 'This looks like assessment content. I will not select or generate the answer. I can explain the underlying topic or give you a similar practice example instead.';
$string['policy_allowedfoundation'] = 'Your request passed Jupiter’s first safety check.';
$string['provider_notconnected'] = 'The Jupiter safety foundation is working. A live AI model is not connected in this version, so no learner content has been sent to an external AI provider.';
$string['local_jupiter_ai:use'] = 'Use Jupiter AI Tutor';
$string['local_jupiter_ai:manage'] = 'Manage Jupiter AI Tutor';

$string['privacy:metadata:audit'] = 'Privacy-minimised safety and usage audit records for Jupiter AI Tutor.';
$string['privacy:metadata:audit:userid'] = 'The learner user ID.';
$string['privacy:metadata:audit:courseid'] = 'The authorised course ID.';
$string['privacy:metadata:audit:cmid'] = 'The optional course module ID.';
$string['privacy:metadata:audit:eventtype'] = 'The type of AI interaction event.';
$string['privacy:metadata:audit:decision'] = 'The safety policy decision.';
$string['privacy:metadata:audit:reasoncode'] = 'The policy reason code.';
$string['privacy:metadata:audit:inputhash'] = 'A one-way SHA-256 hash of the input, not the raw prompt.';
$string['privacy:metadata:audit:inputchars'] = 'The input character count.';
$string['privacy:metadata:audit:timecreated'] = 'When the audit event was created.';

$string['assessmentcontextblocked'] = 'Assessment content cannot be used as AI Tutor grounding.';
$string['policy_sensitive'] = 'Please do not enter passwords, financial details, identity-document numbers, API keys, or other sensitive personal information. Ask your learning question without those details.';
$string['policy_injection'] = 'Jupiter safety rules cannot be overridden. I can still help explain the authorised lesson concept without revealing or bypassing system rules.';
$string['outputblocked'] = 'I could not safely provide that response. Please ask for a hint or an explanation of the lesson concept.';
$string['outputcoachfallback'] = 'I will not provide the final answer to assessed work. Tell me what you have tried and I will give you the next hint.';
$string['ratelimited'] = 'You are asking questions too quickly. Please wait a moment and try again.';
$string['maxcontextchars'] = 'Maximum lesson context characters';
$string['maxcontextchars_desc'] = 'Upper safety limit for authorised lesson context prepared for a future AI provider. No profile, parent, grade or other learner data is included.';

$string['chatsubtitle'] = 'Controlled learning assistant';
$string['chatwelcome'] = 'Hi! I’m Jupiter AI Tutor. Ask me to explain a lesson concept, give you a hint, or help you practise. I won’t complete assessed work or give you quiz answers.';
$string['chatplaceholder'] = 'Ask Jupiter AI about this course...';
$string['sendbutton'] = 'Send';
$string['transparencynoticeshort'] = 'AI learning assistant · Do not enter personal information · Assessment answers are protected';

$string['closechat'] = 'Close Jupiter AI Tutor';
$string['chatwelcome_v030'] = 'Jupiter AI Tutor is an AI learning tool. It can explain concepts, provide hints and help with practice. It does not replace a teacher or tutor and will not provide assessed answers.';
