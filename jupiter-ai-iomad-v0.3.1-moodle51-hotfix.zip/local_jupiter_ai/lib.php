<?php
defined('MOODLE_INTERNAL') || die();

/**
 * Add Jupiter AI Tutor to course navigation only for authorised users.
 */
function local_jupiter_ai_extend_navigation_course($navigation, $course, $context) {
    global $USER;

    if (empty($USER->id) || isguestuser() || !get_config('local_jupiter_ai', 'enabled')) {
        return;
    }
    if (!has_capability('local/jupiter_ai:use', $context)) {
        return;
    }

    $url = new moodle_url('/local/jupiter_ai/tutor.php', ['courseid' => $course->id]);
    $navigation->add(
        get_string('aitutor', 'local_jupiter_ai'),
        $url,
        navigation_node::TYPE_CUSTOM,
        null,
        'jupiteraitutor'
    );
}
