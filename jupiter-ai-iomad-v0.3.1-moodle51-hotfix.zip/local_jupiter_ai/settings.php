<?php
defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    $settings = new admin_settingpage('local_jupiter_ai', get_string('settingsheading', 'local_jupiter_ai'));
    $ADMIN->add('localplugins', $settings);

    $settings->add(new admin_setting_heading(
        'local_jupiter_ai/securityheading',
        get_string('securityheading', 'local_jupiter_ai'),
        get_string('securityheading_desc', 'local_jupiter_ai')
    ));

    $settings->add(new admin_setting_configcheckbox(
        'local_jupiter_ai/enabled',
        get_string('enabled', 'local_jupiter_ai'),
        get_string('enabled_desc', 'local_jupiter_ai'),
        1
    ));

    $settings->add(new admin_setting_configcheckbox(
        'local_jupiter_ai/blockduringassessment',
        get_string('blockduringassessment', 'local_jupiter_ai'),
        get_string('blockduringassessment_desc', 'local_jupiter_ai'),
        1
    ));

    $settings->add(new admin_setting_configcheckbox(
        'local_jupiter_ai/storeprompttext',
        get_string('storeprompttext', 'local_jupiter_ai'),
        get_string('storeprompttext_desc', 'local_jupiter_ai'),
        0
    ));

    $settings->add(new admin_setting_configtext(
        'local_jupiter_ai/maxcontextchars',
        get_string('maxcontextchars', 'local_jupiter_ai'),
        get_string('maxcontextchars_desc', 'local_jupiter_ai'),
        12000,
        PARAM_INT
    ));

    $settings->add(new admin_setting_configselect(
        'local_jupiter_ai/provider',
        get_string('provider', 'local_jupiter_ai'),
        get_string('provider_desc', 'local_jupiter_ai'),
        'disabled',
        ['disabled' => get_string('provider_disabled', 'local_jupiter_ai')]
    ));
}
