<?php
require_once(__DIR__ . '/../../config.php');

$courseid = required_param('courseid', PARAM_INT);
$cmid = optional_param('cmid', 0, PARAM_INT);
$question = optional_param('question', '', PARAM_RAW_TRIMMED);

$course = get_course($courseid);
require_login($course);

$context = context_course::instance($courseid);
require_capability('local/jupiter_ai:use', $context);

if (!get_config('local_jupiter_ai', 'enabled')) {
    throw new moodle_exception('aidisabled', 'local_jupiter_ai');
}

if ($cmid) {
    $cm = get_coursemodule_from_id('', $cmid, $courseid, false, MUST_EXIST);
    $modinfo = get_fast_modinfo($course, $USER->id);
    $cminfo = $modinfo->get_cm($cmid);
    if (!$cminfo->uservisible) {
        throw new moodle_exception('nopermissions', 'error', '', get_string('aitutor', 'local_jupiter_ai'));
    }
}

$PAGE->set_context($context);
$PAGE->set_course($course);
$PAGE->set_url(new moodle_url('/local/jupiter_ai/tutor.php', ['courseid' => $courseid, 'cmid' => $cmid]));
$PAGE->set_title(get_string('aitutor', 'local_jupiter_ai'));
$PAGE->set_heading(format_string($course->fullname));

$assessmentactive = \local_jupiter_ai\assessment_guard::has_active_assessment((int)$USER->id, $courseid);
$result = null;
$submittedquestion = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_sesskey();
    $submittedquestion = required_param('question', PARAM_RAW_TRIMMED);

    \local_jupiter_ai\rate_limiter::check();
    $policy = \local_jupiter_ai\policy_engine::classify($submittedquestion, $assessmentactive);
    \local_jupiter_ai\audit_logger::log((int)$USER->id, $courseid, $cmid, $submittedquestion, $policy);

    if ($policy['decision'] === \local_jupiter_ai\policy_engine::BLOCK ||
        $policy['decision'] === \local_jupiter_ai\policy_engine::COACH_ONLY) {
        $result = $policy;
    } else {
        $provider = new \local_jupiter_ai\provider\disabled_provider();
        $safecontext = \local_jupiter_ai\context_assembler::build((int)$USER->id, $courseid, $cmid);
        $safecontext['system'] = \local_jupiter_ai\coaching_engine::instructions($policy);
        $response = $provider->generate($safecontext, $submittedquestion, $policy);

        $result = [
            'decision' => 'foundation',
            'reasoncode' => 'provider_disabled',
            'message' => $response['text'],
        ];
    }
}

echo $OUTPUT->header();

echo html_writer::start_div('jupiter-ai-shell');
echo html_writer::start_div('jupiter-ai-header');
echo get_string('aitutor', 'local_jupiter_ai');
echo html_writer::tag('span', get_string('chatsubtitle', 'local_jupiter_ai'), ['class' => 'jupiter-ai-subtitle']);
echo html_writer::end_div();

echo html_writer::start_div('jupiter-ai-chat');

if (!$submittedquestion) {
    echo html_writer::start_div('jupiter-ai-row assistant');
    echo html_writer::div(get_string('chatwelcome', 'local_jupiter_ai'), 'jupiter-ai-bubble');
    echo html_writer::end_div();
}

if ($submittedquestion) {
    echo html_writer::start_div('jupiter-ai-row user');
    echo html_writer::div(s($submittedquestion), 'jupiter-ai-bubble');
    echo html_writer::end_div();

    echo html_writer::start_div('jupiter-ai-row assistant');
    echo html_writer::div(s($result['message'] ?? get_string('outputblocked', 'local_jupiter_ai')), 'jupiter-ai-bubble');
    echo html_writer::end_div();
}

if ($assessmentactive) {
    echo html_writer::start_div('jupiter-ai-row assistant');
    echo html_writer::div(get_string('assessmentlocked', 'local_jupiter_ai'), 'jupiter-ai-bubble');
    echo html_writer::end_div();
}

echo html_writer::end_div();

echo html_writer::div(get_string('transparencynoticeshort', 'local_jupiter_ai'), 'jupiter-ai-notice');

if (!$assessmentactive) {
    $action = new moodle_url('/local/jupiter_ai/tutor.php', ['courseid' => $courseid, 'cmid' => $cmid]);
    echo html_writer::start_div('jupiter-ai-composer');
    echo html_writer::start_tag('form', ['method' => 'post', 'action' => $action]);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
    echo html_writer::start_div('jupiter-ai-composer-inner');
    echo html_writer::tag('textarea', '', [
        'id' => 'jupiter-ai-question',
        'name' => 'question',
        'rows' => 2,
        'class' => 'form-control',
        'maxlength' => 3000,
        'required' => 'required',
        'placeholder' => get_string('chatplaceholder', 'local_jupiter_ai'),
        'aria-label' => get_string('asklabel', 'local_jupiter_ai'),
    ]);
    echo html_writer::tag('button', get_string('sendbutton', 'local_jupiter_ai'), [
        'type' => 'submit',
        'class' => 'btn btn-primary',
    ]);
    echo html_writer::end_div();
    echo html_writer::end_tag('form');
    echo html_writer::end_div();
}

echo html_writer::end_div();
echo $OUTPUT->footer();
