<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_jupiter_ai';
$plugin->version   = 2026090603;
$plugin->release   = '0.3.1';
$plugin->requires  = 2024042200;
$plugin->maturity  = MATURITY_ALPHA;
