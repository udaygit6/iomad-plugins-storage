Jupiter Iomad Integration v0.6.0

Adds WooCommerce My Courses and a short-lived signed SSO handoff to the companion Iomad local_jupiter_sso plugin. Existing v0.5.4 provisioning remains intact.

Security: SSO access is allowed only for logged-in WordPress customers with a paid, successfully provisioned mapped order item. The browser receives no Iomad REST token or LMS password.
