Jupiter Iomad Integration 1.5.1
Notification menu parent-detection hotfix.

Problem:
v1.5.0 required jupiter_account_type=parent_guardian before displaying Notifications.
A user could already have an active verified family relationship and therefore correctly
see My Children, while the Notifications menu remained hidden.

Fix:
Notifications now authorizes parent access from the authoritative active
jupiter_family_relationships record, matching the family portal security model.
The endpoint itself performs the same server-side relationship check.

No Iomad changes.
Certificate v1.4.1 security flow remains unchanged.
No database schema change.
