Jupiter Iomad Integration 1.6.0
Parent event notification delivery.

- Course completion email when a newly observed linked learner completion appears.
- Certificate earned email when a newly observed issued certificate appears.
- Respects each parent's v1.5 notification preferences.
- First scan creates a baseline only: historical achievements do NOT generate emails.
- Event-specific idempotency keys prevent duplicate successful notifications.
- Uses existing WordPress wp_mail path (therefore existing WP Mail SMTP/Zoho configuration).
- Detailed learner data remains in authenticated Parent Dashboard; email is deliberately minimal.
- 15-minute WP-Cron scan against the already-authorised Iomad parent summary.
- My Children now appears before Notifications in the parent menu.
- Learning reminder and weekly summary remain preference-only for the next scheduled-notification stage.
- No Iomad plugin update and no database schema migration.
