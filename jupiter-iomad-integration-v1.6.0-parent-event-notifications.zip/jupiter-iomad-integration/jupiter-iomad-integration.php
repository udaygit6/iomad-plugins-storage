<?php
/**
 * Plugin Name: Jupiter Iomad Integration
 * Description: Maps WooCommerce products to Iomad and imports Iomad courses as WooCommerce draft products.
 * Version: 1.6.0
 * Author: Jupiter The Scholar
 */
if (!defined('ABSPATH')) exit;

define('JUPITER_IOMAD_VERSION','1.6.0');



/**
 * Header basket icon with live WooCommerce item-count badge.
 * Usage in an Astra HTML header element: [jupiter_cart_icon]
 */
function jupiter_iomad_cart_icon_markup(){
    if(!function_exists('wc_get_cart_url')) return '';

    $count=0;
    if(function_exists('WC') && WC() && WC()->cart){
        $count=(int)WC()->cart->get_cart_contents_count();
    }

    $display_count=$count>99?'99+':(string)$count;
    $badge_class=$count>0?'jupiter-cart-count':'jupiter-cart-count is-empty';

    return '<a class="jupiter-cart-live" href="'.esc_url(wc_get_cart_url()).'" aria-label="'.esc_attr(sprintf(_n('View basket, %d item','View basket, %d items',$count,'jupiter-iomad'),$count)).'">'
        .'<span class="jupiter-cart-icon-glyph" aria-hidden="true">🛒</span>'
        .'<span class="'.esc_attr($badge_class).'">'.esc_html($display_count).'</span>'
        .'</a>';
}

add_shortcode('jupiter_cart_icon','jupiter_iomad_cart_icon_markup');


/** Jupiter wording for the empty WooCommerce basket button. */
add_filter('woocommerce_return_to_shop_text', function($text){
    return 'Return to Courses';
});

/** Refresh the badge immediately after WooCommerce AJAX add/remove operations. */
add_filter('woocommerce_add_to_cart_fragments',function($fragments){
    $fragments['a.jupiter-cart-live']=jupiter_iomad_cart_icon_markup();
    return $fragments;
});

/** Keep the badge compact and overlaid on the cart, Amazon-style. */
add_action('wp_head',function(){
    if(is_admin()) return;
    ?>
    <style id="jupiter-cart-badge-css">
      .jupiter-cart-live{
        position:relative;
        display:inline-flex;
        align-items:center;
        justify-content:center;
        text-decoration:none!important;
        line-height:1;
        overflow:visible;
      }
      .jupiter-cart-icon-glyph{font-size:28px;line-height:1;display:block;}
      .jupiter-cart-count{
        position:absolute;
        top:-7px;
        right:-8px;
        min-width:16px;
        height:16px;
        padding:0 4px;
        box-sizing:border-box;
        border-radius:999px;
        background:#E9A72F;
        color:#10233F;
        font-size:10px;
        font-weight:700;
        line-height:16px;
        text-align:center;
        pointer-events:none;
        z-index:2;
      }
      .jupiter-cart-count.is-empty{display:none;}
      @media (max-width:921px){
        .jupiter-cart-icon-glyph{font-size:24px;}
        .jupiter-cart-count{top:-6px;right:-7px;min-width:15px;height:15px;line-height:15px;font-size:9px;}
      }
    </style>
    <?php
});

function jupiter_iomad_get_settings(){
    return [
        'url'=>trim((string)get_option('jupiter_iomad_rest_url','')),
        'token'=>trim((string)get_option('jupiter_iomad_token','')),
        'core_token'=>trim((string)get_option('jupiter_iomad_core_token','')),
    ];
}

function jupiter_iomad_api_post($function,array $params=[]){
    $s=jupiter_iomad_get_settings();
    if(!$s['url']||!$s['token']) return new WP_Error('missing_settings','Configure the Iomad REST URL and token under WooCommerce → Jupiter Iomad.');
    $body=array_merge([
        'wstoken'=>$s['token'],
        'wsfunction'=>$function,
        'moodlewsrestformat'=>'json',
    ],$params);
    $r=wp_remote_post($s['url'],[
        'timeout'=>apply_filters('jupiter_iomad_api_timeout',45,$function),
        'redirection'=>2,
        'sslverify'=>true,
        'body'=>$body,
    ]);
    if(is_wp_error($r)){
        $msg=$r->get_error_message();
        if(stripos($msg,'timed out')!==false || stripos($msg,'cURL error 28')!==false){
            return new WP_Error('iomad_timeout','Iomad request timed out while waiting for a response. Iomad may still have processed the request; this item is safe to retry.');
        }
        return $r;
    }
    $status=wp_remote_retrieve_response_code($r);
    $data=json_decode(wp_remote_retrieve_body($r),true);
    if($status<200||$status>=300) return new WP_Error('http_error','Iomad returned HTTP '.$status.'.');
    if(json_last_error()!==JSON_ERROR_NONE) return new WP_Error('bad_json','Iomad returned an unreadable response.');
    if(is_array($data) && !empty($data['exception'])) return new WP_Error('api_error','Iomad error: '.(!empty($data['message'])?$data['message']:$data['exception']));
    return $data;
}

function jupiter_iomad_core_api_post($function,array $params=[]){
    $s=jupiter_iomad_get_settings();
    if(!$s['url']||!$s['core_token']) return new WP_Error('missing_core_settings','Configure the Iomad REST URL and Jupiter Core Integration token under WooCommerce → Jupiter Iomad.');
    $body=array_merge([
        'wstoken'=>$s['core_token'],
        'wsfunction'=>$function,
        'moodlewsrestformat'=>'json',
    ],$params);
    $r=wp_remote_post($s['url'],[
        'timeout'=>apply_filters('jupiter_iomad_api_timeout',45,$function),
        'redirection'=>2,
        'sslverify'=>true,
        'body'=>$body,
    ]);
    if(is_wp_error($r)){
        $msg=$r->get_error_message();
        if(stripos($msg,'timed out')!==false || stripos($msg,'cURL error 28')!==false){
            return new WP_Error('iomad_timeout','Iomad request timed out while waiting for a response. Iomad may still have processed the request; this item is safe to retry.');
        }
        return $r;
    }
    $status=wp_remote_retrieve_response_code($r);
    $data=json_decode(wp_remote_retrieve_body($r),true);
    if($status<200||$status>=300) return new WP_Error('http_error','Iomad returned HTTP '.$status.'.');
    if(json_last_error()!==JSON_ERROR_NONE) return new WP_Error('bad_json','Iomad returned an unreadable response.');
    if(is_array($data) && !empty($data['exception'])) return new WP_Error('api_error','Iomad error: '.(!empty($data['message'])?$data['message']:$data['exception']));
    return $data;
}

function jupiter_iomad_find_product($company_id,$course_id){
    $ids=get_posts([
        'post_type'=>'product',
        'post_status'=>['publish','draft','pending','private'],
        'posts_per_page'=>1,
        'fields'=>'ids',
        'meta_query'=>[
            'relation'=>'AND',
            ['key'=>'_jupiter_iomad_company_id','value'=>absint($company_id),'compare'=>'=','type'=>'NUMERIC'],
            ['key'=>'_jupiter_iomad_course_id','value'=>absint($course_id),'compare'=>'=','type'=>'NUMERIC'],
        ],
    ]);
    return !empty($ids)?absint($ids[0]):0;
}

add_action('woocommerce_product_options_general_product_data',function(){
    global $post;
    echo '<div class="options_group">';
    woocommerce_wp_text_input([
        'id'=>'_jupiter_iomad_company_id','label'=>'Iomad Company ID','desc_tip'=>true,
        'description'=>'Iomad company ID mapped to this WooCommerce product.','type'=>'number',
        'custom_attributes'=>['min'=>'1','step'=>'1'],
    ]);
    woocommerce_wp_text_input([
        'id'=>'_jupiter_iomad_course_id','label'=>'Iomad Course ID','desc_tip'=>true,
        'description'=>'Iomad course ID mapped to this WooCommerce product.','type'=>'number',
        'custom_attributes'=>['min'=>'1','step'=>'1'],
    ]);
    if($post&&$post->ID){
        echo '<p class="form-field"><label>Verify mapping</label>';
        echo '<button type="button" class="button" id="jupiter-iomad-verify" data-product-id="'.esc_attr($post->ID).'">Verify Iomad Mapping</button>';
        echo '<span id="jupiter-iomad-verify-result" style="margin-left:10px;"></span></p>';
    }
    echo '</div>';
});

add_action('woocommerce_process_product_meta',function($post_id){
    if(!current_user_can('edit_post',$post_id)) return;
    $company_id=isset($_POST['_jupiter_iomad_company_id'])?absint(wp_unslash($_POST['_jupiter_iomad_company_id'])):0;
    $course_id=isset($_POST['_jupiter_iomad_course_id'])?absint(wp_unslash($_POST['_jupiter_iomad_course_id'])):0;
    $company_id?update_post_meta($post_id,'_jupiter_iomad_company_id',$company_id):delete_post_meta($post_id,'_jupiter_iomad_company_id');
    $course_id?update_post_meta($post_id,'_jupiter_iomad_course_id',$course_id):delete_post_meta($post_id,'_jupiter_iomad_course_id');
});

add_action('admin_menu',function(){
    add_submenu_page('woocommerce','Jupiter Iomad','Jupiter Iomad','manage_woocommerce','jupiter-iomad','jupiter_iomad_render_admin_page');
});

add_action('admin_init',function(){
    register_setting('jupiter_iomad_settings','jupiter_iomad_rest_url',['type'=>'string','sanitize_callback'=>'esc_url_raw','default'=>'']);
    register_setting('jupiter_iomad_settings','jupiter_iomad_token',['type'=>'string','sanitize_callback'=>'sanitize_text_field','default'=>'']);
    register_setting('jupiter_iomad_settings','jupiter_iomad_core_token',['type'=>'string','sanitize_callback'=>'sanitize_text_field','default'=>'']);
    register_setting('jupiter_iomad_settings','jupiter_iomad_live_provisioning',['type'=>'string','sanitize_callback'=>function($v){return $v==='1'?'1':'0';},'default'=>'0']);
    register_setting('jupiter_iomad_settings','jupiter_iomad_sso_secret',['type'=>'string','sanitize_callback'=>'sanitize_text_field','default'=>'']);
    register_setting('jupiter_iomad_settings','jupiter_iomad_sso_base_url',['type'=>'string','sanitize_callback'=>'esc_url_raw','default'=>'']);
});

function jupiter_iomad_render_admin_page(){
    if(!current_user_can('manage_woocommerce')) return;
    $url=get_option('jupiter_iomad_rest_url','');
    $token=get_option('jupiter_iomad_token','');
    $core_token=get_option('jupiter_iomad_core_token','');
    $live_provisioning=get_option('jupiter_iomad_live_provisioning','0')==='1';
    $sso_secret=(string)get_option('jupiter_iomad_sso_secret','');
    $sso_base_url=(string)get_option('jupiter_iomad_sso_base_url','');
    if(!$sso_base_url && $url){$sso_base_url=preg_replace('~/webservice/rest/server\.php/?$~','',rtrim($url,'/'));}
    ?>
    <div class="wrap">
      <h1>Jupiter Iomad Integration</h1>
      <h2>Connection</h2>
      <form method="post" action="options.php">
        <?php settings_fields('jupiter_iomad_settings'); ?>
        <table class="form-table" role="presentation">
          <tr><th><label for="jupiter_iomad_rest_url">Iomad REST URL</label></th><td><input type="url" class="regular-text code" id="jupiter_iomad_rest_url" name="jupiter_iomad_rest_url" value="<?php echo esc_attr($url); ?>" placeholder="https://iomad.example.com/webservice/rest/server.php"></td></tr>
          <tr><th><label for="jupiter_iomad_token">Iomadservice token</label></th><td><input type="password" class="regular-text" id="jupiter_iomad_token" name="jupiter_iomad_token" value="<?php echo esc_attr($token); ?>" autocomplete="new-password"><p class="description">TOKEN: IOMADSERVICE. Used for company/course allocation and enrolment APIs. Keep private.</p></td></tr>
          <tr><th><label for="jupiter_iomad_core_token">Jupiter Core Integration token</label></th><td><input type="password" class="regular-text" id="jupiter_iomad_core_token" name="jupiter_iomad_core_token" value="<?php echo esc_attr($core_token); ?>" autocomplete="new-password"><p class="description">TOKEN: JUPITER CORE INTEGRATION. Used for learner lookup/create APIs. Keep private.</p></td></tr>
          <tr><th><label for="jupiter_iomad_live_provisioning">Live provisioning</label></th><td><label><input type="checkbox" id="jupiter_iomad_live_provisioning" name="jupiter_iomad_live_provisioning" value="1" <?php checked($live_provisioning); ?>> Enable Iomad learner creation, company assignment and course enrolment for paid mapped orders</label><p class="description">Dry-run remains available while this is off. v0.5.3 keeps timeout reconciliation and adds a live WooCommerce basket badge for the site header.</p></td></tr>
          <tr><th><label for="jupiter_iomad_sso_base_url">Iomad SSO Base URL</label></th><td><input type="url" class="regular-text code" id="jupiter_iomad_sso_base_url" name="jupiter_iomad_sso_base_url" value="<?php echo esc_attr($sso_base_url); ?>" placeholder="https://iomad.jupiterthescholar.com"><p class="description">Base HTTPS URL used by the learner Access Course button. If blank, it is inferred from the REST URL.</p></td></tr>
          <tr><th><label for="jupiter_iomad_sso_secret">SSO shared secret</label></th><td><input type="password" class="regular-text code" id="jupiter_iomad_sso_secret" name="jupiter_iomad_sso_secret" value="<?php echo esc_attr($sso_secret); ?>" autocomplete="new-password"> <button type="button" class="button" id="jupiter-iomad-generate-sso-secret">Generate secure secret</button><p class="description">Must match the secret configured in Iomad → Jupiter SSO. Keep private. Generate once, save here, then copy the same value into Iomad.</p></td></tr>
        </table>
        <?php submit_button('Save Connection'); ?>
      </form>
      <hr>
      <h2>Paid Order Provisioning</h2>
      <p><strong>Version 0.5.3 contains the hardened live provisioning workflow plus the live basket badge.</strong> Live provisioning is <strong><?php echo $live_provisioning?'ENABLED':'DISABLED'; ?></strong>. When disabled, paid orders run the existing read-only dry run.</p>
      <p>When enabled, a paid mapped order will find/create the learner, assign the learner to the mapped Iomad company, enrol the learner into the mapped course as Student role ID 5, and record item-level idempotency metadata plus order notes. Already-provisioned items are skipped before any remote user lookup. Timeout/uncertain enrolment responses are marked retry-pending. On retry, v0.5.3 first checks the learner's current Iomad courses and marks the item reconciled-success when the enrolment already happened, avoiding a blind duplicate enrolment call.</p>
      <hr>
      <h2>Import Iomad Courses</h2>
      <p>Enter an Iomad Company ID, load its allocated courses, then create a WooCommerce <strong>Draft</strong> product.</p>
      <table class="form-table" role="presentation"><tr><th><label for="jupiter-iomad-import-company">Iomad Company ID</label></th><td><input type="number" min="1" step="1" id="jupiter-iomad-import-company" value="4"> <button type="button" class="button button-secondary" id="jupiter-iomad-load-courses">Load Courses</button> <span id="jupiter-iomad-load-status" style="margin-left:10px;"></span></td></tr></table>
      <div id="jupiter-iomad-course-results"></div>
    </div>
    <?php
}

add_action('admin_footer',function(){
    $screen=get_current_screen(); if(!$screen) return;
    $nonce=wp_create_nonce('jupiter_iomad_admin');
    if($screen->post_type==='product'){ ?>
    <script>
    jQuery(function($){
      $('#jupiter-iomad-verify').on('click',function(){
        const $b=$(this),$r=$('#jupiter-iomad-verify-result');
        const companyId=parseInt($('#_jupiter_iomad_company_id').val(),10)||0;
        const courseId=parseInt($('#_jupiter_iomad_course_id').val(),10)||0;
        if(!companyId||!courseId){$r.html('<strong style="color:#b32d2e;">✗ Enter both Company ID and Course ID.</strong>');return;}
        $b.prop('disabled',true);$r.text('Checking Iomad...');
        $.post(ajaxurl,{action:'jupiter_iomad_verify_mapping',nonce:'<?php echo esc_js($nonce); ?>',product_id:$b.data('product-id'),company_id:companyId,course_id:courseId})
        .done(function(resp){if(resp.success){$r.html('<strong style="color:#1d7f35;">✓ '+$('<div>').text(resp.data.message).html()+'</strong>');}else{$r.html('<strong style="color:#b32d2e;">✗ '+$('<div>').text(resp.data.message||'Verification failed.').html()+'</strong>');}})
        .fail(function(){$r.html('<strong style="color:#b32d2e;">✗ Request failed.</strong>');})
        .always(function(){$b.prop('disabled',false);});
      });
      $('#_jupiter_iomad_company_id,#_jupiter_iomad_course_id').on('input change',function(){$('#jupiter-iomad-verify-result').empty();});
    });
    </script><?php }
    if($screen->id==='woocommerce_page_jupiter-iomad'){ ?>
    <script>
    jQuery(function($){
      const nonce='<?php echo esc_js($nonce); ?>';
      $('#jupiter-iomad-generate-sso-secret').on('click',function(){
        const bytes=new Uint8Array(48);window.crypto.getRandomValues(bytes);
        const secret=Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
        $('#jupiter_iomad_sso_secret').attr('type','text').val(secret).trigger('change').focus().select();
        alert('Secure SSO secret generated. Save Connection, then copy the same secret into the Iomad Jupiter SSO settings.');
      });
      $('#jupiter-iomad-load-courses').on('click',function(){
        const companyId=parseInt($('#jupiter-iomad-import-company').val(),10)||0;
        const $s=$('#jupiter-iomad-load-status'),$r=$('#jupiter-iomad-course-results');
        if(!companyId){$s.html('<strong style="color:#b32d2e;">Enter a valid Company ID.</strong>');return;}
        $s.text('Loading...');$r.empty();
        $.post(ajaxurl,{action:'jupiter_iomad_load_courses',nonce:nonce,company_id:companyId}).done(function(resp){
          if(!resp.success){$s.html('<strong style="color:#b32d2e;">✗ '+$('<div>').text(resp.data.message||'Could not load courses.').html()+'</strong>');return;}
          $s.html('<strong style="color:#1d7f35;">✓ '+$('<div>').text(resp.data.company_name).html()+'</strong>');
          let h='<table class="widefat striped" style="max-width:900px;margin-top:15px;"><thead><tr><th>Course ID</th><th>Course</th><th>WooCommerce</th><th>Action</th></tr></thead><tbody>';
          resp.data.courses.forEach(function(c){
            h+='<tr><td>'+c.id+'</td><td>'+$('<div>').text(c.fullname).html()+'</td>';
            if(c.product_id){h+='<td>Mapped to Product #'+c.product_id+'</td><td><a class="button" href="'+c.edit_url+'">Edit Product</a></td>';}
            else{h+='<td>Not created</td><td><button type="button" class="button button-primary jupiter-create-product" data-company="'+resp.data.company_id+'" data-course="'+c.id+'">Create Draft Product</button></td>';}
            h+='</tr>';
          });
          h+='</tbody></table>';$r.html(h);
        }).fail(function(){$s.html('<strong style="color:#b32d2e;">✗ Request failed.</strong>');});
      });
      $(document).on('click','.jupiter-create-product',function(){
        const $b=$(this);$b.prop('disabled',true).text('Creating...');
        $.post(ajaxurl,{action:'jupiter_iomad_create_product',nonce:nonce,company_id:$b.data('company'),course_id:$b.data('course')}).done(function(resp){
          if(resp.success){$b.replaceWith('<a class="button button-primary" href="'+resp.data.edit_url+'">Edit Draft Product</a>');}
          else{alert(resp.data.message||'Could not create product.');$b.prop('disabled',false).text('Create Draft Product');}
        }).fail(function(){alert('Request failed.');$b.prop('disabled',false).text('Create Draft Product');});
      });
    });
    </script><?php }
});

add_action('wp_ajax_jupiter_iomad_verify_mapping',function(){
    check_ajax_referer('jupiter_iomad_admin','nonce');
    if(!current_user_can('manage_woocommerce')) wp_send_json_error(['message'=>'You do not have permission to verify this mapping.'],403);
    $product_id=absint($_POST['product_id']??0);$company_id=absint($_POST['company_id']??0);$course_id=absint($_POST['course_id']??0);
    if(!$product_id||get_post_type($product_id)!=='product') wp_send_json_error(['message'=>'Invalid WooCommerce product.']);
    if(!$company_id||!$course_id) wp_send_json_error(['message'=>'Enter both Iomad Company ID and Course ID.']);
    $data=jupiter_iomad_api_post('block_iomad_company_admin_get_company_courses',['criteria'=>[['companyid'=>$company_id,'shared'=>0]]]);
    if(is_wp_error($data)) wp_send_json_error(['message'=>$data->get_error_message()]);
    foreach(($data['companies']??[]) as $company){
        if(absint($company['id']??0)!==$company_id) continue;
        $company_name=sanitize_text_field($company['name']??('Company '.$company_id));
        foreach(($company['courses']??[]) as $course){
            if(absint($course['id']??0)===$course_id){
                $course_name=sanitize_text_field($course['fullname']??('Course '.$course_id));
                wp_send_json_success(['message'=>'Connected — '.$company_name.' → '.$course_name]);
            }
        }
        wp_send_json_error(['message'=>'Connected to '.$company_name.', but Course ID '.$course_id.' is not allocated to this company.']);
    }
    wp_send_json_error(['message'=>'Company ID '.$company_id.' was not found in Iomad.']);
});

add_action('wp_ajax_jupiter_iomad_load_courses',function(){
    check_ajax_referer('jupiter_iomad_admin','nonce');
    if(!current_user_can('manage_woocommerce')) wp_send_json_error(['message'=>'You do not have permission to load Iomad courses.'],403);
    $company_id=absint($_POST['company_id']??0); if(!$company_id) wp_send_json_error(['message'=>'Enter a valid Company ID.']);
    $data=jupiter_iomad_api_post('block_iomad_company_admin_get_company_courses',['criteria'=>[['companyid'=>$company_id,'shared'=>0]]]);
    if(is_wp_error($data)) wp_send_json_error(['message'=>$data->get_error_message()]);
    foreach(($data['companies']??[]) as $company){
        if(absint($company['id']??0)!==$company_id) continue;
        $out=[];
        foreach(($company['courses']??[]) as $course){
            $course_id=absint($course['id']??0);if(!$course_id) continue;
            $product_id=jupiter_iomad_find_product($company_id,$course_id);
            $out[]=[
                'id'=>$course_id,
                'fullname'=>sanitize_text_field($course['fullname']??('Course '.$course_id)),
                'product_id'=>$product_id,
                'edit_url'=>$product_id?get_edit_post_link($product_id,'raw'):'',
            ];
        }
        wp_send_json_success(['company_id'=>$company_id,'company_name'=>sanitize_text_field($company['name']??('Company '.$company_id)),'courses'=>$out]);
    }
    wp_send_json_error(['message'=>'Company ID '.$company_id.' was not found in Iomad.']);
});

add_action('wp_ajax_jupiter_iomad_create_product',function(){
    check_ajax_referer('jupiter_iomad_admin','nonce');
    if(!current_user_can('manage_woocommerce')) wp_send_json_error(['message'=>'You do not have permission to create WooCommerce products.'],403);
    $company_id=absint($_POST['company_id']??0);$course_id=absint($_POST['course_id']??0);
    if(!$company_id||!$course_id) wp_send_json_error(['message'=>'Invalid company or course ID.']);
    $existing=jupiter_iomad_find_product($company_id,$course_id);
    if($existing) wp_send_json_success(['product_id'=>$existing,'edit_url'=>get_edit_post_link($existing,'raw'),'existing'=>true]);

    $data=jupiter_iomad_api_post('block_iomad_company_admin_get_company_courses',['criteria'=>[['companyid'=>$company_id,'shared'=>0]]]);
    if(is_wp_error($data)) wp_send_json_error(['message'=>$data->get_error_message()]);
    $course_name='';
    foreach(($data['companies']??[]) as $company){
        if(absint($company['id']??0)!==$company_id) continue;
        foreach(($company['courses']??[]) as $course){
            if(absint($course['id']??0)===$course_id){$course_name=sanitize_text_field($course['fullname']??'');break 2;}
        }
    }
    if(!$course_name) wp_send_json_error(['message'=>'The selected Iomad course is not allocated to this company.']);
    if(!class_exists('WC_Product_Simple')) wp_send_json_error(['message'=>'WooCommerce is not available.']);
    try{
        $p=new WC_Product_Simple();
        $p->set_name($course_name);
        $p->set_status('draft');
        $p->set_virtual(true);
        $p->set_catalog_visibility('visible');
        $product_id=$p->save();
        if(!$product_id) wp_send_json_error(['message'=>'WooCommerce could not create the draft product.']);
        update_post_meta($product_id,'_jupiter_iomad_company_id',$company_id);
        update_post_meta($product_id,'_jupiter_iomad_course_id',$course_id);
        update_post_meta($product_id,'_jupiter_iomad_imported',1);
        wp_send_json_success(['product_id'=>$product_id,'edit_url'=>get_edit_post_link($product_id,'raw'),'existing'=>false]);
    }catch(Throwable $e){
        wp_send_json_error(['message'=>'Could not create product: '.$e->getMessage()]);
    }
});


/**
 * v0.4.2 dry-run paid order handler.
 *
 * Safe/read-only LMS behaviour:
 * - detects Iomad-mapped WooCommerce products
 * - looks up the buyer by email using Jupiter Core Integration
 * - writes diagnostic order notes/meta
 * - NEVER creates users, assigns companies, or enrols courses
 *
 * $force=true is used only by the explicit admin order action so an
 * administrator can re-run diagnostics without changing order status.
 */
function jupiter_iomad_paid_order_dry_run($order_id,$force=false){
    if(!function_exists('wc_get_order')) return;
    $order=wc_get_order($order_id);
    if(!$order) return;

    // Automatic events are idempotent. The explicit admin action may re-run it.
    if(!$force && $order->get_meta('_jupiter_iomad_dry_run_v042_done',true)) return;

    $email=sanitize_email($order->get_billing_email());
    $first=sanitize_text_field($order->get_billing_first_name());
    $last=sanitize_text_field($order->get_billing_last_name());
    $wp_user_id=absint($order->get_user_id());

    // Write an immediate breadcrumb before any remote API call so failures are visible.
    $order->add_order_note('[Jupiter Iomad] DRY RUN started for Order #'.$order->get_id().'. No LMS write actions will be performed.');
    $order->save();

    $mapped=[];
    foreach($order->get_items('line_item') as $item_id=>$item){
        $product=$item->get_product();
        if(!$product) continue;
        $product_id=absint($product->get_id());
        $company_id=absint(get_post_meta($product_id,'_jupiter_iomad_company_id',true));
        $course_id=absint(get_post_meta($product_id,'_jupiter_iomad_course_id',true));
        if(!$company_id||!$course_id) continue;
        $mapped[]=[
            'item_id'=>absint($item_id),
            'product_id'=>$product_id,
            'product_name'=>sanitize_text_field($item->get_name()),
            'company_id'=>$company_id,
            'course_id'=>$course_id,
        ];
    }

    if(empty($mapped)){
        $order->add_order_note('[Jupiter Iomad] DRY RUN finished: no Iomad-mapped course products were found. No LMS action required.');
        $order->update_meta_data('_jupiter_iomad_dry_run_v042_done',gmdate('c'));
        $order->update_meta_data('_jupiter_iomad_dry_run_v042_result','no_mapped_products');
        $order->save();
        return;
    }

    $lookup_status='not_run';
    $iomad_user_id=0;
    $lookup_message='';
    if($email){
        $lookup=jupiter_iomad_core_api_post('core_user_get_users_by_field',[
            'field'=>'email',
            'values'=>[$email],
        ]);
        if(is_wp_error($lookup)){
            $lookup_status='error';
            $lookup_message=$lookup->get_error_message();
        }elseif(!empty($lookup[0]['id'])){
            $lookup_status='found';
            $iomad_user_id=absint($lookup[0]['id']);
            $lookup_message='Existing Iomad user found.';
        }else{
            $lookup_status='not_found';
            $lookup_message='No Iomad user found for this email; production provisioning would create one.';
        }
    }else{
        $lookup_status='missing_email';
        $lookup_message='Order has no billing email; provisioning would be blocked.';
    }

    $summary=[];
    foreach($mapped as $m){
        $summary[]='Product #'.$m['product_id'].' → Company '.$m['company_id'].' / Course '.$m['course_id'];
    }

    $buyer=trim($first.' '.$last);
    $note='[Jupiter Iomad] DRY RUN result — Buyer: '.($buyer!==''?$buyer:'(no name)').' <'.($email!==''?$email:'no email').'>';
    if($wp_user_id) $note.=' | WP User #'.$wp_user_id;
    $note.=' | '.implode('; ',$summary);
    $note.=' | Learner lookup: '.$lookup_status;
    if($iomad_user_id) $note.=' (Iomad User #'.$iomad_user_id.')';
    if($lookup_message) $note.=' — '.$lookup_message;
    $note.=' No Iomad create/assign/enrol actions were executed.';
    $order->add_order_note($note);

    $order->update_meta_data('_jupiter_iomad_dry_run_v042_done',gmdate('c'));
    $order->update_meta_data('_jupiter_iomad_dry_run_v042_result',$lookup_status);
    $order->update_meta_data('_jupiter_iomad_dry_run_v042_email',$email);
    $order->update_meta_data('_jupiter_iomad_dry_run_v042_iomad_user_id',$iomad_user_id);
    $order->update_meta_data('_jupiter_iomad_dry_run_v042_mappings',wp_json_encode($mapped));
    $order->save();
}

/**
 * Return the Iomad learner for an exact email, or 0 when not found.
 */
function jupiter_iomad_lookup_user_by_email($email){
    $email=sanitize_email($email);
    if(!$email) return new WP_Error('missing_email','A valid billing email is required for Iomad provisioning.');
    $lookup=jupiter_iomad_core_api_post('core_user_get_users_by_field',[
        'field'=>'email',
        'values'=>[$email],
    ]);
    if(is_wp_error($lookup)) return $lookup;
    if(is_array($lookup) && !empty($lookup[0]['id'])) return absint($lookup[0]['id']);
    return 0;
}

/**
 * Create a learner using WooCommerce billing identity.
 * createpassword=1 lets Moodle/Iomad create the password instead of WordPress
 * storing or generating an LMS password.
 */
function jupiter_iomad_create_learner($order){
    $email=sanitize_email($order->get_billing_email());
    $first=sanitize_text_field($order->get_billing_first_name());
    $last=sanitize_text_field($order->get_billing_last_name());
    if(!$email) return new WP_Error('missing_email','A valid billing email is required to create an Iomad learner.');
    if($first==='') $first='Jupiter';
    if($last==='') $last='Learner';

    // Stable, lowercase and collision-resistant username. Email remains the identity key.
    $username='jts_'.substr(hash('sha256',strtolower($email)),0,20);
    $created=jupiter_iomad_core_api_post('core_user_create_users',[
        'users'=>[0=>[
            'createpassword'=>1,
            'username'=>$username,
            'auth'=>'manual',
            'firstname'=>$first,
            'lastname'=>$last,
            'email'=>$email,
        ]],
    ]);
    if(is_wp_error($created)){
        // A concurrent/retried request may have created the same email first.
        $retry=jupiter_iomad_lookup_user_by_email($email);
        if(!is_wp_error($retry) && $retry) return $retry;
        return $created;
    }
    if(is_array($created) && !empty($created[0]['id'])) return absint($created[0]['id']);
    return new WP_Error('create_failed','Iomad did not return the new learner ID.');
}

function jupiter_iomad_assign_user_to_company($user_id,$company_id){
    $data=jupiter_iomad_api_post('block_iomad_company_admin_assign_users',[
        'users'=>[0=>[
            'userid'=>absint($user_id),
            'companyid'=>absint($company_id),
            'departmentid'=>0,
            'managertype'=>0,
            'educator'=>0,
        ]],
    ]);
    if(is_wp_error($data)) return $data;
    if(is_array($data) && isset($data['users'][0]['result'])){
        if($data['users'][0]['result']) return true;
        $msg=sanitize_text_field($data['users'][0]['message']??'Iomad company assignment failed.');
        // Iomad may report an already-present membership on a retry/second purchase.
        if(stripos($msg,'already')!==false) return true;
        return new WP_Error('company_assign_failed',$msg?:'Iomad company assignment failed.');
    }
    return new WP_Error('company_assign_bad_response','Iomad returned an unexpected company-assignment response.');
}

/**
 * Check whether a learner is already actively enrolled in a Moodle/Iomad course.
 * Requires core_enrol_get_users_courses on the Jupiter Core Integration service.
 * This is used only to reconcile an earlier uncertain/timeout enrolment result.
 */
function jupiter_iomad_is_user_enrolled_in_course($user_id,$course_id){
    $courses=jupiter_iomad_core_api_post('core_enrol_get_users_courses',[
        'userid'=>absint($user_id),
        'returnusercount'=>0,
    ]);
    if(is_wp_error($courses)) return $courses;
    if(!is_array($courses)) return new WP_Error('enrol_check_bad_response','Iomad returned an unexpected course-enrolment lookup response.');
    foreach($courses as $course){
        if(absint($course['id']??0)===absint($course_id)) return true;
    }
    return false;
}

function jupiter_iomad_enrol_user_in_course($user_id,$course_id){
    $data=jupiter_iomad_api_post('block_iomad_company_admin_enrol_users',[
        'enrolments'=>[0=>[
            'roleid'=>5,
            'userid'=>absint($user_id),
            'courseid'=>absint($course_id),
        ]],
    ]);
    if(is_wp_error($data)) return $data;
    // The proven Iomad endpoint returns JSON true on success. Be tolerant of
    // equivalent success wrappers without treating an explicit false as success.
    if($data===true) return true;
    if(is_array($data)){
        if(isset($data['result'])) return $data['result']?true:new WP_Error('enrol_failed',sanitize_text_field($data['message']??'Iomad enrolment failed.'));
        if(isset($data[0]['result'])) return $data[0]['result']?true:new WP_Error('enrol_failed',sanitize_text_field($data[0]['message']??'Iomad enrolment failed.'));
    }
    return new WP_Error('enrol_bad_response','Iomad returned an unexpected enrolment response.');
}

/**
 * Live paid-order provisioning with item-level idempotency.
 * An item is marked provisioned only after lookup/create + company assignment + enrolment all succeed.
 */
function jupiter_iomad_provision_paid_order($order_id,$force=false){
    if(!function_exists('wc_get_order')) return;
    $order=wc_get_order($order_id);
    if(!$order) return;

    if(!$order->is_paid()){
        if($force){$order->add_order_note('[Jupiter Iomad] Provisioning blocked: Order #'.$order->get_id().' is not marked paid.');$order->save();}
        return;
    }

    // Build the mapped-item set first. This lets us skip a fully provisioned
    // order without making any remote Iomad calls at all.
    $mapped=[];
    foreach($order->get_items('line_item') as $item_id=>$item){
        $product=$item->get_product(); if(!$product) continue;
        $product_id=absint($product->get_id());
        $company_id=absint(get_post_meta($product_id,'_jupiter_iomad_company_id',true));
        $course_id=absint(get_post_meta($product_id,'_jupiter_iomad_course_id',true));
        if(!$company_id||!$course_id) continue;
        $mapped[]=[
            'item_id'=>absint($item_id),
            'product_id'=>$product_id,
            'company_id'=>$company_id,
            'course_id'=>$course_id,
            'provisioned'=>(string)wc_get_order_item_meta($item_id,'_jupiter_iomad_provisioned',true),
            'user_id'=>absint(wc_get_order_item_meta($item_id,'_jupiter_iomad_user_id',true)),
            'state'=>(string)wc_get_order_item_meta($item_id,'_jupiter_iomad_provisioning_state',true),
        ];
    }

    if(empty($mapped)){
        $order->add_order_note('[Jupiter Iomad] No Iomad-mapped products were found. No LMS provisioning required.');
        $order->update_meta_data('_jupiter_iomad_provisioning_status','no_mapped_products');
        $order->save();
        return;
    }

    $pending=array_values(array_filter($mapped,function($m) use ($force){return $force || empty($m['provisioned']);}));
    if(empty($pending)){
        foreach($mapped as $m){
            $detail=$m['provisioned']?' at '.$m['provisioned']:'';
            $uid=$m['user_id']?' (Iomad User #'.$m['user_id'].')':'';
            $order->add_order_note('[Jupiter Iomad] SKIPPED — Product #'.$m['product_id'].' is already provisioned'.$detail.$uid.'. No LMS API calls were made.');
        }
        $order->update_meta_data('_jupiter_iomad_provisioning_status','already_provisioned');
        $order->save();
        return;
    }

    $email=sanitize_email($order->get_billing_email());
    if(!$email){$order->add_order_note('[Jupiter Iomad] Provisioning blocked: paid order has no valid billing email.');$order->save();return;}

    $order->add_order_note('[Jupiter Iomad] Provisioning started for paid Order #'.$order->get_id().'. Pending mapped item(s): '.count($pending).'.');
    $order->save();

    $iomad_user_id=jupiter_iomad_lookup_user_by_email($email);
    if(is_wp_error($iomad_user_id)){
        $state=$iomad_user_id->get_error_code()==='iomad_timeout'?'retry_pending':'failed_lookup';
        $order->add_order_note('[Jupiter Iomad] Provisioning '.($state==='retry_pending'?'paused for retry':'failed').' during learner lookup: '.$iomad_user_id->get_error_message());
        $order->update_meta_data('_jupiter_iomad_provisioning_status',$state);$order->save();return;
    }
    $created_now=false;
    if(!$iomad_user_id){
        $iomad_user_id=jupiter_iomad_create_learner($order);
        if(is_wp_error($iomad_user_id)){
            $state=$iomad_user_id->get_error_code()==='iomad_timeout'?'retry_pending':'failed_create';
            $order->add_order_note('[Jupiter Iomad] Provisioning '.($state==='retry_pending'?'paused for retry':'failed').' while creating learner: '.$iomad_user_id->get_error_message());
            $order->update_meta_data('_jupiter_iomad_provisioning_status',$state);$order->save();return;
        }
        $created_now=true;
        $order->add_order_note('[Jupiter Iomad] Learner created in Iomad as User #'.$iomad_user_id.' for '.$email.'.');
    }else{
        $order->add_order_note('[Jupiter Iomad] Existing Iomad learner found as User #'.$iomad_user_id.' for '.$email.'.');
    }

    $success_count=0;$failure_count=0;$retry_count=0;$skipped_count=0;
    foreach($mapped as $m){
        $item_id=$m['item_id'];$product_id=$m['product_id'];$company_id=$m['company_id'];$course_id=$m['course_id'];

        if(!$force && $m['provisioned']){
            $skipped_count++;
            continue;
        }

        // If a previous enrolment call timed out, do not blindly repeat it. First
        // reconcile against Iomad's current active course list for this learner.
        $previous_state=(string)wc_get_order_item_meta($item_id,'_jupiter_iomad_provisioning_state',true);
        if($previous_state==='retry_pending'){
            $already_enrolled=jupiter_iomad_is_user_enrolled_in_course($iomad_user_id,$course_id);
            if(is_wp_error($already_enrolled)){
                $retry_count++;
                wc_update_order_item_meta($item_id,'_jupiter_iomad_provisioning_state','retry_pending');
                wc_update_order_item_meta($item_id,'_jupiter_iomad_last_error',$already_enrolled->get_error_message());
                $order->add_order_note('[Jupiter Iomad] RECONCILIATION PENDING — Product #'.$product_id.' / Course '.$course_id.' could not be verified after the earlier timeout: '.$already_enrolled->get_error_message().' No repeat enrolment API call was made.');
                continue;
            }
            if($already_enrolled===true){
                $now=gmdate('c');
                wc_update_order_item_meta($item_id,'_jupiter_iomad_provisioned',$now);
                wc_update_order_item_meta($item_id,'_jupiter_iomad_user_id',$iomad_user_id);
                wc_update_order_item_meta($item_id,'_jupiter_iomad_company_id',$company_id);
                wc_update_order_item_meta($item_id,'_jupiter_iomad_course_id',$course_id);
                wc_update_order_item_meta($item_id,'_jupiter_iomad_provisioning_state','success');
                wc_update_order_item_meta($item_id,'_jupiter_iomad_reconciled_from_timeout',1);
                wc_delete_order_item_meta($item_id,'_jupiter_iomad_last_error');
                $success_count++;
                $order->add_order_note('[Jupiter Iomad] RECONCILED SUCCESS — Product #'.$product_id.' → Iomad User #'.$iomad_user_id.' is already enrolled in Course '.$course_id.'. Previous timeout had an uncertain response; no repeat enrolment API call was made.');
                continue;
            }
            $order->add_order_note('[Jupiter Iomad] RECONCILED — Product #'.$product_id.' is not currently enrolled in Course '.$course_id.'. A safe enrolment retry will now be attempted.');
        }

        $attempts=absint(wc_get_order_item_meta($item_id,'_jupiter_iomad_attempts',true))+1;
        wc_update_order_item_meta($item_id,'_jupiter_iomad_attempts',$attempts);
        wc_update_order_item_meta($item_id,'_jupiter_iomad_provisioning_state','processing');
        wc_update_order_item_meta($item_id,'_jupiter_iomad_last_attempt_at',gmdate('c'));

        $assigned=jupiter_iomad_assign_user_to_company($iomad_user_id,$company_id);
        if(is_wp_error($assigned)){
            $is_timeout=$assigned->get_error_code()==='iomad_timeout';
            $is_timeout?$retry_count++:$failure_count++;
            wc_update_order_item_meta($item_id,'_jupiter_iomad_provisioning_state',$is_timeout?'retry_pending':'failed');
            wc_update_order_item_meta($item_id,'_jupiter_iomad_last_error',$assigned->get_error_message());
            $order->add_order_note('[Jupiter Iomad] Product #'.$product_id.' '.($is_timeout?'company assignment response timed out; marked RETRY PENDING':'failed company assignment').' (Company '.$company_id.'): '.$assigned->get_error_message());
            continue;
        }

        $enrolled=jupiter_iomad_enrol_user_in_course($iomad_user_id,$course_id);
        if(is_wp_error($enrolled)){
            $is_timeout=$enrolled->get_error_code()==='iomad_timeout';
            $is_timeout?$retry_count++:$failure_count++;
            wc_update_order_item_meta($item_id,'_jupiter_iomad_provisioning_state',$is_timeout?'retry_pending':'failed');
            wc_update_order_item_meta($item_id,'_jupiter_iomad_last_error',$enrolled->get_error_message());
            $order->add_order_note('[Jupiter Iomad] Product #'.$product_id.' '.($is_timeout?'course enrolment response timed out; marked RETRY PENDING':'failed course enrolment').' (Course '.$course_id.'): '.$enrolled->get_error_message());
            continue;
        }

        $now=gmdate('c');
        wc_update_order_item_meta($item_id,'_jupiter_iomad_provisioned',$now);
        wc_update_order_item_meta($item_id,'_jupiter_iomad_user_id',$iomad_user_id);
        wc_update_order_item_meta($item_id,'_jupiter_iomad_company_id',$company_id);
        wc_update_order_item_meta($item_id,'_jupiter_iomad_course_id',$course_id);
        wc_update_order_item_meta($item_id,'_jupiter_iomad_provisioning_state','success');
        wc_delete_order_item_meta($item_id,'_jupiter_iomad_last_error');
        $success_count++;
        $order->add_order_note('[Jupiter Iomad] SUCCESS — Product #'.$product_id.' → Iomad User #'.$iomad_user_id.' → Company '.$company_id.' → Course '.$course_id.' (Student role 5).');
    }

    if($failure_count===0 && $retry_count===0){
        $order->update_meta_data('_jupiter_iomad_provisioning_status','success');
        $order->update_meta_data('_jupiter_iomad_iomad_user_id',$iomad_user_id);
        $order->update_meta_data('_jupiter_iomad_provisioned_at',gmdate('c'));
        $order->add_order_note('[Jupiter Iomad] Provisioning completed successfully: '.$success_count.' newly provisioned item(s), '.$skipped_count.' already-provisioned item(s) skipped.'.($created_now?' New learner was created.':' Existing learner was reused.'));
    }elseif($retry_count>0){
        $order->update_meta_data('_jupiter_iomad_provisioning_status','retry_pending');
        $order->add_order_note('[Jupiter Iomad] Provisioning is RETRY PENDING for '.$retry_count.' item(s); '.$failure_count.' definite failure(s); '.$success_count.' successful item(s). Timeout means the Iomad result may be uncertain, so only unmarked items will be retried.');
    }else{
        $order->update_meta_data('_jupiter_iomad_provisioning_status','partial_or_failed');
        $order->add_order_note('[Jupiter Iomad] Provisioning finished with '.$failure_count.' failed mapped item(s). Successful item(s): '.$success_count.'. Only items not marked provisioned will be retried.');
    }
    $order->save();
}

/** Route paid events either to dry-run or to live provisioning. */
function jupiter_iomad_handle_paid_order($order_id){
    if(get_option('jupiter_iomad_live_provisioning','0')==='1') jupiter_iomad_provision_paid_order($order_id,false);
    else jupiter_iomad_paid_order_dry_run($order_id,false);
}

add_action('woocommerce_payment_complete','jupiter_iomad_handle_paid_order',20,1);
add_action('woocommerce_order_status_processing','jupiter_iomad_handle_paid_order',20,1);
add_action('woocommerce_order_status_completed','jupiter_iomad_handle_paid_order',20,1);

// Keep the existing safe manual dry-run action.
add_filter('woocommerce_order_actions',function($actions){
    $actions['jupiter_iomad_run_dry_run']='Run Jupiter Iomad dry run';
    if(get_option('jupiter_iomad_live_provisioning','0')==='1') $actions['jupiter_iomad_run_provisioning']='Retry Jupiter Iomad pending items';
    return $actions;
});
add_action('woocommerce_order_action_jupiter_iomad_run_dry_run',function($order){
    if(!is_a($order,'WC_Order')) return;
    jupiter_iomad_paid_order_dry_run($order->get_id(),true);
});
add_action('woocommerce_order_action_jupiter_iomad_run_provisioning',function($order){
    if(!is_a($order,'WC_Order')) return;
    jupiter_iomad_provision_paid_order($order->get_id(),false);
});


/**
 * v0.6.0 Learner portal and signed SSO handoff.
 * WordPress remains the learner-facing identity. No Iomad password or REST token
 * is exposed to the browser. Access is granted only for a paid/provisioned item
 * owned by the currently logged-in WooCommerce customer.
 */
function jupiter_iomad_register_my_courses_endpoint(){
    add_rewrite_endpoint('my-courses',EP_ROOT|EP_PAGES);
}
add_action('init','jupiter_iomad_register_my_courses_endpoint');

/**
 * Plugin upgrades do not always run the activation hook, so a newly-added
 * WooCommerce endpoint can remain 404 until permalinks are manually saved.
 * Flush rewrite rules once per plugin version after the endpoint is registered.
 */
function jupiter_iomad_maybe_flush_rewrite_rules(){
    $stored=(string)get_option('jupiter_iomad_rewrite_version','');
    if($stored!==JUPITER_IOMAD_VERSION){
        jupiter_iomad_register_my_courses_endpoint();
        flush_rewrite_rules(false);
        update_option('jupiter_iomad_rewrite_version',JUPITER_IOMAD_VERSION,false);
    }
}
add_action('init','jupiter_iomad_maybe_flush_rewrite_rules',99);

register_activation_hook(__FILE__,function(){
    jupiter_iomad_register_my_courses_endpoint();
    flush_rewrite_rules();
    update_option('jupiter_iomad_rewrite_version',JUPITER_IOMAD_VERSION,false);
});
register_deactivation_hook(__FILE__,function(){flush_rewrite_rules();});

add_filter('woocommerce_account_menu_items',function($items){
    if(!is_array($items)) return $items;
    $out=[];
    foreach($items as $key=>$label){
        if($key==='customer-logout') $out['my-courses']='My Courses';
        $out[$key]=$label;
    }
    if(!isset($out['my-courses'])) $out['my-courses']='My Courses';
    return $out;
});

function jupiter_iomad_get_customer_courses($wp_user_id){
    if(!function_exists('wc_get_orders')) return [];
    $wp_user_id=absint($wp_user_id); if(!$wp_user_id) return [];
    $user=get_userdata($wp_user_id); if(!$user) return [];
    $email=strtolower(sanitize_email($user->user_email));
    $orders=wc_get_orders([
        'customer_id'=>$wp_user_id,
        'status'=>['processing','completed'],
        'limit'=>-1,
        'orderby'=>'date',
        'order'=>'DESC',
        'return'=>'objects',
    ]);
    $courses=[];
    foreach($orders as $order){
        if(!is_a($order,'WC_Order') || !$order->is_paid()) continue;
        if($email && strtolower(sanitize_email($order->get_billing_email()))!==$email) continue;
        foreach($order->get_items('line_item') as $item_id=>$item){
            $product=$item->get_product(); if(!$product) continue;
            $product_id=absint($product->get_id());
            $company_id=absint(get_post_meta($product_id,'_jupiter_iomad_company_id',true));
            $course_id=absint(get_post_meta($product_id,'_jupiter_iomad_course_id',true));
            $provisioned=(string)wc_get_order_item_meta($item_id,'_jupiter_iomad_provisioned',true);
            $iomad_user_id=absint(wc_get_order_item_meta($item_id,'_jupiter_iomad_user_id',true));
            $state=(string)wc_get_order_item_meta($item_id,'_jupiter_iomad_provisioning_state',true);
            if(!$company_id||!$course_id||!$provisioned||!$iomad_user_id||$state!=='success') continue;
            if(isset($courses[$course_id])) continue;
            $courses[$course_id]=[
                'course_id'=>$course_id,'company_id'=>$company_id,'iomad_user_id'=>$iomad_user_id,
                'product_id'=>$product_id,'product_name'=>sanitize_text_field($item->get_name()),
                'order_id'=>$order->get_id(),'item_id'=>absint($item_id),
                'image'=>get_the_post_thumbnail_url($product_id,'full'),
            ];
        }
    }
    return array_values($courses);
}

add_action('woocommerce_account_my-courses_endpoint',function(){
    if(!is_user_logged_in()){echo '<p>Please sign in to view your courses.</p>';return;}
    $courses=jupiter_iomad_get_customer_courses(get_current_user_id());
    echo '<div class="jupiter-my-courses"><h2>My Courses</h2>';
    if(empty($courses)){
        echo '<p>You do not have any active Jupiter courses yet.</p>';
        if(function_exists('wc_get_page_permalink')) echo '<p><a class="button" href="'.esc_url(wc_get_page_permalink('shop')).'">Browse Courses</a></p>';
        echo '</div>'; return;
    }
    echo '<div class="jupiter-course-grid">';
    foreach($courses as $c){
        $access=wp_nonce_url(add_query_arg(['jupiter_iomad_sso'=>1,'course_id'=>$c['course_id']],home_url('/')),'jupiter_iomad_sso_'.$c['course_id']);
        echo '<article class="jupiter-course-card">';
        if($c['image']) echo '<img src="'.esc_url($c['image']).'" alt="">';
        echo '<div class="jupiter-course-card-body"><span class="jupiter-course-eyebrow">Jupiter Learning</span><h3>'.esc_html($c['product_name']).'</h3><p>Your enrolment is active. Continue your lessons, knowledge checks and assessments.</p><a class="button alt" href="'.esc_url($access).'">Access Course</a></div></article>';
    }
    echo '</div></div>';
});

add_action('wp_head',function(){
    if(is_admin()) return; ?>
    <style id="jupiter-my-courses-css">
    .jupiter-course-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:24px;margin:20px 0}
    .jupiter-course-card{border:1px solid #e6e3ef;border-radius:16px;overflow:hidden;background:#fff;box-shadow:0 8px 28px rgba(16,35,63,.08)}
    .jupiter-course-card img{display:block;width:100%;height:auto;max-height:460px;object-fit:contain;background:#0b1230}
    .jupiter-course-card-body{padding:22px}.jupiter-course-card h3{margin:6px 0 10px;color:#10233F}
    .jupiter-course-eyebrow{font-size:12px;text-transform:uppercase;letter-spacing:.08em;font-weight:700;color:#6F3DF4}
    .jupiter-course-card .button{margin-top:8px;border-radius:999px;padding:11px 20px;background:#6F3DF4;color:#fff}
    </style><?php
});

function jupiter_iomad_base64url_encode($data){return rtrim(strtr(base64_encode($data),'+/','-_'),'=');}

function jupiter_iomad_find_owned_course($wp_user_id,$course_id){
    foreach(jupiter_iomad_get_customer_courses($wp_user_id) as $course){
        if(absint($course['course_id'])===absint($course_id)) return $course;
    }
    return null;
}

add_action('template_redirect',function(){
    if(empty($_GET['jupiter_iomad_sso'])) return;
    if(!is_user_logged_in()) auth_redirect();
    $course_id=absint($_GET['course_id']??0);
    if(!$course_id || !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce']??'')),'jupiter_iomad_sso_'.$course_id)) wp_die('Invalid or expired course access request.','Jupiter Course Access',['response'=>403]);
    $owned=jupiter_iomad_find_owned_course(get_current_user_id(),$course_id);
    if(!$owned) wp_die('This course is not provisioned for your Jupiter account.','Jupiter Course Access',['response'=>403]);
    $secret=trim((string)get_option('jupiter_iomad_sso_secret',''));
    if(strlen($secret)<32) wp_die('Jupiter SSO is not configured yet. Please contact support.','Jupiter Course Access',['response'=>503]);
    $s=jupiter_iomad_get_settings();
    $base=trim((string)get_option('jupiter_iomad_sso_base_url',''));
    if(!$base && !empty($s['url'])) $base=preg_replace('~/webservice/rest/server\\.php/?$~','',rtrim($s['url'],'/'));
    $base=rtrim(esc_url_raw($base),'/');
    if(!$base || stripos($base,'https://')!==0) wp_die('Secure Iomad SSO URL is not configured.','Jupiter Course Access',['response'=>503]);
    $user=wp_get_current_user();
    $now=time();
    $claims=[
        'iss'=>home_url('/'),'aud'=>'jupiter-iomad','wp_user_id'=>get_current_user_id(),
        'iomad_user_id'=>absint($owned['iomad_user_id']),'email'=>sanitize_email($user->user_email),
        'course_id'=>$course_id,'iat'=>$now,'exp'=>$now+90,'jti'=>wp_generate_uuid4(),
        'return_url'=>wc_get_account_endpoint_url('my-courses'),
    ];
    $payload=jupiter_iomad_base64url_encode(wp_json_encode($claims));
    $sig=jupiter_iomad_base64url_encode(hash_hmac('sha256',$payload,$secret,true));
    $token=$payload.'.'.$sig;
    // This is an intentionally cross-domain redirect from the trusted Jupiter WordPress site
    // to the administrator-configured HTTPS Iomad host. wp_safe_redirect() rejects external
    // hosts unless separately allow-listed, which can send learners back to WordPress instead.
    // Validate the configured target here, then perform a normal 302 redirect.
    $target=$base.'/local/jupiter_sso/login.php?token='.rawurlencode($token);
    $target_parts=wp_parse_url($target);
    $base_parts=wp_parse_url($base);
    if(empty($target_parts['host']) || empty($base_parts['host']) ||
       !hash_equals(strtolower($base_parts['host']),strtolower($target_parts['host'])) ||
       strtolower((string)($target_parts['scheme']??''))!=='https') {
        wp_die('Secure Iomad SSO redirect could not be validated.','Jupiter Course Access',['response'=>503]);
    }
    wp_redirect($target,302,'Jupiter Iomad');
    exit;
});


/**
 * v0.7.0 Jupiter Family Linking foundation.
 *
 * Front-end accounts are normal WordPress/WooCommerce users underneath; users
 * register through jupiterthescholar.com rather than wp-admin. Parent and
 * learner identities remain separate. Relationship authorization is enforced
 * server-side and is never inferred from names, surnames or purchaser identity.
 */

function jupiter_iomad_family_table(){
    global $wpdb;
    return $wpdb->prefix.'jupiter_family_relationships';
}

function jupiter_iomad_family_install(){
    global $wpdb;
    require_once ABSPATH.'wp-admin/includes/upgrade.php';
    $table=jupiter_iomad_family_table();
    $charset=$wpdb->get_charset_collate();
    $sql="CREATE TABLE {$table} (
      id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
      parent_wp_user_id bigint(20) unsigned NOT NULL,
      learner_iomad_user_id bigint(20) unsigned NOT NULL,
      relationship_type varchar(32) NOT NULL DEFAULT 'parent_guardian',
      status varchar(20) NOT NULL DEFAULT 'active',
      verification_method varchar(32) NOT NULL DEFAULT 'one_time_code',
      verified_at datetime NOT NULL,
      revoked_at datetime NULL,
      created_at datetime NOT NULL,
      updated_at datetime NOT NULL,
      PRIMARY KEY  (id),
      UNIQUE KEY parent_learner (parent_wp_user_id,learner_iomad_user_id),
      KEY parent_status (parent_wp_user_id,status),
      KEY learner_status (learner_iomad_user_id,status)
    ) {$charset};";
    dbDelta($sql);
    update_option('jupiter_iomad_family_schema','1',false);
}
add_action('init',function(){
    if(get_option('jupiter_iomad_family_schema')!=='1') jupiter_iomad_family_install();
},5);

function jupiter_iomad_register_family_endpoints(){
    add_rewrite_endpoint('parent-access',EP_ROOT|EP_PAGES);
    add_rewrite_endpoint('my-children',EP_ROOT|EP_PAGES);
}
add_action('init','jupiter_iomad_register_family_endpoints');

function jupiter_iomad_current_learner_identity($wp_user_id){
    $courses=jupiter_iomad_get_customer_courses(absint($wp_user_id));
    $ids=[];
    foreach($courses as $course){
        $id=absint($course['iomad_user_id']??0);
        if($id) $ids[$id]=true;
    }
    if(count($ids)!==1) return 0;
    return (int)array_key_first($ids);
}

add_filter('woocommerce_account_menu_items',function($items){
    if(!is_array($items) || !is_user_logged_in()) return $items;
    $uid=get_current_user_id();
    $out=[];
    $learnerid=jupiter_iomad_current_learner_identity($uid);
    global $wpdb;
    $haschildren=(bool)$wpdb->get_var($wpdb->prepare(
        "SELECT id FROM ".jupiter_iomad_family_table()." WHERE parent_wp_user_id=%d AND status='active' LIMIT 1",$uid
    ));
    foreach($items as $key=>$label){
        if($key==='customer-logout'){
            if($learnerid) $out['parent-access']='Parent / Guardian Access';
            $out['my-children']='My Children';
        }
        $out[$key]=$label;
    }
    return $out;
},30);

function jupiter_iomad_parentlink_api($function,array $params=[]){
    return jupiter_iomad_core_api_post($function,$params);
}

add_action('woocommerce_account_parent-access_endpoint',function(){
    if(!is_user_logged_in()){ echo '<p>Please sign in.</p>'; return; }
    $uid=get_current_user_id();
    $learnerid=jupiter_iomad_current_learner_identity($uid);
    echo '<div class="jupiter-family"><h2>Parent / Guardian Access</h2>';
    if(!$learnerid){
        echo '<p>Parent linking is available only for a verified Jupiter learner account with an active provisioned learning identity.</p></div>';
        return;
    }
    echo '<p>Generate a temporary code for the parent or guardian you want to connect to your learning account. The code expires after 15 minutes and can be used once.</p>';
    if(!empty($_POST['jupiter_generate_parent_code'])){
        check_admin_referer('jupiter_generate_parent_code');
        $r=jupiter_iomad_parentlink_api('local_jupiter_parentlink_generate',['learnerid'=>$learnerid]);
        if(is_wp_error($r)){
            echo '<div class="woocommerce-error">'.esc_html($r->get_error_message()).'</div>';
        } elseif(!empty($r['code'])){
            echo '<div class="jupiter-link-code"><div>Your temporary link code</div><strong>'.esc_html($r['code']).'</strong><p>Expires in 15 minutes. Only share this with the parent or guardian you intend to connect.</p></div>';
        }
    }
    echo '<form method="post">';
    wp_nonce_field('jupiter_generate_parent_code');
    echo '<button class="button" type="submit" name="jupiter_generate_parent_code" value="1">Generate parent link code</button></form></div>';
});

function jupiter_iomad_family_active_relationship($parentid,$learnerid){
    global $wpdb;
    return $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM ".jupiter_iomad_family_table()." WHERE parent_wp_user_id=%d AND learner_iomad_user_id=%d AND status='active' LIMIT 1",
        absint($parentid),absint($learnerid)
    ));
}


function jupiter_iomad_parent_child_url($learnerid,$view='overview'){
    return add_query_arg(['jupiter_child'=>absint($learnerid),'jupiter_view'=>sanitize_key($view)],wc_get_account_endpoint_url('my-children'));
}
function jupiter_iomad_parent_requested_child($parentid){
    $learnerid=isset($_GET['jupiter_child'])?absint($_GET['jupiter_child']):0;
    return ($learnerid && jupiter_iomad_family_active_relationship($parentid,$learnerid))?$learnerid:0;
}
function jupiter_iomad_parent_requested_view(){
    $allowed=['overview','courses','progress','assessments','certificates','reports'];
    $v=isset($_GET['jupiter_view'])?sanitize_key(wp_unslash($_GET['jupiter_view'])):'overview';
    return in_array($v,$allowed,true)?$v:'overview';
}
add_action('template_redirect',function(){
 if(!is_user_logged_in()||empty($_GET['jupiter_cert_access']))return;
 $lid=absint($_GET['learner']??0);$code=sanitize_text_field(wp_unslash($_GET['cert']??''));$mode=sanitize_key($_GET['mode']??'view');if(!in_array($mode,['view','download'],true))$mode='view';$nonce=$_GET['_wpnonce']??'';
 if(!$lid||$code===''||!wp_verify_nonce($nonce,'jupiter_cert_'.$lid.'_'.$code.'_'.$mode))wp_die('Invalid certificate request.',403);
 if(!jupiter_iomad_family_active_relationship(get_current_user_id(),$lid))wp_die('Learner relationship is not authorised.',403);
 $s=jupiter_iomad_parentlink_api('local_jupiter_parentlink_summary',['learnerid'=>$lid]);if(is_wp_error($s))wp_die('Unable to verify certificate.',502);
 $ok=false;foreach((array)($s['certificates']??[]) as $c){if(hash_equals((string)($c['code']??''),$code)){$ok=true;break;}}if(!$ok)wp_die('Certificate is not available for this learner.',403);
 $a=jupiter_iomad_parentlink_api('local_jupiter_parentlink_certificate_access',['learnerid'=>$lid,'code'=>$code,'mode'=>$mode]);if(is_wp_error($a)||empty($a['url']))wp_die('Secure certificate access could not be created.',502);
 wp_redirect(esc_url_raw($a['url']));exit;
});
function jupiter_iomad_render_parent_child_detail($s,$learnerid,$view){
    $name=esc_html($s['displayname']??'Learner'); $initials=esc_html($s['initials']??'');
    $courses=is_array($s['courses']??null)?$s['courses']:[]; $certs=is_array($s['certificates']??null)?$s['certificates']:[];
    $tabs=['overview'=>'Overview','courses'=>'Courses','progress'=>'Progress','assessments'=>'Assessments','certificates'=>'Certificates','reports'=>'Reports'];
    echo '<section class="jupiter-detail-shell"><div class="jupiter-detail-hero"><div class="jupiter-detail-person"><span class="jupiter-avatar">'.$initials.'</span><div><span class="jupiter-eyebrow">LEARNER</span><h2>'.$name.'</h2><p>✓ Verified parent/guardian relationship</p></div></div><a class="jupiter-back" href="'.esc_url(wc_get_account_endpoint_url('my-children')).'">← Family dashboard</a></div><nav class="jupiter-detail-tabs">';
    foreach($tabs as $k=>$label) echo '<a class="'.($view===$k?'active':'').'" href="'.esc_url(jupiter_iomad_parent_child_url($learnerid,$k)).'">'.esc_html($label).'</a>';
    echo '</nav>';

    if($view==='courses'){
        echo '<div class="jupiter-detail-heading"><div><span class="jupiter-eyebrow">LEARNING</span><h3>Courses</h3></div><span>'.count($courses).' course'.(count($courses)===1?'':'s').'</span></div>';
        if(!$courses) echo '<div class="jupiter-empty">No courses are currently available.</div>';
        foreach($courses as $c){$pct=max(0,min(100,(float)($c['progress']??0)));$status=!empty($c['completed'])?'Completed':($pct>0?'In progress':'Not started');$cid=absint($c['courseid']??0);
            echo '<article class="jupiter-detail-card"><div class="jupiter-course-row"><div><span class="jupiter-eyebrow">COURSE</span><h4>'.esc_html($c['coursename']??'Course').'</h4></div><span class="jupiter-status '.esc_attr(strtolower(str_replace(' ','-',$status))).'">'.esc_html($status).'</span></div><div class="jupiter-progress-meta"><span>'.esc_html($pct).'% complete</span><span>'.absint($c['lessonsdone']??0).' / '.absint($c['lessonstotal']??0).' lessons</span></div><div class="jupiter-progressbar"><span style="width:'.esc_attr($pct).'%"></span></div><div class="jupiter-card-actions"><a href="'.esc_url(jupiter_iomad_parent_child_url($learnerid,'progress').'#course-'.$cid).'">View progress</a><a href="'.esc_url(jupiter_iomad_parent_child_url($learnerid,'assessments').'#course-'.$cid).'">Assessments</a></div></article>';
        }
    } elseif($view==='progress'){
        echo '<div class="jupiter-detail-heading"><div><span class="jupiter-eyebrow">PROGRESS & REPORTS</span><h3>Learning progress</h3></div><span>Live Iomad data</span></div>';
        foreach($courses as $c){$pct=max(0,min(100,(float)($c['progress']??0)));$units=is_array($c['units']??null)?$c['units']:[];
            echo '<article id="course-'.absint($c['courseid']??0).'" class="jupiter-detail-card"><div class="jupiter-course-row"><h4>'.esc_html($c['coursename']??'Course').'</h4><strong>'.esc_html($pct).'%</strong></div><div class="jupiter-progressbar"><span style="width:'.esc_attr($pct).'%"></span></div><div class="jupiter-mini-stats jupiter-report-stats"><span><b>'.absint($c['lessonsdone']??0).'/'.absint($c['lessonstotal']??0).'</b> Lessons</span><span><b>'.absint($c['starterattempted']??0).'/'.absint($c['startertotal']??0).'</b> Starters</span><span><b>'.absint($c['exitpassed']??0).'/'.absint($c['exittotal']??0).'</b> Exit passes</span></div>';
            if($units){echo '<h5>Unit progress</h5>';foreach($units as $u){$up=max(0,min(100,(float)($u['progress']??0)));echo '<div class="jupiter-unit"><div><strong>'.esc_html($u['name']??'Unit').'</strong><span>'.esc_html($up).'%</span></div><div class="jupiter-progressbar small"><span style="width:'.esc_attr($up).'%"></span></div><small>'.absint($u['lessonsdone']??0).'/'.absint($u['lessonstotal']??0).' lessons · '.absint($u['exitspassed']??0).'/'.absint($u['exitstotal']??0).' exit assessments passed</small></div>';}} else echo '<p class="jupiter-muted">Detailed unit progress is not available for this course.</p>';
            echo '</article>';
        }
    } elseif($view==='assessments'){
        echo '<div class="jupiter-detail-heading"><div><span class="jupiter-eyebrow">ASSESSMENTS</span><h3>Scores & attempts</h3></div><span>Parent-friendly results</span></div>';
        $allscores=[];$allattempted=0;$allpassed=0;foreach($courses as $tc){foreach((array)($tc['assessments']??[]) as $ta){if(!empty($ta['attempted'])){$allattempted++;if(!empty($ta['passed']))$allpassed++;if(isset($ta['score'])&&is_numeric($ta['score']))$allscores[]=(float)$ta['score'];}}}
        $avg=$allscores?round(array_sum($allscores)/count($allscores),1):null;
        echo '<div class="jupiter-assessment-summary"><div><strong>'.absint($allattempted).'</strong><span>Attempts recorded</span></div><div><strong>'.absint($allpassed).'</strong><span>Passed</span></div><div><strong>'.($avg===null?'—':esc_html($avg).'%').'</strong><span>Average score</span></div></div>';
        if(count($allscores)>=2){$first=$allscores[0];$last=$allscores[count($allscores)-1];$delta=round($last-$first,1);$trend=$delta>0?'Improving':($delta<0?'Lower than first recorded score':'Stable');echo '<div class="jupiter-parent-note"><strong>Recorded score trend: '.esc_html($trend).'</strong><br>First recorded score '.esc_html($first).'% → latest recorded score '.esc_html($last).'%. This is a simple comparison of available scored attempts, not a prediction.</div>';}
        foreach($courses as $c){$aa=is_array($c['assessments']??null)?$c['assessments']:[];$shown=0;echo '<article id="course-'.absint($c['courseid']??0).'" class="jupiter-detail-card"><h4>'.esc_html($c['coursename']??'Course').'</h4>';
            foreach(array_reverse($aa) as $a){if(empty($a['attempted']))continue;$shown++;$pass=!empty($a['passed']);echo '<div class="jupiter-result-row"><div><strong>'.esc_html($a['name']??'Assessment').'</strong><small>'.esc_html(ucfirst((string)($a['type']??'assessment'))).' assessment</small></div><div class="jupiter-result-score '.($pass?'pass':'review').'"><b>'.esc_html((float)($a['score']??0)).'%</b><span>'.($pass?'Passed':'Review').'</span></div></div>';}
            if(!$shown)echo '<p class="jupiter-muted">No graded assessments are available yet.</p>';echo '</article>';
        }
    } elseif($view==='reports'){
        $cc=count($courses);$done=0;$sum=0;$ld=0;$lt=0;$attempted=0;$passed=0;$scores=[];$latest=0;
        foreach($courses as $c){$sum+=(float)($c['progress']??0);if(!empty($c['completed']))$done++;$ld+=absint($c['lessonsdone']??0);$lt+=absint($c['lessonstotal']??0);$latest=max($latest,(int)($c['lastactivity']??0));foreach((array)($c['assessments']??[]) as $a){if(empty($a['attempted']))continue;$attempted++;if(!empty($a['passed']))$passed++;if(isset($a['score'])&&is_numeric($a['score']))$scores[]=(float)$a['score'];}}
        $overall=$cc?round($sum/$cc):0;$avg=$scores?round(array_sum($scores)/count($scores),1):null;
        echo '<div class="jupiter-detail-heading"><div><span class="jupiter-eyebrow">PARENT REPORT</span><h3>Learning report</h3></div><span>Current learning snapshot</span></div><div class="jupiter-report-grid">';
        foreach([[$overall.'%','Overall progress'],[$done.'/'.$cc,'Courses completed'],[$ld.'/'.$lt,'Lessons completed'],[$attempted,'Assessments attempted'],[$passed,'Assessments passed'],[$avg===null?'—':$avg.'%','Average recorded score']] as $r)echo '<div><strong>'.esc_html($r[0]).'</strong><span>'.esc_html($r[1]).'</span></div>';
        echo '</div><article class="jupiter-detail-card"><h4>Course summary</h4>';
        foreach($courses as $c){$pct=max(0,min(100,(float)($c['progress']??0)));echo '<div class="jupiter-report-course"><div><strong>'.esc_html($c['coursename']??'Course').'</strong><small>'.(!empty($c['completed'])?'Completed':($pct>0?'In progress':'Not started')).'</small></div><div><b>'.esc_html($pct).'%</b><small>'.absint($c['lessonsdone']??0).'/'.absint($c['lessonstotal']??0).' lessons</small></div></div>';}
        echo '</article><div class="jupiter-parent-note"><strong>About this report</strong><br>This uses current authorised Iomad learning records. Raw Moodle logs, device information and private learner communications are not exposed. Assessment averages use recorded scored attempts only.</div>';
    } elseif($view==='certificates'){
        echo '<div class="jupiter-detail-heading"><div><span class="jupiter-eyebrow">ACHIEVEMENTS</span><h3>Certificates</h3></div><span>'.count($certs).' earned</span></div>';
        if(!$certs)echo '<div class="jupiter-empty">No certificates have been issued yet.</div>';
        foreach($certs as $cert){$code=(string)($cert['code']??'');echo '<article class="jupiter-certificate-card"><span class="jupiter-certificate-seal">★</span><div><span class="jupiter-eyebrow">CERTIFICATE EARNED</span><h4>'.esc_html($cert['coursename']??$cert['name']??'Certificate').'</h4><p>'.(!empty($cert['issued'])?'Issued '.esc_html(wp_date(get_option('date_format'),(int)$cert['issued'])):'Issued by Jupiter learning platform').'</p><small>Certificate record verified from Iomad.</small>';if($code!==''){
            $viewurl=wp_nonce_url(add_query_arg(['jupiter_cert_access'=>1,'learner'=>$learnerid,'cert'=>$code,'mode'=>'view'],home_url('/')),'jupiter_cert_'.$learnerid.'_'.$code.'_view');
            $downloadurl=wp_nonce_url(add_query_arg(['jupiter_cert_access'=>1,'learner'=>$learnerid,'cert'=>$code,'mode'=>'download'],home_url('/')),'jupiter_cert_'.$learnerid.'_'.$code.'_download');
            echo '<div class="jupiter-achievement-badge">★ Achievement unlocked · Course completed</div>';echo '<div class="jupiter-cert-actions"><a class="button" target="_blank" rel="noopener" href="'.esc_url($viewurl).'">View Certificate</a><a class="button jupiter-cert-download" href="'.esc_url($downloadurl).'">Download PDF</a></div>';
        }echo '</div></article>';}
        echo '<div class="jupiter-parent-note"><strong>Secure certificate access</strong><br>Certificates are delivered through a short-lived parent-authorised link. The parent is not logged in as the learner and the learner LMS session is not exposed.</div>';
    } else {
        $cc=count($courses);$done=0;$sum=0;$ass=0;$latest=0;foreach($courses as $c){$sum+=(float)($c['progress']??0);if(!empty($c['completed']))$done++;$latest=max($latest,(int)($c['lastactivity']??0));foreach((array)($c['assessments']??[]) as $a)if(!empty($a['attempted']))$ass++;}$overall=$cc?round($sum/$cc):0;
        echo '<div class="jupiter-detail-heading"><div><span class="jupiter-eyebrow">OVERVIEW</span><h3>Learning at a glance</h3></div></div><div class="jupiter-click-stats">';
        foreach([['progress',$overall.'%','Overall progress'],['courses',$cc,'Courses'],['assessments',$ass,'Assessments'],['certificates',count($certs),'Certificates'],['reports','↗','Learning report']] as $x)echo '<a href="'.esc_url(jupiter_iomad_parent_child_url($learnerid,$x[0])).'"><strong>'.esc_html($x[1]).'</strong><span>'.esc_html($x[2]).'</span><small>View details →</small></a>';
        echo '</div><div class="jupiter-parent-note"><strong>'.absint($done).' completed course'.($done===1?'':'s').'</strong>'.($latest?' · Last learning activity '.esc_html(human_time_diff($latest,current_time('timestamp',true))).' ago':'').'</div>';
    }
    echo '</section>';
}
add_action('woocommerce_account_my-children_endpoint',function(){
    if(!is_user_logged_in()){ echo '<p>Please sign in.</p>'; return; }
    global $wpdb;
    $uid=get_current_user_id();
    echo '<div class="jupiter-family"><h2>My Children</h2>';
    $requestedlearner=jupiter_iomad_parent_requested_child($uid);
    if($requestedlearner){
        $detail=jupiter_iomad_parentlink_api('local_jupiter_parentlink_summary',['learnerid'=>$requestedlearner]);
        if(is_wp_error($detail) || empty($detail['learnerid'])) echo '<div class="woocommerce-error">Learning information could not be loaded securely.</div>';
        else jupiter_iomad_render_parent_child_detail($detail,$requestedlearner,jupiter_iomad_parent_requested_view());
        echo '</div>';
        return;
    }

    // Final confirmation: invitation details are kept server-side in a short-lived transient.
    if(!empty($_POST['jupiter_confirm_child_link'])){
        check_admin_referer('jupiter_confirm_child_link');
        $key='jupiter_link_confirm_'.$uid;
        $pending=get_transient($key);
        delete_transient($key);
        if(!is_array($pending) || empty($pending['invitationid']) || empty($pending['learnerid'])){
            echo '<div class="woocommerce-error">The link confirmation expired. Please enter the code again.</div>';
        } else {
            $consume=jupiter_iomad_parentlink_api('local_jupiter_parentlink_consume',['invitationid'=>absint($pending['invitationid'])]);
            if(is_wp_error($consume) || empty($consume['success']) || absint($consume['learnerid']??0)!==absint($pending['learnerid'])){
                echo '<div class="woocommerce-error">The link code is no longer valid. Please generate a new code.</div>';
            } else {
                $now=current_time('mysql',true);
                $table=jupiter_iomad_family_table();
                $existing=$wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM {$table} WHERE parent_wp_user_id=%d AND learner_iomad_user_id=%d LIMIT 1",
                    $uid,absint($pending['learnerid'])
                ));
                $data=[
                    'relationship_type'=>'parent_guardian','status'=>'active',
                    'verification_method'=>'one_time_code','verified_at'=>$now,
                    'revoked_at'=>null,'updated_at'=>$now
                ];
                if($existing){
                    $wpdb->update($table,$data,['id'=>$existing->id]);
                } else {
                    $data['parent_wp_user_id']=$uid;
                    $data['learner_iomad_user_id']=absint($pending['learnerid']);
                    $data['created_at']=$now;
                    $wpdb->insert($table,$data);
                }
                echo '<div class="woocommerce-message">Child linked successfully.</div>';
            }
        }
    }

    // Lookup stage. Do not persist a relationship until the authenticated parent confirms.
    if(!empty($_POST['jupiter_lookup_child_code'])){
        check_admin_referer('jupiter_lookup_child_code');
        $code=strtoupper(sanitize_text_field(wp_unslash($_POST['link_code']??'')));
        $r=jupiter_iomad_parentlink_api('local_jupiter_parentlink_lookup',['code'=>$code]);
        if(is_wp_error($r)){
            echo '<div class="woocommerce-error">That link code is invalid or expired.</div>';
        } elseif(!empty($r['invitationid']) && !empty($r['learnerid'])){
            set_transient('jupiter_link_confirm_'.$uid,[
                'invitationid'=>absint($r['invitationid']),
                'learnerid'=>absint($r['learnerid']),
                'displayname'=>sanitize_text_field($r['displayname']??'Learner'),
            ],5*MINUTE_IN_SECONDS);
            echo '<div class="jupiter-link-confirm"><h3>Confirm child link</h3><p>Connect your parent/guardian account with <strong>'.esc_html($r['displayname']??'Learner').'</strong>?</p>';
            echo '<form method="post">'; wp_nonce_field('jupiter_confirm_child_link');
            echo '<button class="button alt" type="submit" name="jupiter_confirm_child_link" value="1">Confirm relationship</button></form></div>';
        }
    }

    $children=$wpdb->get_results($wpdb->prepare(
        "SELECT learner_iomad_user_id,verified_at FROM ".jupiter_iomad_family_table()." WHERE parent_wp_user_id=%d AND status='active' ORDER BY verified_at DESC",$uid
    ));
    if($children){
        $currentparent=wp_get_current_user();
        echo '<section class="jupiter-parent-welcome"><div><span class="jupiter-eyebrow">PARENT DASHBOARD</span><h2>Welcome, '.esc_html($currentparent->display_name).'</h2><p>Here\'s your family\'s learning progress at a glance.</p></div><div class="jupiter-parent-actions"><a class="button jupiter-outline-button" href="#jupiter-link-child">+ Link another child</a></div></section>';
        echo '<div class="jupiter-family-heading"><h3>My family</h3><span>'.count($children).' linked learner'.(count($children)===1?'':'s').'</span></div><div class="jupiter-child-grid">';
        foreach($children as $child){
            // Relationship is checked in WordPress before any learner data is requested.
            // The learner ID is never accepted from a browser query string for this card.
            $summary=jupiter_iomad_parentlink_api('local_jupiter_parentlink_summary',[
                'learnerid'=>absint($child->learner_iomad_user_id)
            ]);
            if(is_wp_error($summary) || empty($summary['learnerid'])){
                echo '<article class="jupiter-child-card"><strong>Linked child</strong><p>Learning information could not be loaded from Iomad. The verified relationship is still active.</p></article>';
                continue;
            }
            $name=esc_html($summary['displayname']??'Learner');
            $initials=esc_html($summary['initials']??'');
            $courses=is_array($summary['courses']??null)?$summary['courses']:[];
            $coursecount=count($courses); $completedcount=0; $sumprogress=0; $latest=0;
            foreach($courses as $metriccourse){
                $sumprogress+=(float)($metriccourse['progress']??0);
                if(!empty($metriccourse['completed'])) $completedcount++;
                $latest=max($latest,(int)($metriccourse['lastactivity']??0));
            }
            $overall=$coursecount ? round($sumprogress/$coursecount) : 0;

            echo '<article class="jupiter-child-card jupiter-child-dashboard">';
            echo '<header class="jupiter-child-head"><span class="jupiter-avatar">'.$initials.'</span><div><h3>'.$name.'</h3><span class="jupiter-verified">✓ Verified parent/guardian relationship</span></div></header>';

            echo '<div class="jupiter-stat-grid">';
            echo '<a class="jupiter-stat jupiter-stat-link" href="'.esc_url(jupiter_iomad_parent_child_url($child->learner_iomad_user_id,'progress')).'"><strong>'.esc_html($overall).'%</strong><span>Overall progress</span><small>View →</small></a>';
            echo '<a class="jupiter-stat jupiter-stat-link" href="'.esc_url(jupiter_iomad_parent_child_url($child->learner_iomad_user_id,'courses')).'"><strong>'.esc_html($coursecount).'</strong><span>Active courses</span><small>View →</small></a>';
            echo '<a class="jupiter-stat jupiter-stat-link" href="'.esc_url(jupiter_iomad_parent_child_url($child->learner_iomad_user_id,'courses')).'"><strong>'.esc_html($completedcount).'</strong><span>Completed courses</span><small>View →</small></a>';
            echo '<div class="jupiter-stat"><strong>'.esc_html($latest ? human_time_diff($latest,current_time('timestamp',true)).' ago' : '—').'</strong><span>Last learning activity</span></div>';
            echo '</div>';

            $attentionitems=[]; $achievementcount=count(is_array($summary['certificates']??null)?$summary['certificates']:[]);
            foreach($courses as $signalcourse){
                $scname=(string)($signalcourse['coursename']??'Course');
                $scstatus=(string)($signalcourse['status']??'');
                $sclast=(int)($signalcourse['lastactivity']??0);
                if($scstatus==='in_progress' && $sclast && $sclast < (current_time('timestamp',true)-(7*DAY_IN_SECONDS))){
                    $attentionitems[]=['level'=>'attention','title'=>'Learning has paused','text'=>$scname.' has had no learning activity for more than 7 days.'];
                }
                if($scstatus==='not_started' && $sclast && $sclast < (current_time('timestamp',true)-(7*DAY_IN_SECONDS))){
                    $attentionitems[]=['level'=>'info','title'=>'Course not started','text'=>$scname.' is available but has not been started.'];
                }
                $assessments=is_array($signalcourse['assessments']??null)?$signalcourse['assessments']:[];
                $reviewcount=0;
                foreach($assessments as $sa){
                    if(!empty($sa['attempted']) && ($sa['type']??'')==='exit' && empty($sa['passed'])) $reviewcount++;
                }
                if($reviewcount){
                    $attentionitems[]=['level'=>'attention','title'=>'Assessment needs review','text'=>$reviewcount.' exit assessment'.($reviewcount===1?'':'s').' in '.$scname.' '.($reviewcount===1?'has':'have').' not yet met the pass mark.'];
                }
            }
            $attention=count($attentionitems);
            echo '<div class="jupiter-glance">';
            echo '<a href="'.esc_url(jupiter_iomad_parent_child_url($child->learner_iomad_user_id,'certificates')).'"><span class="jupiter-glance-icon">★</span><p><strong>'.absint($achievementcount).'</strong><small>Certificates earned</small></p></a>';
            echo '<a href="'.esc_url(jupiter_iomad_parent_child_url($child->learner_iomad_user_id,'courses')).'"><span class="jupiter-glance-icon">✓</span><p><strong>'.absint($completedcount).'</strong><small>Courses completed</small></p></a>';
            echo '<div><span class="jupiter-glance-icon">!</span><p><strong>'.absint($attention).'</strong><small>Needs attention</small></p></div>';
            echo '</div>';

            echo '<div class="jupiter-course-list"><div class="jupiter-section-head"><h4>Learning overview</h4><span>Real progress from Iomad</span></div>';
            if(!$courses){
                echo '<div class="jupiter-empty">No active courses are currently available.</div>';
            } else {
                foreach($courses as $course){
                    $pct=max(0,min(100,(float)($course['progress']??0)));
                    $done=absint($course['activitiesdone']??0);
                    $total=absint($course['activitiestotal']??0);
                    $status=!empty($course['completed'])?'Completed':($pct>0?'In progress':'Not started');
                    echo '<section class="jupiter-course-progress">';
                    echo '<div class="jupiter-course-row"><strong>'.esc_html($course['coursename']??'Course').'</strong><span class="jupiter-status '.esc_attr(strtolower(str_replace(' ','-',$status))).'">'.esc_html($status).'</span></div>';
                    echo '<div class="jupiter-progress-meta"><span>'.esc_html($pct).'% complete</span><span>'.esc_html($done).' / '.esc_html($total).' completion activities</span></div>';
                    echo '<div class="jupiter-progressbar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="'.esc_attr($pct).'"><span style="width:'.esc_attr($pct).'%"></span></div>';
                    if(!empty($course['lastactivity'])) echo '<small>Last activity '.esc_html(human_time_diff((int)$course['lastactivity'],current_time('timestamp',true))).' ago</small>';

                    $units=is_array($course['units']??null)?$course['units']:[];
                    $assessments=is_array($course['assessments']??null)?$course['assessments']:[];
                    if($units || $assessments || !empty($course['lessonstotal']) || !empty($course['exittotal'])){
                        echo '<details class="jupiter-course-details"><summary>View learning details</summary>';
                        echo '<div class="jupiter-mini-stats">';
                        echo '<span><b>'.absint($course['lessonsdone']??0).'/'.absint($course['lessonstotal']??0).'</b> Lessons</span>';
                        echo '<span><b>'.absint($course['starterattempted']??0).'/'.absint($course['startertotal']??0).'</b> Starters</span>';
                        echo '<span><b>'.absint($course['exitpassed']??0).'/'.absint($course['exittotal']??0).'</b> Exit passes</span>';
                        echo '</div>';
                        if($units){
                            echo '<h5>Units</h5><div class="jupiter-unit-list">';
                            foreach($units as $unit){
                                $up=max(0,min(100,(float)($unit['progress']??0)));
                                echo '<div class="jupiter-unit"><div><strong>'.esc_html($unit['name']??'Unit').'</strong><span>'.esc_html($up).'%</span></div>';
                                echo '<div class="jupiter-progressbar small"><span style="width:'.esc_attr($up).'%"></span></div>';
                                echo '<small>'.absint($unit['lessonsdone']??0).'/'.absint($unit['lessonstotal']??0).' lessons · '.absint($unit['exitspassed']??0).'/'.absint($unit['exitstotal']??0).' exit assessments passed</small></div>';
                            }
                            echo '</div>';
                        }
                        if($assessments){
                            echo '<h5>Recent assessments</h5><div class="jupiter-assessment-list">';
                            $shown=0;
                            foreach(array_reverse($assessments) as $a){
                                if(empty($a['attempted'])) continue;
                                $shown++; if($shown>6) break;
                                $pass=!empty($a['passed']);
                                echo '<div class="jupiter-assessment"><span>'.esc_html($a['name']??'Assessment').'</span><b class="'.($pass?'pass':'review').'">'.esc_html($a['score']??0).'% '.($pass?'Passed':'Review').'</b></div>';
                            }
                            if(!$shown) echo '<p class="jupiter-muted">No graded assessments yet.</p>';
                            echo '</div>';
                        }
                        echo '</details>';
                    }
                    echo '</section>';
                }
            }
            echo '</div>';

            $certificates=is_array($summary['certificates']??null)?$summary['certificates']:[];
            $recent=is_array($summary['recentactivity']??null)?$summary['recentactivity']:[];
            echo '<section class="jupiter-attention-panel"><div class="jupiter-section-head"><h4>Attention needed</h4><span>'.absint($attention).' item'.($attention===1?'':'s').'</span></div>';
            if(!$attentionitems){
                echo '<div class="jupiter-all-good"><span>✓</span><div><strong>Everything looks on track</strong><small>No learning issues need your attention right now.</small></div></div>';
            } else {
                foreach(array_slice($attentionitems,0,4) as $item){
                    echo '<div class="jupiter-attention-item '.esc_attr($item['level']).'"><span>!</span><div><strong>'.esc_html($item['title']).'</strong><small>'.esc_html($item['text']).'</small></div></div>';
                }
            }
            echo '</section>';
            echo '<div class="jupiter-parent-panels">';
            echo '<section class="jupiter-panel"><div class="jupiter-panel-title"><h4>Achievements & certificates</h4></div>';
            if($certificates){
                foreach($certificates as $cert){
                    echo '<div class="jupiter-achievement"><span class="jupiter-cert-icon">★</span><div><strong>'.esc_html($cert['coursename']??$cert['name']??'Certificate').'</strong><small>Certificate earned'.(!empty($cert['issued'])?' · '.esc_html(wp_date(get_option('date_format'),(int)$cert['issued'])):'').'</small><span class="jupiter-achievement-label">Achievement recorded</span></div></div>';
                }
            } else {
                echo '<p class="jupiter-muted">Certificates will appear here when they are issued.</p>';
            }
            echo '</section>';

            echo '<section class="jupiter-panel jupiter-activity-panel"><div class="jupiter-panel-title"><h4>Learning activity</h4></div>';
            if($recent){
                $latest=$recent[0]??[];
                echo '<div class="jupiter-activity-summary"><span class="jupiter-activity-dot">✓</span><div><strong>Learning activity recorded</strong><small>'.esc_html($latest['coursename']??'').(!empty($latest['time'])?' · '.esc_html(human_time_diff((int)$latest['time'],current_time('timestamp',true))).' ago':'').'</small></div></div>';
                echo '<details class="jupiter-activity-more"><summary>View recent activity</summary><div>';
                $shown=0;
                foreach($recent as $event){
                    $shown++; if($shown>5) break;
                    $action=(string)($event['action']??'activity');
                    $target=str_replace('_',' ',(string)($event['target']??'learning activity'));
                    $label=ucfirst($action).' '.strtolower($target);
                    echo '<div class="jupiter-activity compact"><span class="jupiter-activity-dot">✓</span><div><strong>'.esc_html($label).'</strong><small>'.esc_html($event['coursename']??'').(!empty($event['time'])?' · '.esc_html(human_time_diff((int)$event['time'],current_time('timestamp',true))).' ago':'').'</small></div></div>';
                }
                echo '</div></details>';
            } else {
                echo '<p class="jupiter-muted">No recent learning activity is available.</p>';
            }
            echo '</section></div>';

            echo '<div class="jupiter-child-actions"><a class="button" href="'.esc_url(wc_get_page_permalink('shop')).'">Browse courses</a></div>';
            echo '</article>';
        }
        echo '</div>';
    } else {
        echo '<p>No children are linked to this account yet.</p>';
    }

    echo '<h3>Link a child</h3><p>Enter the temporary code generated from the learner\'s Jupiter account.</p>';
    echo '<form method="post" class="jupiter-link-form">'; wp_nonce_field('jupiter_lookup_child_code');
    echo '<input type="text" name="link_code" maxlength="14" autocomplete="off" required placeholder="XXXX-XXXX-XXXX" aria-label="Temporary child link code"> ';
    echo '<button class="button" type="submit" name="jupiter_lookup_child_code" value="1">Continue</button></form></div>';
});

add_action('wp_head',function(){
    if(is_admin()) return; ?>
    <style id="jupiter-family-css">
      .jupiter-family{max-width:900px}.jupiter-link-code,.jupiter-link-confirm,.jupiter-child-card{border:1px solid #e6e3ef;border-radius:16px;padding:22px;margin:18px 0;background:#fff;box-shadow:0 8px 28px rgba(16,35,63,.07)}
      .jupiter-link-code strong{display:block;font-size:2rem;letter-spacing:.12em;color:#10233F;margin:10px 0}
      .jupiter-link-form input{min-width:240px;padding:12px;border:1px solid #cbc6da;border-radius:10px;text-transform:uppercase}
      .jupiter-child-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px}
    </style><?php
});


/**
 * v0.7.1 account identity UX.
 * Shopping remains available to parents: purchasing is not itself permission
 * to view a child's learning record, and enrolment assignment remains a
 * separate controlled workflow.
 */

/* v0.7.3: theme header injection removed; account identity stays inside My Account. */


/* v0.7.2 — explicit Jupiter account types and role-aware customer UX. */
function jupiter_iomad_account_type($uid=0){
    $uid=$uid?:get_current_user_id();
    $type=sanitize_key((string)get_user_meta($uid,'jupiter_account_type',true));
    if(in_array($type,['learner','parent_guardian','tutor','academy'],true)) return $type;

    // Migration-safe inference for existing test accounts only.
    global $wpdb;
    if($wpdb->get_var($wpdb->prepare(
        "SELECT id FROM ".jupiter_iomad_family_table()." WHERE parent_wp_user_id=%d AND status='active' LIMIT 1",$uid
    ))) return 'parent_guardian';
    if(jupiter_iomad_current_learner_identity($uid)) return 'learner';
    return '';
}

add_action('woocommerce_register_form',function(){ ?>
    <p class="form-row form-row-wide">
      <label for="jupiter_account_type">I am registering as <span class="required">*</span></label>
      <select name="jupiter_account_type" id="jupiter_account_type" required>
        <option value="">Choose account type</option>
        <option value="parent_guardian">Parent / Guardian</option>
        <option value="learner">Learner</option>
        <option value="tutor">Tutor</option>
        <option value="academy">Academy</option>
      </select>
    </p>
<?php });
add_filter('woocommerce_registration_errors',function($errors){
    $type=sanitize_key(wp_unslash($_POST['jupiter_account_type']??''));
    if(!in_array($type,['learner','parent_guardian','tutor','academy'],true)){
        $errors->add('jupiter_account_type','Please choose a valid Jupiter account type.');
    }
    return $errors;
});
add_action('woocommerce_created_customer',function($customer_id){
    $type=sanitize_key(wp_unslash($_POST['jupiter_account_type']??''));
    if(in_array($type,['learner','parent_guardian','tutor','academy'],true)){
        update_user_meta($customer_id,'jupiter_account_type',$type);
    }
});

add_action('woocommerce_edit_account_form',function(){
    $type=jupiter_iomad_account_type();
    $labels=['learner'=>'Learner','parent_guardian'=>'Parent / Guardian','tutor'=>'Tutor','academy'=>'Academy'];
    if(isset($labels[$type])){
        echo '<p class="form-row form-row-wide"><label>Jupiter account type</label><strong>'.esc_html($labels[$type]).'</strong></p>';
    }
});

add_filter('woocommerce_account_menu_items',function($items){
    if(!is_user_logged_in()) return $items;
    $type=jupiter_iomad_account_type();
    $remove=['downloads','edit-address'];
    foreach($remove as $k) unset($items[$k]);
    unset($items['parent-access'],$items['my-children']);

    $out=[];
    foreach($items as $key=>$label){
        if($key==='customer-logout'){
            if($type==='learner') $out['parent-access']='Parent / Guardian Access';
            if($type==='parent_guardian') $out['my-children']='My Children';
        }
        $out[$key]=$label;
    }
    return $out;
},999);

add_action('wp',function(){
    if(!function_exists('is_account_page') || !is_account_page()) return;
    remove_action('woocommerce_account_dashboard','woocommerce_account_dashboard',10);
});
add_action('woocommerce_account_dashboard',function(){
    $u=wp_get_current_user(); $type=jupiter_iomad_account_type($u->ID);
    $labels=['learner'=>'Learner','parent_guardian'=>'Parent / Guardian','tutor'=>'Tutor','academy'=>'Academy'];
    $label=$labels[$type]??'Jupiter member';
    echo '<section class="jupiter-account-home"><p class="jupiter-eyebrow">Signed in as</p><h2>'.esc_html($u->display_name).'</h2><span class="jupiter-account-badge">'.esc_html($label).'</span>';
    if($type==='parent_guardian'){
        echo '<p>Manage linked children, review learning progress and browse educational courses from your Jupiter account.</p>';
        echo '<p><a class="button alt" href="'.esc_url(wc_get_account_endpoint_url('my-children')).'">View My Children</a> <a class="button" href="'.esc_url(wc_get_page_permalink('shop')).'">Browse Courses</a></p>';
    } elseif($type==='learner'){
        echo '<p>Continue your learning and manage secure parent or guardian access.</p>';
        echo '<p><a class="button alt" href="'.esc_url(wc_get_account_endpoint_url('my-courses')).'">My Courses</a> <a class="button" href="'.esc_url(wc_get_account_endpoint_url('parent-access')).'">Parent / Guardian Access</a></p>';
    }
    echo '</section>';
},20);



/* v0.7.3 — parent purchase recipient selection and clean account UX. */

function jupiter_iomad_parent_children($parentid){
    global $wpdb;
    return $wpdb->get_results($wpdb->prepare(
        "SELECT learner_iomad_user_id FROM ".jupiter_iomad_family_table().
        " WHERE parent_wp_user_id=%d AND status='active' ORDER BY verified_at DESC",
        absint($parentid)
    ));
}

function jupiter_iomad_learner_label($learnerid){
    $r=jupiter_iomad_parentlink_api('local_jupiter_parentlink_summary',['learnerid'=>absint($learnerid)]);
    if(is_wp_error($r) || empty($r['displayname'])) return 'Linked child';
    return sanitize_text_field($r['displayname']);
}

add_action('woocommerce_review_order_before_payment',function(){
    if(!is_user_logged_in() || jupiter_iomad_account_type()!=='parent_guardian') return;
    $children=jupiter_iomad_parent_children(get_current_user_id());
    echo '<section class="jupiter-course-recipient"><h3>Who is this course for?</h3>';
    echo '<p>Select who should receive the learning access. The purchaser and learner can be different people.</p>';
    echo '<label class="jupiter-recipient-option"><input type="radio" name="jupiter_course_recipient" value="self" checked> <strong>Myself</strong></label>';
    foreach($children as $child){
        $id=absint($child->learner_iomad_user_id);
        echo '<label class="jupiter-recipient-option"><input type="radio" name="jupiter_course_recipient" value="child:'.esc_attr($id).'"> <strong>'.esc_html(jupiter_iomad_learner_label($id)).'</strong> <span>Linked child</span></label>';
    }
    if(!$children) echo '<p><small>No linked children yet. You can link a child from My Account → My Children.</small></p>';
    echo '</section>';
},8);

add_action('woocommerce_checkout_create_order',function($order){
    if(!is_user_logged_in() || jupiter_iomad_account_type()!=='parent_guardian') return;
    $raw=sanitize_text_field(wp_unslash($_POST['jupiter_course_recipient']??'self'));
    if($raw==='self'){
        $order->update_meta_data('_jupiter_recipient_type','self');
        $order->update_meta_data('_jupiter_recipient_wp_user_id',get_current_user_id());
        return;
    }
    if(strpos($raw,'child:')===0){
        $learnerid=absint(substr($raw,6));
        // Never trust the posted learner ID: verify the active relationship server-side.
        if($learnerid && jupiter_iomad_family_active_relationship(get_current_user_id(),$learnerid)){
            $order->update_meta_data('_jupiter_recipient_type','linked_child');
            $order->update_meta_data('_jupiter_recipient_iomad_user_id',$learnerid);
            return;
        }
    }
    throw new Exception('Please select a valid course recipient.');
},20);

/*
 * IMPORTANT: v0.7.3 records the verified recipient on the order.
 * Existing paid-order provisioning is deliberately not silently redirected
 * until the child-recipient provisioning branch is explicitly tested.
 */



/* v0.7.4 — scoped My Account presentation. No global WooCommerce grid overrides. */
add_action('wp_head',function(){
    if(is_admin() || !is_user_logged_in() || !function_exists('is_account_page') || !is_account_page()) return; ?>
<style id="jupiter-account-ux-074">
body.logged-in.woocommerce-account .woocommerce-MyAccount-navigation{
  float:left!important;width:28%!important;max-width:300px!important;margin:0 4% 30px 0!important;
}
body.logged-in.woocommerce-account .woocommerce-MyAccount-content{
  float:left!important;width:68%!important;max-width:none!important;margin:0!important;min-width:0!important;
}
body.logged-in.woocommerce-account .woocommerce:after{content:"";display:table;clear:both}
body.logged-in.woocommerce-account .woocommerce-MyAccount-navigation ul{
  margin:0!important;padding:0!important;list-style:none!important;border:1px solid #eceaf2!important;
  border-radius:14px!important;overflow:hidden!important;background:#fff!important;
}
body.logged-in.woocommerce-account .woocommerce-MyAccount-navigation li{
  margin:0!important;padding:0!important;border-bottom:1px solid #eceaf2!important;
}
body.logged-in.woocommerce-account .woocommerce-MyAccount-navigation li:last-child{border-bottom:0!important}
body.logged-in.woocommerce-account .woocommerce-MyAccount-navigation a{
  display:block!important;padding:14px 18px!important;text-decoration:none!important;
}
body.logged-in.woocommerce-account .jupiter-family{max-width:100%!important}
body.logged-in.woocommerce-account .jupiter-child-grid{display:grid;grid-template-columns:1fr;gap:18px}
body.logged-in.woocommerce-account .jupiter-child-card{width:auto!important;max-width:100%!important;box-sizing:border-box!important}
body.logged-in.woocommerce-account .jupiter-link-form{display:flex;gap:12px;align-items:center;flex-wrap:wrap}
body.logged-in.woocommerce-account .jupiter-link-form input{flex:1 1 260px;max-width:420px}
@media(max-width:800px){
 body.logged-in.woocommerce-account .woocommerce-MyAccount-navigation,
 body.logged-in.woocommerce-account .woocommerce-MyAccount-content{
   float:none!important;width:100%!important;max-width:none!important;margin:0 0 28px!important;
 }
 body.logged-in.woocommerce-account .woocommerce-MyAccount-navigation ul{border-radius:12px!important}
}
</style>
<?php },1100);

add_action('wp_head',function(){
    if(is_admin() || is_user_logged_in() || !function_exists('is_account_page') || !is_account_page()) return; ?>
<style id="jupiter-registration-ux-074">
.woocommerce-account .woocommerce form .form-row select#jupiter_account_type{
 width:100%;min-height:46px;padding:8px 10px;border:1px solid #d9d6e2;border-radius:8px;background:#fff;
}
</style>
<?php },1100);

add_action('wp_head',function(){
 if(is_admin() || !is_user_logged_in() || !function_exists('is_account_page') || !is_account_page()) return; ?>
<style id="jupiter-parent-dashboard-075">
.jupiter-child-dashboard{padding:28px!important}
.jupiter-child-head{display:flex!important;gap:16px;align-items:center;margin-bottom:24px}
.jupiter-child-head h3{margin:0 0 4px!important;font-size:1.45rem!important}
.jupiter-avatar{width:56px!important;height:56px!important;flex:0 0 56px;display:flex!important;align-items:center;justify-content:center;border-radius:50%;background:#f1eef9;font-weight:800}
.jupiter-verified{font-size:.88rem;color:#667085}
.jupiter-stat-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:20px 0 30px}
.jupiter-stat{border:1px solid #ece9f3;border-radius:14px;padding:16px;min-width:0}
.jupiter-stat strong{display:block;font-size:1.35rem;margin-bottom:5px}
.jupiter-stat span{font-size:.8rem;color:#667085}
.jupiter-course-list h4{font-size:1.15rem;margin:0 0 10px}
.jupiter-course-progress{padding:18px 0;border-top:1px solid #ece9f3}
.jupiter-course-row,.jupiter-progress-meta{display:flex;justify-content:space-between;gap:14px;align-items:center}
.jupiter-progress-meta{margin:9px 0 8px;font-size:.86rem;color:#667085}
.jupiter-progressbar{height:10px;border-radius:999px;background:#eceaf1;overflow:hidden}
.jupiter-progressbar span{display:block;height:100%;border-radius:999px;background:#5b34d6}
.jupiter-status{font-size:.76rem;font-weight:700;padding:5px 9px;border-radius:999px;background:#f2f1f5;white-space:nowrap}
.jupiter-status.completed{background:#edf7ef}.jupiter-status.in-progress{background:#fff4d8}
.jupiter-course-progress small{display:block;margin-top:7px;color:#667085}
.jupiter-child-actions{margin-top:20px}
.jupiter-empty{padding:16px;border-radius:12px;background:#f8f7fa;color:#667085}
@media(max-width:1050px){.jupiter-stat-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:600px){
 .jupiter-child-dashboard{padding:18px!important}.jupiter-stat-grid{grid-template-columns:1fr 1fr}
 .jupiter-course-row,.jupiter-progress-meta{align-items:flex-start;flex-direction:column;gap:5px}
}
</style>
<?php },1120);

add_action('wp_head',function(){
 if(is_admin() || !is_user_logged_in() || !function_exists('is_account_page') || !is_account_page()) return; ?>
<style id="jupiter-parent-dashboard-080">
.jupiter-course-details{margin-top:14px;border:1px solid #ebe7f4;border-radius:12px;background:#faf9fd}
.jupiter-course-details summary{cursor:pointer;padding:12px 14px;font-weight:700;color:#4b2bbf;list-style:none}
.jupiter-course-details summary::-webkit-details-marker{display:none}
.jupiter-course-details summary:after{content:"+";float:right;font-size:1.2rem}
.jupiter-course-details[open] summary:after{content:"−"}
.jupiter-course-details[open] summary{border-bottom:1px solid #ebe7f4}
.jupiter-course-details>div,.jupiter-course-details>h5,.jupiter-course-details>p{margin-left:14px;margin-right:14px}
.jupiter-mini-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;padding:14px 0}
.jupiter-mini-stats span{padding:11px;border-radius:10px;background:#fff;color:#667085;font-size:.82rem}
.jupiter-mini-stats b{display:block;color:#17233c;font-size:1.05rem}
.jupiter-course-details h5{margin-top:12px;margin-bottom:8px;font-size:.95rem}
.jupiter-unit{padding:10px 0;border-top:1px solid #efedf5}
.jupiter-unit>div:first-child{display:flex;justify-content:space-between;gap:12px}
.jupiter-progressbar.small{height:7px;margin:7px 0}
.jupiter-unit small,.jupiter-achievement small,.jupiter-activity small{display:block;color:#667085;margin-top:3px}
.jupiter-assessment-list{padding-bottom:10px}
.jupiter-assessment{display:flex;justify-content:space-between;gap:12px;padding:9px 0;border-top:1px solid #efedf5;font-size:.88rem}
.jupiter-assessment .pass{color:#217a4a}.jupiter-assessment .review{color:#9b5b00}
.jupiter-parent-panels{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:28px}
.jupiter-panel{border:1px solid #ebe7f4;border-radius:16px;padding:18px;background:#fff}
.jupiter-panel-title h4{margin:0 0 12px;font-size:1.05rem}
.jupiter-achievement,.jupiter-activity{display:flex;gap:11px;align-items:flex-start;padding:11px 0;border-top:1px solid #f0eef5}
.jupiter-cert-icon,.jupiter-activity-dot{width:34px;height:34px;flex:0 0 34px;border-radius:10px;display:flex;align-items:center;justify-content:center;background:#fff3cf;color:#8b6200;font-weight:800}
.jupiter-activity-dot{background:#efeafd;color:#5532c8}
.jupiter-muted{color:#667085;font-size:.9rem}
@media(max-width:800px){
 .jupiter-parent-panels{grid-template-columns:1fr}
 .jupiter-mini-stats{grid-template-columns:1fr}
 .jupiter-assessment{flex-direction:column;gap:4px}
}
</style>
<?php },1130);

add_action('wp_head',function(){
 if(is_admin() || !is_user_logged_in() || !function_exists('is_account_page') || !is_account_page()) return; ?>
<style id="jupiter-parent-dashboard-081">
.jupiter-child-dashboard{background:linear-gradient(180deg,#fff 0,#fcfbff 100%)}
.jupiter-glance{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:0 0 30px}
.jupiter-glance>div{display:flex;align-items:center;gap:12px;padding:14px 16px;border:1px solid #ebe7f4;border-radius:14px;background:#fff}
.jupiter-glance-icon{width:38px;height:38px;border-radius:11px;display:flex;align-items:center;justify-content:center;background:#f4efff;color:#5b34d6;font-weight:800}
.jupiter-glance p{margin:0}.jupiter-glance strong{display:block;font-size:1.05rem}.jupiter-glance small{display:block;color:#667085}
.jupiter-section-head{display:flex;justify-content:space-between;align-items:center;gap:15px;margin-bottom:8px}
.jupiter-section-head h4{margin:0}.jupiter-section-head span{font-size:.8rem;color:#8a8398}
.jupiter-activity-summary{display:flex;gap:11px;align-items:flex-start;padding:8px 0}
.jupiter-activity-more{margin-top:10px;border-top:1px solid #f0eef5}
.jupiter-activity-more summary{cursor:pointer;padding:12px 0;color:#5532c8;font-weight:700;list-style:none}
.jupiter-activity-more summary:after{content:"+";float:right}.jupiter-activity-more[open] summary:after{content:"−"}
.jupiter-activity.compact{padding:9px 0}.jupiter-activity.compact strong{font-size:.86rem}
.jupiter-activity-panel{align-self:start}
@media(max-width:650px){
 .jupiter-glance{grid-template-columns:1fr}.jupiter-section-head{align-items:flex-start;flex-direction:column;gap:3px}
}
</style>
<?php },1140);

add_action('wp_head',function(){
 if(is_admin() || !is_user_logged_in() || !function_exists('is_account_page') || !is_account_page()) return; ?>
<style id="jupiter-parent-dashboard-090">
/* Jupiter Parent Dashboard — mature, all-age visual system */
.jupiter-child-dashboard{
 border:0!important;border-radius:22px!important;padding:0!important;overflow:hidden;
 background:#fff!important;box-shadow:0 14px 42px rgba(29,18,67,.08)
}
.jupiter-child-head{
 margin:0!important;padding:26px 28px!important;
 background:linear-gradient(110deg,#29145f 0%,#4d22a8 58%,#6c35db 100%);
 color:#fff
}
.jupiter-child-head h3{color:#fff!important;font-size:1.65rem!important}
.jupiter-child-head .jupiter-avatar{
 background:rgba(255,255,255,.14)!important;color:#fff!important;
 border:1px solid rgba(255,255,255,.25)
}
.jupiter-child-head .jupiter-verified{color:#efe9ff!important}
.jupiter-stat-grid{padding:0 28px;margin:24px 0 16px!important}
.jupiter-stat{background:#fff!important;border:1px solid #ece8f5!important;box-shadow:0 5px 18px rgba(35,20,70,.04)}
.jupiter-stat strong{color:#251453;font-size:1.55rem!important}
.jupiter-glance{padding:0 28px;margin-bottom:30px!important}
.jupiter-glance>div{box-shadow:0 4px 14px rgba(35,20,70,.035)}
.jupiter-glance>div:first-child .jupiter-glance-icon{background:#fff2c9;color:#8b6400}
.jupiter-glance>div:nth-child(2) .jupiter-glance-icon{background:#e9f8ef;color:#197247}
.jupiter-glance>div:nth-child(3) .jupiter-glance-icon{background:#f2edff;color:#5b34d6}
.jupiter-course-list{padding:0 28px}
.jupiter-section-head{padding-bottom:12px;border-bottom:1px solid #ece8f5}
.jupiter-section-head h4{font-size:1.3rem!important;color:#17233c}
.jupiter-course-progress{
 margin:16px 0!important;padding:20px!important;border:1px solid #ece8f5!important;
 border-radius:16px;background:#fff;box-shadow:0 5px 18px rgba(35,20,70,.035)
}
.jupiter-course-row strong{font-size:1.03rem;color:#283858}
.jupiter-progressbar{height:9px!important;background:#eeeaf5!important}
.jupiter-progressbar span{background:linear-gradient(90deg,#5a31d4,#7a42e8)!important}
.jupiter-course-details{background:#fbfaff!important;margin-top:16px!important}
.jupiter-course-details:not([open]){background:#fff!important}
.jupiter-course-details summary{color:#5428c7!important}
.jupiter-parent-panels{padding:0 28px;margin:28px 0 0!important}
.jupiter-panel{box-shadow:0 5px 18px rgba(35,20,70,.035)}
.jupiter-panel-title h4{color:#17233c}
.jupiter-achievement{background:linear-gradient(90deg,#fffaf0,#fff);border-radius:12px;padding:12px!important}
.jupiter-cert-icon{background:#ffedb5!important;color:#825b00!important}
.jupiter-activity-more:not([open])>div{display:none}
.jupiter-child-actions{padding:22px 28px 30px!important;margin:0!important}
.jupiter-child-actions .button{
 border-radius:999px!important;padding:12px 24px!important;
 background:#ffc84d!important;color:#17233c!important;border:0!important;font-weight:700!important
}
@media(max-width:800px){
 .jupiter-child-head{padding:22px 18px!important}
 .jupiter-stat-grid,.jupiter-glance,.jupiter-course-list,.jupiter-parent-panels{padding-left:18px;padding-right:18px}
 .jupiter-child-actions{padding:20px 18px 24px!important}
}
</style>
<?php },1150);

add_action('wp_head',function(){
 if(is_admin() || !is_user_logged_in() || !function_exists('is_account_page') || !is_account_page()) return; ?>
<style id="jupiter-parent-dashboard-100">
.jupiter-parent-welcome{display:flex;justify-content:space-between;gap:24px;align-items:center;margin:0 0 24px;padding:24px 26px;border:1px solid #e9e4f4;border-radius:18px;background:linear-gradient(100deg,#faf8ff 0%,#fff 65%,#fff9e9 100%)}
.jupiter-parent-welcome h2{margin:3px 0 5px!important;font-size:1.75rem!important;color:#1b1535}.jupiter-parent-welcome p{margin:0;color:#667085}
.jupiter-eyebrow{font-size:.72rem;letter-spacing:.12em;font-weight:800;color:#6737d5}
.jupiter-outline-button{background:#fff!important;color:#4e27bd!important;border:1px solid #d8cff1!important;border-radius:999px!important;padding:10px 16px!important;white-space:nowrap}
.jupiter-family-heading{display:flex;justify-content:space-between;align-items:center;gap:15px;margin:0 0 14px}
.jupiter-family-heading h3{margin:0!important;color:#17233c}.jupiter-family-heading span{font-size:.82rem;color:#7b7489}
.jupiter-child-grid{gap:24px!important}.jupiter-child-dashboard{transition:transform .18s ease,box-shadow .18s ease}
.jupiter-child-dashboard:hover{transform:translateY(-1px);box-shadow:0 18px 48px rgba(29,18,67,.11)}
#jupiter-link-child{margin-top:34px!important;padding-top:8px}
@media(max-width:720px){.jupiter-parent-welcome{align-items:flex-start;flex-direction:column;padding:20px}.jupiter-parent-actions,.jupiter-parent-actions .button{width:100%;text-align:center}}
</style>
<?php },1160);

add_action('wp_head',function(){
 if(is_admin() || !is_user_logged_in() || !function_exists('is_account_page') || !is_account_page()) return; ?>
<style id="jupiter-parent-dashboard-110">
.jupiter-attention-panel{margin:28px 28px 0;padding:18px;border:1px solid #ebe7f4;border-radius:16px;background:#fff;box-shadow:0 5px 18px rgba(35,20,70,.035)}
.jupiter-attention-panel .jupiter-section-head{margin-bottom:0}
.jupiter-all-good,.jupiter-attention-item{display:flex;gap:12px;align-items:flex-start;margin-top:12px;padding:13px 14px;border-radius:12px}
.jupiter-all-good{background:#edf9f1}.jupiter-all-good>span{color:#167246;font-weight:900}
.jupiter-all-good strong,.jupiter-attention-item strong{display:block;color:#17233c}
.jupiter-all-good small,.jupiter-attention-item small{display:block;color:#667085;margin-top:3px;line-height:1.45}
.jupiter-attention-item{background:#fff7e7;border:1px solid #f5dfac}
.jupiter-attention-item.info{background:#f5f2ff;border-color:#e4dcfa}
.jupiter-attention-item>span{width:28px;height:28px;flex:0 0 28px;display:flex;align-items:center;justify-content:center;border-radius:8px;background:#ffe6a7;color:#7c5500;font-weight:900}
.jupiter-attention-item.info>span{background:#e9e1ff;color:#5731c7}
.jupiter-achievement-label{display:inline-block;margin-top:7px;padding:3px 7px;border-radius:999px;background:#fff1c8;color:#765400;font-size:.7rem;font-weight:700}
@media(max-width:800px){.jupiter-attention-panel{margin-left:18px;margin-right:18px}}
</style>
<?php },1170);

add_action('wp_head',function(){
 if(is_admin() || !is_user_logged_in() || !function_exists('is_account_page') || !is_account_page()) return; ?>
<style id="jupiter-parent-dashboard-111-hotfix">
/* Woo account content can be narrow even on desktop; size cards to their container. */
.jupiter-parent-welcome{
 display:grid!important;grid-template-columns:minmax(0,1fr)!important;
 gap:16px!important;align-items:start!important
}
.jupiter-parent-actions{justify-self:start!important}
.jupiter-parent-welcome h2{
 font-size:clamp(1.55rem,4vw,2rem)!important;
 line-height:1.12!important;overflow-wrap:normal!important;word-break:normal!important
}
.jupiter-stat-grid{
 display:grid!important;
 grid-template-columns:repeat(auto-fit,minmax(145px,1fr))!important;
 gap:12px!important
}
.jupiter-stat{min-width:145px!important}
.jupiter-stat strong,.jupiter-stat span{
 overflow-wrap:normal!important;word-break:normal!important;hyphens:none!important
}
.jupiter-glance{
 display:grid!important;
 grid-template-columns:repeat(auto-fit,minmax(160px,1fr))!important
}
.jupiter-parent-panels{
 grid-template-columns:repeat(auto-fit,minmax(240px,1fr))!important
}
.jupiter-child-head{flex-wrap:wrap!important}
.jupiter-child-head>div{min-width:0!important}
.jupiter-child-head h3,.jupiter-verified{overflow-wrap:normal!important;word-break:normal!important}
.jupiter-course-row,.jupiter-progress-meta{flex-wrap:wrap!important}
@media(max-width:700px){
 .jupiter-stat-grid{grid-template-columns:1fr 1fr!important}
 .jupiter-stat{min-width:0!important}
}
@media(max-width:420px){
 .jupiter-stat-grid,.jupiter-glance,.jupiter-parent-panels{grid-template-columns:1fr!important}
}
</style>
<?php },1190);

add_action('wp_head',function(){
 if(is_admin()||!is_user_logged_in()||!function_exists('is_account_page')||!is_account_page())return; ?>
<style id="jupiter-parent-learning-hub-120">
.jupiter-stat-link{text-decoration:none!important;color:inherit!important}.jupiter-stat-link small{display:block;margin-top:9px;color:#6334d7;font-weight:700;font-size:.72rem}
.jupiter-glance>a{display:flex;align-items:center;gap:12px;padding:14px 16px;border:1px solid #ebe7f4;border-radius:14px;background:#fff;text-decoration:none!important;color:inherit!important}.jupiter-glance>a:first-child .jupiter-glance-icon{background:#fff2c9;color:#8b6400}.jupiter-glance>a:nth-child(2) .jupiter-glance-icon{background:#e9f8ef;color:#197247}
.jupiter-detail-shell{border:1px solid #e8e2f2;border-radius:22px;overflow:hidden;background:#fff;box-shadow:0 14px 42px rgba(29,18,67,.07)}
.jupiter-detail-hero{display:flex;justify-content:space-between;align-items:center;gap:20px;padding:25px 28px;background:linear-gradient(110deg,#29145f,#5530bd 60%,#7138e1);color:#fff}.jupiter-detail-person{display:flex;align-items:center;gap:15px}.jupiter-detail-person h2{color:#fff!important;margin:2px 0!important;font-size:1.65rem!important}.jupiter-detail-person p{margin:0;color:#efeaff}.jupiter-detail-hero .jupiter-eyebrow{color:#f4d66c}.jupiter-back{color:#fff!important;text-decoration:none!important;border:1px solid rgba(255,255,255,.35);border-radius:999px;padding:8px 13px}
.jupiter-detail-tabs{display:flex;gap:4px;padding:12px 18px;border-bottom:1px solid #eee9f5;overflow-x:auto}.jupiter-detail-tabs a{padding:9px 13px;border-radius:10px;text-decoration:none!important;color:#5d5870!important;white-space:nowrap;font-weight:700;font-size:.86rem}.jupiter-detail-tabs a.active{background:#f1ebff;color:#5527c8!important}
.jupiter-detail-heading{display:flex;justify-content:space-between;align-items:end;gap:15px;padding:26px 28px 12px}.jupiter-detail-heading h3{margin:3px 0 0!important}.jupiter-detail-heading>span{color:#777084;font-size:.82rem}
.jupiter-detail-card{margin:12px 28px 18px;padding:20px;border:1px solid #ebe6f3;border-radius:16px;background:#fff}.jupiter-detail-card h4{margin:2px 0 12px!important}.jupiter-card-actions{display:flex;gap:10px;margin-top:15px}.jupiter-card-actions a{padding:8px 11px;border-radius:9px;background:#f3effc;text-decoration:none!important;font-weight:700;font-size:.8rem}.jupiter-report-stats{margin:18px 0!important}
.jupiter-result-row{display:flex;justify-content:space-between;align-items:center;gap:15px;padding:14px 0;border-top:1px solid #f0edf5}.jupiter-result-row small{display:block;color:#777084;margin-top:3px}.jupiter-result-score{text-align:right}.jupiter-result-score b{display:block;font-size:1.05rem}.jupiter-result-score span{font-size:.75rem;font-weight:700}.jupiter-result-score.pass{color:#187247}.jupiter-result-score.review{color:#9a5d00}
.jupiter-certificate-card{display:flex;gap:18px;align-items:flex-start;margin:12px 28px 18px;padding:22px;border:1px solid #efe2ad;border-radius:16px;background:linear-gradient(100deg,#fffaf0,#fff)}.jupiter-certificate-seal{width:50px;height:50px;flex:0 0 50px;display:flex;align-items:center;justify-content:center;border-radius:14px;background:#ffe8a3;color:#805b00;font-size:1.35rem}.jupiter-certificate-card h4{margin:4px 0!important}
.jupiter-click-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;padding:5px 28px 22px}.jupiter-click-stats a{padding:18px;border:1px solid #e9e4f2;border-radius:14px;text-decoration:none!important;color:inherit!important}.jupiter-click-stats strong{display:block;font-size:1.5rem;color:#24134f}.jupiter-click-stats span{display:block;margin-top:4px}.jupiter-click-stats small{display:block;margin-top:10px;color:#6032d0;font-weight:700}.jupiter-parent-note{margin:12px 28px 26px;padding:14px 16px;border-radius:12px;background:#f8f6fc;color:#615a70;line-height:1.5}
@media(max-width:760px){.jupiter-detail-hero{align-items:flex-start;flex-direction:column}.jupiter-detail-heading,.jupiter-detail-card,.jupiter-certificate-card,.jupiter-parent-note{margin-left:18px;margin-right:18px}.jupiter-detail-heading{padding-left:0;padding-right:0}.jupiter-click-stats{padding-left:18px;padding-right:18px}}
</style><?php },1200);

add_action('wp_head',function(){if(is_admin()||!is_user_logged_in()||!function_exists('is_account_page')||!is_account_page())return;?><style id="jupiter-parent-reports-130">
.jupiter-report-grid,.jupiter-assessment-summary{display:grid;grid-template-columns:repeat(auto-fit,minmax(135px,1fr));gap:12px;padding:4px 28px 18px}.jupiter-report-grid>div,.jupiter-assessment-summary>div{padding:17px;border:1px solid #ebe6f3;border-radius:14px;background:#fff}.jupiter-report-grid strong,.jupiter-assessment-summary strong{display:block;color:#251453;font-size:1.35rem}.jupiter-report-grid span,.jupiter-assessment-summary span{display:block;margin-top:4px;color:#70697d;font-size:.78rem}.jupiter-report-course{display:flex;justify-content:space-between;align-items:center;gap:18px;padding:14px 0;border-top:1px solid #f0edf5}.jupiter-report-course:first-of-type{border-top:0}.jupiter-report-course>div:last-child{text-align:right}.jupiter-report-course small{display:block;color:#777084;margin-top:3px}.jupiter-cert-meta{margin-top:12px;padding:10px 12px;border-radius:10px;background:#fff7df}.jupiter-cert-meta span{display:block;font-size:.7rem;color:#766b4c}.jupiter-cert-meta code{display:block;margin-top:3px;overflow-wrap:anywhere;color:#4d4020;background:transparent}@media(max-width:760px){.jupiter-report-grid,.jupiter-assessment-summary{padding-left:18px;padding-right:18px}.jupiter-report-course{align-items:flex-start}}</style><?php },1210);
add_action('wp_head',function(){if(is_admin()||!is_user_logged_in())return;?><style>.jupiter-cert-actions{margin-top:14px}.jupiter-cert-actions .button{border-radius:10px!important;background:#5b31ce!important;color:#fff!important;border:0!important;padding:9px 14px!important}</style><?php },1220);
add_action('wp_head',function(){if(is_admin()||!is_user_logged_in())return;?><style id="jupiter-cert-141">
.jupiter-cert-actions{display:flex;gap:10px;flex-wrap:wrap}.jupiter-cert-actions .jupiter-cert-download{background:#fff!important;color:#5b31ce!important;border:1px solid #cfc1f4!important}
</style><?php },1230);

/* Jupiter Parent Notifications & Achievements v1.5.0 */
function jupiter_parent_notification_defaults(){
    return ['course_completed'=>1,'certificate_earned'=>1,'learning_reminder'=>0,'weekly_summary'=>0];
}
function jupiter_parent_notification_preferences($userid){
    $saved=get_user_meta($userid,'jupiter_parent_notification_preferences',true);
    return wp_parse_args(is_array($saved)?$saved:[],jupiter_parent_notification_defaults());
}
add_action('init',function(){
    add_rewrite_endpoint('parent-notifications',EP_ROOT|EP_PAGES);
});
add_filter('query_vars',function($vars){$vars[]='parent-notifications';return $vars;});
add_filter('woocommerce_account_menu_items',function($items){
    if(!is_user_logged_in()) return $items;
    global $wpdb;
    $table=$wpdb->prefix.'jupiter_family_relationships';
    $isparent=(bool)$wpdb->get_var($wpdb->prepare(
        "SELECT 1 FROM {$table} WHERE parent_wp_user_id=%d AND status='active' LIMIT 1",
        get_current_user_id()
    ));
    if(!$isparent) return $items;
    $out=[];
    foreach($items as $k=>$v){
        if($k==='customer-logout') $out['parent-notifications']='Notifications';
        $out[$k]=$v;
    }
    return $out;
},35);

add_action('woocommerce_account_parent-notifications_endpoint',function(){
    if(!is_user_logged_in()) return;
    $uid=get_current_user_id();
    global $wpdb;
    $table=$wpdb->prefix.'jupiter_family_relationships';
    $isparent=(bool)$wpdb->get_var($wpdb->prepare(
        "SELECT 1 FROM {$table} WHERE parent_wp_user_id=%d AND status='active' LIMIT 1",$uid
    ));
    if(!$isparent){echo '<p>This area is available to authorised parent/guardian accounts.</p>';return;}
    if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['jupiter_parent_notifications_nonce']) &&
       wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['jupiter_parent_notifications_nonce'])),'jupiter_parent_notifications')){
        $prefs=[
          'course_completed'=>isset($_POST['course_completed'])?1:0,
          'certificate_earned'=>isset($_POST['certificate_earned'])?1:0,
          'learning_reminder'=>isset($_POST['learning_reminder'])?1:0,
          'weekly_summary'=>isset($_POST['weekly_summary'])?1:0,
        ];
        update_user_meta($uid,'jupiter_parent_notification_preferences',$prefs);
        echo '<div class="woocommerce-message" role="alert">Notification preferences saved.</div>';
    }
    $p=jupiter_parent_notification_preferences($uid);
    echo '<section class="jupiter-parent-prefs"><div class="jupiter-parent-eyebrow">PARENT SETTINGS</div><h2>Learning notifications</h2>';
    echo '<p class="jupiter-parent-muted">Choose which learning updates you would like to receive. These preferences do not change your access to your child’s learning information.</p>';
    echo '<form method="post">';
    wp_nonce_field('jupiter_parent_notifications','jupiter_parent_notifications_nonce');
    $rows=[
      'course_completed'=>['Course completed','Receive an update when a linked learner completes a course.'],
      'certificate_earned'=>['Certificate earned','Receive an update when a linked learner earns a certificate.'],
      'learning_reminder'=>['Learning reminder','Receive an occasional reminder when learning appears inactive.'],
      'weekly_summary'=>['Weekly learning summary','Receive a concise weekly summary of linked learner progress.'],
    ];
    foreach($rows as $key=>$r){
      echo '<label class="jupiter-pref-row"><span><strong>'.esc_html($r[0]).'</strong><small>'.esc_html($r[1]).'</small></span><input type="checkbox" name="'.esc_attr($key).'" value="1" '.checked(!empty($p[$key]),true,false).'></label>';
    }
    echo '<button type="submit" class="button">Save preferences</button></form>';
    echo '<div class="jupiter-parent-note"><strong>Privacy</strong><br>Notifications will contain only the minimum learning information needed for the update. Detailed learner information remains inside the authenticated Parent Dashboard.</div></section>';
});

add_action('wp_head',function(){if(is_admin()||!is_user_logged_in())return;?><style id="jupiter-parent-notifications-150">
.jupiter-parent-prefs{max-width:760px}.jupiter-parent-eyebrow{font-size:12px;letter-spacing:.14em;font-weight:700;color:#6737dc;margin-bottom:8px}.jupiter-parent-muted{color:#71667b}.jupiter-pref-row{display:flex;justify-content:space-between;gap:24px;align-items:center;border:1px solid #e7e0f2;border-radius:14px;padding:16px 18px;margin:12px 0;background:#fff}.jupiter-pref-row span{display:flex;flex-direction:column;gap:4px}.jupiter-pref-row small{font-size:13px;color:#756b7d}.jupiter-pref-row input{width:20px;height:20px;flex:0 0 auto}.jupiter-parent-prefs .button{margin-top:8px;border-radius:10px!important;background:#5b31ce!important;color:#fff!important;border:0!important;padding:10px 16px!important}
</style><?php },1240);
add_action('wp_head',function(){if(is_admin()||!is_user_logged_in())return;?><style id="jupiter-achievements-150">
.jupiter-achievement-badge{display:inline-block;margin:10px 0 14px;padding:7px 10px;border-radius:999px;background:#fff4cc;color:#6b5200;font-size:12px;font-weight:700}
</style><?php },1241);

add_filter('woocommerce_account_menu_items',function($items){
    if(!isset($items['my-children']) && !isset($items['parent-notifications'])) return $items;
    $out=[];
    foreach($items as $k=>$v){
        if(in_array($k,['my-children','parent-notifications'],true)) continue;
        if($k==='customer-logout'){
            if(isset($items['my-children'])) $out['my-children']=$items['my-children'];
            if(isset($items['parent-notifications'])) $out['parent-notifications']=$items['parent-notifications'];
        }
        $out[$k]=$v;
    }
    return $out;
},1200);


/* Jupiter Parent Event Notifications v1.6.0
 * Uses WP-Cron every 15 minutes. First observation is baseline only.
 * Subsequent newly observed completion/certificate events are mailed once.
 */
function jupiter_parent_notification_event_key($parentid,$learnerid,$type,$courseid,$identity=''){
    return 'jpn_'.hash('sha256',implode('|',[absint($parentid),absint($learnerid),sanitize_key($type),absint($courseid),(string)$identity]));
}
function jupiter_parent_notification_sent($key){
    global $wpdb;
    return (bool)$wpdb->get_var($wpdb->prepare(
        "SELECT option_id FROM {$wpdb->options} WHERE option_name=%s LIMIT 1",'_jupiter_notify_'.$key
    ));
}
function jupiter_parent_notification_mark_sent($key){
    add_option('_jupiter_notify_'.$key,(string)time(),'','no');
}
function jupiter_parent_notification_mail($parent,$learnername,$type,$coursename,$dashboardurl){
    $subject=$type==='certificate_earned'
      ? sprintf('%s earned a certificate',$learnername)
      : sprintf('%s completed a course',$learnername);
    $headline=$type==='certificate_earned'?'Certificate earned':'Course completed';
    $body='<p>Hello '.esc_html($parent->display_name).',</p>'
         .'<p><strong>'.esc_html($learnername).'</strong> has reached a new learning milestone.</p>'
         .'<p><strong>'.esc_html($headline).':</strong> '.esc_html($coursename).'</p>'
         .'<p><a href="'.esc_url($dashboardurl).'">View the Parent Dashboard</a> for the full learning record.</p>'
         .'<p>Jupiter The Scholar</p>';
    return wp_mail($parent->user_email,$subject,$body,['Content-Type: text/html; charset=UTF-8']);
}
function jupiter_parent_notification_scan(){
    global $wpdb;
    $table=$wpdb->prefix.'jupiter_family_relationships';
    $rels=$wpdb->get_results("SELECT parent_wp_user_id,learner_iomad_user_id FROM {$table} WHERE status='active'");
    foreach($rels as $rel){
        $parentid=absint($rel->parent_wp_user_id);$learnerid=absint($rel->learner_iomad_user_id);
        $parent=get_userdata($parentid); if(!$parent || !is_email($parent->user_email)) continue;
        $summary=jupiter_iomad_parentlink_api('local_jupiter_parentlink_summary',['learnerid'=>$learnerid]);
        if(is_wp_error($summary)||!is_array($summary)) continue;
        $learnername=sanitize_text_field($summary['displayname']??'Linked learner');
        $baselinekey='_jupiter_notify_baseline_'.$parentid.'_'.$learnerid;
        $baseline=get_option($baselinekey,null);
        $current=['completed'=>[],'certificates'=>[]];
        foreach((array)($summary['courses']??[]) as $c){
            if(!empty($c['completed'])){
                $cid=absint($c['courseid']??0);
                if($cid)$current['completed'][(string)$cid]=sanitize_text_field($c['coursename']??'Course');
            }
        }
        foreach((array)($summary['certificates']??[]) as $c){
            $cid=absint($c['courseid']??0);$code=(string)($c['code']??'');
            if($cid && $code!=='')$current['certificates'][$cid.'|'.$code]=sanitize_text_field($c['coursename']??'Course');
        }
        // First scan creates a historical baseline. No existing achievement email is sent.
        if($baseline===null || !is_array($baseline)){
            update_option($baselinekey,$current,false); continue;
        }
        $prefs=jupiter_parent_notification_preferences($parentid);
        $dashboard=wc_get_account_endpoint_url('my-children');
        if(!empty($prefs['course_completed'])){
            foreach(array_diff_key($current['completed'],(array)($baseline['completed']??[])) as $cid=>$name){
                $key=jupiter_parent_notification_event_key($parentid,$learnerid,'course_completed',$cid);
                if(!jupiter_parent_notification_sent($key) &&
                   jupiter_parent_notification_mail($parent,$learnername,'course_completed',$name,$dashboard)){
                    jupiter_parent_notification_mark_sent($key);
                }
            }
        }
        if(!empty($prefs['certificate_earned'])){
            foreach(array_diff_key($current['certificates'],(array)($baseline['certificates']??[])) as $identity=>$name){
                [$cid,$code]=array_pad(explode('|',$identity,2),2,'');
                $key=jupiter_parent_notification_event_key($parentid,$learnerid,'certificate_earned',$cid,$code);
                if(!jupiter_parent_notification_sent($key) &&
                   jupiter_parent_notification_mail($parent,$learnername,'certificate_earned',$name,$dashboard)){
                    jupiter_parent_notification_mark_sent($key);
                }
            }
        }
        // Advance snapshot after processing. Failed wp_mail remains eligible only until this scan ends;
        // sent marker is written only after wp_mail reports successful handoff.
        update_option($baselinekey,$current,false);
    }
}
add_filter('cron_schedules',function($s){
    if(!isset($s['jupiter_15min']))$s['jupiter_15min']=['interval'=>900,'display'=>'Every 15 minutes'];
    return $s;
});
add_action('init',function(){
    if(!wp_next_scheduled('jupiter_parent_notification_scan_event')){
        wp_schedule_event(time()+300,'jupiter_15min','jupiter_parent_notification_scan_event');
    }
});
add_action('jupiter_parent_notification_scan_event','jupiter_parent_notification_scan');
