<?php
require_once(__DIR__ . '/../../config.php');

use core\session\manager;

function local_jupiter_sso_fail(string $message, int $code = 403): void {
    global $PAGE, $OUTPUT;
    http_response_code($code);
    $PAGE->set_context(context_system::instance());
    $PAGE->set_url(new moodle_url('/local/jupiter_sso/login.php'));
    $PAGE->set_title('Jupiter course access');
    $PAGE->set_heading('Jupiter course access');
    echo $OUTPUT->header();
    echo $OUTPUT->notification(s($message), 'notifyproblem');
    echo $OUTPUT->footer();
    exit;
}

function local_jupiter_sso_b64decode(string $value) {
    $value = strtr($value, '-_', '+/');
    $pad = strlen($value) % 4;
    if ($pad) {
        $value .= str_repeat('=', 4 - $pad);
    }
    return base64_decode($value, true);
}

$token = required_param('token', PARAM_RAW_TRIMMED);
$config = get_config('local_jupiter_sso');
$secret = trim((string)($config->sharedsecret ?? ''));
$issuer = trim((string)($config->trustedissuer ?? ''));

if (strlen($secret) < 32 || $issuer === '') {
    local_jupiter_sso_fail(get_string('notconfigured', 'local_jupiter_sso'), 503);
}

$parts = explode('.', $token);
if (count($parts) !== 2) {
    local_jupiter_sso_fail(get_string('invalidtoken', 'local_jupiter_sso'));
}
[$payload64, $sig64] = $parts;
$expected = rtrim(strtr(base64_encode(hash_hmac('sha256', $payload64, $secret, true)), '+/', '-_'), '=');
if (!hash_equals($expected, $sig64)) {
    local_jupiter_sso_fail(get_string('invalidtoken', 'local_jupiter_sso'));
}

$json = local_jupiter_sso_b64decode($payload64);
$claims = is_string($json) ? json_decode($json, true) : null;
if (!is_array($claims)) {
    local_jupiter_sso_fail(get_string('invalidtoken', 'local_jupiter_sso'));
}

$now = time();
$exp = (int)($claims['exp'] ?? 0);
$iat = (int)($claims['iat'] ?? 0);
$jti = clean_param((string)($claims['jti'] ?? ''), PARAM_ALPHANUMEXT);
$tokenissuer = (string)($claims['iss'] ?? '');
$aud = (string)($claims['aud'] ?? '');
$userid = (int)($claims['iomad_user_id'] ?? 0);
$courseid = (int)($claims['course_id'] ?? 0);
$email = clean_param((string)($claims['email'] ?? ''), PARAM_EMAIL);

if (!$exp || $exp < $now || $exp > $now + 120 || !$iat || abs($now - $iat) > 120 || !$jti ||
        !hash_equals(rtrim($issuer, '/') . '/', rtrim($tokenissuer, '/') . '/') || $aud !== 'jupiter-iomad' ||
        !$userid || !$courseid || !$email) {
    local_jupiter_sso_fail(get_string('invalidtoken', 'local_jupiter_sso'));
}

// One-time token: clear expired records, then reject any replay before authenticating.
$DB->delete_records_select('local_jupiter_sso_nonce', 'expiresat < ?', [$now]);
if ($DB->record_exists('local_jupiter_sso_nonce', ['jti' => $jti])) {
    local_jupiter_sso_fail(get_string('invalidtoken', 'local_jupiter_sso'));
}

$user = $DB->get_record('user', ['id' => $userid, 'deleted' => 0, 'suspended' => 0], '*', IGNORE_MISSING);
if (!$user || strcasecmp((string)$user->email, $email) !== 0) {
    local_jupiter_sso_fail(get_string('notallowed', 'local_jupiter_sso'));
}
$course = $DB->get_record('course', ['id' => $courseid], '*', IGNORE_MISSING);
if (!$course || (int)$course->id === SITEID) {
    local_jupiter_sso_fail(get_string('notallowed', 'local_jupiter_sso'));
}
$context = context_course::instance($courseid);
if (!is_enrolled($context, $user, '', true)) {
    local_jupiter_sso_fail(get_string('notallowed', 'local_jupiter_sso'));
}
if (empty($course->visible)) {
    local_jupiter_sso_fail(get_string('coursehidden', 'local_jupiter_sso'));
}

$record = (object)[
    'jti' => $jti,
    'userid' => $userid,
    'courseid' => $courseid,
    'timecreated' => $now,
    'expiresat' => $exp,
];
try {
    $DB->insert_record('local_jupiter_sso_nonce', $record);
} catch (dml_exception $e) {
    local_jupiter_sso_fail(get_string('invalidtoken', 'local_jupiter_sso'));
}

// Jupiter WordPress is the learner authentication authority for this SSO flow.
// Newly-created Moodle users may carry the standard 'force password change'
// preferences from account provisioning. Those are appropriate for direct
// Moodle password logins, but would break passwordless Jupiter SSO by forcing
// the learner to set a second LMS password. Clear them before establishing the
// Moodle session.
unset_user_preference('auth_forcepasswordchange', $user);
unset_user_preference('create_password', $user);

// Prevent fixation and establish the normal Moodle authenticated session.
manager::kill_user_sessions($user->id);
complete_user_login($user);

$returnurl = trim((string)($config->returnurl ?? ''));
if ($returnurl !== '') {
    $SESSION->jupiter_return_url = $returnurl;
}

// Force the purchased course as both the desired destination and the immediate
// post-login redirect. This avoids Moodle dashboard/homepage preferences taking
// precedence over the Jupiter course hand-off.
$courseurl = new moodle_url('/course/view.php', ['id' => $courseid]);
$SESSION->wantsurl = $courseurl->out(false);
redirect($courseurl, '', 0);
