# Jupiter Oak Integration 0.6.0

Phase: rich Oak lesson import into an existing Iomad course.

## What changed in 0.6.0
- Fetches Oak lesson summary, assets, transcript and lesson quiz data.
- Builds one consolidated Moodle Page per Oak lesson.
- Adds lesson outcome, key learning points, keywords, misconceptions and teacher tips when available.
- Adds authenticated links to Oak video and downloadable resources without exposing the API key.
- Adds transcript inside the lesson page when available.
- Adds starter and exit quiz questions as self-check content inside the page.
- Enables manual Moodle completion on lesson pages.
- Re-importing refreshes existing lesson pages instead of duplicating them.
- Hides the legacy individual v0.5 asset URL activities after a rich lesson page is built.
- Unavailable/licensing-restricted Oak responses are recorded and do not stop the rest of the unit import.

## Deliberate limitation
The starter/exit questions in 0.6.0 are rendered as self-check content on the lesson page. They are not yet native Moodle Quiz question-bank activities; native graded quiz creation is a later hardening step.


## 0.7.2
- Removes legacy per-asset URL activities created by the 0.5 importer when they are tracked in the Jupiter Oak mapping table.
- Creates native Moodle Quiz activities from supported Oak starter and exit multiple-choice questions.
- Exit quizzes use a 70% pass grade and automatic completion based on the passing grade.
- Starter quizzes use view-based completion.
- Keeps inline self-check quiz rendering as a safe fallback if native quiz creation is not possible for a particular Oak question set.


## 0.7.2
- Fixes `Class "qformat_default" not found` on Moodle/Iomad 5.1 by loading `question/format.php` before the GIFT question-format implementation.


## v0.7.2
- Sends safe Content-Disposition filenames for Oak assets, so browsers download PPTX/PDF/MP4/TXT rather than asset.php.
- Expands native quiz conversion to Oak multiple-choice (including multi-correct) and short-answer questions.
- Shows sanitized import warning details to make unsupported/restricted content diagnosable.


## 0.7.3
- Moodle 5.x native quiz questions now import into the course default Question bank activity context, then attach to the generated Quiz activity.
- Improved admin-safe database error detail if question creation still fails.

## v0.8.0
- Professional learner index naming: L01 | Lesson, L01 | Starter, L01 | Exit.
- Groups each lesson with its starter and exit assessment in course navigation.
- Refreshes existing imported activity names without duplicates.
- Clearer learning pathway and Learning materials presentation.


## v0.9.0
- Create/reuse one hidden Iomad course per Oak programme.
- Allocate the course to one, multiple, or all active Iomad companies.
- Uses Iomad 5.1 company/course schema and company root departments.
- Keeps course hidden until review; WooCommerce publication remains separate.


## v0.10.1 learner progression
- Lesson completes automatically when viewed.
- Starter quiz completes after the learner receives a grade.
- Exit assessment completes only with a passing grade (70%).
- Starter unlocks after its lesson. Exit unlocks after starter completion.
- The next lesson unlocks only after the previous exit assessment is passed.
- Existing imported activities are refreshed idempotently on re-import.


## 0.10.9
- Enforces controlled enrolment on Jupiter-managed Oak programme courses: self enrolment and guest access are disabled.
- Automatically registers imported Oak Exit quizzes as native course-completion activity criteria.
- Uses ALL aggregation for overall course completion and the activity criteria group.
- Completion sync is idempotent.
- Safety guard refuses to silently add new completion requirements after learners have already completed the course.
