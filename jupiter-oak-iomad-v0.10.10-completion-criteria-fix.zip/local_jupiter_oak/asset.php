<?php
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/filelib.php');

$courseid = required_param('courseid', PARAM_INT);
$lesson = required_param('lesson', PARAM_ALPHANUMEXT);
$type = required_param('type', PARAM_ALPHANUMEXT);

$course = get_course($courseid);
require_login($course);
$coursecontext = context_course::instance($courseid);

// Normal enrolled learners do not need the privileged moodle/course:view capability
// ("View courses without participation"). Allow active enrolled participants, while
// still permitting administrators/managers who legitimately hold that capability.
$isenrolled = is_enrolled($coursecontext, $USER, '', true);
$canviewwithoutparticipation = has_capability('moodle/course:view', $coursecontext);
if (!$isenrolled && !$canviewwithoutparticipation) {
    throw new required_capability_exception(
        $coursecontext,
        'moodle/course:view',
        'nopermissions',
        ''
    );
}

// Answer-key assets are teacher/admin resources. Enrolled learners must not be
// able to bypass the lesson UI by calling asset.php directly.
$restrictedanswers = ['worksheetAnswers', 'starterQuizAnswers', 'exitQuizAnswers'];
if (in_array($type, $restrictedanswers, true) && !has_capability('moodle/course:update', $coursecontext)) {
    throw new required_capability_exception($coursecontext, 'moodle/course:update', 'nopermissions', '');
}

$baseurl = rtrim((string)get_config('local_jupiter_oak', 'apiurl'), '/');
$apikey = (string)get_config('local_jupiter_oak', 'apikey');
if ($baseurl === '' || $apikey === '') {
    throw new moodle_exception('error_nokey', 'local_jupiter_oak');
}

$url = $baseurl . '/lessons/' . rawurlencode($lesson) . '/assets/' . rawurlencode($type);
$curl = new curl();
$curl->setHeader(['Authorization: Bearer ' . $apikey, 'Accept: */*']);
$curl->setopt(['CURLOPT_FOLLOWLOCATION' => 0, 'CURLOPT_TIMEOUT' => 60, 'CURLOPT_CONNECTTIMEOUT' => 10]);
$body = $curl->get($url);
$info = $curl->get_info();
$status = (int)($info['http_code'] ?? 0);

if ($status === 301 || $status === 302 || $status === 303 || $status === 307 || $status === 308) {
    $headers = $curl->getResponse();
    $target = null;
    foreach ($headers as $name => $value) {
        if (strtolower((string)$name) === 'location') {
            $target = is_array($value) ? end($value) : $value;
            break;
        }
    }
    if (!$target) {
        throw new moodle_exception('error_asset', 'local_jupiter_oak', '', 'Oak returned a redirect without a destination.');
    }
    redirect($target);
}

if ($status < 200 || $status >= 300 || $curl->get_errno()) {
    $decoded = json_decode($body, true);
    $message = 'Oak asset request failed (HTTP ' . $status . ').';
    if (is_array($decoded)) {
        $cause = $decoded['data']['cause'] ?? null;
        $api = $decoded['message'] ?? null;
        if ($cause) {
            $message .= ' ' . clean_param((string)$cause, PARAM_TEXT);
        } else if ($api) {
            $message .= ' ' . clean_param((string)$api, PARAM_TEXT);
        }
    }
    throw new moodle_exception('error_asset', 'local_jupiter_oak', '', $message);
}

$contenttype = trim((string)($info['content_type'] ?? 'application/octet-stream'));
// Some curl backends include a charset parameter. Keep the MIME type clean for extension mapping.
$basetype = strtolower(trim(explode(';', $contenttype, 2)[0]));

// Oak's streaming endpoint returns the binary body, but browsers only see this Moodle proxy URL.
// Always provide a safe Content-Disposition filename so resources are not saved as asset.php.
$extensionmap = [
    'slideDeck' => 'pptx',
    'worksheet' => 'pdf',
    'worksheetAnswers' => 'pdf',
    'starterQuiz' => 'pdf',
    'starterQuizAnswers' => 'pdf',
    'exitQuiz' => 'pdf',
    'exitQuizAnswers' => 'pdf',
    'video' => 'mp4',
    'transcript' => 'txt',
    'lessonGuide' => 'pdf',
    'additionalMaterial' => 'pdf',
    'supplementaryResource' => 'bin',
];
$mimetypeextensions = [
    'application/vnd.openxmlformats-officedocument.presentationml.presentation' => 'pptx',
    'application/pdf' => 'pdf',
    'video/mp4' => 'mp4',
    'text/plain' => 'txt',
    'application/zip' => 'zip',
];
$extension = $mimetypeextensions[$basetype] ?? ($extensionmap[$type] ?? 'bin');
$filename = clean_filename($lesson . '-' . strtolower(preg_replace('/(?<!^)[A-Z]/', '-$0', $type)) . '.' . $extension);

header('Content-Type: ' . ($contenttype !== '' ? $contenttype : 'application/octet-stream'));
header('Content-Disposition: attachment; filename="' . $filename . '"; filename*=UTF-8\'\'' . rawurlencode($filename));
header('X-Content-Type-Options: nosniff');
header('Content-Length: ' . strlen($body));
header('Cache-Control: private, max-age=300');
echo $body;
