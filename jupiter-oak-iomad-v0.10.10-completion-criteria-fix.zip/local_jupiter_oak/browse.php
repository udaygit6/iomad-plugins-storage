<?php
require_once(__DIR__ . '/../../config.php');

require_login();
require_capability('moodle/site:config', context_system::instance());

$subjects = [
    'art' => 'Art',
    'citizenship' => 'Citizenship',
    'computing' => 'Computing',
    'cooking-nutrition' => 'Cooking & Nutrition',
    'design-technology' => 'Design & Technology',
    'english' => 'English',
    'french' => 'French',
    'geography' => 'Geography',
    'german' => 'German',
    'history' => 'History',
    'maths' => 'Maths',
    'music' => 'Music',
    'physical-education' => 'Physical Education',
    'religious-education' => 'Religious Education',
    'rshe-pshe' => 'RSHE / PSHE',
    'science' => 'Science',
    'spanish' => 'Spanish',
];

$subject = optional_param('subject', 'maths', PARAM_ALPHANUMEXT);
$programme = optional_param('programme', '', PARAM_ALPHANUMEXT);
$unit = optional_param('unit', '', PARAM_ALPHANUMEXT);

if (!array_key_exists($subject, $subjects)) {
    $subject = 'maths';
}

$PAGE->set_url(new moodle_url('/local/jupiter_oak/browse.php', [
    'subject' => $subject,
    'programme' => $programme,
    'unit' => $unit,
]));
$PAGE->set_context(context_system::instance());
$PAGE->set_pagelayout('admin');
$PAGE->set_title(get_string('browsecurriculum', 'local_jupiter_oak'));
$PAGE->set_heading(get_string('browsecurriculum', 'local_jupiter_oak'));

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('browsecurriculum', 'local_jupiter_oak'));

$client = new \local_jupiter_oak\oak_client();
$programmeresult = $client->get_programmes($subject);

if (!$programmeresult['ok']) {
    echo $OUTPUT->notification(s($programmeresult['message']), \core\output\notification::NOTIFY_ERROR);
    echo $OUTPUT->footer();
    exit;
}

$programmeoptions = [];
foreach ($programmeresult['data'] as $item) {
    if (is_string($item)) {
        $programmeoptions[$item] = ucwords(str_replace('-', ' ', $item));
    } else if (is_array($item)) {
        $slug = $item['programmeSlug'] ?? $item['slug'] ?? '';
        if ($slug !== '') {
            $title = $item['programmeTitle'] ?? $item['title'] ?? ucwords(str_replace('-', ' ', $slug));
            $programmeoptions[$slug] = $title;
        }
    }
}

if ($programme !== '' && !array_key_exists($programme, $programmeoptions)) {
    $programme = '';
    $unit = '';
}

$unitoptions = [];
$unitrows = [];
if ($programme !== '') {
    $unitresult = $client->get_units($programme);
    if (!$unitresult['ok']) {
        echo $OUTPUT->notification(s($unitresult['message']), \core\output\notification::NOTIFY_ERROR);
    } else {
        foreach ($unitresult['data'] as $u) {
            if (!is_array($u)) {
                continue;
            }
            $slug = (string)($u['unitSlug'] ?? $u['slug'] ?? '');
            if ($slug === '') {
                continue;
            }
            $title = (string)($u['unitTitle'] ?? $u['title'] ?? ucwords(str_replace('-', ' ', $slug)));
            $order = (string)($u['unitOrder'] ?? $u['order'] ?? '');
            $unitoptions[$slug] = $title;
            $unitrows[] = [$order, $title, $slug];
        }
    }
}

if ($unit !== '' && !array_key_exists($unit, $unitoptions)) {
    $unit = '';
}

echo html_writer::start_tag('form', [
    'method' => 'get',
    'action' => (new moodle_url('/local/jupiter_oak/browse.php'))->out(false),
    'class' => 'mb-4',
]);

echo html_writer::div(
    html_writer::label(get_string('selectsubject', 'local_jupiter_oak'), 'id_subject') .
    html_writer::select($subjects, 'subject', $subject, false, ['id' => 'id_subject', 'class' => 'custom-select']),
    'form-group'
);

echo html_writer::div(
    html_writer::label(get_string('selectprogramme', 'local_jupiter_oak'), 'id_programme') .
    html_writer::select($programmeoptions, 'programme', $programme, ['' => get_string('chooseprogramme', 'local_jupiter_oak')], ['id' => 'id_programme', 'class' => 'custom-select']),
    'form-group'
);

if ($programme !== '' && !empty($unitoptions)) {
    echo html_writer::div(
        html_writer::label(get_string('selectunit', 'local_jupiter_oak'), 'id_unit') .
        html_writer::select($unitoptions, 'unit', $unit, ['' => get_string('chooseunit', 'local_jupiter_oak')], ['id' => 'id_unit', 'class' => 'custom-select']),
        'form-group'
    );
}

echo html_writer::empty_tag('input', [
    'type' => 'submit',
    'value' => $programme === '' ? get_string('loadunits', 'local_jupiter_oak') : get_string('loadlessons', 'local_jupiter_oak'),
    'class' => 'btn btn-primary',
]);
echo html_writer::end_tag('form');

if ($programme !== '' && !empty($unitrows)) {
    echo $OUTPUT->heading(get_string('unitsfound', 'local_jupiter_oak') . ' — ' . s($programmeoptions[$programme]), 3);
    $table = new html_table();
    $table->head = [
        get_string('unitorder', 'local_jupiter_oak'),
        get_string('unittitle', 'local_jupiter_oak'),
        get_string('unitslug', 'local_jupiter_oak'),
    ];
    foreach ($unitrows as $row) {
        $table->data[] = [s($row[0]), s($row[1]), html_writer::tag('code', s($row[2]))];
    }
    echo html_writer::table($table);
}

if ($unit !== '') {
    $summaryresult = $client->get_unit_summary($unit);
    if (!$summaryresult['ok']) {
        echo $OUTPUT->notification(s($summaryresult['message']), \core\output\notification::NOTIFY_ERROR);
    } else {
        $summary = $summaryresult['data'];
        $lessons = [];

        // Oak's unit summary exposes lessons in the top-level `unitLessons` array.
        // Keep a defensive fallback for older/variant response shapes.
        if (!empty($summary['unitLessons']) && is_array($summary['unitLessons'])) {
            $lessons = $summary['unitLessons'];
        } else {
            $extractlessons = function($node) use (&$extractlessons, &$lessons) {
                if (!is_array($node)) {
                    return;
                }
                foreach ($node as $key => $value) {
                    if (($key === 'unitLessons' || $key === 'lessons' || $key === 'items') && is_array($value)) {
                        foreach ($value as $lesson) {
                            if (is_array($lesson) && (isset($lesson['lessonSlug']) || isset($lesson['lessonTitle']) || isset($lesson['slug']) || isset($lesson['title']))) {
                                $lessons[] = $lesson;
                            }
                        }
                    }
                    if (is_array($value)) {
                        $extractlessons($value);
                    }
                }
            };
            $extractlessons($summary);
        }

        // Remove duplicate lessons if Oak exposes the same lesson in more than one nested block.
        $normalised = [];
        foreach ($lessons as $lesson) {
            $slug = (string)($lesson['lessonSlug'] ?? $lesson['slug'] ?? '');
            $title = (string)($lesson['lessonTitle'] ?? $lesson['title'] ?? '');
            $order = (string)($lesson['lessonOrder'] ?? $lesson['order'] ?? '');
            if ($slug === '' && $title === '') {
                continue;
            }
            $key = $slug !== '' ? $slug : md5($title . '|' . $order);
            if (!isset($normalised[$key])) {
                $normalised[$key] = ['order' => $order, 'title' => $title, 'slug' => $slug];
            }
        }

        echo $OUTPUT->heading(get_string('lessonsfound', 'local_jupiter_oak') . ' — ' . s($unitoptions[$unit]), 3);

        if (empty($normalised)) {
            echo $OUTPUT->notification(get_string('nolessons', 'local_jupiter_oak'), \core\output\notification::NOTIFY_WARNING);
        } else {
            $table = new html_table();
            $table->head = [
                get_string('lessonorder', 'local_jupiter_oak'),
                get_string('lessontitle', 'local_jupiter_oak'),
                get_string('lessonslug', 'local_jupiter_oak'),
            ];
            foreach ($normalised as $lesson) {
                $table->data[] = [
                    s($lesson['order']),
                    s($lesson['title']),
                    html_writer::tag('code', s($lesson['slug'])),
                ];
            }
            echo html_writer::table($table);

            $importurl = new moodle_url('/local/jupiter_oak/import.php', [
                'subject' => $subject,
                'programme' => $programme,
                'unit' => $unit,
                'unittitle' => $unitoptions[$unit],
                'programmetitle' => $programmeoptions[$programme] ?? $programme,
            ]);
            echo html_writer::div(
                html_writer::link($importurl, get_string('importselectedunit', 'local_jupiter_oak'), ['class' => 'btn btn-success']),
                'mt-3'
            );
        }
    }
}

echo $OUTPUT->footer();
