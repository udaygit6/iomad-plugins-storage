<?php
namespace local_jupiter_oak;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->dirroot . '/course/lib.php');

/**
 * Creates/reuses Jupiter Oak programme courses and allocates them to Iomad companies.
 *
 * Courses are created hidden by default. This makes an Oak import a controlled content
 * staging operation; publishing remains an explicit business decision.
 */
class course_provisioner {

    /** Return active Iomad companies which can receive a course allocation. */
    public function get_companies(): array {
        global $DB;

        $manager = $DB->get_manager();
        $table = new \xmldb_table('local_iomad_companies');
        if (!$manager->table_exists($table)) {
            throw new \moodle_exception('Iomad company table is not available on this site.');
        }

        $records = $DB->get_records_select(
            'local_iomad_companies',
            'suspended = 0 AND isterminated = 0',
            [],
            'name ASC',
            'id,name,shortname,coursecategoryid'
        );
        return array_values($records);
    }

    /**
     * Create or safely reuse the course mapped to an Oak programme.
     *
     * @return array{courseid:int,created:bool,coursename:string,shortname:string}
     */
    public function provision_programme_course(string $subject, string $programme, string $programmetitle,
            array $companyids): array {
        global $DB, $USER;

        $companyids = array_values(array_unique(array_filter(array_map('intval', $companyids), static fn($v) => $v > 0)));
        if (!$companyids) {
            throw new \moodle_exception('Select at least one Iomad company for the new course.');
        }

        $companies = $DB->get_records_list('local_iomad_companies', 'id', $companyids, '', 'id,name,shortname,coursecategoryid,suspended,isterminated');
        if (count($companies) !== count($companyids)) {
            throw new \moodle_exception('One or more selected Iomad companies no longer exist.');
        }
        foreach ($companies as $company) {
            if (!empty($company->suspended) || !empty($company->isterminated)) {
                throw new \moodle_exception('Suspended or terminated companies cannot receive new Oak courses.');
            }
        }

        // Reuse the one programme course previously created by this integration.
        $mappings = $DB->get_records('local_jupiter_oak_import', [
            'itemtype' => 'programme',
            'oakslug' => $programme,
        ], 'id ASC');
        foreach ($mappings as $mapping) {
            if (!empty($mapping->courseid) && $DB->record_exists('course', ['id' => $mapping->courseid])) {
                $course = get_course((int)$mapping->courseid);
                $this->assign_course_to_companies((int)$course->id, $companyids);
                $this->enforce_controlled_enrolment((int)$course->id);
                return [
                    'courseid' => (int)$course->id,
                    'created' => false,
                    'coursename' => $course->fullname,
                    'shortname' => $course->shortname,
                ];
            }
        }

        $primary = reset($companies);
        $categoryid = (int)$primary->coursecategoryid;
        if ($categoryid <= 0 || !$DB->record_exists('course_categories', ['id' => $categoryid])) {
            throw new \moodle_exception('The selected primary company does not have a valid Iomad course category.');
        }

        require_capability('moodle/course:create', \context_coursecat::instance($categoryid));

        $cleanprogramme = trim($programmetitle) !== '' ? trim($programmetitle) : ucwords(str_replace('-', ' ', $programme));
        $fullname = 'Jupiter | ' . $cleanprogramme;
        $shortbase = strtoupper('JTS-OAK-' . preg_replace('/[^A-Za-z0-9]+/', '-', $programme));
        $shortbase = trim($shortbase, '-');
        $shortname = $this->unique_shortname(substr($shortbase, 0, 90));

        $data = (object)[
            'fullname' => clean_param($fullname, PARAM_TEXT),
            'shortname' => clean_param($shortname, PARAM_TEXT),
            'category' => $categoryid,
            'summary' => '<p>Jupiter course created from the Oak National Academy programme <strong>' . s($cleanprogramme) . '</strong>.</p>' .
                '<p>Content remains hidden until it has been reviewed and approved for publication.</p>',
            'summaryformat' => FORMAT_HTML,
            'format' => 'topics',
            'visible' => 0,
            'enablecompletion' => 1,
        ];

        $course = create_course($data);
        if (!$course || empty($course->id)) {
            throw new \moodle_exception('Moodle did not return the newly created course.');
        }

        // Ensure Iomad has a settings row for the course. Keep it non-shared by default;
        // explicit company allocations below define who receives it.
        if (!$DB->record_exists('local_iomad_courses', ['courseid' => $course->id])) {
            $DB->insert_record('local_iomad_courses', (object)[
                'courseid' => $course->id,
                'licensed' => 0,
                'shared' => 0,
                'validlength' => 0,
                'warnexpire' => 0,
                'warncompletion' => 0,
                'notifyperiod' => 0,
                'expireafter' => 0,
                'warnnotstarted' => 0,
                'hasgrade' => 1,
            ]);
        }

        $this->assign_course_to_companies((int)$course->id, $companyids);
        $this->enforce_controlled_enrolment((int)$course->id);

        $now = time();
        $DB->insert_record('local_jupiter_oak_import', (object)[
            'itemtype' => 'programme',
            'oakslug' => $programme,
            'parentslug' => null,
            'programme' => $programme,
            'subject' => $subject,
            'assettype' => null,
            'courseid' => $course->id,
            'sectionnum' => null,
            'cmid' => null,
            'status' => 'provisioned',
            'statusmessage' => 'Hidden Iomad programme course created and company allocation applied.',
            'usermodified' => (int)$USER->id,
            'timecreated' => $now,
            'timemodified' => $now,
        ]);

        return [
            'courseid' => (int)$course->id,
            'created' => true,
            'coursename' => $course->fullname,
            'shortname' => $course->shortname,
        ];
    }

    /** Assign a course to one or more companies, idempotently. */
    public function assign_course_to_companies(int $courseid, array $companyids): void {
        global $DB;

        if (!class_exists('\\local_iomad\\company')) {
            throw new \moodle_exception('Iomad company API is not available.');
        }

        foreach ($companyids as $companyid) {
            $companyid = (int)$companyid;
            if ($companyid <= 0) {
                continue;
            }
            if ($DB->record_exists('local_iomad_company_courses', [
                'companyid' => $companyid,
                'courseid' => $courseid,
            ])) {
                continue;
            }

            $rootdepartment = \local_iomad\company::get_company_parentnode($companyid);
            if (!$rootdepartment || empty($rootdepartment->id)) {
                throw new \moodle_exception('Unable to resolve the root department for Iomad company ID ' . $companyid . '.');
            }

            $DB->insert_record('local_iomad_company_courses', (object)[
                'companyid' => $companyid,
                'courseid' => $courseid,
                'departmentid' => (int)$rootdepartment->id,
            ]);
        }
    }

    /**
     * Jupiter-managed Oak courses must never grant open learner access.
     * Company allocation controls catalogue availability; learner entitlement is
     * granted separately by WooCommerce/licence/admin provisioning.
     */
    private function enforce_controlled_enrolment(int $courseid): void {
        global $CFG;

        require_once($CFG->libdir . '/enrollib.php');

        foreach (['self', 'guest'] as $method) {
            $plugin = enrol_get_plugin($method);
            if (!$plugin) {
                continue;
            }
            foreach (enrol_get_instances($courseid, false) as $instance) {
                if ($instance->enrol === $method && (int)$instance->status !== ENROL_INSTANCE_DISABLED) {
                    $plugin->update_status($instance, ENROL_INSTANCE_DISABLED);
                }
            }
        }
    }

    private function unique_shortname(string $base): string {
        global $DB;
        $candidate = $base;
        $n = 2;
        while ($DB->record_exists('course', ['shortname' => $candidate])) {
            $suffix = '-' . $n++;
            $candidate = substr($base, 0, 90 - strlen($suffix)) . $suffix;
        }
        return $candidate;
    }
}
