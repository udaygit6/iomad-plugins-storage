<?php
namespace local_jupiter_oak;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->dirroot . '/course/lib.php');
require_once($GLOBALS['CFG']->dirroot . '/course/modlib.php');
require_once($GLOBALS['CFG']->dirroot . '/mod/quiz/locallib.php');
require_once($GLOBALS['CFG']->libdir . '/questionlib.php');
require_once($GLOBALS['CFG']->dirroot . '/question/editlib.php');
// qformat_gift extends qformat_default, which Moodle defines in question/format.php.
require_once($GLOBALS['CFG']->dirroot . '/question/format.php');
require_once($GLOBALS['CFG']->dirroot . '/question/format/gift/format.php');

/**
 * Imports an Oak unit into an existing Moodle/Iomad course.
 *
 * v0.10 learner model:
 *   one Iomad course -> one section per Oak unit -> one rich Moodle Page per lesson
 *   plus native Moodle starter/exit quizzes where Oak returns usable questions.
 * Legacy per-asset URL activities from v0.5 are removed once the consolidated lesson is available.
 */
class importer {
    private oak_client $client;

    public function __construct(?oak_client $client = null) {
        $this->client = $client ?? new oak_client();
    }

    public function import_unit(int $courseid, string $subject, string $programme, string $unitslug, string $unittitle): array {
        global $DB;

        $course = get_course($courseid);
        require_capability('moodle/course:update', \context_course::instance($courseid));

        $summaryresult = $this->client->get_unit_summary($unitslug);
        if (!$summaryresult['ok']) {
            throw new \moodle_exception('error_oakrequest', 'local_jupiter_oak', '', $summaryresult['message']);
        }

        $lessons = $this->normalise_lessons($summaryresult['data']);
        if (!$lessons) {
            throw new \moodle_exception('error_nolessonsimport', 'local_jupiter_oak');
        }

        $sectionnum = $this->get_or_create_unit_section($courseid, $programme, $unitslug, $unittitle);
        $createdlessons = 0;
        $updatedlessons = 0;
        $skippedresources = 0;
        $errors = [];

        foreach ($lessons as $lesson) {
            $lessonslug = $lesson['slug'];
            $lessontitle = $lesson['title'];
            $lessonorder = $lesson['order'];

            $summary = $this->client->get_lesson_summary($lessonslug);
            $assets = $this->client->get_lesson_assets($lessonslug);
            $quiz = $this->client->get_lesson_quiz($lessonslug);
            $transcript = $this->client->get_lesson_transcript($lessonslug);

            foreach ([$summary, $assets, $quiz, $transcript] as $response) {
                if (!$response['ok'] && $response['status'] !== 400 && $response['status'] !== 404) {
                    $errors[] = $lessontitle . ': ' . $response['message'];
                }
                if (!$response['ok']) {
                    $skippedresources++;
                }
            }

            $quizdata = $quiz['ok'] ? (array)$quiz['data'] : [];
            $starter = is_array($quizdata['starterQuiz'] ?? null) ? $quizdata['starterQuiz'] : [];
            $exit = is_array($quizdata['exitQuiz'] ?? null) ? $quizdata['exitQuiz'] : [];

            $nativequizlinks = [];
            if ($starter) {
                try {
                    $nativequizlinks['starter'] = $this->sync_native_quiz(
                        $courseid, $sectionnum, $lessonslug, $lessontitle, $lessonorder, 'starter', $starter, false
                    );
                } catch (\Throwable $e) {
                    $errors[] = $lessontitle . ' starter quiz: ' . $this->safe_exception_message($e);
                }
            }
            if ($exit) {
                try {
                    $nativequizlinks['exit'] = $this->sync_native_quiz(
                        $courseid, $sectionnum, $lessonslug, $lessontitle, $lessonorder, 'exit', $exit, true
                    );
                } catch (\Throwable $e) {
                    $errors[] = $lessontitle . ' exit quiz: ' . $this->safe_exception_message($e);
                }
            }

            $content = $this->build_lesson_content(
                $courseid,
                $lessonslug,
                $lessontitle,
                $lessonorder,
                $summary['ok'] ? (array)$summary['data'] : [],
                $assets['ok'] ? (array)$assets['data'] : [],
                $quizdata,
                $transcript['ok'] ? (array)$transcript['data'] : [],
                [
                    'summary' => $summary['ok'] ? '' : $summary['message'],
                    'assets' => $assets['ok'] ? '' : $assets['message'],
                    'quiz' => $quiz['ok'] ? '' : $quiz['message'],
                    'transcript' => $transcript['ok'] ? '' : $transcript['message'],
                ],
                $nativequizlinks
            );

            $mapping = $DB->get_record('local_jupiter_oak_import', [
                'itemtype' => 'lesson', 'oakslug' => $lessonslug, 'courseid' => $courseid,
            ]);

            if ($mapping && !empty($mapping->cmid) && $DB->record_exists('course_modules', ['id' => $mapping->cmid])) {
                $this->update_lesson_page((int)$mapping->cmid, $courseid, $lessontitle, $lessonorder, $content);
                $updatedlessons++;
            } else {
                $cmid = $this->create_lesson_page($courseid, $sectionnum, $lessonslug, $lessontitle, $lessonorder, $content);
                $createdlessons++;
                $this->record_mapping('lesson', $lessonslug, $unitslug, $programme, $subject, null,
                    $courseid, $sectionnum, $cmid, 'imported', 'Rich Oak lesson page created.');
            }

            // v0.5 created many individual URL activities. Remove only modules tracked by this plugin.
            $this->purge_legacy_asset_modules($courseid, $lessonslug);
        }

        // Keep the course index learner-friendly: Lesson -> Starter -> Exit for each Oak lesson.
        $this->order_unit_activities($courseid, $sectionnum, $lessons);
        $this->apply_learning_progression($courseid, $lessons);
        try {
            $this->sync_exit_course_completion($courseid);
        } catch (\Throwable $e) {
            $errors[] = 'Course completion automation: ' . $this->safe_exception_message($e);
        }

        rebuild_course_cache($courseid, true);
        $this->record_mapping('unit', $unitslug, null, $programme, $subject, null,
            $courseid, $sectionnum, null, 'imported', 'Unit refreshed using consolidated Oak lesson pages.');

        return [
            'courseid' => $courseid,
            'coursename' => $course->fullname,
            'sectionnum' => $sectionnum,
            'lessoncount' => count($lessons),
            'createdlessons' => $createdlessons,
            'updatedlessons' => $updatedlessons,
            'createdassets' => 0,
            'nativequizzes' => $this->count_unit_native_quizzes($courseid, $unitslug),
            'skippedassets' => $skippedresources,
            'errors' => array_values(array_unique($errors)),
        ];
    }

    private function normalise_lessons(array $summary): array {
        $raw = !empty($summary['unitLessons']) && is_array($summary['unitLessons']) ? $summary['unitLessons'] : [];
        $out = [];
        foreach ($raw as $lesson) {
            if (!is_array($lesson)) {
                continue;
            }
            $slug = clean_param((string)($lesson['lessonSlug'] ?? $lesson['slug'] ?? ''), PARAM_ALPHANUMEXT);
            if ($slug === '') {
                continue;
            }
            $out[$slug] = [
                'slug' => $slug,
                'title' => clean_param((string)($lesson['lessonTitle'] ?? $lesson['title'] ?? $slug), PARAM_TEXT),
                'order' => (int)($lesson['lessonOrder'] ?? $lesson['order'] ?? 0),
            ];
        }
        uasort($out, static fn($a, $b) => $a['order'] <=> $b['order']);
        return array_values($out);
    }

    private function get_or_create_unit_section(int $courseid, string $programme, string $unitslug, string $unittitle): int {
        global $DB;

        $existing = $DB->get_record('local_jupiter_oak_import', [
            'itemtype' => 'unit', 'oakslug' => $unitslug, 'courseid' => $courseid,
        ]);
        if ($existing && !empty($existing->sectionnum)) {
            course_create_sections_if_missing($courseid, [(int)$existing->sectionnum]);
            return (int)$existing->sectionnum;
        }

        $maxsection = (int)$DB->get_field_sql('SELECT COALESCE(MAX(section), 0) FROM {course_sections} WHERE course = ?', [$courseid]);
        $sectionnum = $maxsection + 1;
        course_create_sections_if_missing($courseid, [$sectionnum]);
        $sectioninfo = get_fast_modinfo($courseid)->get_section_info($sectionnum);
        course_update_section($courseid, $sectioninfo, [
            'name' => $unittitle,
            'summary' => '<p><strong>Oak source unit:</strong> ' . s($unittitle) . '</p>' .
                '<p>Imported from Oak National Academy. Individual unavailable or licensing-restricted resources are skipped and recorded.</p>',
            'summaryformat' => FORMAT_HTML,
            'visible' => 1,
        ]);
        $this->record_mapping('unit', $unitslug, null, $programme, '', null,
            $courseid, $sectionnum, null, 'importing', 'Unit section created.');
        return $sectionnum;
    }

    private function create_lesson_page(int $courseid, int $sectionnum, string $lessonslug,
            string $lessontitle, int $lessonorder, string $content): int {
        $moduleinfo = (object)[
            'modulename' => 'page',
            'course' => $courseid,
            'section' => $sectionnum,
            'visible' => 1,
            'name' => sprintf('L%02d | Lesson | %s', max(1, $lessonorder), $lessontitle),
            'introeditor' => ['text' => '', 'format' => FORMAT_HTML, 'itemid' => 0],
            'contenteditor' => ['text' => $content, 'format' => FORMAT_HTML, 'itemid' => 0],
            'display' => 5,
            'completion' => COMPLETION_TRACKING_AUTOMATIC,
            'completionview' => 1,
        ];
        $created = create_module($moduleinfo);
        return (int)$created->coursemodule;
    }

    private function update_lesson_page(int $cmid, int $courseid, string $lessontitle, int $lessonorder, string $content): void {
        global $DB;
        $cm = get_coursemodule_from_id('page', $cmid, $courseid, false, MUST_EXIST);
        $page = $DB->get_record('page', ['id' => $cm->instance], '*', MUST_EXIST);
        $page->name = sprintf('L%02d | Lesson | %s', max(1, $lessonorder), $lessontitle);
        $page->content = $content;
        $page->contentformat = FORMAT_HTML;
        $page->timemodified = time();
        $DB->update_record('page', $page);
        $DB->set_field('course_modules', 'completion', COMPLETION_TRACKING_AUTOMATIC, ['id' => $cmid]);
        $DB->set_field('course_modules', 'completionview', 1, ['id' => $cmid]);
    }

    private function build_lesson_content(int $courseid, string $lessonslug, string $lessontitle, int $lessonorder,
            array $summary, array $assetdata, array $quizdata, array $transcriptdata, array $errors,
            array $nativequizlinks = []): string {
        $html = '<div class="jupiter-oak-lesson">';
        $html .= '<p><strong>Lesson ' . sprintf('%02d', max(1, $lessonorder)) . '</strong> &nbsp;•&nbsp; Learn &nbsp;→&nbsp; Starter check &nbsp;→&nbsp; Exit assessment</p>';
        $html .= '<h2>' . s($lessontitle) . '</h2>';

        $outcome = $this->first_text($summary, ['pupilLessonOutcome', 'lessonOutcome', 'learningOutcome', 'outcome']);
        if ($outcome !== '') {
            $html .= '<h3>Lesson outcome</h3><p>' . format_text(s($outcome), FORMAT_PLAIN) . '</p>';
        }

        $klps = $this->first_list($summary, ['keyLearningPoints', 'keyLearningPoint']);
        if ($klps) {
            $html .= '<h3>Key learning points</h3>' . $this->list_html($klps);
        }

        $keywords = $this->normalise_keywords($summary['keywords'] ?? $summary['keyWords'] ?? []);
        if ($keywords) {
            $html .= '<h3>Keywords</h3><dl>';
            foreach ($keywords as $kw) {
                $html .= '<dt><strong>' . s($kw['keyword']) . '</strong></dt>';
                if ($kw['description'] !== '') {
                    $html .= '<dd>' . s($kw['description']) . '</dd>';
                }
            }
            $html .= '</dl>';
        }

        $misconceptions = $summary['misconceptionsAndCommonMistakes'] ?? $summary['misconceptions'] ?? [];
        $mischtml = $this->misconceptions_html($misconceptions);
        if ($mischtml !== '') {
            $html .= '<h3>Common misconceptions</h3>' . $mischtml;
        }

        $teachertip = $this->first_text($summary, ['teacherTips', 'teacherTip']);
        if ($teachertip !== '') {
            $html .= '<details><summary><strong>Teacher tip</strong></summary><p>' . s($teachertip) . '</p></details>';
        }

        $assets = $assetdata['assets'] ?? [];
        $assetmap = [];
        foreach ($assets as $asset) {
            if (is_array($asset) && !empty($asset['type'])) {
                $assetmap[(string)$asset['type']][] = $asset;
            }
        }

        if (isset($assetmap['video'])) {
            $html .= '<h3>Lesson video</h3>';
            $html .= '<p>' . $this->asset_link($courseid, $lessonslug, 'video', 'Watch Oak lesson video') . '</p>';
        }

        $transcript = $this->extract_transcript($transcriptdata);
        if ($transcript !== '') {
            $html .= '<details><summary><strong>Video transcript</strong></summary>';
            $html .= '<div style="white-space:pre-wrap">' . s($transcript) . '</div></details>';
        }

        $resourceorder = ['slideDeck', 'worksheet', 'supplementaryResource', 'additionalMaterial', 'lessonGuide'];
        $reslinks = [];
        foreach ($resourceorder as $type) {
            if (!empty($assetmap[$type])) {
                foreach ($assetmap[$type] as $asset) {
                    $label = (string)($asset['label'] ?? $this->asset_label($type));
                    $reslinks[] = $this->asset_link($courseid, $lessonslug, $type, $label);
                }
            }
        }
        if ($reslinks) {
            $html .= '<h3>Learning materials</h3><p><small>Use the lesson materials below to support learning, practice and revision.</small></p><ul><li>' . implode('</li><li>', $reslinks) . '</li></ul>';
        }

        $starter = is_array($quizdata['starterQuiz'] ?? null) ? $quizdata['starterQuiz'] : [];
        $exit = is_array($quizdata['exitQuiz'] ?? null) ? $quizdata['exitQuiz'] : [];
        if (!empty($nativequizlinks['starter'])) {
            $html .= '<h3>Starter knowledge check</h3><p><a class="btn btn-secondary" href="' . s($nativequizlinks['starter']) . '">Start knowledge check</a></p>';
        } else if ($starter) {
            $html .= '<h3>Starter quiz</h3>' . $this->quiz_html($starter);
        }
        if (!empty($nativequizlinks['exit'])) {
            $html .= '<h3>Exit assessment</h3><p><a class="btn btn-primary" href="' . s($nativequizlinks['exit']) . '">Start exit assessment</a></p>' .
                '<p><small>The exit quiz uses Moodle grading and requires a 70% pass mark.</small></p>';
        } else if ($exit) {
            $html .= '<h3>Exit quiz</h3>' . $this->quiz_html($exit);
        }

        $oakurl = (string)($assetdata['oakUrl'] ?? $summary['oakUrl'] ?? 'https://www.thenational.academy/');
        $html .= '<hr><p><small>Source: <a href="' . s($oakurl) . '" target="_blank" rel="noopener">Oak National Academy</a>. ' .
            'Oak lesson content is used under the applicable Open Government Licence terms except where otherwise stated.</small></p>';
        if (!empty($assetdata['attribution']) && is_array($assetdata['attribution'])) {
            $html .= '<ul>';
            foreach ($assetdata['attribution'] as $line) {
                $html .= '<li><small>' . s((string)$line) . '</small></li>';
            }
            $html .= '</ul>';
        }

        $notices = array_filter($errors);
        if ($notices) {
            $html .= '<details><summary><small>Unavailable/restricted Oak items</small></summary><ul>';
            foreach ($notices as $name => $message) {
                $html .= '<li><small>' . s(ucfirst((string)$name)) . ': ' . s((string)$message) . '</small></li>';
            }
            $html .= '</ul></details>';
        }

        $html .= '</div>';
        return $html;
    }

    private function asset_link(int $courseid, string $lesson, string $type, string $label): string {
        $url = new \moodle_url('/local/jupiter_oak/asset.php', [
            'courseid' => $courseid, 'lesson' => $lesson, 'type' => $type,
        ]);
        return '<a href="' . s($url->out(false)) . '" target="_blank" rel="noopener">' . s($label) . '</a>';
    }

    private function first_text(array $data, array $keys): string {
        foreach ($keys as $key) {
            if (!array_key_exists($key, $data)) {
                continue;
            }
            $value = $data[$key];
            if (is_string($value) && trim($value) !== '') {
                return trim($value);
            }
            if (is_array($value)) {
                foreach ($value as $item) {
                    if (is_string($item) && trim($item) !== '') {
                        return trim($item);
                    }
                    if (is_array($item)) {
                        foreach (['text', 'content', 'value', 'tip'] as $subkey) {
                            if (!empty($item[$subkey]) && is_string($item[$subkey])) {
                                return trim($item[$subkey]);
                            }
                        }
                    }
                }
            }
        }
        return '';
    }

    private function first_list(array $data, array $keys): array {
        foreach ($keys as $key) {
            if (empty($data[$key]) || !is_array($data[$key])) {
                continue;
            }
            $out = [];
            foreach ($data[$key] as $item) {
                if (is_string($item)) {
                    $out[] = $item;
                } else if (is_array($item)) {
                    foreach (['keyLearningPoint', 'text', 'content', 'description'] as $subkey) {
                        if (!empty($item[$subkey]) && is_string($item[$subkey])) {
                            $out[] = $item[$subkey];
                            break;
                        }
                    }
                }
            }
            if ($out) {
                return $out;
            }
        }
        return [];
    }

    private function list_html(array $items): string {
        return '<ul><li>' . implode('</li><li>', array_map(static fn($v) => s((string)$v), $items)) . '</li></ul>';
    }

    private function normalise_keywords($raw): array {
        if (!is_array($raw)) {
            return [];
        }
        $out = [];
        foreach ($raw as $item) {
            if (is_string($item)) {
                $out[] = ['keyword' => $item, 'description' => ''];
            } else if (is_array($item)) {
                $word = (string)($item['keyword'] ?? $item['word'] ?? $item['text'] ?? '');
                if ($word !== '') {
                    $out[] = [
                        'keyword' => $word,
                        'description' => (string)($item['description'] ?? $item['definition'] ?? ''),
                    ];
                }
            }
        }
        return $out;
    }

    private function misconceptions_html($raw): string {
        if (is_string($raw) && trim($raw) !== '') {
            return '<p>' . s($raw) . '</p>';
        }
        if (!is_array($raw)) {
            return '';
        }
        $html = '';
        foreach ($raw as $item) {
            if (is_string($item)) {
                $html .= '<p>' . s($item) . '</p>';
                continue;
            }
            if (!is_array($item)) {
                continue;
            }
            $mistake = (string)($item['misconception'] ?? $item['misconceptionText'] ?? $item['text'] ?? '');
            $response = (string)($item['response'] ?? $item['misconceptionResponse'] ?? $item['responseText'] ?? '');
            if ($mistake !== '') {
                $html .= '<p><strong>Misconception:</strong> ' . s($mistake) . '</p>';
            }
            if ($response !== '') {
                $html .= '<p><strong>Response:</strong> ' . s($response) . '</p>';
            }
        }
        return $html;
    }

    private function extract_transcript(array $data): string {
        foreach (['transcript', 'videoTranscript', 'text', 'content'] as $key) {
            if (!empty($data[$key]) && is_string($data[$key])) {
                return trim($data[$key]);
            }
        }
        if (array_is_list($data)) {
            $parts = [];
            foreach ($data as $item) {
                if (is_string($item)) {
                    $parts[] = $item;
                } else if (is_array($item)) {
                    foreach (['text', 'transcript', 'content'] as $key) {
                        if (!empty($item[$key]) && is_string($item[$key])) {
                            $parts[] = $item[$key];
                            break;
                        }
                    }
                }
            }
            return trim(implode("\n\n", $parts));
        }
        return '';
    }

    private function quiz_html(array $questions): string {
        $html = '<ol>';
        foreach ($questions as $question) {
            if (!is_array($question)) {
                continue;
            }
            $prompt = (string)($question['question'] ?? $question['prompt'] ?? 'Question');
            $html .= '<li><p><strong>' . s($prompt) . '</strong></p>';
            $answers = is_array($question['answers'] ?? null) ? $question['answers'] : [];
            if ($answers) {
                $html .= '<ul>';
                $correct = [];
                foreach ($answers as $answer) {
                    if (!is_array($answer)) {
                        continue;
                    }
                    $content = (string)($answer['content'] ?? $answer['text'] ?? $answer['correctChoice'] ?? '');
                    if ($content === '') {
                        continue;
                    }
                    $html .= '<li>' . s($content) . '</li>';
                    if (array_key_exists('distractor', $answer) && $answer['distractor'] === false) {
                        $correct[] = $content;
                    } else if (!empty($answer['correct'])) {
                        $correct[] = $content;
                    }
                }
                $html .= '</ul>';
                if ($correct) {
                    $html .= '<details><summary>Check answer</summary><p>' . s(implode('; ', $correct)) . '</p></details>';
                }
            }
            $html .= '</li>';
        }
        $html .= '</ol>';
        return $html;
    }

    /** Keep imported activities grouped in a professional learner sequence. */
    private function order_unit_activities(int $courseid, int $sectionnum, array $lessons): void {
        global $DB;
        $section = $DB->get_record('course_sections', ['course' => $courseid, 'section' => $sectionnum], '*', MUST_EXIST);
        $current = array_values(array_filter(array_map('intval', explode(',', (string)$section->sequence))));
        $ordered = [];
        foreach ($lessons as $lesson) {
            $slug = $lesson['slug'];
            foreach ([['lesson', $slug], ['quiz', $slug . '-starter'], ['quiz', $slug . '-exit']] as [$type, $oakslug]) {
                $mapping = $DB->get_record('local_jupiter_oak_import', [
                    'itemtype' => $type, 'oakslug' => $oakslug, 'courseid' => $courseid,
                ]);
                if ($mapping && !empty($mapping->cmid) && in_array((int)$mapping->cmid, $current, true)) {
                    $ordered[] = (int)$mapping->cmid;
                }
            }
        }
        // Preserve any administrator-created/untracked activities in their existing order.
        foreach ($current as $cmid) {
            if (!in_array($cmid, $ordered, true)) {
                $ordered[] = $cmid;
            }
        }
        $section->sequence = implode(',', $ordered);
        $DB->update_record('course_sections', $section);
    }

    /**
     * Apply a professional lesson progression:
     * Lesson (view) -> Starter (receive grade) -> Exit (pass at 70%) -> next Lesson.
     *
     * Moodle stores availability conditions as JSON on course_modules. Completion status values:
     * 1 = complete, 2 = complete/pass. The standard availability_completion condition reads them.
     */
    private function apply_learning_progression(int $courseid, array $lessons): void {
        global $DB;

        $previousexitcmid = null;
        foreach ($lessons as $lesson) {
            $slug = $lesson['slug'];
            $lessonmap = $DB->get_record('local_jupiter_oak_import', [
                'itemtype' => 'lesson', 'oakslug' => $slug, 'courseid' => $courseid,
            ]);
            $startermap = $DB->get_record('local_jupiter_oak_import', [
                'itemtype' => 'quiz', 'oakslug' => $slug . '-starter', 'courseid' => $courseid,
            ]);
            $exitmap = $DB->get_record('local_jupiter_oak_import', [
                'itemtype' => 'quiz', 'oakslug' => $slug . '-exit', 'courseid' => $courseid,
            ]);

            $lessoncmid = $lessonmap && !empty($lessonmap->cmid) ? (int)$lessonmap->cmid : 0;
            $startercmid = $startermap && !empty($startermap->cmid) ? (int)$startermap->cmid : 0;
            $exitcmid = $exitmap && !empty($exitmap->cmid) ? (int)$exitmap->cmid : 0;

            if ($lessoncmid && $DB->record_exists('course_modules', ['id' => $lessoncmid])) {
                $DB->set_field('course_modules', 'completion', COMPLETION_TRACKING_AUTOMATIC, ['id' => $lessoncmid]);
                $DB->set_field('course_modules', 'completionview', 1, ['id' => $lessoncmid]);
                $DB->set_field('course_modules', 'completiongradeitemnumber', null, ['id' => $lessoncmid]);
                $DB->set_field('course_modules', 'completionpassgrade', 0, ['id' => $lessoncmid]);
                $this->set_completion_availability($lessoncmid, $previousexitcmid, $previousexitcmid ? COMPLETION_COMPLETE_PASS : null);
            }

            if ($startercmid && $DB->record_exists('course_modules', ['id' => $startercmid])) {
                $DB->set_field('course_modules', 'completion', COMPLETION_TRACKING_AUTOMATIC, ['id' => $startercmid]);
                $DB->set_field('course_modules', 'completionview', 0, ['id' => $startercmid]);
                $DB->set_field('course_modules', 'completiongradeitemnumber', 0, ['id' => $startercmid]);
                $DB->set_field('course_modules', 'completionpassgrade', 0, ['id' => $startercmid]);
                $this->set_completion_availability($startercmid, $lessoncmid ?: null, $lessoncmid ? COMPLETION_COMPLETE : null);
            }

            if ($exitcmid && $DB->record_exists('course_modules', ['id' => $exitcmid])) {
                $DB->set_field('course_modules', 'completion', COMPLETION_TRACKING_AUTOMATIC, ['id' => $exitcmid]);
                $DB->set_field('course_modules', 'completionview', 0, ['id' => $exitcmid]);
                $DB->set_field('course_modules', 'completiongradeitemnumber', 0, ['id' => $exitcmid]);
                $DB->set_field('course_modules', 'completionpassgrade', 1, ['id' => $exitcmid]);
                $this->set_completion_availability($exitcmid, $startercmid ?: null, $startercmid ? COMPLETION_COMPLETE : null);
                $previousexitcmid = $exitcmid;
            }
        }
    }

    /**
     * Register every Oak Exit quiz in this course as a native course-completion
     * activity criterion. The operation is idempotent and uses ALL aggregation.
     *
     * Safety rule: once any learner has already completed the course we do not
     * silently add new requirements, because that would change the meaning of an
     * already-issued completion/certificate. Finish curriculum imports before
     * publishing/enrolling learners, or deliberately reset completion data first.
     */
    private function sync_exit_course_completion(int $courseid): void {
        global $CFG, $DB;

        require_once($CFG->libdir . '/completionlib.php');

        if (!$DB->get_field('course', 'enablecompletion', ['id' => $courseid])) {
            $DB->set_field('course', 'enablecompletion', 1, ['id' => $courseid]);
        }

        $exitmaps = $DB->get_records_select(
            'local_jupiter_oak_import',
            'courseid = :courseid AND itemtype = :itemtype AND ' . $DB->sql_like('oakslug', ':suffix'),
            ['courseid' => $courseid, 'itemtype' => 'quiz', 'suffix' => '%-exit'],
            'id ASC'
        );

        $exitcmids = [];
        foreach ($exitmaps as $map) {
            $cmid = (int)($map->cmid ?? 0);
            if ($cmid > 0 && $DB->record_exists('course_modules', ['id' => $cmid, 'course' => $courseid])) {
                $exitcmids[$cmid] = $cmid;
            }
        }
        if (!$exitcmids) {
            return;
        }

        $existing = $DB->get_records('course_completion_criteria', [
            'course' => $courseid,
            'criteriatype' => COMPLETION_CRITERIA_TYPE_ACTIVITY,
        ]);
        $existingcmids = [];
        foreach ($existing as $criterion) {
            $criterioncmid = (int)$criterion->moduleinstance;
            $existingcmids[$criterioncmid] = true;

            // Repair criteria created by Jupiter Oak v0.10.9. Moodle's activity
            // completion criterion requires the module name as well as the CM id.
            // Restrict the repair to CM ids belonging to Oak Exit quizzes so that
            // unrelated administrator-defined completion criteria are untouched.
            if ($criterioncmid > 0 && isset($exitcmids[$criterioncmid]) && empty($criterion->module)) {
                $criterion->module = 'quiz';
                $DB->update_record('course_completion_criteria', $criterion);
            }
        }

        $missing = array_values(array_filter($exitcmids, static fn($cmid) => empty($existingcmids[$cmid])));
        if ($missing && $DB->record_exists_select(
            'course_completions',
            'course = :course AND timecompleted IS NOT NULL',
            ['course' => $courseid]
        )) {
            throw new \moodle_exception(
                'Oak Exit quizzes were imported, but course-completion criteria were not changed because this course already has completed learners. ' .
                'Do not silently invalidate issued completions. Finalise the curriculum before production enrolments, or explicitly reset completion data in a controlled test.'
            );
        }

        foreach ($missing as $cmid) {
            $DB->insert_record('course_completion_criteria', (object)[
                'course' => $courseid,
                'criteriatype' => COMPLETION_CRITERIA_TYPE_ACTIVITY,
                'module' => 'quiz',
                'moduleinstance' => $cmid,
                'courseinstance' => null,
                'enrolperiod' => null,
                'timeend' => null,
                'gradepass' => null,
                'role' => null,
            ]);
        }

        // Overall course completion = ALL conditions.
        $overall = $DB->get_record_select('course_completion_aggr_methd',
            'course = :course AND criteriatype IS NULL', ['course' => $courseid]);
        if ($overall) {
            if ((int)$overall->method !== COMPLETION_AGGREGATION_ALL) {
                $overall->method = COMPLETION_AGGREGATION_ALL;
                $overall->value = null;
                $DB->update_record('course_completion_aggr_methd', $overall);
            }
        } else {
            $DB->insert_record('course_completion_aggr_methd', (object)[
                'course' => $courseid,
                'criteriatype' => null,
                'method' => COMPLETION_AGGREGATION_ALL,
                'value' => null,
            ]);
        }

        // Activity completion group = ALL Exit activities.
        $activityagg = $DB->get_record('course_completion_aggr_methd', [
            'course' => $courseid,
            'criteriatype' => COMPLETION_CRITERIA_TYPE_ACTIVITY,
        ]);
        if ($activityagg) {
            if ((int)$activityagg->method !== COMPLETION_AGGREGATION_ALL) {
                $activityagg->method = COMPLETION_AGGREGATION_ALL;
                $activityagg->value = null;
                $DB->update_record('course_completion_aggr_methd', $activityagg);
            }
        } else {
            $DB->insert_record('course_completion_aggr_methd', (object)[
                'course' => $courseid,
                'criteriatype' => COMPLETION_CRITERIA_TYPE_ACTIVITY,
                'method' => COMPLETION_AGGREGATION_ALL,
                'value' => null,
            ]);
        }

        if ($missing) {
            // Existing in-progress learners need course completion re-evaluated.
            $DB->set_field('course_completions', 'reaggregate', time(), ['course' => $courseid]);
        }
    }

    /** Set or clear one completion-based availability restriction. */
    private function set_completion_availability(int $cmid, ?int $requiredcmid, ?int $requiredstate): void {
        global $DB;
        if (!$requiredcmid || $requiredstate === null) {
            $DB->set_field('course_modules', 'availability', null, ['id' => $cmid]);
            return;
        }
        $availability = [
            'op' => '&',
            'c' => [[
                'type' => 'completion',
                'cm' => $requiredcmid,
                'e' => $requiredstate,
            ]],
            'showc' => [true],
        ];
        $DB->set_field('course_modules', 'availability', json_encode($availability), ['id' => $cmid]);
    }

    private function purge_legacy_asset_modules(int $courseid, string $lessonslug): void {
        global $DB;
        $records = $DB->get_records('local_jupiter_oak_import', [
            'itemtype' => 'asset', 'courseid' => $courseid, 'parentslug' => $lessonslug,
        ]);
        foreach ($records as $record) {
            if (!empty($record->cmid) && $DB->record_exists('course_modules', ['id' => $record->cmid])) {
                course_delete_module((int)$record->cmid, false);
            }
            $record->cmid = null;
            $record->status = 'removed';
            $record->statusmessage = 'Legacy per-asset activity removed by v0.7 consolidated lesson importer.';
            $record->timemodified = time();
            $DB->update_record('local_jupiter_oak_import', $record);
        }
    }

    /**
     * Create one native Moodle quiz for an Oak starter/exit quiz.
     * Existing mapped quizzes are reused so refreshes remain idempotent.
     */
    private function sync_native_quiz(int $courseid, int $sectionnum, string $lessonslug, string $lessontitle,
            int $lessonorder, string $kind, array $questions, bool $requirepass): string {
        global $DB;

        $quizslug = $lessonslug . '-' . $kind;
        $mapping = $DB->get_record('local_jupiter_oak_import', [
            'itemtype' => 'quiz', 'oakslug' => $quizslug, 'courseid' => $courseid,
        ]);

        if ($mapping && !empty($mapping->cmid) && $DB->record_exists('course_modules', ['id' => $mapping->cmid])) {
            // A refresh must rebuild the native quiz, not merely rename it. Earlier releases
            // returned here, leaving old question text, old review settings and missing-media
            // questions permanently in Moodle. Rebuilding also ensures Oak question changes are
            // reflected. This intentionally clears attempts for this imported quiz on a unit refresh.
            course_delete_module((int)$mapping->cmid, false);
            $DB->delete_records('local_jupiter_oak_import', ['id' => $mapping->id]);
            $mapping = false;
        }

        $usable = $this->normalise_quiz_questions($questions);
        if (!$usable) {
            throw new \moodle_exception('Oak returned quiz data, but no supported multiple-choice questions could be created.');
        }

        $label = $kind === 'exit' ? 'Exit quiz' : 'Starter quiz';
        $name = sprintf('L%02d | %s | %s', max(1, $lessonorder), $kind === 'exit' ? 'Exit' : 'Starter', $lessontitle);
        $moduleinfo = (object)[
            'modulename' => 'quiz',
            'course' => $courseid,
            'section' => $sectionnum,
            'visible' => 1,
            'name' => $name,
            'introeditor' => [
                'text' => '<p>Imported from Oak National Academy for the lesson <strong>' . s($lessontitle) . '</strong>.</p>',
                'format' => FORMAT_HTML,
                'itemid' => 0,
            ],
            'grade' => 100,
            'attempts' => 0,
            'grademethod' => QUIZ_GRADEHIGHEST,
            'questionsperpage' => 1,
            'preferredbehaviour' => 'deferredfeedback',
            'shuffleanswers' => 1,
            // Show the learner their achieved mark/grade after submitting, but do not
            // expose the attempted question review, correctness or right answers.
            // 4368 = immediately after + while open + after close in Moodle's review bitmask.
            'reviewattempt' => 4368,
            'reviewcorrectness' => 4368,
            'reviewmarks' => 4368,
            'reviewmaxmarks' => 4368,
            'reviewspecificfeedback' => 0,
            'reviewgeneralfeedback' => 0,
            'reviewrightanswer' => 0,
            'reviewoverallfeedback' => 4368,
            'timeopen' => 0,
            'timeclose' => 0,
            'timelimit' => 0,
            'overduehandling' => 'autosubmit',
            'graceperiod' => 0,
            // Moodle quiz DB fields are NOT NULL. create_module() does not populate
            // access-rule defaults when a module is created programmatically, so
            // provide the same empty/default values as the quiz settings form.
            // Moodle 5.1 quiz_process_options() copies quizpassword into the
            // database password field. Supplying only 'password' is overwritten.
            'quizpassword' => '',
            'subnet' => '',
            'browsersecurity' => '-',
            'completion' => COMPLETION_TRACKING_AUTOMATIC,
            'completionview' => 0,
            'completiongradeitemnumber' => 0,
            'completionpassgrade' => $requirepass ? 1 : 0,
        ];
        $created = create_module($moduleinfo);
        $cmid = (int)$created->coursemodule;
        $cm = get_coursemodule_from_id('quiz', $cmid, $courseid, false, MUST_EXIST);
        $quiz = $DB->get_record('quiz', ['id' => $cm->instance], '*', MUST_EXIST);

        $questionids = $this->import_gift_questions_into_quiz($courseid, $cmid, $quiz, $usable, $quizslug);
        if (!$questionids) {
            course_delete_module($cmid, false);
            throw new \moodle_exception('No native Moodle questions were created for the Oak quiz.');
        }

        $quizobj = \mod_quiz\quiz_settings::create($quiz->id);
        $gradecalculator = $quizobj->get_grade_calculator();
        $gradecalculator->recompute_quiz_sumgrades();
        // Explicitly set the quiz maximum to 100 after slots exist. This makes a 4/5
        // attempt rescale to 80/100 and keeps the gradebook/pass threshold in the same scale.
        $gradecalculator->update_quiz_maximum_grade(100.0);
        $quiz = $DB->get_record('quiz', ['id' => $quiz->id], '*', MUST_EXIST);
        quiz_grade_item_update($quiz);

        // Defensive DB update because programmatic module creation can vary across Moodle releases.
        $DB->set_field('quiz', 'reviewattempt', 4368, ['id' => $quiz->id]);
        $DB->set_field('quiz', 'reviewcorrectness', 4368, ['id' => $quiz->id]);
        $DB->set_field('quiz', 'reviewmarks', 4368, ['id' => $quiz->id]);
        if ($DB->get_manager()->field_exists('quiz', 'reviewmaxmarks')) {
            $DB->set_field('quiz', 'reviewmaxmarks', 4368, ['id' => $quiz->id]);
        }
        $DB->set_field('quiz', 'reviewspecificfeedback', 0, ['id' => $quiz->id]);
        $DB->set_field('quiz', 'reviewgeneralfeedback', 0, ['id' => $quiz->id]);
        $DB->set_field('quiz', 'reviewrightanswer', 0, ['id' => $quiz->id]);
        $DB->set_field('quiz', 'reviewoverallfeedback', 4368, ['id' => $quiz->id]);
        if ($requirepass) {
            $DB->delete_records('quiz_feedback', ['quizid' => $quiz->id]);
            $DB->insert_record('quiz_feedback', (object)[
                'quizid' => $quiz->id, 'feedbacktext' => '<strong>Passed</strong> — you achieved at least 70%. Lesson assessment complete.',
                'feedbacktextformat' => FORMAT_HTML, 'mingrade' => 70.0, 'maxgrade' => 100.00001,
            ]);
            $DB->insert_record('quiz_feedback', (object)[
                'quizid' => $quiz->id, 'feedbacktext' => '<strong>Not passed</strong> — your score is below 70%. Review the lesson and try again.',
                'feedbacktextformat' => FORMAT_HTML, 'mingrade' => 0.0, 'maxgrade' => 70.0,
            ]);
        }

        if ($requirepass) {
            $gradeitem = $DB->get_record('grade_items', [
                'courseid' => $courseid, 'itemtype' => 'mod', 'itemmodule' => 'quiz', 'iteminstance' => $quiz->id,
            ]);
            if ($gradeitem) {
                $gradeitem->gradepass = 70.0;
                $DB->update_record('grade_items', $gradeitem);
                // Ensure Moodle's gradebook/completion caches see the new pass threshold immediately.
                if (class_exists('grade_item')) {
                    $gi = \grade_item::fetch(['id' => $gradeitem->id]);
                    if ($gi) {
                        $gi->gradepass = 70.0;
                        $gi->update('local/jupiter_oak');
                    }
                }
            }
        }

        $this->record_mapping('quiz', $quizslug, $lessonslug, null, null, $kind,
            $courseid, $sectionnum, $cmid, 'imported', ucfirst($kind) . ' native Moodle quiz created from Oak questions.');

        return (new \moodle_url('/mod/quiz/view.php', ['id' => $cmid]))->out(false);
    }

    private function normalise_quiz_questions(array $questions): array {
        $out = [];
        foreach ($questions as $index => $question) {
            if (!is_array($question)) {
                continue;
            }
            $prompt = trim((string)($question['question'] ?? $question['prompt'] ?? $question['questionText'] ?? ''));
            $supplementary = trim((string)($question['text'] ?? ''));
            $answers = is_array($question['answers'] ?? null) ? $question['answers'] : [];

            // Oak's documented lesson quiz response currently does not expose an image URL/binary
            // for image-dependent questions. Never create an unfair Moodle question with the model
            // or diagram missing. If Oak supplies useful supplementary text, include it; if the
            // question/answers declare image media that we cannot faithfully render, skip it.
            // Oak can represent image media in several nested shapes. If a usable HTTP(S)
            // URL is present, render it in the Moodle question. If the wording clearly depends
            // on a diagram/model but Oak supplied no renderable media, skip the question rather
            // than grading a learner on an incomplete prompt.
            $imageurl = $this->find_question_image_url($question);
            $hasimageanswer = false;
            foreach ($answers as $mediaanswer) {
                if (is_array($mediaanswer) && strtolower((string)($mediaanswer['type'] ?? $mediaanswer['answerType'] ?? 'text')) === 'image') {
                    $hasimageanswer = true;
                    break;
                }
            }
            if ($supplementary !== '') {
                $prompt .= '<br><br>' . $supplementary;
            }
            if ($imageurl !== '') {
                $prompt .= '<br><br><img src="' . s($imageurl) . '" alt="Question diagram" style="max-width:100%;height:auto">';
            } else {
                $dependentwording = preg_match('/\b(model|diagram|image|picture|shown|below|above|figure|graph)\b/i', $prompt);
                if ($hasimageanswer || $dependentwording) {
                    continue;
                }
            }
            $questiontype = strtolower(trim((string)($question['questionType'] ?? $question['type'] ?? 'multiple-choice')));
            if ($prompt === '' || !$answers) {
                continue;
            }

            // Oak currently returns multiple-choice, short-answer, matching and ordering questions.
            // v0.7.2 creates native Moodle questions for multiple-choice and short-answer.
            if (in_array($questiontype, ['multiple-choice', 'multiple_choice', 'multiplechoice', 'mcq'], true)) {
                $normalanswers = [];
                foreach ($answers as $answer) {
                    if (!is_array($answer)) {
                        continue;
                    }
                    $text = trim((string)($answer['content'] ?? $answer['text'] ?? $answer['answer'] ?? ''));
                    if ($text === '') {
                        continue;
                    }
                    $correct = (array_key_exists('distractor', $answer) && $answer['distractor'] === false) ||
                        (!empty($answer['correct'])) || (!empty($answer['isCorrect']));
                    $normalanswers[] = ['text' => $text, 'correct' => $correct];
                }
                $correctcount = count(array_filter($normalanswers, static fn($a) => $a['correct']));
                if (count($normalanswers) >= 2 && $correctcount >= 1) {
                    $out[] = [
                        'type' => 'multichoice',
                        'name' => 'Oak ' . ($index + 1) . ': ' . shorten_text($prompt, 60),
                        'prompt' => $prompt,
                        'answers' => $normalanswers,
                        'correctcount' => $correctcount,
                    ];
                }
                continue;
            }

            if (in_array($questiontype, ['short-answer', 'short_answer', 'shortanswer'], true)) {
                $acceptable = [];
                foreach ($answers as $answer) {
                    if (!is_array($answer)) {
                        continue;
                    }
                    $text = trim((string)($answer['content'] ?? $answer['text'] ?? $answer['answer'] ?? ''));
                    if ($text === '') {
                        continue;
                    }
                    // Oak marks incorrect options as distractors. Do not accidentally accept every
                    // supplied short-answer option as correct. If correctness metadata is present,
                    // accept only the non-distractor/correct values.
                    $hascorrectness = array_key_exists('distractor', $answer) || array_key_exists('correct', $answer) || array_key_exists('isCorrect', $answer);
                    $iscorrect = (array_key_exists('distractor', $answer) && $answer['distractor'] === false) ||
                        (!empty($answer['correct'])) || (!empty($answer['isCorrect']));
                    if (!$hascorrectness || $iscorrect) {
                        $acceptable[] = $text;
                    }
                }
                $acceptable = array_values(array_unique($acceptable));
                if ($acceptable) {
                    $out[] = [
                        'type' => 'shortanswer',
                        'name' => 'Oak ' . ($index + 1) . ': ' . shorten_text($prompt, 60),
                        'prompt' => $prompt,
                        'answers' => $acceptable,
                    ];
                }
            }
        }
        return $out;
    }

    /** Find the first usable image URL anywhere in an Oak quiz-question payload. */
    private function find_question_image_url(array $value): string {
        $preferredkeys = ['imageUrl', 'imageURL', 'questionImageUrl', 'questionImageURL', 'url', 'src', 'source'];
        foreach ($preferredkeys as $key) {
            if (!empty($value[$key]) && is_string($value[$key]) && preg_match('~^https?://~i', $value[$key])) {
                $url = clean_param($value[$key], PARAM_URL);
                if ($url !== '' && preg_match('/\.(?:png|jpe?g|gif|webp|svg)(?:\?|$)/i', $url)) {
                    return $url;
                }
            }
        }
        foreach ($value as $key => $child) {
            if (is_string($child) && preg_match('~^https?://~i', $child) &&
                    preg_match('/(?:image|img|media|asset|diagram|model)/i', (string)$key)) {
                $url = clean_param($child, PARAM_URL);
                if ($url !== '') {
                    return $url;
                }
            }
            if (is_array($child)) {
                $found = $this->find_question_image_url($child);
                if ($found !== '') {
                    return $found;
                }
            }
        }
        return '';
    }

    private function gift_escape(string $text): string {
        $text = str_replace(["\r\n", "\r"], "\n", $text);
        return strtr($text, ['\\' => '\\\\', '~' => '\\~', '=' => '\\=', '{' => '\\{', '}' => '\\}', '#' => '\\#', ':' => '\\:']);
    }

    private function import_gift_questions_into_quiz(int $courseid, int $cmid, \stdClass $quiz,
            array $questions, string $quizslug): array {
        $course = get_course($courseid);

        // Moodle 5.x stores reusable questions in a Question bank activity context.
        // Importing directly into the Quiz module context can fail on modern Moodle
        // question-bank schema/API expectations. Reuse/create the course's default
        // system-type question bank, import there, then add those questions to Quiz.
        $qbankcm = \core_question\local\bank\question_bank_helper::get_default_open_instance_system_type($course, true);
        $questioncontext = \context_module::instance($qbankcm->id);
        $category = question_get_top_category($questioncontext->id, true);
        $gift = '';
        foreach ($questions as $i => $question) {
            $promptprefix = (strpos($question['prompt'], '<') !== false) ? '[html]' : '';
            $gift .= '::' . $this->gift_escape($quizslug . '-' . ($i + 1)) . '::' . $promptprefix . $this->gift_escape($question['prompt']) . " {\n";
            if (($question['type'] ?? '') === 'shortanswer') {
                foreach ($question['answers'] as $answer) {
                    $gift .= '=' . $this->gift_escape($answer) . "\n";
                }
            } else {
                $correctcount = max(1, (int)($question['correctcount'] ?? 1));
                $positive = 100.0 / $correctcount;
                foreach ($question['answers'] as $answer) {
                    if ($answer['correct']) {
                        if ($correctcount === 1) {
                            $gift .= '=' . $this->gift_escape($answer['text']) . "\n";
                        } else {
                            $gift .= '~%' . rtrim(rtrim(number_format($positive, 5, '.', ''), '0'), '.') . '%' . $this->gift_escape($answer['text']) . "\n";
                        }
                    } else {
                        $gift .= '~' . $this->gift_escape($answer['text']) . "\n";
                    }
                }
            }
            $gift .= "}\n\n";
        }

        $tmp = make_request_directory() . '/jupiter-oak-' . sha1($quizslug . microtime(true)) . '.gift';
        file_put_contents($tmp, $gift);
        $format = new \qformat_gift();
        $format->setCategory($category);
        $format->setCourse($course);
        $format->setContexts([$questioncontext]);
        $format->setFilename($tmp);
        $format->setRealfilename(basename($tmp));
        $format->setMatchgrades('error');
        $format->setCatfromfile(false);
        $format->setContextfromfile(false);
        $format->setStoponerror(false);
        $format->set_display_progress(false);
        if (!$format->importpreprocess() || !$format->importprocess() || !$format->importpostprocess()) {
            @unlink($tmp);
            throw new \moodle_exception('Moodle could not import the generated Oak quiz questions.');
        }
        @unlink($tmp);

        $questionids = array_map('intval', $format->questionids);
        foreach ($questionids as $questionid) {
            quiz_require_question_use($questionid);
            quiz_add_quiz_question($questionid, $quiz, 0, 1);
        }
        return $questionids;
    }

    /**
     * Return a useful admin-safe error message. Moodle's generic dmlwriteexception
     * message is often only "Error writing to database"; debuginfo identifies
     * the failing table/constraint without exposing credentials.
     */
    private function safe_exception_message(\Throwable $e): string {
        $message = $e->getMessage();
        if ($e instanceof \moodle_exception && !empty($e->debuginfo)) {
            $debug = trim(strip_tags((string)$e->debuginfo));
            if ($debug !== '') {
                $debug = preg_replace('/\s+/', ' ', $debug);
                $message .= ' [' . shorten_text($debug, 350) . ']';
            }
        }
        return $message;
    }

    private function count_unit_native_quizzes(int $courseid, string $unitslug): int {
        global $DB;
        $lessons = $DB->get_records('local_jupiter_oak_import', [
            'itemtype' => 'lesson', 'courseid' => $courseid, 'parentslug' => $unitslug,
        ]);
        if (!$lessons) {
            return 0;
        }
        $count = 0;
        foreach ($lessons as $lesson) {
            $count += $DB->count_records_select('local_jupiter_oak_import',
                'itemtype = ? AND courseid = ? AND parentslug = ? AND status = ?',
                ['quiz', $courseid, $lesson->oakslug, 'imported']);
        }
        return $count;
    }

    private function asset_label(string $type): string {
        $labels = [
            'slideDeck' => 'Slide deck', 'video' => 'Video', 'worksheet' => 'Worksheet',
            'worksheetAnswers' => 'Worksheet answers', 'starterQuiz' => 'Starter quiz',
            'starterQuizAnswers' => 'Starter quiz answers', 'exitQuiz' => 'Exit quiz',
            'exitQuizAnswers' => 'Exit quiz answers', 'transcript' => 'Transcript',
            'supplementaryResource' => 'Supplementary resource', 'additionalMaterial' => 'Additional material',
            'lessonGuide' => 'Lesson guide',
        ];
        return $labels[$type] ?? ucwords(trim(preg_replace('/(?<!^)[A-Z]/', ' $0', $type)));
    }

    private function record_mapping(string $itemtype, string $oakslug, ?string $parentslug, ?string $programme,
            ?string $subject, ?string $assettype, int $courseid, ?int $sectionnum, ?int $cmid,
            string $status, string $message = ''): void {
        global $DB, $USER;
        $params = ['itemtype' => $itemtype, 'oakslug' => $oakslug, 'courseid' => $courseid];
        $record = $DB->get_record('local_jupiter_oak_import', $params);
        $now = time();
        $data = (object)[
            'itemtype' => $itemtype,
            'oakslug' => $oakslug,
            'parentslug' => $parentslug,
            'programme' => $programme,
            'subject' => $subject,
            'assettype' => $assettype,
            'courseid' => $courseid,
            'sectionnum' => $sectionnum,
            'cmid' => $cmid,
            'status' => $status,
            'statusmessage' => $message,
            'usermodified' => (int)($USER->id ?? 0),
            'timemodified' => $now,
        ];
        if ($record) {
            $data->id = $record->id;
            $DB->update_record('local_jupiter_oak_import', $data);
        } else {
            $data->timecreated = $now;
            $DB->insert_record('local_jupiter_oak_import', $data);
        }
    }
}
