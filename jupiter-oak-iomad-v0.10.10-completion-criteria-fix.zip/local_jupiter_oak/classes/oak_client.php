<?php
namespace local_jupiter_oak;

defined('MOODLE_INTERNAL') || die();

class oak_client {
    private string $baseurl;
    private string $apikey;

    public function __construct(?string $baseurl = null, ?string $apikey = null) {
        $this->baseurl = rtrim($baseurl ?? (string)get_config('local_jupiter_oak', 'apiurl'), '/');
        $this->apikey = $apikey ?? (string)get_config('local_jupiter_oak', 'apikey');
    }

    private function request(string $path): array {
        global $CFG;
        require_once($CFG->libdir . '/filelib.php');

        if (empty($this->baseurl) || empty($this->apikey)) {
            return ['ok' => false, 'status' => 0, 'data' => null, 'message' => 'Oak API URL or API key is missing.'];
        }

        $curl = new \curl();
        $curl->setHeader([
            'Authorization: Bearer ' . $this->apikey,
            'Accept: application/json',
        ]);

        $response = $curl->get($this->baseurl . $path, [], [
            'CURLOPT_TIMEOUT' => 35,
            'CURLOPT_CONNECTTIMEOUT' => 10,
        ]);
        $info = $curl->get_info();
        $status = isset($info['http_code']) ? (int)$info['http_code'] : 0;
        $decoded = json_decode($response, true);

        if ($status >= 200 && $status < 300 && is_array($decoded)) {
            return ['ok' => true, 'status' => $status, 'data' => $decoded, 'message' => 'OK'];
        }

        return ['ok' => false, 'status' => $status, 'data' => null, 'message' => $this->safe_error_message($response, $status)];
    }

    public function test_connection(): array {
        $result = $this->request('/subjects/maths/programmes');
        if ($result['ok']) {
            $result['message'] = 'Connected successfully. Oak returned ' . count($result['data']) . ' Maths programme(s).';
        }
        return $result;
    }

    public function get_programmes(string $subject): array {
        $subject = clean_param($subject, PARAM_ALPHANUMEXT);
        if ($subject === '') {
            return ['ok' => false, 'status' => 0, 'data' => null, 'message' => 'Subject is missing.'];
        }
        return $this->request('/subjects/' . rawurlencode($subject) . '/programmes');
    }

    public function get_units(string $programme): array {
        $programme = clean_param($programme, PARAM_ALPHANUMEXT);
        if ($programme === '') {
            return ['ok' => false, 'status' => 0, 'data' => null, 'message' => 'Programme is missing.'];
        }
        return $this->request('/programmes/' . rawurlencode($programme) . '/units');
    }

    public function get_unit_summary(string $unit): array {
        $unit = clean_param($unit, PARAM_ALPHANUMEXT);
        if ($unit === '') {
            return ['ok' => false, 'status' => 0, 'data' => null, 'message' => 'Unit is missing.'];
        }
        return $this->request('/units/' . rawurlencode($unit) . '/summary');
    }

    public function get_lesson_summary(string $lesson): array {
        $lesson = clean_param($lesson, PARAM_ALPHANUMEXT);
        if ($lesson === '') {
            return ['ok' => false, 'status' => 0, 'data' => null, 'message' => 'Lesson is missing.'];
        }
        return $this->request('/lessons/' . rawurlencode($lesson) . '/summary');
    }

    public function get_lesson_assets(string $lesson): array {
        $lesson = clean_param($lesson, PARAM_ALPHANUMEXT);
        if ($lesson === '') {
            return ['ok' => false, 'status' => 0, 'data' => null, 'message' => 'Lesson is missing.'];
        }
        return $this->request('/lessons/' . rawurlencode($lesson) . '/assets');
    }

    public function get_lesson_quiz(string $lesson): array {
        $lesson = clean_param($lesson, PARAM_ALPHANUMEXT);
        if ($lesson === '') {
            return ['ok' => false, 'status' => 0, 'data' => null, 'message' => 'Lesson is missing.'];
        }
        return $this->request('/lessons/' . rawurlencode($lesson) . '/quiz');
    }

    public function get_lesson_transcript(string $lesson): array {
        $lesson = clean_param($lesson, PARAM_ALPHANUMEXT);
        if ($lesson === '') {
            return ['ok' => false, 'status' => 0, 'data' => null, 'message' => 'Lesson is missing.'];
        }
        return $this->request('/lessons/' . rawurlencode($lesson) . '/transcript');
    }

    private function safe_error_message(string $response, int $status): string {
        if ($status === 401) {
            return 'HTTP 401: Oak rejected the API key.';
        }
        if ($status === 429) {
            return 'HTTP 429: Oak API rate limit reached.';
        }
        if ($status === 0) {
            return 'No HTTP response was received from Oak. Check outbound HTTPS/DNS connectivity.';
        }

        $decoded = json_decode($response, true);
        if (is_array($decoded)) {
            $cause = $decoded['data']['cause'] ?? null;
            if (!empty($cause)) {
                return 'HTTP ' . $status . ': ' . clean_param((string)$cause, PARAM_TEXT);
            }
            if (!empty($decoded['message'])) {
                return 'HTTP ' . $status . ': ' . clean_param((string)$decoded['message'], PARAM_TEXT);
            }
            if (!empty($decoded['error'])) {
                return 'HTTP ' . $status . ': ' . clean_param((string)$decoded['error'], PARAM_TEXT);
            }
        }
        return 'HTTP ' . $status . ': Oak API request was unsuccessful.';
    }
}
