<?php
defined('MOODLE_INTERNAL') || die();

function xmldb_local_jupiter_oak_upgrade($oldversion) {
    global $DB;

    $dbman = $DB->get_manager();

    if ($oldversion < 2026090306) {
        $table = new xmldb_table('local_jupiter_oak_import');
        if (!$dbman->table_exists($table)) {
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('itemtype', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, null);
            $table->add_field('oakslug', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null);
            $table->add_field('parentslug', XMLDB_TYPE_CHAR, '255', null, null, null, null);
            $table->add_field('programme', XMLDB_TYPE_CHAR, '255', null, null, null, null);
            $table->add_field('subject', XMLDB_TYPE_CHAR, '60', null, null, null, null);
            $table->add_field('assettype', XMLDB_TYPE_CHAR, '80', null, null, null, null);
            $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table->add_field('sectionnum', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
            $table->add_field('cmid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
            $table->add_field('status', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'queued');
            $table->add_field('statusmessage', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('usermodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_index('item_course_slug', XMLDB_INDEX_NOTUNIQUE, ['itemtype', 'courseid', 'oakslug']);
            $table->add_index('courseid', XMLDB_INDEX_NOTUNIQUE, ['courseid']);
            $table->add_index('status', XMLDB_INDEX_NOTUNIQUE, ['status']);
            $dbman->create_table($table);
        }

        upgrade_plugin_savepoint(true, 2026090306, 'local', 'jupiter_oak');
    }

    if ($oldversion < 2026090307) {
        // v0.7 introduces importer behaviour only; no schema changes are required.
        upgrade_plugin_savepoint(true, 2026090307, 'local', 'jupiter_oak');
    }

    if ($oldversion < 2026090308) {
        // v0.7.1 fixes question-format library loading; no schema changes are required.
        upgrade_plugin_savepoint(true, 2026090308, 'local', 'jupiter_oak');
    }

    return true;
}
