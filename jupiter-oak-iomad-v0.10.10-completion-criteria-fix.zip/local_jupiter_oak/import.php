<?php
require_once(__DIR__ . '/../../config.php');

require_login();
require_capability('moodle/site:config', context_system::instance());

$subject = required_param('subject', PARAM_ALPHANUMEXT);
$programme = required_param('programme', PARAM_ALPHANUMEXT);
$unit = required_param('unit', PARAM_ALPHANUMEXT);
$unittitle = required_param('unittitle', PARAM_TEXT);
$programmetitle = optional_param('programmetitle', '', PARAM_TEXT);
$mode = optional_param('mode', 'programme', PARAM_ALPHA);
$courseid = optional_param('courseid', 0, PARAM_INT);
$allcompanies = optional_param('allcompanies', 0, PARAM_BOOL);
$companyids = optional_param_array('companyids', [], PARAM_INT);
$confirm = optional_param('confirm', 0, PARAM_BOOL);

$PAGE->set_url(new moodle_url('/local/jupiter_oak/import.php', [
    'subject' => $subject,
    'programme' => $programme,
    'unit' => $unit,
    'unittitle' => $unittitle,
    'programmetitle' => $programmetitle,
]));
$PAGE->set_context(context_system::instance());
$PAGE->set_pagelayout('admin');
$PAGE->set_title('Import Oak unit into Iomad');
$PAGE->set_heading('Import Oak unit into Iomad');

echo $OUTPUT->header();
echo $OUTPUT->heading('Import Oak unit into Iomad');

$provisioner = new \local_jupiter_oak\course_provisioner();
try {
    $companies = $provisioner->get_companies();
} catch (Throwable $e) {
    echo $OUTPUT->notification(s($e->getMessage()), \core\output\notification::NOTIFY_ERROR);
    echo $OUTPUT->footer();
    exit;
}

$companyoptions = [];
foreach ($companies as $company) {
    $companyoptions[(int)$company->id] = format_string($company->name) . ' [' . s($company->shortname) . ']';
}

$courses = get_courses('all', 'fullname ASC', 'c.id,c.fullname,c.shortname,c.visible');
$courseoptions = [];
foreach ($courses as $c) {
    if ((int)$c->id === SITEID) {
        continue;
    }
    $courseoptions[(int)$c->id] = format_string($c->fullname) . ' [' . s($c->shortname) . '] (ID ' . (int)$c->id . ')';
}

if ($confirm && confirm_sesskey()) {
    try {
        $allocationids = $allcompanies ? array_map(static fn($c) => (int)$c->id, $companies) : $companyids;
        $createdcourse = false;

        if ($mode === 'programme') {
            if (!$allocationids) {
                throw new moodle_exception('Select at least one company, or choose Allocate to all active companies.');
            }
            $provision = $provisioner->provision_programme_course($subject, $programme, $programmetitle, $allocationids);
            $courseid = (int)$provision['courseid'];
            $createdcourse = !empty($provision['created']);
        } else {
            if (!isset($courseoptions[$courseid])) {
                throw new moodle_exception('Selected target course does not exist.');
            }
            if ($allocationids) {
                $provisioner->assign_course_to_companies($courseid, $allocationids);
            }
        }

        $importer = new \local_jupiter_oak\importer();
        $result = $importer->import_unit($courseid, $subject, $programme, $unit, $unittitle);

        $prefix = $createdcourse ? 'New hidden Iomad programme course created. ' : 'Existing programme course reused. ';
        echo $OUTPUT->notification(
            $prefix . 'Import complete: ' . (int)$result['createdlessons'] . ' new lesson page(s), ' .
            (int)$result['updatedlessons'] . ' refreshed lesson page(s), and ' .
            (int)($result['nativequizzes'] ?? 0) . ' native Moodle quiz mapping(s). Target course: ' . s($result['coursename']) .
            ' (ID ' . (int)$courseid . ').',
            \core\output\notification::NOTIFY_SUCCESS
        );

        if ($allocationids) {
            echo $OUTPUT->notification(
                'Iomad allocation applied to ' . count(array_unique(array_map('intval', $allocationids))) . ' company/companies. ' .
                'The course remains hidden until review is complete.',
                \core\output\notification::NOTIFY_INFO
            );
        }

        if (!empty($result['errors'])) {
            $details = array_slice(array_map(static function($message) {
                return s(shorten_text((string)$message, 220));
            }, $result['errors']), 0, 8);
            echo $OUTPUT->notification(
                'Oak skipped/restricted some content, or a supported native quiz could not be created. ' .
                'The import continued safely.<br><small>' . implode('<br>', $details) . '</small>',
                \core\output\notification::NOTIFY_WARNING
            );
        }

        echo html_writer::link(new moodle_url('/course/view.php', ['id' => $courseid]), 'Open imported Iomad course', ['class' => 'btn btn-primary']);
        echo ' ';
        echo html_writer::link(new moodle_url('/local/jupiter_oak/browse.php', [
            'subject' => $subject, 'programme' => $programme, 'unit' => $unit,
        ]), 'Back to Oak browser', ['class' => 'btn btn-secondary']);
        echo $OUTPUT->footer();
        exit;
    } catch (Throwable $e) {
        echo $OUTPUT->notification(s($e->getMessage()), \core\output\notification::NOTIFY_ERROR);
    }
}

$displayprogramme = $programmetitle !== '' ? $programmetitle : ucwords(str_replace('-', ' ', $programme));
echo html_writer::tag('p', '<strong>Oak programme:</strong> ' . s($displayprogramme) .
    '<br><strong>Oak unit:</strong> ' . s($unittitle));

echo $OUTPUT->notification(
    '<strong>Recommended production workflow:</strong> create/reuse one hidden Iomad course for the Oak programme, ' .
    'allocate it to the required company/companies, import the selected unit, review it, then publish later.',
    \core\output\notification::NOTIFY_INFO
);

echo html_writer::start_tag('form', ['method' => 'post', 'action' => $PAGE->url->out(false)]);
echo html_writer::input_hidden_params($PAGE->url);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'confirm', 'value' => '1']);

echo html_writer::tag('h3', '1. Import destination');
echo html_writer::start_tag('div', ['class' => 'mb-3']);
echo html_writer::empty_tag('input', ['type' => 'radio', 'id' => 'id_mode_programme', 'name' => 'mode', 'value' => 'programme', 'checked' => 'checked']);
echo ' ' . html_writer::tag('label', '<strong>Create/reuse Oak programme course (recommended)</strong><br><small>One professional course per Oak programme. The course is created hidden and reused for later units.</small>', ['for' => 'id_mode_programme']);
echo html_writer::end_tag('div');

echo html_writer::start_tag('div', ['class' => 'mb-3']);
echo html_writer::empty_tag('input', ['type' => 'radio', 'id' => 'id_mode_existing', 'name' => 'mode', 'value' => 'existing']);
echo ' ' . html_writer::tag('label', 'Import into an existing Iomad course', ['for' => 'id_mode_existing']);
echo '<br>' . html_writer::select($courseoptions, 'courseid', $courseid, ['0' => 'Choose existing course'], ['class' => 'custom-select mt-2']);
echo html_writer::end_tag('div');

echo html_writer::tag('h3', '2. Iomad company allocation');
echo html_writer::tag('p', '<small>Select one or more companies. For a Jupiter-wide catalogue course, use all active companies. The first selected company provides the Moodle course category; Iomad allocations control tenant access.</small>');
if (!$companyoptions) {
    echo $OUTPUT->notification('No active Iomad companies are available.', \core\output\notification::NOTIFY_WARNING);
} else {
    echo html_writer::start_tag('div', ['class' => 'mb-2']);
    echo html_writer::empty_tag('input', ['type' => 'checkbox', 'id' => 'id_allcompanies', 'name' => 'allcompanies', 'value' => '1']);
    echo ' ' . html_writer::tag('label', '<strong>Allocate to all active companies</strong>', ['for' => 'id_allcompanies']);
    echo html_writer::end_tag('div');

    foreach ($companyoptions as $id => $label) {
        $fieldid = 'id_company_' . (int)$id;
        echo html_writer::start_tag('div', ['class' => 'mb-1']);
        echo html_writer::empty_tag('input', ['type' => 'checkbox', 'id' => $fieldid, 'name' => 'companyids[]', 'value' => (int)$id]);
        echo ' ' . html_writer::tag('label', s($label), ['for' => $fieldid]);
        echo html_writer::end_tag('div');
    }
}

echo html_writer::tag('p', '<strong>Safety:</strong> newly created courses remain hidden. This import does not publish a WooCommerce product.', ['class' => 'mt-3']);
echo html_writer::empty_tag('input', ['type' => 'submit', 'value' => 'Provision course and import Oak unit', 'class' => 'btn btn-primary']);
echo html_writer::end_tag('form');

echo $OUTPUT->footer();
