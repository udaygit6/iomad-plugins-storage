<?php
defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    $settings = new admin_settingpage('local_jupiter_oak', get_string('settingsheading', 'local_jupiter_oak'));
    $ADMIN->add('localplugins', $settings);

    $settings->add(new admin_setting_heading(
        'local_jupiter_oak/heading',
        get_string('settingsheading', 'local_jupiter_oak'),
        get_string('settingsdesc', 'local_jupiter_oak')
    ));

    $settings->add(new admin_setting_configtext(
        'local_jupiter_oak/apiurl',
        get_string('apiurl', 'local_jupiter_oak'),
        get_string('apiurl_desc', 'local_jupiter_oak'),
        'https://open-api.thenational.academy',
        PARAM_URL
    ));

    $settings->add(new admin_setting_configpasswordunmask(
        'local_jupiter_oak/apikey',
        get_string('apikey', 'local_jupiter_oak'),
        get_string('apikey_desc', 'local_jupiter_oak'),
        ''
    ));

    $ADMIN->add('localplugins', new admin_externalpage(
        'local_jupiter_oak_test',
        get_string('testconnection', 'local_jupiter_oak'),
        new moodle_url('/local/jupiter_oak/test.php'),
        'moodle/site:config'
    ));

    $ADMIN->add('localplugins', new admin_externalpage(
        'local_jupiter_oak_browse',
        get_string('browsecurriculum', 'local_jupiter_oak'),
        new moodle_url('/local/jupiter_oak/browse.php'),
        'moodle/site:config'
    ));
}
