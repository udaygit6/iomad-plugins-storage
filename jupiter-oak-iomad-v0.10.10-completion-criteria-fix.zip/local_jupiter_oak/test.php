<?php
require_once(__DIR__ . '/../../config.php');

require_login();
require_capability('moodle/site:config', context_system::instance());

$PAGE->set_url(new moodle_url('/local/jupiter_oak/test.php'));
$PAGE->set_context(context_system::instance());
$PAGE->set_pagelayout('admin');
$PAGE->set_title(get_string('testconnection', 'local_jupiter_oak'));
$PAGE->set_heading(get_string('testconnection', 'local_jupiter_oak'));

$client = new \local_jupiter_oak\oak_client();
$result = $client->test_connection();

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('testconnection', 'local_jupiter_oak'));

if ($result['ok']) {
    echo $OUTPUT->notification(get_string('connectionok', 'local_jupiter_oak') . ' ' . s($result['message']), \core\output\notification::NOTIFY_SUCCESS);
} else {
    echo $OUTPUT->notification(get_string('connectionfailed', 'local_jupiter_oak') . ' ' . s($result['message']), \core\output\notification::NOTIFY_ERROR);
}

echo html_writer::div('HTTP status: ' . (int)$result['status']);
echo html_writer::div(html_writer::link(new moodle_url('/admin/settings.php', ['section' => 'local_jupiter_oak']), 'Back to Jupiter Oak settings'), 'mt-3');
echo $OUTPUT->footer();
