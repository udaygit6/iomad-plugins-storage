<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_jupiter_oak';
$plugin->version = 2026090501;
$plugin->release = '0.10.10';
$plugin->requires  = 2024042200;
$plugin->maturity  = MATURITY_ALPHA;
