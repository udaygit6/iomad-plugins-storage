Jupiter Parent Link 0.3.1
- Fixes parent certificate access redirecting to the Iomad login page.
- The one-time endpoint now renders the already-issued Iomad certificate PDF directly.
- It does not create an Iomad login/session and does not call the certificate issuance path.
- Adds view/download delivery mode.
- Token remains random, SHA-256 hashed at rest, 120-second expiry and single use.
- PDF responses are private/no-store.
