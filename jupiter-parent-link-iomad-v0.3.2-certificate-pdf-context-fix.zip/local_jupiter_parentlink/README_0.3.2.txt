Jupiter Parent Link 0.3.2
Fixes direct parent certificate PDF rendering:
- Sets Moodle $PAGE module context before loading the Iomad certificate template.
- Suppresses display_errors before certificate rendering so debug text cannot corrupt PDF bytes.
- Keeps one-time 120-second parent-authorised token and existing ownership validation.
- No new database schema change from 0.3.1.
- WordPress 1.4.1 remains compatible; no WordPress update required for this fix.
