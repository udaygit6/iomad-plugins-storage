Jupiter Parent Link 0.2.2
- Fixes Oak unit Exit-assessment attribution: quiz parentslug identifies a lesson, which is now resolved through the lesson mapping to its unit.
- Uses Moodle quiz_grades as authoritative result data.
- Falls back to best finished non-preview quiz_attempt when an aggregate quiz_grades row is absent.
- Does not fabricate or restore attempts deleted by a prior Oak quiz rebuild.
- No new external-service function and no database schema change.
