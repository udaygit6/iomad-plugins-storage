<?php
// Parent-safe certificate delivery endpoint.
// It never creates a Moodle login session for the parent or learner.
require_once(__DIR__.'/../../config.php');
require_once($CFG->dirroot.'/mod/iomadcertificate/locallib.php');
require_once($CFG->libdir.'/pdflib.php');

$token=required_param('token',PARAM_ALPHANUM);
$hash=hash('sha256',$token);
$r=$DB->get_record('local_jupiter_parent_tokens',['tokenhash'=>$hash]);
if(!$r || !empty($r->used) || (int)$r->expires < time()) {
    throw new moodle_exception('invalidaccess','error');
}

$i=$DB->get_record('iomadcertificate_issues',['id'=>(int)$r->issueid,'userid'=>(int)$r->userid],'*',MUST_EXIST);
$certuser=$DB->get_record('user',['id'=>(int)$i->userid],'*',MUST_EXIST);
$iomadcertificate=$DB->get_record('iomadcertificate',['id'=>(int)$i->iomadcertificateid],'*',MUST_EXIST);
$course=$DB->get_record('course',['id'=>(int)$iomadcertificate->course],'*',MUST_EXIST);
$moduleid=$DB->get_field('modules','id',['name'=>'iomadcertificate'],MUST_EXIST);
$cm=get_coursemodule_from_instance('iomadcertificate',(int)$iomadcertificate->id,(int)$course->id,false,MUST_EXIST);
$context=context_module::instance($cm->id);
$PAGE->set_context($context);
$PAGE->set_cm($cm, $course);
$PAGE->set_url(new moodle_url('/local/jupiter_parentlink/certificate.php'));

// Consume before PDF generation. Refresh/replay cannot re-use this capability URL.
$r->used=1;
$DB->update_record('local_jupiter_parent_tokens',$r);

// IMPORTANT: use the already-issued record. Do not call iomadcertificate_get_issue(),
// because parent access must never issue a new certificate.
$certrecord=$i;

// A PDF response must never be preceded by HTML/debug output.
$CFG->debugdisplay = 0;
@ini_set('display_errors', '0');
@ini_set('log_errors', '1');

make_cache_directory('tcpdf');
require($CFG->dirroot.'/mod/iomadcertificate/type/'.$iomadcertificate->iomadcertificatetype.'/certificate.php');

$filename=iomadcertificate_get_iomadcertificate_filename($iomadcertificate,$cm,$course).'.pdf';
$filecontents=$pdf->Output('','S');
$forcedownload=((string)$r->mode==='download');

// Private child education record: do not cache the PDF response.
header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
send_file($filecontents,$filename,0,0,true,$forcedownload,'application/pdf');
