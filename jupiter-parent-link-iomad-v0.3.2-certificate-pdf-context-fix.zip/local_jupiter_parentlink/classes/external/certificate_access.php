<?php
namespace local_jupiter_parentlink\external;
defined('MOODLE_INTERNAL') || die();
require_once($CFG->libdir.'/externallib.php');
use core_external\external_api; use core_external\external_function_parameters; use core_external\external_single_structure; use core_external\external_value; use moodle_url;
class certificate_access extends external_api{
 public static function execute_parameters():external_function_parameters{return new external_function_parameters(['learnerid'=>new external_value(PARAM_INT,'Learner'),'code'=>new external_value(PARAM_ALPHANUMEXT,'Certificate code'),'mode'=>new external_value(PARAM_ALPHA,'view or download',VALUE_DEFAULT,'view')]);}
 public static function execute(int $learnerid,string $code,string $mode='view'):array{global $DB;
  $p=self::validate_parameters(self::execute_parameters(),compact('learnerid','code','mode'));require_capability('local/jupiter_parentlink:redeem',\context_system::instance());
  $i=$DB->get_record_sql("SELECT i.*,c.course FROM {iomadcertificate_issues} i JOIN {iomadcertificate} c ON c.id=i.iomadcertificateid WHERE i.userid=:u AND i.code=:c",['u'=>$p['learnerid'],'c'=>$p['code']],MUST_EXIST);
  $mode=in_array($p['mode'],['view','download'],true)?$p['mode']:'view';$token=bin2hex(random_bytes(32));$expires=time()+120;$DB->delete_records_select('local_jupiter_parent_tokens','expires < :n',['n'=>time()]);
  $DB->insert_record('local_jupiter_parent_tokens',(object)['tokenhash'=>hash('sha256',$token),'userid'=>$i->userid,'issueid'=>$i->id,'expires'=>$expires,'used'=>0,'mode'=>$mode,'timecreated'=>time()]);
  return ['url'=>(new moodle_url('/local/jupiter_parentlink/certificate.php',['token'=>$token]))->out(false),'expires'=>$expires];
 }
 public static function execute_returns():external_single_structure{return new external_single_structure(['url'=>new external_value(PARAM_URL,'URL'),'expires'=>new external_value(PARAM_INT,'Expiry')]);}
}
