<?php
namespace local_jupiter_parentlink\external;
defined('MOODLE_INTERNAL') || die();
use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_value;
use core_external\external_single_structure;
class consume extends external_api {
 public static function execute_parameters(){ return new external_function_parameters(['invitationid'=>new external_value(PARAM_INT,'Invitation ID')]); }
 public static function execute($invitationid){
  global $DB;
  $p=self::validate_parameters(self::execute_parameters(),['invitationid'=>$invitationid]);
  require_capability('local/jupiter_parentlink:redeem',\context_system::instance());
  $tx=$DB->start_delegated_transaction();
  $r=$DB->get_record('local_jupiter_parentlink',['id'=>$p['invitationid']], '*', MUST_EXIST);
  if($r->status!=='active' || (int)$r->expiresat < time()) throw new \moodle_exception('invalidparameter');
  $r->status='used'; $r->usedat=time(); $DB->update_record('local_jupiter_parentlink',$r); $tx->allow_commit();
  return ['success'=>true,'learnerid'=>(int)$r->userid];
 }
 public static function execute_returns(){ return new external_single_structure(['success'=>new external_value(PARAM_BOOL,'Consumed'),'learnerid'=>new external_value(PARAM_INT,'Learner ID')]); }
}
