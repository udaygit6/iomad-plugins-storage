<?php
namespace local_jupiter_parentlink\external;
defined('MOODLE_INTERNAL') || die();

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_value;

class generate extends external_api {
    public static function execute_parameters() {
        return new external_function_parameters([
            'learnerid' => new external_value(PARAM_INT, 'Iomad learner user ID'),
        ]);
    }

    public static function execute($learnerid) {
        global $DB;

        $p = self::validate_parameters(self::execute_parameters(), ['learnerid' => $learnerid]);
        require_capability('local/jupiter_parentlink:redeem', \context_system::instance());

        $learnerid = (int)$p['learnerid'];
        $user = $DB->get_record('user', ['id' => $learnerid, 'deleted' => 0, 'suspended' => 0], 'id', MUST_EXIST);

        // A new invitation invalidates all previous active invitations for this learner.
        $DB->set_field_select(
            'local_jupiter_parentlink',
            'status',
            'revoked',
            'userid = ? AND status = ?',
            [$user->id, 'active']
        );

        // 32 unambiguous symbols = 5 bits/character; 12 chars = 60 bits entropy.
        $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        $raw = '';
        for ($i = 0; $i < 12; $i++) {
            $raw .= $alphabet[random_int(0, strlen($alphabet) - 1)];
        }
        $displaycode = substr($raw, 0, 4) . '-' . substr($raw, 4, 4) . '-' . substr($raw, 8, 4);
        $now = time();
        $expiresat = $now + 900;

        $id = $DB->insert_record('local_jupiter_parentlink', (object)[
            'userid' => $user->id,
            'tokenhash' => hash('sha256', $raw),
            'status' => 'active',
            'expiresat' => $expiresat,
            'timecreated' => $now,
        ]);

        return [
            'success' => true,
            'invitationid' => (int)$id,
            'code' => $displaycode,
            'expiresat' => $expiresat,
        ];
    }

    public static function execute_returns() {
        return new external_single_structure([
            'success' => new external_value(PARAM_BOOL, 'Generated'),
            'invitationid' => new external_value(PARAM_INT, 'Invitation ID'),
            'code' => new external_value(PARAM_TEXT, 'One-time plaintext code; returned only at generation'),
            'expiresat' => new external_value(PARAM_INT, 'Expiry timestamp'),
        ]);
    }
}
