<?php
namespace local_jupiter_parentlink\external;
defined('MOODLE_INTERNAL') || die();
use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_value;
use core_external\external_single_structure;
class lookup extends external_api {
 public static function execute_parameters(){ return new external_function_parameters(['code'=>new external_value(PARAM_RAW_TRIMMED,'One-time link code')]); }
 public static function execute($code){
  global $DB;
  $p=self::validate_parameters(self::execute_parameters(),['code'=>$code]);
  require_capability('local/jupiter_parentlink:redeem',\context_system::instance());
  $norm=strtoupper(preg_replace('/[^A-Z0-9]/i','',$p['code']));
  if(strlen($norm)!==12) throw new \moodle_exception('invalidparameter');
  $r=$DB->get_record('local_jupiter_parentlink',['tokenhash'=>hash('sha256',$norm),'status'=>'active']);
  if(!$r || (int)$r->expiresat < time()) throw new \moodle_exception('invalidparameter');
  $u=$DB->get_record('user',['id'=>$r->userid,'deleted'=>0],'id,firstname,lastname',MUST_EXIST);
  return ['invitationid'=>(int)$r->id,'learnerid'=>(int)$u->id,'displayname'=>trim($u->firstname.' '.substr($u->lastname,0,1).'.'),'expiresat'=>(int)$r->expiresat];
 }
 public static function execute_returns(){ return new external_single_structure([
  'invitationid'=>new external_value(PARAM_INT,'Invitation ID'), 'learnerid'=>new external_value(PARAM_INT,'Learner ID'),
  'displayname'=>new external_value(PARAM_TEXT,'Minimal display name'), 'expiresat'=>new external_value(PARAM_INT,'Expiry')]); }
}
