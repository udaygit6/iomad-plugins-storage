<?php
namespace local_jupiter_parentlink\external;
defined('MOODLE_INTERNAL') || die();

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_multiple_structure;
use core_external\external_single_structure;
use core_external\external_value;

class summary extends external_api {
    public static function execute_parameters() {
        return new external_function_parameters([
            'learnerid'=>new external_value(PARAM_INT,'Iomad learner user ID'),
        ]);
    }

    private static function label_slug(string $slug): string {
        $slug=preg_replace('/-(starter|exit)$/','',$slug);
        return \core_text::strtotitle(str_replace(['-','_'],' ',$slug));
    }

    public static function execute($learnerid) {
        global $DB, $CFG;
        require_once($CFG->libdir . '/completionlib.php');
        $p=self::validate_parameters(self::execute_parameters(),['learnerid'=>$learnerid]);
        require_capability('local/jupiter_parentlink:redeem',\context_system::instance());

        $userid=(int)$p['learnerid'];
        $user=$DB->get_record('user',['id'=>$userid,'deleted'=>0],
            'id,firstname,lastname,lastaccess,suspended',MUST_EXIST);
        if($user->suspended) throw new \moodle_exception('invaliduser');

        $enrolled=enrol_get_users_courses($userid,true,'id,fullname,shortname,visible','fullname ASC');
        $courses=[]; $recent=[]; $certificates=[]; $overalllatest=0;

        foreach($enrolled as $course){
            if((int)$course->id===SITEID || empty($course->visible)) continue;
            $cid=(int)$course->id; $ctx=\context_course::instance($cid);

            $cc=$DB->get_record('course_completions',['course'=>$cid,'userid'=>$userid],
                'id,timecompleted',IGNORE_MISSING);
            $completed=($cc && !empty($cc->timecompleted));
            $completiontime=$completed?(int)$cc->timecompleted:0;

            $lastactivity=(int)$DB->get_field_sql(
                "SELECT MAX(timecreated) FROM {logstore_standard_log}
                   WHERE userid=:u AND courseid=:c AND anonymous=0",
                ['u'=>$userid,'c'=>$cid]);
            $overalllatest=max($overalllatest,$lastactivity);

            // Canonical activity completion criteria.
            $criteria=$DB->get_records('course_completion_criteria',
                ['course'=>$cid,'criteriatype'=>COMPLETION_CRITERIA_TYPE_ACTIVITY],
                'id ASC','id,module,moduleinstance');
            $criteriaTotal=0; $criteriaDone=0;
            foreach($criteria as $criterion){
                if(empty($criterion->moduleinstance)) continue;
                $criteriaTotal++;
                $state=$DB->get_field('course_modules_completion','completionstate',
                    ['coursemoduleid'=>(int)$criterion->moduleinstance,'userid'=>$userid]);
                if($state!==false && (int)$state!==COMPLETION_INCOMPLETE) $criteriaDone++;
            }

            // Jupiter/Oak mappings give us lesson/unit/assessment intelligence.
            $units=[]; $lessonsTotal=0; $lessonsDone=0;
            $starterTotal=0; $starterAttempted=0; $exitTotal=0; $exitAttempted=0; $exitPassed=0;
            $assessmentrows=[];

            if($DB->get_manager()->table_exists('local_jupiter_oak_import')){
                $unitmaps=$DB->get_records('local_jupiter_oak_import',
                    ['courseid'=>$cid,'itemtype'=>'unit'],'sectionnum ASC,id ASC');
                foreach($unitmaps as $unit){
                    $unitname=self::label_slug((string)$unit->oakslug);
                    if(!empty($unit->sectionnum)){
                        $section=$DB->get_record('course_sections',
                            ['course'=>$cid,'section'=>(int)$unit->sectionnum],'id,name',IGNORE_MISSING);
                        if($section && trim((string)$section->name)!=='') $unitname=format_string($section->name,true,['context'=>$ctx]);
                    }
                    $units[(string)$unit->oakslug]=[
                        'name'=>$unitname,'lessonstotal'=>0,'lessonsdone'=>0,
                        'exitstotal'=>0,'exitspassed'=>0
                    ];
                }

                $lessonmaps=$DB->get_records('local_jupiter_oak_import',
                    ['courseid'=>$cid,'itemtype'=>'lesson'],'id ASC');
                $lessonunitmap=[];
                foreach($lessonmaps as $m){
                    $lessonunitmap[(string)$m->oakslug]=(string)($m->parentslug??'');
                    $lessonsTotal++;
                    $done=false;
                    if(!empty($m->cmid)){
                        $state=$DB->get_field('course_modules_completion','completionstate',
                            ['coursemoduleid'=>(int)$m->cmid,'userid'=>$userid]);
                        $done=($state!==false && (int)$state!==COMPLETION_INCOMPLETE);
                    }
                    if($done) $lessonsDone++;
                    $parent=(string)($m->parentslug??'');
                    if(isset($units[$parent])){
                        $units[$parent]['lessonstotal']++;
                        if($done) $units[$parent]['lessonsdone']++;
                    }
                }

                $quizmaps=$DB->get_records('local_jupiter_oak_import',
                    ['courseid'=>$cid,'itemtype'=>'quiz'],'id ASC');
                foreach($quizmaps as $m){
                    if(empty($m->cmid)) continue;
                    $cm=$DB->get_record('course_modules',['id'=>(int)$m->cmid],
                        'id,instance',IGNORE_MISSING);
                    if(!$cm) continue;
                    $quiz=$DB->get_record('quiz',['id'=>(int)$cm->instance],
                        'id,name,grade,sumgrades',IGNORE_MISSING);
                    if(!$quiz) continue;

                    // quiz_grades is authoritative for the Moodle quiz final grade. For older
                    // imported courses, defensively fall back to the best finished quiz attempt
                    // if the aggregate row is absent. Never count previews or unfinished attempts.
                    $grade=$DB->get_record('quiz_grades',
                        ['quiz'=>(int)$quiz->id,'userid'=>$userid],'id,grade,timemodified',IGNORE_MISSING);
                    $attempted=($grade!==false);
                    $rawgrade=$attempted?(float)$grade->grade:0.0;
                    $gradetime=$attempted?(int)$grade->timemodified:0;
                    if(!$attempted){
                        $attempt=$DB->get_record_sql(
                            "SELECT id,sumgrades,timefinish
                               FROM {quiz_attempts}
                              WHERE quiz=:q AND userid=:u AND preview=0 AND state=:state
                           ORDER BY sumgrades DESC,timefinish DESC",
                            ['q'=>(int)$quiz->id,'u'=>$userid,'state'=>'finished'],IGNORE_MULTIPLE);
                        if($attempt){
                            $attempted=true;
                            $gradetime=(int)$attempt->timefinish;
                            $sumgrades=(float)($quiz->sumgrades??0);
                            $rawgrade=$sumgrades>0 ? ((float)$attempt->sumgrades/$sumgrades)*(float)$quiz->grade : 0.0;
                        }
                    }
                    $pct=($attempted && (float)$quiz->grade>0)
                        ? round(($rawgrade/(float)$quiz->grade)*100,1):0.0;

                    $gradeitem=$DB->get_record('grade_items',
                        ['courseid'=>$cid,'itemmodule'=>'quiz','iteminstance'=>(int)$quiz->id],
                        'id,gradepass',IGNORE_MISSING);
                    $passpct=70.0;
                    if($gradeitem && (float)$gradeitem->gradepass>0 && (float)$quiz->grade>0){
                        $passpct=round(((float)$gradeitem->gradepass/(float)$quiz->grade)*100,1);
                    }
                    $passed=$attempted && $pct >= $passpct;
                    $isexit=str_ends_with((string)$m->oakslug,'-exit');
                    $isstarter=str_ends_with((string)$m->oakslug,'-starter');

                    if($isstarter){$starterTotal++; if($attempted)$starterAttempted++;}
                    if($isexit){
                        $exitTotal++; if($attempted)$exitAttempted++; if($passed)$exitPassed++;
                        $lessonparent=(string)($m->parentslug??'');
                        $unitparent=$lessonunitmap[$lessonparent]??$lessonparent;
                        if(isset($units[$unitparent])){
                            $units[$unitparent]['exitstotal']++;
                            if($passed)$units[$unitparent]['exitspassed']++;
                        }
                    }
                    if($isstarter || $isexit){
                        $assessmentrows[]=[
                            'name'=>format_string($quiz->name,true,['context'=>$ctx]),
                            'type'=>$isexit?'exit':'starter',
                            'attempted'=>$attempted,'score'=>(float)$pct,'passed'=>$passed,
                            'time'=>$attempted?$gradetime:0
                        ];
                    }
                }
            }

            // Prefer authoritative course completion. Otherwise derive meaningful Oak progress
            // from Exit assessments; otherwise fall back to Moodle completion criteria.
            if($completed){
                $progress=100.0; $status='completed';
            } elseif($exitTotal>0){
                $progress=round(($exitPassed/$exitTotal)*100,1);
                $status=($exitAttempted>0 || $lessonsDone>0)?'in_progress':'not_started';
            } elseif($criteriaTotal>0){
                $progress=round(($criteriaDone/$criteriaTotal)*100,1);
                $status=$criteriaDone>0?'in_progress':'not_started';
            } else {
                $progress=0.0;
                $status=$lastactivity>0?'in_progress':'not_started';
            }

            $unitrows=[];
            foreach($units as $u){
                $unitprogress=$u['exitstotal']?round(($u['exitspassed']/$u['exitstotal'])*100,1):
                    ($u['lessonstotal']?round(($u['lessonsdone']/$u['lessonstotal'])*100,1):0.0);
                $unitrows[]=[
                    'name'=>$u['name'],'progress'=>(float)$unitprogress,
                    'lessonsdone'=>(int)$u['lessonsdone'],'lessonstotal'=>(int)$u['lessonstotal'],
                    'exitspassed'=>(int)$u['exitspassed'],'exitstotal'=>(int)$u['exitstotal']
                ];
            }

            // Issued certificates only. No certificate is exposed until it actually exists.
            if($DB->get_manager()->table_exists('iomadcertificate_issues')
                    && $DB->get_manager()->table_exists('iomadcertificate')){
                try {
                    $sql="SELECT ci.id,ci.code,ci.timecreated,ic.name
                            FROM {iomadcertificate_issues} ci
                            JOIN {iomadcertificate} ic ON ic.id=ci.iomadcertificateid
                           WHERE ci.userid=:u AND ic.course=:c
                        ORDER BY ci.timecreated DESC";
                    foreach($DB->get_records_sql($sql,['u'=>$userid,'c'=>$cid]) as $cert){
                        $certificates[]=[
                            'courseid'=>$cid,'coursename'=>format_string($course->fullname,true,['context'=>$ctx]),
                            'name'=>format_string($cert->name,true,['context'=>$ctx]),
                            'issued'=>(int)$cert->timecreated,'code'=>(string)($cert->code??'')
                        ];
                    }
                } catch (\Throwable $e) {
                    // Certificate enrichment is optional; never break the parent dashboard.
                }
            }

            $courses[]=[
                'courseid'=>$cid,
                'coursename'=>format_string($course->fullname,true,['context'=>$ctx]),
                'progress'=>(float)$progress,'status'=>$status,'completed'=>$completed,
                'completiontime'=>$completiontime,'lastactivity'=>$lastactivity,
                'activitiesdone'=>(int)$criteriaDone,'activitiestotal'=>(int)$criteriaTotal,
                'lessonsdone'=>$lessonsDone,'lessonstotal'=>$lessonsTotal,
                'starterattempted'=>$starterAttempted,'startertotal'=>$starterTotal,
                'exitattempted'=>$exitAttempted,'exitpassed'=>$exitPassed,'exittotal'=>$exitTotal,
                'units'=>$unitrows,'assessments'=>$assessmentrows
            ];
        }

        // Privacy-minimised recent learning feed: no IP, device, message or raw event payload.
        $sql="SELECT l.id,l.courseid,l.action,l.target,l.objecttable,l.timecreated,c.fullname
                FROM {logstore_standard_log} l
                JOIN {course} c ON c.id=l.courseid
               WHERE l.userid=:u AND l.courseid<>:site AND l.anonymous=0
                     AND l.action IN ('viewed','submitted','completed','graded')
            ORDER BY l.timecreated DESC";
        $logs=$DB->get_records_sql($sql,['u'=>$userid,'site'=>SITEID],0,12);
        foreach($logs as $log){
            $recent[]=[
                'courseid'=>(int)$log->courseid,
                'coursename'=>format_string($log->fullname),
                'action'=>(string)$log->action,
                'target'=>(string)$log->target,
                'time'=>(int)$log->timecreated
            ];
        }

        return [
            'learnerid'=>$userid,'displayname'=>fullname($user),
            'initials'=>strtoupper(\core_text::substr($user->firstname,0,1).\core_text::substr($user->lastname,0,1)),
            'lastaccess'=>(int)$user->lastaccess,'lastlearningactivity'=>$overalllatest,
            'courses'=>$courses,'recentactivity'=>$recent,'certificates'=>$certificates
        ];
    }

    public static function execute_returns() {
        $unit=new external_single_structure([
            'name'=>new external_value(PARAM_TEXT,'Unit name'),
            'progress'=>new external_value(PARAM_FLOAT,'Unit progress'),
            'lessonsdone'=>new external_value(PARAM_INT,'Lessons completed'),
            'lessonstotal'=>new external_value(PARAM_INT,'Lessons total'),
            'exitspassed'=>new external_value(PARAM_INT,'Exit assessments passed'),
            'exitstotal'=>new external_value(PARAM_INT,'Exit assessments total'),
        ]);
        $assessment=new external_single_structure([
            'name'=>new external_value(PARAM_TEXT,'Assessment name'),
            'type'=>new external_value(PARAM_ALPHA,'starter or exit'),
            'attempted'=>new external_value(PARAM_BOOL,'Has a grade'),
            'score'=>new external_value(PARAM_FLOAT,'Percentage score'),
            'passed'=>new external_value(PARAM_BOOL,'Pass status'),
            'time'=>new external_value(PARAM_INT,'Grade time'),
        ]);
        $course=new external_single_structure([
            'courseid'=>new external_value(PARAM_INT,'Course ID'),
            'coursename'=>new external_value(PARAM_TEXT,'Course name'),
            'progress'=>new external_value(PARAM_FLOAT,'Progress'),
            'status'=>new external_value(PARAM_ALPHAEXT,'not_started, in_progress or completed'),
            'completed'=>new external_value(PARAM_BOOL,'Course complete'),
            'completiontime'=>new external_value(PARAM_INT,'Course completion time'),
            'lastactivity'=>new external_value(PARAM_INT,'Last course activity'),
            'activitiesdone'=>new external_value(PARAM_INT,'Completion criteria done'),
            'activitiestotal'=>new external_value(PARAM_INT,'Completion criteria total'),
            'lessonsdone'=>new external_value(PARAM_INT,'Oak lessons completed'),
            'lessonstotal'=>new external_value(PARAM_INT,'Oak lessons total'),
            'starterattempted'=>new external_value(PARAM_INT,'Starter assessments attempted'),
            'startertotal'=>new external_value(PARAM_INT,'Starter assessments total'),
            'exitattempted'=>new external_value(PARAM_INT,'Exit assessments attempted'),
            'exitpassed'=>new external_value(PARAM_INT,'Exit assessments passed'),
            'exittotal'=>new external_value(PARAM_INT,'Exit assessments total'),
            'units'=>new external_multiple_structure($unit),
            'assessments'=>new external_multiple_structure($assessment),
        ]);
        return new external_single_structure([
            'learnerid'=>new external_value(PARAM_INT,'Learner ID'),
            'displayname'=>new external_value(PARAM_TEXT,'Display name'),
            'initials'=>new external_value(PARAM_TEXT,'Initials'),
            'lastaccess'=>new external_value(PARAM_INT,'Last site access'),
            'lastlearningactivity'=>new external_value(PARAM_INT,'Latest learning activity'),
            'courses'=>new external_multiple_structure($course),
            'recentactivity'=>new external_multiple_structure(new external_single_structure([
                'courseid'=>new external_value(PARAM_INT,'Course ID'),
                'coursename'=>new external_value(PARAM_TEXT,'Course name'),
                'action'=>new external_value(PARAM_ALPHANUMEXT,'Action'),
                'target'=>new external_value(PARAM_ALPHANUMEXT,'Target'),
                'time'=>new external_value(PARAM_INT,'Event time'),
            ])),
            'certificates'=>new external_multiple_structure(new external_single_structure([
                'courseid'=>new external_value(PARAM_INT,'Course ID'),
                'coursename'=>new external_value(PARAM_TEXT,'Course name'),
                'name'=>new external_value(PARAM_TEXT,'Certificate name'),
                'issued'=>new external_value(PARAM_INT,'Issued time'),
                'code'=>new external_value(PARAM_ALPHANUMEXT,'Certificate code'),
            ])),
        ]);
    }
}
