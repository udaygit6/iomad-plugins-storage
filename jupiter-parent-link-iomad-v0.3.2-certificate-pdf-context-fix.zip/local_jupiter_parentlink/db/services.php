<?php
defined('MOODLE_INTERNAL') || die();
$functions = [
 'local_jupiter_parentlink_summary' => [
  'classname' => 'local_jupiter_parentlink\\external\\summary', 'methodname' => 'execute',
  'description' => 'Return a minimal learning-progress summary for an authorised Jupiter learner.',
  'type' => 'read', 'capabilities' => 'local/jupiter_parentlink:redeem', 'ajax' => false,
 ],
 'local_jupiter_parentlink_generate' => [
  'classname' => 'local_jupiter_parentlink\\external\\generate', 'methodname' => 'execute',
  'description' => 'Generate a one-time parent-link invitation for a specified learner.',
  'type' => 'write', 'capabilities' => 'local/jupiter_parentlink:redeem', 'ajax' => false,
 ],
 'local_jupiter_parentlink_lookup' => [
  'classname' => 'local_jupiter_parentlink\\external\\lookup', 'methodname' => 'execute',
  'description' => 'Validate a parent-link code and return minimal learner confirmation.',
  'type' => 'read', 'capabilities' => 'local/jupiter_parentlink:redeem', 'ajax' => false,
 ],
 'local_jupiter_parentlink_consume' => [
  'classname' => 'local_jupiter_parentlink\\external\\consume', 'methodname' => 'execute',
  'description' => 'Consume a validated parent-link invitation.',
  'type' => 'write', 'capabilities' => 'local/jupiter_parentlink:redeem', 'ajax' => false,
 ],
    'local_jupiter_parentlink_certificate_access' => ['classname'=>'local_jupiter_parentlink\\external\\certificate_access','description'=>'Create one-time parent certificate URL','type'=>'read','ajax'=>false,'capabilities'=>'local/jupiter_parentlink:redeem'],
];
