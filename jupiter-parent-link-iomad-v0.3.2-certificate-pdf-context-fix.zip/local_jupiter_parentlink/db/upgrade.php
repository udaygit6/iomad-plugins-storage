<?php
defined('MOODLE_INTERNAL') || die();
function xmldb_local_jupiter_parentlink_upgrade($oldversion) {
 global $DB; $dbman=$DB->get_manager();
 if($oldversion < 2026090530){
  $t=new xmldb_table('local_jupiter_parent_tokens');
  $t->add_field('id',XMLDB_TYPE_INTEGER,'10',null,XMLDB_NOTNULL,XMLDB_SEQUENCE);
  $t->add_field('tokenhash',XMLDB_TYPE_CHAR,'64',null,XMLDB_NOTNULL);
  $t->add_field('userid',XMLDB_TYPE_INTEGER,'10',null,XMLDB_NOTNULL);
  $t->add_field('issueid',XMLDB_TYPE_INTEGER,'10',null,XMLDB_NOTNULL);
  $t->add_field('expires',XMLDB_TYPE_INTEGER,'10',null,XMLDB_NOTNULL);
  $t->add_field('used',XMLDB_TYPE_INTEGER,'1',null,XMLDB_NOTNULL,null,'0');
  $t->add_field('timecreated',XMLDB_TYPE_INTEGER,'10',null,XMLDB_NOTNULL);
  $t->add_key('primary',XMLDB_KEY_PRIMARY,['id']);
  $t->add_index('tokenhash_uix',XMLDB_INDEX_UNIQUE,['tokenhash']);
  $t->add_index('expires_ix',XMLDB_INDEX_NOTUNIQUE,['expires']);
  if(!$dbman->table_exists($t))$dbman->create_table($t);
  upgrade_plugin_savepoint(true,2026090530,'local','jupiter_parentlink');
 }
 if($oldversion < 2026090531){
  $t=new xmldb_table('local_jupiter_parent_tokens');
  $f=new xmldb_field('mode',XMLDB_TYPE_CHAR,'10',null,XMLDB_NOTNULL,null,'view','used');
  if(!$dbman->field_exists($t,$f))$dbman->add_field($t,$f);
  upgrade_plugin_savepoint(true,2026090531,'local','jupiter_parentlink');
 }
 return true;
}
