<?php
require_once(__DIR__ . '/../../config.php');
require_login();
redirect(new moodle_url('/my/'), get_string('uimoved', 'local_jupiter_parentlink'));
