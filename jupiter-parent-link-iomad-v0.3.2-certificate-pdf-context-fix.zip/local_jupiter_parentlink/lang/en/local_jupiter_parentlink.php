<?php
$string['pluginname'] = 'Jupiter Parent Link';
$string['parentlink'] = 'Parent / Guardian Access';
$string['parentlink:redeem'] = 'Redeem Jupiter parent link invitations';
$string['linkheading'] = 'Link a parent or guardian';
$string['linkintro'] = 'Generate a temporary one-time code for the parent or guardian you intend to link to your learning account.';
$string['privacyinfo'] = 'After a link is confirmed, authorised learning information such as course progress and achievements may be shared with that parent or guardian through Jupiter. Do not share this code with anyone else.';
$string['yourcode'] = 'Your temporary parent link code';
$string['expiresin'] = 'This code expires in 15 minutes and can be used once.';
$string['sharewarning'] = 'Only give this code to the parent or guardian you want to link.';
$string['generatecode'] = 'Generate parent link code';
$string['generatenewcode'] = 'Generate a new code';

$string['uimoved'] = 'Parent and guardian access is managed securely from your Jupiter account.';
