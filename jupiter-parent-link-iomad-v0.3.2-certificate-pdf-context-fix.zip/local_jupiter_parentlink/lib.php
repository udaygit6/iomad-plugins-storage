<?php
defined('MOODLE_INTERNAL') || die();
// Parent-link user experience is intentionally provided by jupiterthescholar.com.
// This Iomad plugin remains the authoritative invitation/API backend.
