<?php
defined('MOODLE_INTERNAL') || die();
$plugin->component = 'local_jupiter_parentlink';
$plugin->version = 2026090532;
$plugin->requires = 2025100600;
$plugin->maturity = MATURITY_ALPHA;
$plugin->release = '0.3.2';
