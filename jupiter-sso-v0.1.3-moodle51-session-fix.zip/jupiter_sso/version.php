<?php
// This file is part of Moodle - http://moodle.org/
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_jupiter_sso';
$plugin->version   = 2026090501;
$plugin->requires  = 2025041400;
$plugin->maturity  = MATURITY_ALPHA;
$plugin->release   = '0.1.3';
