Jupiter SSO for Iomad/Moodle 5.1 - v0.1.1

Companion plugin for Jupiter Iomad Integration v0.6.0 on WordPress.
Validates a 90-second HMAC-SHA256 signed one-time token, confirms the exact Iomad learner and active course enrolment, creates the Moodle session, then redirects directly to the purchased course.

The course must be visible to learners. REST tokens and LMS passwords are never passed through the browser.

0.1.2: Clears Moodle force-password-change/create-password preferences for Jupiter SSO learners before login so WordPress remains the single learner credential.
