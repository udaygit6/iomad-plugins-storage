Jupiter SSO 0.1.4
Moodle 5.1 session lifecycle fix.

Root cause:
v0.1.3 called core\session\manager::destroy_user_sessions($user->id)
immediately before complete_user_login($user). If the browser already owned
a session for that learner, Moodle could close the active request session and
then complete_user_login()/shutdown mutated the closed session.

Fix:
- Remove destroy_user_sessions() from the login request.
- Let complete_user_login() perform Moodle's standard authenticated session transition.
- Preserve signed token validation, nonce replay protection, enrolment checks,
  forced-password preference clearing and direct course redirect.
- No database schema change.
- No web-service change.

Production debug display is intentionally NOT overridden by this plugin.
That remains a deployment/configuration setting and should be disabled
persistently in the production Moodle configuration/image.
