<?php
defined('MOODLE_INTERNAL') || die();
$string['pluginname'] = 'Jupiter SSO';
$string['settingsheading'] = 'Jupiter WordPress SSO';
$string['sharedsecret'] = 'SSO shared secret';
$string['sharedsecret_desc'] = 'Must exactly match the secret configured in the Jupiter Iomad Integration WordPress plugin. Use at least 32 random characters and keep it private.';
$string['trustedissuer'] = 'Trusted WordPress URL';
$string['trustedissuer_desc'] = 'Exact Jupiter WordPress base URL allowed to issue learner SSO tokens, for example https://jupiterthescholar.com/';
$string['returnurl'] = 'Jupiter My Courses URL';
$string['returnurl_desc'] = 'Learner-facing URL to return to Jupiter, for example https://jupiterthescholar.com/my-account/my-courses/.';
$string['invalidtoken'] = 'This Jupiter course access link is invalid or has expired.';
$string['notconfigured'] = 'Jupiter SSO has not been configured by the administrator.';
$string['notallowed'] = 'This Jupiter account is not allowed to access the requested course.';
$string['coursehidden'] = 'This course is still under review and is not available to learners yet.';
