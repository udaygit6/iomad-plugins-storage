<?php
require_once(__DIR__ . '/../../config.php');
require_login();
$config = get_config('local_jupiter_sso');
$returnurl = trim((string)($config->returnurl ?? ''));
if ($returnurl === '' || stripos($returnurl, 'https://') !== 0) {
    redirect(new moodle_url('/'));
}
redirect($returnurl);
