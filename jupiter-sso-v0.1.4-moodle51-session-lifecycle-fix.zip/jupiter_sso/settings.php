<?php
defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    $settings = new admin_settingpage('local_jupiter_sso', get_string('pluginname', 'local_jupiter_sso'));
    $ADMIN->add('localplugins', $settings);

    $settings->add(new admin_setting_heading('local_jupiter_sso/heading', get_string('settingsheading', 'local_jupiter_sso'), ''));
    $settings->add(new admin_setting_configpasswordunmask(
        'local_jupiter_sso/sharedsecret',
        get_string('sharedsecret', 'local_jupiter_sso'),
        get_string('sharedsecret_desc', 'local_jupiter_sso'),
        ''
    ));
    $settings->add(new admin_setting_configtext(
        'local_jupiter_sso/trustedissuer',
        get_string('trustedissuer', 'local_jupiter_sso'),
        get_string('trustedissuer_desc', 'local_jupiter_sso'),
        'https://jupiterthescholar.com/',
        PARAM_URL
    ));
    $settings->add(new admin_setting_configtext(
        'local_jupiter_sso/returnurl',
        get_string('returnurl', 'local_jupiter_sso'),
        get_string('returnurl_desc', 'local_jupiter_sso'),
        'https://jupiterthescholar.com/my-account/my-courses/',
        PARAM_URL
    ));
}
