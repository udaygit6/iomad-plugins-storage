# Architecture

## Layering (Phase D §5, established during the D1–D3 correction round, carried through D4–D10)

```
React page/component
      ↓
Application / feature service (src/services/<feature>/...)
      ↓
Repository interface (src/repositories/interfaces)
      ↓
Concrete implementation, wired in one place (src/repositories/index.ts)
      ↓
  Phase D: Mock*Repository (in-memory)
  Later:   Supabase*Repository
  Later:   AWS/RDS-backed implementation
```

React components/pages **do not call repositories directly.** They call an
application/feature service, which owns the actual feature logic — filtering
and discovery rules, matching/application validation, submission mapping,
workflow-status transitions (approve/reject/request-more-info), and URL↔filter
mapping. The repository underneath a service stays a plain data-access
boundary: it knows how to fetch/store records, not what a valid request
looks like or what "approve" means as a status transition.

Concretely, in this codebase:

| Service | Repository it sits in front of | Feature logic it owns |
|---|---|---|
| `TutorDiscoveryService` | `TutorRepository` | Featured-tutor selection, filter delegation |
| `SubjectService` | `SubjectRepository` | Homepage featured/others split |
| `MatchingService` | `MatchingRequestRepository` | Per-step validation, form→domain mapping |
| `TutorApplicationService` | `TutorApplicationRepository` | Per-step validation, qualification-list parsing, private-field exclusion |
| `EnquiryService` | `EnquiryRepository` | Validation, submission |
| `AdminApplicationsService` | `TutorApplicationRepository` | Approve/reject/request-info → status transitions |
| `AdminWorkflowServices` | `MatchingRequestRepository`, `EnquiryRepository` | Admin status transitions |

**Trivial static configuration/data does not need this layer.** `siteConfig`
(brand/contact/legal info) and the two design-token stylesheets are read
directly — there's no business rule to encapsulate, so a service around them
would be an abstraction with nothing to abstract. The line: if a page would
otherwise contain validation, a status-transition rule, a filter/mapping
rule, or any logic that decides what counts as a *valid* or *complete*
request, that logic belongs in a service, not the component. Simple
"fetch this and render it" reads with no business rule attached (e.g. a
static subject list with no filtering) are fine to read straight from a
service's or repository's plain accessor method without further layering.

Components import from `src/repositories` (the composition root) or the
interfaces directly only in the rare case where no feature logic exists yet
to justify a service (none currently — every repository in this codebase
is fronted by a service). Swapping a repository implementation to Supabase
later means writing a new class that implements the same interface and
changing one line in `src/repositories/index.ts` — **no service changes and
no component changes**, because services depend on the repository
*interface*, never a concrete implementation.

The same pattern applies to the LMS boundary:

```
Application / feature service
      ↓
LmsService interface (src/services/lms/LmsService.ts)
      ↓
  Phase D: MockLmsService (no network calls at all)
  Later:   IomadLmsAdapter (built once Iomad Technical Discovery is final)
```

## Folder structure

```
src/
  app/              Router configuration
  components/
    ui/             Generic, brand-agnostic primitives (Button, Badge, Accordion, Drawer, EmptyState, ErrorState)
    layout/         Header, Footer, Shell (app chrome)
    tutor/          TutorCard and tutor-specific presentational components
    forms/          WizardShell — shared multi-step form chrome
  pages/            Route-level components (call services, coordinate UI state — no business logic)
    admin/          Admin shell screens
  features/
    matching/       MatchingWizard + its option constants
    tutor-application/  ApplicationWizard
  domain/
    models/         Provider-agnostic TypeScript types — the shared contract
    validation/     Shared validators (required/validEmail/etc.) used by multiple services
  repositories/
    interfaces/     Repository contracts
    mock/           Phase D in-memory implementations
    index.ts        Composition root — the ONLY file that knows which
                     implementation is wired in
  services/
    tutors/         TutorDiscoveryService + URL↔filter mapping
    subjects/       SubjectService
    matching/       MatchingService
    applications/   TutorApplicationService
    enquiries/      EnquiryService
    admin/          AdminApplicationsService, AdminWorkflowServices
    lms/            LmsService interface + MockLmsService
  hooks/            useWizard (step navigation), useAvailabilityLabel (derived label)
  assets/mock/      Clearly-fictional development fixtures
  config/           siteConfig — the single source for brand/contact/legal info
  styles/           tokens.css (design tokens) + global.css (reset/base)
```

`integrations/iomad/` remains unbuilt — Phase D's `MockLmsService` is the
only LMS implementation that exists; the real `IomadLmsAdapter` is a later
persistence-phase deliverable per Phase C.5.

## Provider independence (Phase D §5, §6, §48, §49)

- No component imports `@supabase/supabase-js` or references a table/column
  name. That only happens inside a future `Supabase*Repository`.
- No component imports anything Iomad-specific. Only `MockLmsService` (later,
  `IomadLmsAdapter`) does, and only application/service code — never a
  component — calls `LmsService` methods.
- `siteConfig.ts` is the only place the brand name, tagline, or legal/contact
  details are defined. Every component reads from it; there are zero literal
  "MyGuru" strings anywhere else in the codebase (verified by repo-wide
  search during the D9 architecture audit).

## What Phase D deliberately does NOT include

Per the Phase D brief: no production Supabase schema/RLS, no real Iomad
calls/tokens, no payments, no booking engine, no LMS dashboards, no AWS
infrastructure, and — as of the final pre-deployment fixes — no real admin
authentication (the `/admin/*` noindex/nofollow directive added at this
stage is SEO hygiene, not access control; real admin auth remains a Phase E
concern). See `docs/decisions.md` for the business decisions this phase is
also deliberately not making.
