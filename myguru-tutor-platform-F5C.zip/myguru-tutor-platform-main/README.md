# MyGuru — Tutoring Platform (Phase D development build)

Working brand name — not the confirmed production brand. See `src/config/siteConfig.ts`
for everything that changes on rebrand.

## Status

Phase D, checkpoint D1–D3 (Foundation, Design System, Public Homepage).
Public site routes are scaffolded; only the homepage is fully built. See
`docs/routes.md` for what's real vs. placeholder right now.

## Stack

- React + TypeScript + Vite
- react-router-dom (client routing)
- No UI framework/component library — hand-built design system per the
  approved Phase C Revision 2 "Ink & Chalk" direction (`src/styles/tokens.css`)
- Mock/in-memory repositories only (`src/repositories/mock`) — no live
  database or Iomad connection in this phase

## Getting started

```bash
npm install
npm run dev       # local dev server
npm run build     # type-check + production build
npm run lint      # oxlint (project's configured linter)
npx tsc --noEmit  # type-check only
```

## Documentation

- `ARCHITECTURE.md` — layered architecture, provider-independence rules
- `docs/routes.md` — route map, what's built vs. placeholder
- `docs/domain-model.md` — domain types and their purpose
- `docs/phase-d-implementation.md` — what was built, in what order, and why
- `docs/decisions.md` — outstanding decisions this phase deliberately did not make

Historical/reference documents from earlier phases (Phase B IA, Phase C
prototypes, Phase C.5 architecture + addendum) are not duplicated here —
this project builds on them, it doesn't replace them.
