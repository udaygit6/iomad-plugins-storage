# Current State

**Phase:** F5C (admin organisation course visibility, read-only). See
"F5C — Admin organisation course visibility" below. F5B (course
persistence and organisation course mapping) is **deployed and live
verified** — migrations 0016 and 0017 (the column-ambiguity hotfix) are
both deployed to myguru-staging and immutable; see "F5B — Course
persistence and organisation course mapping" and "F5B hotfix — migration
0017" below. F5A (Iomad company course discovery foundation) is LIVE
VERIFIED — see "F5A — Iomad company course discovery foundation". F4C
(controlled single-company live sync via
`IomadCompanySyncService.syncByCompanyCode()` and
`scripts/iomad-sync-company.ts`) and F4D (admin-only, read-only
`/admin/organisations` visibility page, now extended by F5C) are also
complete, built on top of the F4 foundation described in "F4 — Iomad
company synchronisation foundation" below. The F4 review-fix pass and F4
live-verification pass are documented in their own sections further
down. F0-F3 (+ F3 hardening) and E4-E7 remain accurate: migrations
0011-0014 are **deployed to staging**, E7 has been **manually tested
end-to-end and passed**, and the F0-F3
architecture/system-of-record/integration-contract docs still hold.

**Completed:** E4 + E5 + E6 + E7 (+ E7 review fixes, all four migrations
deployed, manual test plan passed) + F0-F2 documentation + F3 (server-only
read-only Iomad REST integration foundation) + F3 hardening (non-2xx HTTP
handling, `IOMAD_BASE_URL` validation) + F4 (platform-side company
synchronisation, `organisations`/`iomad_company_mappings`, migration
0015, NOT yet pushed to staging, read-only from Iomad, no writes back) +
F4 review fixes (atomic create+link RPC, `unclassified` default
organisation type, corrected `markFailed()` error handling) +
live-verification pass (real `get_companies`-by-code call confirmed
request format, response envelope, and several field names/types) +
F4C (controlled single-company live sync via `syncByCompanyCode()`,
`scripts/iomad-sync-company.ts`, `IOMAD_ALLOW_INSECURE_HTTP` test-only
opt-in) + F4D (admin-only, read-only `/admin/organisations` visibility
page) + F5A (read-only company-course-discovery foundation, now **LIVE
VERIFIED** after a correction pass: company course allocations matched
the documented contract exactly; course settings did not — the
generated `courrseids[0]` parameter fails at runtime, the real call
takes no course-id parameter and is filtered locally; `licensed` is a
genuine JSON boolean on the wire; `shared` remains numeric; zero-course
confirmed a valid success state) + F5B (course persistence —
`courses`/`iomad_course_mappings`/`organisation_course_allocations`,
atomic `sync_iomad_company_course()`/
`mark_stale_organisation_course_allocations()` RPCs,
`IomadCompanyCourseSyncService.syncOrganisationCourses()`,
`scripts/iomad-sync-company-courses.ts` — **migrations 0016 and 0017
(the column-ambiguity hotfix) are now deployed to myguru-staging and
live verified**: Jupiter Test Academy / Iomad company id 4 / Jupiter Test
Mathematics / Iomad course id 4 / licensed: false / shared: false / all
day-counts 0 / sync_status: synced) + **F5C: admin-only, read-only course
visibility extending `/admin/organisations` — selecting an organisation
now shows its allocated courses (name, Iomad course ID, licensed/shared,
day-count settings, allocation sync status) via
`OrganisationRepository.listOrganisationCourses()` → the same
authenticated Supabase browser client + RLS pattern F4D already
established. No new migration, no Iomad call from the browser, no
create/edit/delete, no sync trigger from the UI.**

**Next:** F5C's live UI verification — see "F5C — Admin organisation
course visibility" below for the exact manual steps (Admin →
Organisations → Jupiter Test Academy → confirm Jupiter Test Mathematics
displays Iomad Course ID 4 / Licensed: No / Shared: No / Sync Status:
Synced). Not yet run as part of this task. Beyond that, no further phase
has been started.

---

## F5B — Course persistence and organisation course mapping

**Status: DEPLOYED and LIVE VERIFIED.** Migrations 0016 and 0017 (see
"F5B hotfix — migration 0017" below) are both deployed to
myguru-staging and immutable. Full schema, RPC design, sync algorithm,
and idempotency/multi-tenant/stale-marking behaviour are documented in
full in `docs/IOMAD_INTEGRATION_CONTRACT.md`'s "F5B — Course persistence
and organisation course mapping" section — not repeated here.

**What was built:**
- `supabase/migrations/0016_course_persistence_and_organisation_allocations.sql`
  (new — `courses`, `iomad_course_mappings`,
  `organisation_course_allocations`, RLS admin-read-only on all three,
  `sync_iomad_company_course()` and
  `mark_stale_organisation_course_allocations()` atomic RPCs, both
  `SECURITY INVOKER`, revoked from `public`, granted only to
  `service_role`). Does not modify 0001-0015.
- `netlify/functions/_lib/courseSync/` (new module): `types.ts`,
  `OrganisationCourseSyncRepository.ts` (interface),
  `SupabaseOrganisationCourseSyncRepository.ts` (calls the RPCs),
  `IomadCompanyCourseSyncService.ts` (`syncOrganisationCourses()` —
  builds directly on F5A's live-verified gateway, does not duplicate its
  transport).
- `scripts/iomad-sync-company-courses.ts` (new) — manual CLI, looks up
  the organisation by Iomad company id (requires
  `scripts/iomad-sync-company.ts` to have been run first for that
  company), syncs, prints the sanitised
  `{ companyId, created, updated, unchanged, stale, timestamp }` shape.

**Domain rule enforced throughout:** a course is global; an allocation is
tenant-specific. No code path in this phase ever deletes a course or an
`iomad_course_mapping` — a course missing from a later company-courses
sync only marks that ONE organisation's allocation `stale`.

**Idempotency, rename, settings-change, stale-marking, and multi-tenant
behaviour are proven by tests, not just asserted** — see
`netlify/functions/_lib/courseSync/__tests__/IomadCompanyCourseSyncService.test.ts`,
using the real live-verified Jupiter Test Mathematics fixture (Iomad
company id 4, course id 4, `licensed: false, shared: false`, all
day-counts `0`).

**No Iomad write anywhere** — `IomadCompanyCourseSyncService` only ever
calls `listCompanyCourses()`/`getCourseSettings()` on `IomadGateway`
(enforced by test); the RPCs never reference an Iomad function or make
an HTTP call (enforced by SQL regression test).

**Tests:** 14 service tests (fake gateway + fake repository — first
sync/idempotent-repeat/rename/settings-change/stale-on-removal/
multi-tenant/zero-course-success/zero-course-skips-settings-call/
one-failure-isolation/missing-settings-defaults/duplicate-in-batch/
top-level-fetch-failure/settings-fetch-failure/no-PII-in-logs), 14
repository tests (mocked Supabase client — exact RPC param verification,
no direct table writes for `syncCourse`, best-effort `markFailed`
inspecting the real `error` field, safe error propagation), 30 SQL
regression tests (schema shape, RLS, RPC atomicity markers —
`SECURITY INVOKER` + justification, advisory lock, row locks, both
`is distinct from` change-detection checks, revoke/grant to
`service_role` only, no Iomad reference in either RPC body, confirms
0001-0015 untouched), plus new assertions in both existing
security-audit suites (`netlify/functions/_lib/__tests__/securityAudit.test.ts`
and `scripts/__tests__/securityAudit.test.ts`) covering the new
`courseSync` module and CLI script.

**Verification:**
```
npx tsc -b --noEmit --force -> clean
npm run lint                  -> 0 warnings/errors, 170 files
npx vitest run                 -> 545/545 passing, 52 files (+58 from before this pass — includes one pre-existing 0015 test loosened from "exactly 15 migrations" to "at least 15", since 0016 now legitimately exists)
npm run build                  -> clean, bundle size unchanged (no browser code touched)
```

**Migration 0016 was NOT pushed *as part of this task*.** `npx supabase
db push` was not run at any point during F5B's initial implementation —
the migration existed only as a local file for review at that time. It
has since been reviewed and deployed to myguru-staging (see the F5B
hotfix section below), outside of this repository session.

**Confirmed (at the time of F5B's initial pass):** migrations 0001-0015
checksum-identical before/after that task; 0016 was the only new
migration file (16 total); no Iomad write occurred anywhere; no live
Iomad or Supabase call was made — every test uses fakes/mocks;
`scripts/iomad-sync-company-courses.ts` was written but not executed in
that pass.

---

## F5B hotfix — migration 0017 (column-ambiguity fix)

**Status: DEPLOYED.** After 0016 was deployed to myguru-staging, a live
persistence test surfaced a genuine PostgreSQL runtime defect in
`sync_iomad_company_course()`:

```
ERROR: 42702: column reference "course_id" is ambiguous
DETAIL: It could refer to either a PL/pgSQL variable or a table column.
```

**Root cause:** the function's `returns table (course_id uuid, ...)`
implicitly creates a PL/pgSQL variable named `course_id`, which collided
with the actual `course_id` column on `organisation_course_allocations`
in the one query that referenced it without a table alias. Every other
`course_id` reference in the function was already alias-qualified
(`m.course_id`, `a.course_id`), which is exactly why only that one query
ever raised the error.

**Fix:** `supabase/migrations/0017_fix_course_sync_column_ambiguity.sql`
— a forward-only `CREATE OR REPLACE FUNCTION` (0016 itself was NOT
edited; it is deployed and immutable). Aliases
`organisation_course_allocations` as `oca` in the previously-unaliased
lookup and its corresponding update, qualifying every column reference.
Also defensively aliases the `courses`/`iomad_course_mappings` single-table
UPDATEs, which were already technically safe (no other column name
collides with a `RETURNS TABLE` output), purely so every statement in the
function follows the same explicit-alias convention. Signature (9
parameters) and returned columns (10, including F5B review fix #2's
`allocation_status_changed`) are byte-for-byte unchanged from 0016 —
proven by test, not just asserted. `SECURITY INVOKER`, the advisory lock,
the `service_role`-only grant, idempotent course/allocation reuse,
stale→synced handling, and multi-tenant behaviour are all preserved
unchanged.

**Tests:** 24 SQL regression tests
(`supabase/migrations/__tests__/fixCourseSyncColumnAmbiguity.test.ts`) —
0017 exists, 0016 untouched, forward-fix (no DROP), the fix itself
(`oca.` qualification present, the bare ambiguous form absent via
regex), and every preserved-behaviour property (`SECURITY INVOKER`,
advisory lock, grant, signature, returned columns) proven present.

**Confirmed:** migrations 0001-0016 checksum-identical before/after that
task; 0017 was the only new file (17 total); no Iomad write occurred; no
live Iomad or Supabase call was made in that session — every test uses
static source assertions against the SQL file, not a live database
connection. `npx supabase db push` was not run as part of that task
either — 0017 was deployed separately, outside this repository session.

---

## F5C — Admin organisation course visibility

**Status: implemented, unit-tested, NOT yet manually verified against
the live staging UI.** Read-only visibility only — extends the existing
F4D `/admin/organisations` page to show each organisation's persisted
course allocations (F5B) when selected. No new migration (0016/0017
already provide everything needed), no Iomad call from the browser, no
create/edit/delete, no sync trigger from the UI.

**What was built:**
- `src/repositories/interfaces/index.ts` — new `OrganisationCourse` type
  and `OrganisationRepository.listOrganisationCourses(organisationId)`.
- `src/integrations/supabase/types.ts` — new row types matching 0016's
  schema exactly (`OrganisationCourseAllocationRow`,
  `IomadCourseMappingIdOnlyRow`, `OrganisationCourseAllocationWithCourseRow`).
- `src/repositories/supabase/SupabaseOrganisationRepository.ts` —
  `listOrganisationCourses()`: a single minimal-fields query joining
  `organisation_course_allocations` → `courses` → `iomad_course_mappings`
  via the authenticated browser client, relying on RLS (0016's
  admin-read policies) for authorization — the same pattern F4D's
  `listForAdmin()` already established. Handles a missing course or
  missing Iomad mapping defensively (never throws, falls back to safe
  placeholders).
- `src/repositories/mock/MockOrganisationRepository.ts` — extended with
  the real live-verified Jupiter Test Mathematics fixture (Iomad course
  id 4, `licensed: false, shared: false`, all day-counts `0`,
  `sync_status: synced`) for local/mock-mode preview.
- `src/services/admin/AdminOrganisationsService.ts` — thin pass-through
  `listOrganisationCourses()`.
- `src/pages/admin/AdminOrganisationsPage.tsx` — selecting an
  organisation now shows an "Overview" section (unchanged from F4D) plus
  a "Courses (N)" section with its own loading/error/empty states.
  Multiple courses render as a simple list, not hard-coded to any one
  course name.

**Exact fields displayed per course:** course name, Iomad Course ID
(or `—` if no mapping exists), Allocation Status, Licensed (Yes/No),
Shared (Yes/No), Valid Length ("Not configured" when `0`, otherwise
"`N` days"), Expiry Warning / Completion Warning / Notify Period (all
"`N` days"). Allocation status labels: `synced` → "Synced", `stale` →
"Stale", `failed` → **"Sync issue"** (deliberately not "Failed", per the
brief — a distinct label set from the organisation-level sync status,
which keeps "Failed" for that context). No raw UUIDs, no raw database
errors, no address/custom-field data anywhere (F5B never persisted any
in the first place).

**Security:** route protection is inherited unchanged from the existing
`/admin` `RequireAdmin` + `AdminLayout` subtree — no new auth logic
added. Proven by test that the course list is never fetched before
authorization completes, and that none of the new/modified files
(`AdminOrganisationsPage.tsx`, `SupabaseOrganisationRepository.ts`,
`AdminOrganisationsService.ts`) reference any Iomad wsfunction, the
Iomad token, or the Iomad gateway.

**Tests:** 32 new — 10 repository mapper tests (one course, missing
mapping, null courses embed, stale/failed status, licensed/shared true,
nonzero day-counts, safe field list), 3 service tests, 15 page-level
tests (loading/one-course/multiple-courses/zero-courses/missing-mapping/
stale-label/"Sync issue"-label/Yes-No-booleans/"Not configured"-vs-real-
day-counts/error+retry/org-switch-refreshes-list/no-raw-fields), 3
route-protection/security tests (no course fetch before auth, no Iomad
reference in the three touched files).

**Verification:**
```
npx tsc -b --noEmit --force -> clean
npm run lint                  -> 0 warnings/errors, 171 files
npx vitest run                 -> 612/612 passing, 53 files (+32 from before this pass)
npm run build                  -> clean, bundle +3.75kB (expected — new UI code; no migration touched)
```

**No new migration was created.** 17 migration files total, both 0016
and 0017 checksum-identical before/after this task — nothing was needed
beyond what F5B's schema already provides.

**Manual live UI verification — NOT yet run.** Exact steps:
1. Sign in to `/admin` on myguru-staging as an admin user.
2. Navigate to Organisations, select **Jupiter Test Academy**.
3. Confirm the Overview section shows Iomad Company ID `4`, Sync Status
   "Synced".
4. Confirm the Courses section shows **Courses (1)** with **Jupiter Test
   Mathematics**: Iomad Course ID `4`, Allocation Status "Synced",
   Licensed "No", Shared "No", Valid Length "Not configured", Expiry/
   Completion Warning and Notify Period all "0 days".
5. Select a different organisation and confirm the course list changes
   (does not show Jupiter Test Mathematics for an unrelated organisation).

Do not consider this live-verified until these steps are actually run
against staging.

---

## F5A — Iomad company course discovery foundation

Read-only. Scope: `organisation → iomad_company_mapping → Iomad company
ID → get_company_courses(companyId) → course IDs →
get_course_info() → normalized read-only result`. No user sync, no
enrolment, no licences, no SSO, no course create/update/delete, no
Iomad write of any kind, no new persistence, no new admin UI. Full
request/response contracts, the normalized models, and the gateway/CLI
design are documented in full in
`docs/IOMAD_INTEGRATION_CONTRACT.md`'s "F5A — Company course discovery
foundation" section — not repeated here.

**Status — both contracts LIVE VERIFIED (execution-tested against the
running Iomad instance).** The initial F5A pass documented both contracts
from the generated Iomad admin UI documentation only, marked
`DOCUMENTED, NOT YET execution-verified`. A subsequent live-execution
pass confirmed company-course-allocations exactly as documented, but
found the generated documentation for course settings' request
parameter did not match runtime behaviour — corrected below.

**Correction: `get_course_info`'s real parameter contract.** The
generated documentation described `courrseids[0]=<id>` (an upstream
typo, preserved intentionally in the first pass). Live execution testing
proved **every** parameterized variant fails with
`invalid_parameter_exception` — `courrseids[0]`, `courseids[0]`, and
`courseid[0]` were all tried and all rejected. **The real, successful
call sends no course-id parameter at all** and returns the full
available course-settings collection; the platform now filters that
collection **locally** to the requested course IDs
(`IomadRestGateway.getCourseSettings()`). `buildCourseIdsParams()` (which
built the now-proven-wrong parameter) has been removed from
`IomadRestClient.ts`, with a comment left at its former location
explaining why.

**Type correction: `licensed` is a genuine JSON boolean on the wire**
(observed: `"licensed": false`), not numeric as originally guessed —
`normalizeLicensedFlag()` now uses a boolean value directly, with numeric
0/1 still accepted defensively for compatibility. **`shared` remains
numeric**, confirmed unchanged (`"shared": 0`), normalized as
`shared !== 0` — no semantics invented beyond that.

**Zero-course confirmed as a valid success state.** Before "Jupiter Test
Mathematics" was allocated to Jupiter Test Academy (company id 4),
`get_company_courses` returned `"courses": []` for that company — a
clean, valid response, not an error. `scripts/iomad-company-courses.ts`
now returns `{ companyId, courses: [] }` for this case and does not call
`getCourseSettings()`/`get_course_info` at all.

**What changed in this correction pass:**
- `netlify/functions/_lib/iomad/IomadRestClient.ts` — removed
  `buildCourseIdsParams()` entirely (proven wrong by live execution);
  updated `buildCriteriaParams()`'s doc comment to CONFIRMED for both
  its use cases.
- `netlify/functions/_lib/iomad/IomadResponseAdapters.ts` — added
  `normalizeLicensedFlag()` (boolean primary, numeric defensive
  fallback) replacing the old numeric-only `numericFlagToBoolean()` for
  `licensed`; `shared` keeps the numeric-only `normalizeSharedFlag()`
  (renamed from the old shared function, same numeric-only behaviour).
- `netlify/functions/_lib/iomad/IomadRestGateway.ts` —
  `getCourseSettings()` now calls `get_course_info` with **no**
  parameters and filters the full result locally via a `Set` lookup on
  requested course IDs.
- `scripts/iomad-company-courses.ts` — zero-course guard comment
  strengthened to explicitly document the live-verified "valid success,
  do not call getCourseSettings" behaviour (the guard itself was already
  correctly in place).
- All F5A code/doc comments updated from `DOCUMENTED, NOT YET
  execution-verified` to `LIVE VERIFIED`.

**No persistence added.** No migration, no new table. Migration `0015`
is untouched (checksum-identical before/after this task).

**No admin UI added.** F4D's Organisations page is unchanged.

**Tests:** rewritten/extended against the real fixtures provided
(Jupiter Test Academy company response, the two-entry Jupiter Test
Mathematics course-settings response, the pre-allocation zero-course
response) — company-course-allocation and course-settings adapter tests
in `IomadResponseAdapters.test.ts`; gateway tests in
`IomadRestGateway.test.ts` confirming **no** `courrseids`/`courseids`/
`courseid` parameter is ever sent (only `wstoken`/`wsfunction`/
`moodlewsrestformat`) and that local filtering excludes an unrelated
course present in the full collection; `IomadRestClient.test.ts` updated
for the removed `buildCourseIdsParams()`; `scripts/__tests__/securityAudit.test.ts`
extended with a static check that the zero-course guard exists and
precedes the `getCourseSettings()` call in source.

**Verification:**
```
npx tsc -b --noEmit --force -> clean
npm run lint                  -> 0 warnings/errors, 162 files
npx vitest run                 -> 474/474 passing, 49 files (+4 net from the pre-correction pass)
npm run build                  -> clean, bundle size unchanged (no browser code touched)
```

**Confirmed:** migrations 0001-0015 unmodified (checksum-verified); no
Iomad write anywhere (every method remains read-only, enforced by test);
no live Iomad call made as part of implementing this correction (every
test uses a mocked `fetch` — the live calls that revealed the correction
were run manually, outside this session, by the user).

---

## Live verification: get_companies by code

A real, authenticated call was made against the running Iomad instance —
`block_iomad_company_admin_get_companies`, filtered by
`criteria[0][key]=code`/`criteria[0][value]=MYGURU-SHIKSHA-001` — and its
response captured. Full request/response detail, and exactly what it
does and doesn't confirm, is in
`docs/IOMAD_INTEGRATION_CONTRACT.md`'s "Live-verified: get_companies by
code" section — not repeated here. No token or base URL appears anywhere
in the codebase, tests, fixtures, or documentation for this — only the
function name, request parameters, and response body, none of which are
secrets. Runtime credentials remain exactly `IOMAD_BASE_URL`/
`IOMAD_SERVICE_TOKEN` environment variables, unchanged.

**Contract mismatch found:** none of the existing normalized field
mappings were *wrong* — `id` (numeric), `name`, and the `name ?? shortname`
fallback were already correctly handled. The gap was **coverage, not
correctness**: two confirmed-present fields (`code`, `suspended`) weren't
captured at all, and there was no implementation anywhere of the
verified request format (`criteria[N][key]`/`criteria[N][value]`) — only
the unverified no-criteria bulk call existed.

**Corrections made:**
- `netlify/functions/_lib/iomad/IomadRestClient.ts` — added
  `buildCriteriaParams()`, encoding the confirmed
  `criteria[0][key]`/`criteria[0][value]` request format.
- `netlify/functions/_lib/iomad/IomadResponseAdapters.ts` —
  `normalizeCompany()` now also captures `code` (string, optional) and
  `suspended` (read ONLY as a number — `isSuspended = suspended !== 0`;
  never coerced from a JSON boolean, and left `undefined` rather than
  guessed if absent or non-numeric). `listCompanies()`'s and
  `getCompanyByCode()`'s response-envelope handling comments updated to
  say CONFIRMED (object-wrapped) rather than unverified.
- `netlify/functions/_lib/iomad/IomadRestGateway.ts` — added
  `getCompanyByCode(code)`, mapped to the verified request/response
  shape; throws a safe `unknown_response_schema` error on more than one
  result (duplicate/unexpected), returns `null` on zero results.
  `listCompanies()` itself is UNCHANGED — its no-criteria call remains
  exactly as unverified as before.
- `src/integrations/iomad/IomadGateway.ts` — mirrored the same interface
  addition and field additions (kept in sync by hand, per existing
  convention — this file has no import path to the netlify
  implementation).
- No change to `IomadErrors.ts`, `iomadConfig.ts`,
  `IomadCompanySyncService.ts`, `OrganisationSyncRepository.ts`,
  `SupabaseOrganisationSyncRepository.ts`, or migration 0015 — none of
  those needed correction, and F4's sync algorithm/architecture is
  unchanged.

**Tests added:** a new fixture
(`netlify/functions/_lib/iomad/__tests__/fixtures/shikshaAcademy.ts`,
containing only the verified response body — no credentials) plus 19 new
tests across the existing `IomadResponseAdapters.test.ts` (10 —
mapping the live fixture, numeric-not-boolean `suspended` handling in
both directions, absent-field handling, unknown-field discarding,
envelope parsing with `warnings` present, empty-array handling),
`IomadRestClient.test.ts` (4 — `buildCriteriaParams` encoding, exact
request/response round-trip against the fixture), and
`IomadRestGateway.test.ts` (5 — `getCompanyByCode()`'s exact request
shape, empty result, duplicate-result safe error, warnings-tolerance,
safe non-2xx propagation).

**Test/build results:**
```
npx tsc -b --noEmit --force -> clean
npm run lint                  -> 0 warnings/errors, 151 files
npx vitest run                 -> 372/372 passing, 44 files (+19 from before this pass)
npm run build                  -> clean, bundle size unchanged
npx supabase db push --dry-run -> "Cannot find project ref. Have you run supabase link?" (no project linked; no migration/schema changed in this pass anyway)
```

**Is the F4 sync service ready for a controlled live sync of company
ID 3 / code MYGURU-SHIKSHA-001? Not yet, without one more small step.**
`IomadCompanySyncService.sync()` still only calls `listCompanies()`
(the bulk, no-criteria call, which remains entirely UNVERIFIED against
the real server). The gateway now has a verified, tested path
(`getCompanyByCode('MYGURU-SHIKSHA-001')`) that would safely reach
exactly this one company, but nothing wires that path into the sync
service or `OrganisationSyncRepository.syncCompany()` yet — doing so was
out of scope for this pass (it would touch F4's sync algorithm, which
this task explicitly said not to redesign). The gateway-level building
block is now correct and tested; a small, separate follow-up (a
single-company sync entry point using `getCompanyByCode`, or verifying
`listCompanies()` itself against the live server first) is needed before
a real controlled sync of just company 3 can be attempted. No live
Iomad call and no Supabase push occurred in this pass.

---

## F4 review fixes

Three issues found in review of the initial F4 pass, fixed before
migration 0015 was ever pushed to staging (still not pushed — see below).
No redesign, no F5 work, no live Iomad calls.

**1. Atomic create+link (blocking consistency issue, fixed).** The
original `SupabaseOrganisationSyncRepository.create()` performed a
separate `INSERT` into `organisations` and then a separate `INSERT` into
`iomad_company_mappings` — two independent Supabase requests. If the
second failed, the first could succeed and leave an orphan organisation
with no mapping, and a later sync would then create a *second*
organisation for the same Iomad company, breaking the idempotency the
unique `iomad_company_id` constraint is meant to guarantee. Fixed by
moving the whole find-or-create-or-rename + mark-synced operation into
one Postgres function, `sync_iomad_company()`, added to
`supabase/migrations/0015` (safe to edit in place — not yet deployed,
same precedent as 0014's pre-deployment review fixes). Full design in
`docs/IOMAD_INTEGRATION_CONTRACT.md`'s "Transactional RPC design"
section: a transaction-scoped advisory lock makes it safe under
concurrent calls, not just safe when called sequentially; `SECURITY
INVOKER` (not `DEFINER`) is used and explicitly justified in both the SQL
comment and the docs; the function is revoked from `public` and granted
only to `service_role`, the same pattern `0013`'s
`create_tutor_application()` already established for server-only RPCs.

**2. Organisation classification (blocking domain issue, fixed).** The
original `create()` hard-coded every newly-discovered organisation to
`type: 'myguru_franchise'` — incorrect, since the single shared Iomad
instance will hold MyGuru franchise, Corporate, future school, and
potentially internal companies, and F4 has no verified signal in
`listCompanies()`'s response to tell them apart. Fixed: added
`'unclassified'` to `organisations.type`'s allowed values (now the
column default), and `sync_iomad_company()` always inserts
`'unclassified'` for a newly-discovered company — never inferred from
company name, ID, or any other heuristic. Assigning a real
classification is explicitly left to a future provisioning/admin
workflow that does not exist yet.

**3. `markFailed()` error handling (hardening issue, fixed).**
Supabase-js reports a failed write through the response's `error` field
on normal resolution, not by throwing — the original implementation
wrapped the call in `try/catch` and silently discarded whatever
happened without ever inspecting `error`. Now inspects `error` explicitly
and logs a safe DB error code (never raw detail/PII/secrets) when
present; `try/catch` remains only as a backstop for a genuine
network/client-level exception. Still fully best-effort — never throws
into the sync loop, unchanged contract, corrected implementation.

**Files changed:**
`supabase/migrations/0015_organisation_iomad_company_sync.sql` (edited in
place — `unclassified` type + default, `sync_iomad_company()` RPC and its
grants, updated table comments);
`netlify/functions/_lib/companySync/OrganisationSyncRepository.ts`
(interface: `findByIomadCompanyId`/`create`/`updateNameAndMarkSynced`/
`markSynced` replaced by one `syncCompany()` method);
`netlify/functions/_lib/companySync/SupabaseOrganisationSyncRepository.ts`
(calls the RPC; corrected `markFailed()`);
`netlify/functions/_lib/companySync/IomadCompanySyncService.ts`
(`syncOne()` collapsed to one `syncCompany()` call); `types.ts`
(`OrganisationType` gains `'unclassified'`); both companySync test files
rewritten against the new interface, with new tests for classification
and no-orphan-on-failure; `supabase/migrations/__tests__/organisationIomadCompanySync.test.ts`
extended with a new RPC-focused describe block (atomicity, `SECURITY
INVOKER` + justification comment present, advisory lock present, row
lock present, `unclassified`-only insert, revoke/grant to `service_role`
only, no Iomad reference in the function body);
`docs/{CURRENT_STATE,IOMAD_INTEGRATION_CONTRACT,SYSTEM_OF_RECORD,TARGET_ARCHITECTURE}.md`.

**Tests:** 341/341 passing (up from 326 before this fix pass — net +15:
some old tests were replaced rather than purely added, since the
repository interface itself changed shape).

**Verification:**
```
npx tsc -b --noEmit --force -> clean
npm run lint                  -> 0 warnings/errors, 149 files
npx vitest run                 -> 341/341 passing, 43 files
npm run build                  -> clean, bundle size unchanged
npx supabase db push --dry-run -> "Cannot find project ref. Have you run supabase link?" (no project linked; real push NOT run, dry-run also did not execute against a real project)
```

**Confirmed:** 0001-0014 unmodified (regression tests verify this
explicitly, unchanged from the original F4 pass); no live Iomad calls or
writes anywhere — every test uses a mocked/fake gateway and repository;
migration 0015 still NOT pushed to any Supabase project, staging or
otherwise.

---

## F4 — Iomad company synchronisation foundation

Platform-side company sync built on F3's `listCompanies()`. **Code
complete. Live schema verification pending. Live sync not yet
executed** — these are three separate, distinct claims and none implies
the others:
- **Code complete:** yes — algorithm, persistence, tests, all passing.
  (Revised once by the "F4 review fixes" section above — that revision
  is what's actually deployed to this repo now; read this section as
  describing the current, post-fix state.)
- **Live schema verification:** NOT done — F3's response shapes remain
  unverified (unchanged from F3; see `docs/IOMAD_INTEGRATION_CONTRACT.md`).
- **Live sync executed:** NOT done — no live Iomad call has been made by
  anything in F4; the Iomad AWS environment remains stopped.
- **Company suspension sync:** NOT implemented, NOT claimed complete —
  every organisation F4 creates has `status: 'active'` unconditionally;
  no code path sets `'suspended'` from Iomad data.
- **Organisation classification:** every organisation F4 creates has
  `type: 'unclassified'` unconditionally (see "F4 review fixes" above) —
  no code path infers `myguru_franchise`/`corporate`/`school_future`/
  `internal` from Iomad data.

### What was built

```
IomadGateway.listCompanies()  (F3, unchanged)
  → IomadCompanySyncService.sync()          netlify/functions/_lib/companySync/IomadCompanySyncService.ts
  → OrganisationSyncRepository.syncCompany  netlify/functions/_lib/companySync/OrganisationSyncRepository.ts (interface)
  → SupabaseOrganisationSyncRepository      netlify/functions/_lib/companySync/SupabaseOrganisationSyncRepository.ts
  → sync_iomad_company() RPC (atomic)       supabase/migrations/0015_organisation_iomad_company_sync.sql
  → organisations / iomad_company_mappings
```

Full algorithm, field scope, and rationale documented in
`docs/IOMAD_INTEGRATION_CONTRACT.md`'s "Company sync foundation (F4,
revised after review)" section — not repeated here. Summary: only
`externalId`→`iomad_company_id` and `displayName`→`organisations.name`
are synced (the only two fields F3's adapter exposes); create+link now
happens atomically in one DB transaction (`sync_iomad_company()`, see "F4
review fixes" above); idempotent on `iomad_company_id`, including under
concurrent calls (transaction-scoped advisory lock, not just sequential
re-calls); one company's failure doesn't block others and can't leave an
orphan record; a company missing from a later sync is marked `stale`,
never deleted; the stale-marking pass is skipped entirely when a sync
returns zero companies (guards against mass-staling on a fluke
empty/erroring response).

**No server endpoint.** Per the brief's own escape hatch — this repo has
no existing pattern for an authenticated admin-only Netlify Function
(every existing function is a public rate-limited submission endpoint,
not one that verifies an admin session), so building that cleanly is new
infrastructure, not a small addition. F4 stays service-only;
`IomadCompanySyncService` can be invoked from a test, a future
authenticated endpoint, or a future scheduled job.

**`integration_jobs` reused, not replaced.** `0010`'s `operation_type`
check constraint already includes `sync_company` — F4 does not build a
second queue system and does not wire that operation type to anything
yet. `sync()` runs synchronously (acceptable per the brief for F4).

### Schema — migration 0015 (NOT yet pushed to staging)

`supabase/migrations/0015_organisation_iomad_company_sync.sql` —
`organisations` + `iomad_company_mappings`. UUID PKs, unique
`iomad_company_id` (the only identity key — never email/name), RLS
enabled on both tables with **admin READ-ONLY** policies (`for select`,
`is_admin()`) — no anon/authenticated insert/update/delete policy exists
on either table; the only writer is the sync service, via the
`sync_iomad_company()` RPC (see "F4 review fixes" above) plus two simple
single-table updates for `markFailed`/`markMissingAsStale`, all using the
service-role key, which bypasses RLS (same pattern as `admin_profiles`/
`0008` and `integration_jobs`/`0010`). The RPC itself is revoked from
`public` and granted only to `service_role` — never callable by
anon/authenticated. Does not modify 0001-0014.

**`npx supabase db push --dry-run` was run. Actual output:**
```
Cannot find project ref. Have you run supabase link?
```
No Supabase project is linked in this environment, so the dry-run could
not execute against a real project — this is the genuine command output,
not a fabricated result. The migration has NOT been pushed (dry-run or
real) to any Supabase project. Pushing 0015 to staging is your explicit
next action, same approval pattern as every migration since E4.

### Tests

*(Original F4 pass, before the review fixes above — kept for history.
Current counts are in "F4 review fixes" above: 341/341 repo-wide.)*

34 new tests across 5 files: `IomadCompanySyncService.test.ts` (11 —
create/idempotent-reuse/duplicate-in-batch/rename/unchanged/one-failure-
doesn't-block-others/stale-not-deleted/skip-stale-on-empty-fetch/
top-level-fetch-failure/no-PII-in-logs),
`SupabaseOrganisationSyncRepository.test.ts` (3 — row mapping only, no
live DB), `organisationIomadCompanySync.test.ts` (16 — SQL regression:
schema shape, RLS admin-read-only-no-write, no email/name as identity
key, confirms 0001-0014 untouched and `sync_company` still present in
0010), plus 2 new assertions each in the existing
`netlify/functions/_lib/__tests__/securityAudit.test.ts` (no token in
companySync logs; sync service calls nothing on `IomadGateway` except
`listCompanies`; no write-function references) and
`src/test/security/noSecretKeyInBrowser.test.ts` (no `src/` reference to
`iomad_company_mappings` or `organisations` table writes).

### Verification

*(Original F4 pass — see "F4 review fixes" above for current numbers.)*

```
npx tsc -b --noEmit --force -> clean
npm run lint                  -> 0 warnings/errors, 149 files
npx vitest run                 -> 326/326 passing, 43 files
npm run build                  -> clean (bundle size unchanged — no browser code touched)
npx supabase db push --dry-run -> "Cannot find project ref. Have you run supabase link?" (no project linked; real push NOT run)
```

### What F4 deliberately does not do

Per the brief's "DO NOT" list: no company creation/update/suspension
writes into Iomad, no live Iomad calls, no WooCommerce/Zoho/Oak/openSIS/
SSO/Corporate UI, no F5 work, no second job-queue system, no admin
server endpoint (see rationale above), no Corporate-specific or franchise
billing or student-mapping tables.

------

## F3 hardening review

Two targeted fixes to the F3 read-only Iomad transport, found in review.
No redesign, no F4 work, no live Iomad calls. Confirmed wsfunction
mappings, `companyid`/`courseid` UNVERIFIED assumptions, response
adapters (beyond what these fixes required), the `IomadGateway` interface,
React/browser code, and Supabase schema are all unchanged.

**1. Non-2xx HTTP handling** (`IomadRestClient.ts`) — previously, any
response the Iomad service returned other than 401/403 was parsed as JSON
and treated as potential success/data, even a 500/502/503. Now:
`response.ok` is checked after the existing 401/403 branch; any other
non-2xx status throws a new safe `upstream_http_error`
(`IomadErrors.ts`) without ever calling `response.json()` or otherwise
reading the body — the error message is fixed/generic regardless of
status code or body content. 5xx is deliberately **not** retried (the one
safe retry remains scoped to `network_error` only, as before) —
retrying against a struggling upstream server has no established benefit
in F3's scope.

**2. `IOMAD_BASE_URL` validation** (`iomadConfig.ts`) — a set-but-invalid
base URL (malformed, or `http://` instead of `https://`) previously fell
through to `configured` and would have been used as-is. `getIomadConfig()`
now validates the URL (via the `URL` constructor, then checks
`protocol === 'https:'`) before ever returning `configured`, returning a
new `invalid_config` state (`reason: 'malformed_url' | 'insecure_scheme'`)
instead. `createIomadGateway()` (`IomadRestGateway.ts`) maps this to a
gateway that throws a safe `invalid_config` error on first use — same
"never crash at construction/startup" behavior as the existing
`not_configured` path. No host allowlist was added (final Iomad hostname
not yet fixed, per instruction). The invalid/malformed URL value itself
is never echoed back in any error message.

**Tests:** 18 new tests (12 in `iomadConfig.test.ts` for URL validation,
6 in `IomadRestGateway.test.ts` for `invalid_config` composition) plus 9
new tests in `IomadRestClient.test.ts` for non-2xx handling (500, 502,
503, 404, no-token/no-body-in-message, body-never-read, non-2xx-never-
treated-as-success, no-retry-on-5xx) — total Iomad test count 50 → 68 (in
existing files; net **68** across the 4 `netlify/functions/_lib/iomad/
__tests__/` files, repo-wide total 274 → 292).

**Verification:**
```
npx tsc -b --noEmit --force -> clean
npm run lint                  -> 0 warnings/errors, 142 files
npx vitest run                 -> 292/292 passing, 40 files
npm run build                  -> clean (bundle size unchanged — no browser code touched)
```

**No live Iomad calls or writes occurred** — every test uses a mocked
`fetch`; the Iomad AWS environment remains untouched and was never
contacted.

---

## F3 — Read-only Iomad integration foundation

Server-only, read-only Iomad REST integration. **No writes, no Supabase
migrations, no live Iomad calls** (the target Iomad AWS environment is
intentionally stopped to save cost — nothing in F3 claims real
connectivity or guesses live responses).

**New confirmed business/architecture decisions** (from the brief, not
yet reflected in `TARGET_ARCHITECTURE.md`/`SYSTEM_OF_RECORD.md` — F3 was
scoped to code + `IOMAD_INTEGRATION_CONTRACT.md` + this file only, per
its brief's item 12):

- One Iomad instance serves MyGuru, Corporate, and future portals.
- Iomad Company remains authoritative for LMS tenant/company state
  (already documented in `TARGET_ARCHITECTURE.md` §2's "Company
  ownership" section from the F0-F2 correction pass).
- MyGuru is confirmed as: tutor/student registration funnel, tutor
  marketplace, matching/enquiries, and a future franchise funnel.
- Paid/franchise tutors may later map to their own Iomad company (not a
  single shared B2C company for every tutor).
- Corporate customers receive their own Iomad tenant/platform and largely
  manage their own employees/training — Corporate is primarily a B2B
  managed LMS tenancy, not a MyGuru-administered one.
- Franchise/company managers may create their students/users directly in
  Iomad (not exclusively through the platform).
- Company suspension in Iomad must later sync outward and stop LMS
  operational access, without necessarily removing public portal content
  — i.e. suspension ≠ deletion, and a suspended company's MyGuru-facing
  content (e.g. a tutor's public profile) isn't automatically torn down
  by an LMS-side suspension.
- WooCommerce is confirmed as the future commerce engine (already the
  working assumption in `SYSTEM_OF_RECORD.md`).
- Zoho receives Iomad events via **Zoho Flow** specifically (more precise
  than the earlier "CRM/marketing/accounting" framing — Zoho is
  event-driven from Iomad, not a second source of LMS truth).
- openSIS remains future School/SIS integration only — unchanged from
  F0-F2.

None of the above is implemented yet — recorded here per the brief's
explicit "do not expand this into implementation yet."

### Confirmed Iomad discovery

Recorded from the real Iomad installation's admin UI (not live-called —
see above). Full detail in `docs/IOMAD_INTEGRATION_CONTRACT.md`'s
"Confirmed discovery (F3)" section:

- Global web services enabled; REST enabled, SOAP disabled.
- External service `iomadservice` (plugin `block_iomad_company_admin`,
  access: authorised users).
- Three functions mapped and implemented (read-only, F3 scope):
  `block_iomad_company_admin_get_companies`,
  `..._get_company_courses`, `..._get_course_info`.
- A further ~15 functions confirmed available but explicitly out of F3
  scope (departments, user-company lookup, licences, and every write
  operation: create/edit company, assign/unassign users or courses,
  enrol users, allocate licences, move users, update courses) — listed
  in full in the contract doc.
- `check_token` and `sync_users` confirmed but flagged "do not use yet"
  per the brief.

**The exact request-parameter keys and response schemas for the three
mapped functions are NOT live-verified** — discovery confirmed the
functions exist and are enabled, not their parameter/response shapes.

### What was built

```
Platform service (future)
  → IomadGateway interface        src/integrations/iomad/IomadGateway.ts
  → REST implementation           netlify/functions/_lib/iomad/IomadRestGateway.ts
  → Moodle/Iomad REST transport   netlify/functions/_lib/iomad/IomadRestClient.ts
```

- **`src/integrations/iomad/IomadGateway.ts`** — finalized the F2 contract
  down to what F3 actually implements: `listCompanies()`, `getCompany()`
  (derived, no confirmed single-get function), `listCompanyCourses()`,
  `getCourse()`. Types/interfaces only, still no network code.
- **`netlify/functions/_lib/iomad/`** (new, server-only, mirrors the
  existing `netlify/functions/_lib/` isolation pattern used for
  `supabaseServerClient.ts`):
  - `iomadConfig.ts` — `configured`/`not_configured` state from
    `process.env`; missing env vars never crash startup.
  - `IomadErrors.ts` — safe typed errors + a log helper that never
    includes the token or a raw payload.
  - `IomadRestClient.ts` — the actual REST transport (`wstoken`/
    `wsfunction`/`moodlewsrestformat=json` POST to
    `/webservice/rest/server.php`), bounded timeout, one safe retry on
    transient network errors only. No Netlify-specific imports — portable
    to AWS Lambda/ECS later with no rewrite.
  - `IomadResponseAdapters.ts` — defensive raw→normalized parsing,
    explicitly commented "response adapter pending live schema
    verification."
  - `IomadRestGateway.ts` — the concrete `IomadGateway` implementation +
    `createIomadGateway()` composition entry point (always safe to
    construct).
- Extended both existing security-audit test suites
  (`netlify/functions/_lib/__tests__/securityAudit.test.ts` and
  `src/test/security/noSecretKeyInBrowser.test.ts`) to guard
  `IOMAD_SERVICE_TOKEN`/`VITE_IOMAD*` the same way `SUPABASE_SECRET_KEY`
  is already guarded.
- `.env.example` — same two variable names as before (already present
  from F0-F2), with a clarifying comment on where they're read and that
  missing values are handled gracefully.

**Architecture boundary preserved:** only files under
`netlify/functions/_lib/iomad/` (plus their tests) reference a raw
`block_iomad_company_admin_*` wsfunction string — nowhere else in the
codebase does. `netlify/functions/` continues to have zero import path
back into `src/` (same rule already established for
`netlify/functions/_lib/validation.ts`), so the Iomad implementation
duck-types the `src/integrations/iomad/IomadGateway.ts` contract rather
than importing it.

**No React component, page, or browser-bundled module references Iomad
in any way** — enforced by the security-audit tests above, not just
convention.

### Tests

50 new tests across 4 new files
(`netlify/functions/_lib/iomad/__tests__/`): configuration state (5),
REST transport — success, all seven error codes, retry behaviour,
token-never-leaked (13), response adapters — well-formed/malformed/both
envelope shapes for companies and courses (21), gateway-level function
mapping and configuration composition (11). Plus 2 new assertions in each
existing security-audit suite.

### Verification

```
npx tsc -b --noEmit --force -> clean
npm run lint                  -> 0 warnings/errors, 142 files
npx vitest run                 -> 274/274 passing, 40 files
npm run build                  -> clean (advisory chunk-size warning only, bundle size unchanged — no browser code touched)
```

### Live-test checklist

Full 10-step checklist for when the Iomad AWS environment is next started
is in `docs/IOMAD_INTEGRATION_CONTRACT.md`'s "Live test checklist"
section — confirm token/service authorisation, call each of the three
mapped functions with real parameters, record the real request/response
shapes, verify no secret leaks in logs, update `IomadResponseAdapters.ts`
to match reality, then mark the integration `live-tested`. Not run as
part of F3.

### What F3 deliberately does not do

Per the brief's "DO NOT IMPLEMENT" list: no company creation/update/
suspension, no user creation/assignment, no enrolment, no SSO, no
WooCommerce, no Zoho, no Oak, no openSIS, no Corporate UI, no franchise
billing, no AWS migration, no Supabase schema changes. All of the
confirmed-available write functions are mapped in
`docs/IOMAD_INTEGRATION_CONTRACT.md` for future reference but none are
called.

---

## F0-F2 — Target architecture contract, system of record, Iomad integration contract

Documentation-only phase (plus one narrowly-scoped interfaces-only file).
**No migrations created. No Iomad calls made. No existing E7 behaviour
changed.**

**New docs:**
- `docs/TARGET_ARCHITECTURE.md` (F0) — VedasGuru/MyGuru/Corporate/Iomad/
  Oak/WooCommerce/Zoho/openSIS responsibilities, a Mermaid architecture
  diagram, the temporary Netlify+Supabase → future AWS note, and an
  explicit statement that central identity/SSO is the target but no IdP
  (Cognito or otherwise) is chosen yet.
- `docs/SYSTEM_OF_RECORD.md` (F1) — ownership table for every entity
  listed in the brief (platform identity through accounting records),
  three ground rules (email is never a cross-system key; external IDs are
  persisted; no uncontrolled bidirectional sync), and the proposed F1
  shared-domain entities (`Organisation`, `Portal`, `PlatformUser`,
  `PortalMembership`, `ExternalIdentity`, `IomadCompanyMapping`,
  `IomadUserMapping`, `Course`, `CourseAudience`, `IomadCourseMapping`,
  `Entitlement`), each explicitly labelled `proposed — not yet persisted`.
  Notably, `IntegrationJob` is **not** proposed — `0010_integration_jobs.sql`
  already implements it; F1 recommends reusing that table as-is.
- `docs/IOMAD_INTEGRATION_CONTRACT.md` (F2) — full inventory matrix
  (companies/users/courses/enrolments/learning), every function name
  marked `UNKNOWN — requires staging Iomad discovery` (repository search
  confirmed no exact Iomad/Moodle web-service function name exists
  anywhere in this codebase — `.env.example`'s `IOMAD_BASE_URL`/
  `IOMAD_SERVICE_TOKEN` are empty placeholders, nothing more), a manual
  discovery checklist for the Iomad admin UI, the portal-filtering design
  (`CourseAudience` metadata layer, not per-portal course duplication),
  the ten sync-principle invariants, and the two documented (not
  implemented) future POCs.

**New code (interfaces/types only, unreferenced by anything):**
- `src/integrations/iomad/IomadGateway.ts` — read-only gateway contract
  (`listCompanies`, `getCompany`, `listCourses`, `getCourse`,
  `listCompanyCourses`). No network implementation, no tokens, no secrets,
  no staging calls, not wired into `src/repositories/index.ts` or anywhere
  else. Sits conceptually underneath a future `IomadLmsAdapter`, alongside
  (not replacing) the existing `LmsService` boundary in
  `src/services/lms/`.

**Verification** (code changed — one new .ts file — so full suite run):
```
npx tsc -b --noEmit --force -> clean
npm run lint                  -> 0 warnings/errors, 133 files
npx vitest run                 -> 220/220 passing, 36 files
npm run build                  -> clean (advisory chunk-size warning only)
```
Note: the E7 section below states "229/229 passing, 38 files" from a
prior session. The current repository state (as checked out for F0-F2,
before any F0-F2 code change) actually runs 220/220 across 36 files — this
is pre-existing and not something F0-F2 touched or investigated further,
since it's outside F0-F2's documentation-only scope. Flagging it here for
visibility rather than silently carrying forward a number that no longer
matches what's on disk.

**No Iomad writes performed. No migration created. No existing E7
functionality changed** — `tutor_profiles`, `tutor_applications`,
matching/enquiry workflows, and all Supabase RLS policies are untouched.

### Exact manual action needed from you before F3

Per `docs/IOMAD_INTEGRATION_CONTRACT.md`'s discovery checklist: in the
Iomad/Moodle admin UI, go to **Site administration → Server → Web
services → External services → Functions** and record, for every enabled
function, its exact name, description, owning service, required
capabilities, parameters, and response shape — paying particular
attention to anything with a `company` in the name (Iomad-specific) plus
the core `core_user_*`, `core_course_*`, `enrol_*`, and `core_completion_*`
families. Also confirm (without pasting the token anywhere) that a
service token exists under **Manage tokens**, scoped to the right external
service. Do not paste or expose the token itself.

Discovery (item 1 above) is the only item marked `BLOCKING before F3` in
`docs/IOMAD_INTEGRATION_CONTRACT.md`'s Open Questions, since F3 as scoped
is read-only (list/get companies and courses only — see that document's
"Read-only gateway contract"). The final B2C Iomad company strategy and
the student LMS identity strategy (both already listed as open in
`docs/decisions.md`) are reclassified as `NON-BLOCKING for read-only F3`
— they only become blocking before the later work that actually
provisions B2C companies or student users, not before F3's read-only
gateway.

### Company ownership (correction)

`docs/TARGET_ARCHITECTURE.md` §2 and `docs/SYSTEM_OF_RECORD.md` now state
the company-ownership split explicitly: a VedasGuru `Organisation` is
business/customer metadata; Iomad `Company` is the authoritative LMS
tenant/company record. Initial sync is outward from Iomad (a
create/rename/disable in Iomad syncs to the platform, not the reverse),
and a future VedasGuru admin UI for managing companies is expected to
invoke Iomad's own APIs rather than create an independent second
LMS-company truth on the platform side.

### Next phase (historical — superseded)

At the time of this F0-F2 pass, the next phase was F3 (read-only Iomad
gateway implementation + company sync POC). **F3 is now complete** — see
the "F3 — Read-only Iomad integration foundation" section at the top of
this file for what was actually built. This paragraph is left as a
historical record of what F0-F2 anticipated, not a current TODO.

### Documentation correction pass (this update)

A follow-up documentation-only pass, made after real staging state and
manual testing outcomes were confirmed. Changes: `docs/CURRENT_STATE.md`
brought in line with reality (0011-0014 deployed, E7 manually tested and
passed — replacing every earlier "local only"/"awaiting approval"
statement); `docs/TARGET_ARCHITECTURE.md` and `docs/SYSTEM_OF_RECORD.md`
clarified on company ownership (VedasGuru `Organisation` = business
metadata, Iomad `Company` = authoritative LMS tenant state, sync direction
outward from Iomad, future admin UI invokes Iomad's own APIs rather than
creating a second company truth); the Mermaid diagram in
`TARGET_ARCHITECTURE.md` corrected so Oak flows *into* Iomad (upstream
content source via import/staging/review), not the reverse; and
`docs/IOMAD_INTEGRATION_CONTRACT.md`'s Open Questions reclassified so only
exact enabled web-service discovery remains `BLOCKING before F3` — the
B2C company strategy and student LMS identity strategy are now
`NON-BLOCKING for read-only F3`, each blocking only its own later
provisioning work. No migrations, no Iomad calls, no application code
changes, no tests/build run (documentation-only, per this update's
instructions). The `src/integrations/iomad/IomadGateway.ts` interface
from F0-F2 is unchanged.

---

## Architecture (unchanged, now fully populated)

```
React page/component
  -> application/feature service
  -> repository interface
  -> Mock | Supabase implementation

Public unauthenticated writes:
React -> service -> HTTP endpoint -> Netlify Function -> server Supabase client -> RLS-safe operation

Admin (authenticated) reads/writes:
React -> service -> Supabase repository -> Supabase client (user session) -> RLS admin policy
```

## E4 — Public submission backend

**Migrations (deployed to staging):**
- `supabase/migrations/0011_rate_limit_events.sql` — DB-backed rate-limit
  ledger (not process memory; Netlify Function instances are ephemeral).
  RLS-enabled at creation, zero anon/authenticated policies.
- `supabase/migrations/0012_public_submission_functions.sql` — two atomic
  RPC functions (`create_matching_request`, `create_tutor_application`)
  handling the multi-table transactional writes. Parent find-or-create by
  normalized email uses `ON CONFLICT ... DO NOTHING` (never overwrites,
  never reveals existence). Students never deduplicated. EXECUTE revoked
  from anon/authenticated, granted to service_role only.

**Netlify Functions** (`netlify/functions/`):
- `submit-matching-request.ts`, `submit-tutor-application.ts`,
  `submit-enquiry.ts` (covers both general contact and "Request this
  tutor" via the existing `relatedTutorSlug` field)
- `_lib/supabaseServerClient.ts` — the ONLY place the privileged key is
  read; isolated per the brief's "isolate key-naming differences" instruction
- `_lib/validation.ts`, `_lib/antiAbuse.ts`, `_lib/http.ts` — shared
  server-side validation, anti-abuse (honeypot + timing + DB rate limit),
  generic response shapes (every anti-abuse rejection returns the
  identical response so callers can't tell which check fired)
- Every function: hard-coded allowed write path, rejects unexpected
  fields, never trusts client-side validation, never returns raw
  Postgres/Supabase error text

**Client-side:**
- `SubmitMeta` (honeypot + form-load timestamp) added to the three write
  repository interfaces — genuine new requirement, kept out of the domain
  model itself
- `useAntiAbuseFields` hook + `HoneypotField` component, wired into all
  four submitting forms (MatchingWizard, ApplicationWizard,
  RequestTutorDrawer, ContactPage)
- New `SupabaseMatchingRequestRepository`, `SupabaseTutorApplicationRepository`,
  `SupabaseEnquiryRepository` — `submit()` calls the Netlify Function;
  `list()`/`updateStatus()` use the authenticated browser client + RLS
  admin policies (this is how E5 admin persistence actually works — same
  classes serve both)

## E5 — Admin persistence

- `AdminApplicationsService`/`AdminWorkflowServices` needed **zero changes**
  — they already only call repository methods generically; swapping the
  composition root's wiring (mock -> supabase) was sufficient
- Applications/matching-requests/enquiries: list/detail/approve/reject/
  request-info/status-update all go through the authenticated Supabase
  client, enforced by the existing `*_admin_all` RLS policies (0009) —
  never trusts the UI alone
- Status-history rows written on every transition (who/what/when), using
  `changed_by: auth.uid()`
- Subjects: `SubjectRepository.listForAdmin()`/`setEnabled()` added (real
  interface extension — schema already supported it via `subjects.enabled`
  + `subjects_admin_all` RLS); `AdminSubjectsPage` rewritten to use real
  persistence instead of the old demo-only local component state
- Tutor approval remains workflow-status-only, confirmed unchanged: does
  NOT publish a profile, create Iomad users, or mark anything verified —
  that conversion remains a distinct future workflow, not touched this
  phase

## E6 — Hardening / tests / documentation

**62 new tests** (165 total, up from 103):
- Server validation (25), anti-abuse incl. DB-backed rate limiting (15),
  handler-level request handling — method rejection, malformed JSON,
  field-injection rejection, safe config-error response (4)
- Supabase repository row-mapping for all three new write repositories (8)
- `AdminSubjectsService` (2)
- **Two dedicated security-audit tests** scanning the actual source tree
  (not just spot-checking) for: `SUPABASE_SECRET_KEY`/`service_role`
  anywhere in `src/`, the server client module imported from `src/`, any
  `VITE_*SECRET*` variable, any direct `@supabase/supabase-js` import
  outside `integrations/supabase`+`repositories/supabase`, and (on the
  function side) the privileged key referenced anywhere other than the one
  isolated module, plus a body-logging check
- **Manual grep sweep** (beyond the automated tests) for `SUPABASE_SECRET`,
  `service_role`, `VITE_*SECRET*`, hard-coded key-shaped strings
  (`sb_publishable_`/`sb_secret_`/JWT-shaped/`postgres://user:pass@`
  patterns), generic SQL-execution APIs, and body-logging — all clean

**Build plumbing fix:** added `tsconfig.functions.json` (Node/nodenext
project for `netlify/functions/`) and wired it into the root
`tsconfig.json` references. This actually caught a real gap: the function
files' relative imports were missing the `.js` extensions `nodenext`
module resolution requires, which `tsc -b --noEmit --force` was silently
NOT checking before this fix (the functions directory wasn't in any
TS project). Also added `"node"` to the app project's `types` array so the
security-audit test's `fs`/`path`/`__dirname` usage type-checks correctly.

## Final verification (all re-run once, clean, after every fix above)

```
npx tsc -b --noEmit --force  -> clean (now genuinely covers netlify/functions/ too)
npm run lint                  -> 0 warnings/errors, 120 files
npx vitest run                 -> 165/165 passing, 30 files
npm run build                  -> clean, 608KB JS / 170KB gzipped (advisory chunk-size warning only, not an error)
```

## Deployment status

Migrations `0011` and `0012` are deployed to the remote Supabase staging
project.

## New Netlify environment variables you need to add (names only)

**Netlify staging -> Site settings -> Environment variables**, server-side
(no `VITE_` prefix, never exposed to the browser):

```
SUPABASE_URL=
SUPABASE_SECRET_KEY=
```

(The three client-safe `VITE_*` variables from E3 are unchanged and
already covered in the earlier CURRENT_STATE — not repeated here.)

I have not requested, displayed, or embedded any actual value for either
of these.

## Known limitations

- Admin `updateStatus()` calls (matching requests, tutor applications) are
  two sequential Supabase calls (read current status, then update +
  history insert) rather than a single atomic RPC like the E4 public-write
  path. Acceptable for now (low volume, authenticated-only, not the
  security-critical anonymous path) but worth hardening with an RPC later
  if it becomes a real consistency concern.
- Bundle size grew again (380KB -> 608KB JS uncompressed) from the second
  `@supabase/supabase-js` usage surface (server client type imports still
  contribute to the type graph even though the runtime client itself is
  server-only). Vite's advisory chunk-size warning, not a build failure;
  a code-splitting pass is a reasonable future task, not addressed now.
- The E7 tutor-profile workflow (application approve → draft profile →
  edit → publish → Browse Tutors → unpublish) has since been manually
  tested end-to-end against staging and passed — see the E7 section below
  for the confirmed steps. This item is retained for historical accuracy
  about E4's own scope; it no longer describes the current staging state
  now that 0011-0014 are deployed and E7 has been exercised manually.

## Open decisions

Unchanged from Phase D/E1-E3 (pricing, brand name, DBS policy, B2C Iomad
company strategy). Nothing new introduced by E4-E6 beyond what's listed
above as "needs your approval."

---

## Staging hotfix — 0013 (applied on top of E4-E6, deployed)

**Bug:** `submit-tutor-application` failed on every real submission with
`RPC failed: column reference "slug" is ambiguous`. Root cause:
`create_tutor_application()` (0012) used `unnest(p_subject_slugs) as slug`
(and the same for education levels), and the derived column named `slug`
collided with `subjects.slug`/`education_levels.slug` in the join
condition, in 4 places (2 validation counts, 2 junction-table inserts).
`create_matching_request()` (0012) takes a single scalar slug, never
`unnest()`s an array, and was confirmed unaffected — not touched.

**Fix:** `supabase/migrations/0013_fix_tutor_application_slug_aliases.sql`
— `CREATE OR REPLACE FUNCTION create_tutor_application(...)` with explicit
non-colliding aliases (`unnest(...) as u(subject_slug)` /
`as u(level_slug)`, referenced as `u.subject_slug`/`u.level_slug`).
Signature, return type, SECURITY behaviour, search_path, grants/revokes,
transaction semantics, validation, and application/profile separation are
all unchanged. 0012 itself was NOT modified — the bug is fixed forward.

**Migration deployed to remote staging.**

**Regression test added:** `supabase/migrations/__tests__/tutorApplicationSlugAlias.test.ts`
(5 tests) — asserts 0013's executable SQL no longer contains the ambiguous
bare-`slug` alias, asserts the corrected aliases are present, asserts the
function signature/grants are preserved, and asserts 0012 was left
untouched (bug still present there, confirming no history rewrite).

**Verification:** `tsc -b --noEmit --force` clean · lint 0/0 (121 files) ·
`vitest run` **170/170** passing (31 files) · `build` clean.

---

## E7 — Tutor Profile Creation & Publishing (deployed, manually tested end-to-end, passed)

**Workflow implemented:** approved application -> admin clicks "Create /
open tutor profile" -> draft profile created (idempotent) -> admin edits
public-safe fields in a new Tutor Profiles admin screen -> publish -> shows
on Browse Tutors -> unpublish -> hidden again. Matches the required
`draft -> published -> unpublished` schema states exactly (no new states,
no contradictory booleans).

**New migration:** `supabase/migrations/0014_tutor_profile_creation.sql`
(deployed to remote staging) —
1. `idx_tutor_profiles_application_id` — partial unique index preventing
   more than one profile per application (the schema had no such
   constraint before this).
2. `create_tutor_profile_from_application(p_application_id, p_changed_by)`
   — atomic, idempotent RPC. Validates `status = 'approved'` server-side,
   returns the existing profile if one is already linked (no duplicate),
   copies only public-safe fields (display name derived as "First name +
   last initial", headline derived from subjects, bio/teaching-approach/
   experience-summary copied, subjects+levels copied via junction tables).
   Deliberately does NOT copy email/phone/admin_notes/
   supporting_documents_note/self-reported qualifications, and never sets
   `accepting_students`, verification state, or `published` status.
   `SECURITY INVOKER`, granted to `authenticated` (not `service_role`) —
   this is an admin-triggered operation via the authenticated browser
   session, authorized by the existing RLS admin policies, not a public
   write.

**New application code:**
- `TutorProfileRepository` interface + `AdminTutorProfileView` +
  `TutorProfileUpdateInput` (`src/repositories/interfaces`)
- `MockTutorProfileRepository` (mutates the same shared `mockTutors` array
  `MockTutorRepository` reads — draft/publish/unpublish genuinely affects
  public mock-mode visibility) and `SupabaseTutorProfileRepository`
  (admin CRUD via authenticated client + RLS; creation via the 0014 RPC)
- `AdminTutorProfilesService` — owns "only approved may create", "return
  existing rather than duplicate" business rules (repository + RPC are
  defense-in-depth, not the only guard)
- `AdminTutorProfilesPage` (new admin screen, list + editor: display name,
  headline, bio, teaching approach, experience summary, qualifications
  summary, languages, accepting-students, photo URL, subjects, education
  levels, publish/unpublish) + nav link in `AdminLayout`
- `AdminApplicationsPage` — "Create / open tutor profile" button, shown
  only for `approved` applications
- `AdminLayout` banner corrected (was stale "in-memory only" text from
  before E5 persistence; now accurate staging wording)
- `Footer` — subtle "Staff sign in" link to `/admin/login` (not in main nav)
- `AdminLoginPage` — authorized admins visiting `/admin/login` now redirect
  straight to `/admin/applications` (was `/admin`, which worked via a
  double-redirect through the index route — now direct, per spec)
- Public `SupabaseTutorRepository`/`TutorProfilePage` unchanged — still
  `status='published'` only, confirmed by inspection, not modified

**40 new tests** (210 total, up from 170): naming-derivation helpers (9),
`AdminTutorProfilesService` business rules incl. approved-only and
idempotency (7), Supabase row-mapping incl. private-field exclusion (5),
migration-content regression test (8), Footer staff-link (2), AdminLoginPage
redirect (2), and a full mock-mode end-to-end visibility test — draft
invisible -> publish visible -> unpublish invisible again, plus
double-creation idempotency and subject/level copying (7).

**Verification:**
```
tsc -b --noEmit --force -> clean
lint                     -> 0/0, 133 files
vitest run                -> 210/210 passing, 38 files
build                      -> clean (advisory chunk-size warning only)
```

**Deployed to remote staging.**

**Manual staging test plan — executed, passed.** All steps below were run
end-to-end against staging and confirmed working:
1. In `/admin/applications`, approve a submitted application (or use one
   already `approved`).
2. Click "Create / open tutor profile" — navigates to
   `/admin/tutor-profiles?open=<id>` with a new `draft` profile selected.
3. Confirmed the applicant's email/phone/admin notes are NOT shown
   anywhere in the profile editor.
4. Edited the display name, headline, bio, subjects, and toggled
   "Currently accepting students" on. Clicked "Save draft".
5. Visited the public `/tutors` page — the tutor did NOT appear yet.
6. Visited `/tutors/<slug>` directly (the slug is shown in the admin list
   and linked once published) — was not-found while still in draft.
7. Back in admin, clicked "Publish".
8. Refreshed `/tutors` — the tutor now appeared with the edited fields.
9. Visited `/tutors/<slug>` directly — loaded correctly.
10. Back in admin, clicked "Unpublish".
11. Refreshed `/tutors` — the tutor disappeared again.
12. Clicked "Create / open tutor profile" again on the SAME
    application — reopened the same profile, did not create a second one.
13. Confirmed no verification badge appears on the profile anywhere,
    since no `tutor_verifications` row exists for it.
14. Visited `/admin/login` while already signed in — redirected
    immediately to `/admin/applications`, did not show the form.
15. Visited the public homepage footer — confirmed the small "Staff sign
    in" link is present and not part of the main navigation.

Full workflow confirmed: tutor application → approval → draft profile →
edit → publish → visible on Browse Tutors → unpublish → hidden again.

**Next recommended task:** E8+ candidates — photo upload (Storage), or
beginning Iomad/Oak per your prioritisation (see F0-F2 above for the
architecture/contract groundwork already done for the latter) — none
started.

---

## E7 Review Fixes (0014 revised in place before deployment)

Three issues found in review, all fixed directly in
`supabase/migrations/0014_tutor_profile_creation.sql` (edited in place
before the migration was pushed to staging, then deployed as revised):

1. **Audit identity:** `create_tutor_profile_from_application()` no longer
   accepts a caller-supplied `p_changed_by`. `changed_by` is now derived
   exclusively from `auth.uid()` inside the function. Signature is now
   `(p_application_id uuid)`; REVOKE/GRANT updated to match
   (`create_tutor_profile_from_application(uuid)`).
2. **True concurrent idempotency:** the profile INSERT is now wrapped in
   its own exception block catching `unique_violation`, checking the
   specific constraint name (`idx_tutor_profiles_application_id`) via
   `GET STACKED DIAGNOSTICS` before treating it as a benign race — on a
   real race it returns the winning transaction's profile id instead of
   erroring; any other unique violation (e.g. a slug collision) is
   re-raised unchanged, never silently swallowed.
3. **Profile update atomicity:** new `update_tutor_profile()` RPC (added
   into 0014, not a new 0015, since 0014 isn't deployed yet) replaces the
   previous three-independent-client-calls approach. Validates
   subject/education-level slugs first (same non-ambiguous `unnest(...) as
   u(...)` pattern as 0013's fix), then updates the profile row and
   replaces both junction tables in one transaction. `SupabaseTutorProfileRepository.update()`
   now reads the current profile, merges in the caller's partial updates
   (preserving the interface's partial-update contract), and makes exactly
   one RPC call — no more direct `.from('tutor_profile_subjects')`/
   `.from('tutor_profile_levels')` delete/insert calls from the repository.

**19 new/revised tests** (229 total, up from 210): migration-content
regression tests for all three fixes (12, replacing the original 8),
repository-level tests confirming the RPC call shape excludes
`p_changed_by`, confirming `update()` never touches junction tables
directly, confirming field-merge behaviour, and confirming distinct error
messages for invalid subject vs. invalid education-level slugs (7).

**Verification:** `tsc -b --noEmit --force` clean · `lint` 0/0 (133 files) ·
`vitest run` **229/229** passing (38 files) · `build` clean.

**0014 is deployed to remote Supabase staging.** Nothing in this fix round
touched migrations 0001–0013 or altered any of the established E7
boundaries (no auto-publish, no copying email/phone/supporting-document
notes/qualification evidence, no verification-badge inheritance,
published-only RLS unchanged).
