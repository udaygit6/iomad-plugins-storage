# Iomad Integration Contract (F2/F3/F4/F5A/F5B/F5C)

Status: F2 was contract design + a discovery checklist. F3 added
confirmed discovery from the real Iomad installation and a read-only REST
implementation built against it. F4 adds the platform-side company
synchronisation service that consumes F3's `listCompanies()` — see
"Company sync foundation (F4)" below. F5A adds a read-only company
course discovery foundation (company course allocations + course
settings), now LIVE VERIFIED — see "F5A — Company course discovery
foundation" below. F5B persists F5A's already-live-verified data into
Supabase — `courses`, `iomad_course_mappings`,
`organisation_course_allocations`, and an atomic
`sync_iomad_company_course()` RPC — see "F5B — Course persistence and
organisation course mapping" below. **F5B is now DEPLOYED and LIVE
VERIFIED — migrations 0016 and 0017 (a forward-only column-ambiguity
hotfix to `sync_iomad_company_course()`, see "F5B hotfix — migration
0017" below) are both on myguru-staging and immutable.** **F5C adds
admin-only, read-only visibility of F5B's persisted course allocations,
extending the existing `/admin/organisations` page** — see "F5C — Admin
organisation course visibility" below. No new migration was needed for
F5C.
**No Iomad web-service function names in this document are fabricated.**
Rows not covered by the confirmed discovery remain marked
`UNKNOWN — requires staging Iomad discovery`.

**Historical note on F5A's discovery process: "documented" is not the
same as "execution-verified," and the two can disagree.** F5A's two
request/response contracts (company course allocations, course settings)
were initially provided as documentation from the live Iomad admin UI's
function signatures, marked `DOCUMENTED, NOT YET EXECUTION-VERIFIED`, and
distinct from the rest of this document's confirmations (which came from
actual successful calls). A subsequent execution pass against the running
instance **confirmed the company-course-allocations contract exactly as
documented**, but found that **the course-settings contract's documented
parameter (`courrseids[0]`) does not work at runtime** — every
parameterized variant tried failed, and the real call takes no course-id
parameter at all. Both contracts are now marked `LIVE VERIFIED` — see
"F5A — Company course discovery foundation" below for the full record,
including that correction.

## Confirmed discovery (F3), now partially live-verified (F4 live-verification pass)

Recorded directly from the real Iomad installation's admin UI. At F3,
**the exact request/response schemas for these functions had NOT been
live-verified** — the Iomad AWS environment was intentionally stopped to
save cost, so no live network call had been made against them.

**Update:** the Iomad AWS environment has since been started and a real,
authenticated call has been made and its response captured — see
"Live-verified: get_companies by code" below. This confirms the request
and response contract for one specific call shape
(`get_companies` filtered by `criteria[0][key]=code`). It does **not**
confirm the other two F3 functions (`get_company_courses`,
`get_course_info`), and does **not** confirm the unfiltered bulk
`get_companies` call (no criteria) that `listCompanies()` uses — that
call remains UNVERIFIED. Discovery (below) confirms which functions exist
and are enabled; live-verification (further below) confirms actual
request/response shapes for the one call that's been exercised.

- **Global web services:** enabled.
- **Protocol:** REST enabled, SOAP disabled. This integration only ever
  speaks REST (see `IomadRestClient.ts`).
- **External service:** name `iomadservice`, plugin
  `block_iomad_company_admin`, access authorised users.

**Function status (read, in F3/F4 scope):**

| Function | Purpose | Status |
|---|---|---|
| `block_iomad_company_admin_get_companies` | Get all Iomad companies | **LIVE-VERIFIED** for the criteria-filtered-by-code call (`getCompanyByCode`); UNVERIFIED for the unfiltered bulk call (`listCompanies`) |
| `block_iomad_company_admin_get_company_courses` | Get Iomad company course allocations | Confirmed function / not live-tested |
| `block_iomad_company_admin_get_course_info` | Get Iomad course settings | Confirmed function / not live-tested |

**CONFIRMED — OUT OF F3 SCOPE** (also read, not mapped to `IomadGateway` in F3):

| Function | Purpose |
|---|---|
| `block_iomad_company_admin_get_departments` | Get all company departments |
| `block_iomad_company_admin_get_department_users` | Get users within a department |
| `block_iomad_company_admin_get_user_companies` | Get user company information |
| `block_iomad_company_admin_get_license_info` | License info |
| `block_iomad_company_admin_get_license_from_id` | License info by id |

**CONFIRMED FUTURE WRITE FUNCTIONS — OUT OF F3 SCOPE** (F3 makes no write calls at all):

| Function | Purpose |
|---|---|
| `block_iomad_company_admin_create_companies` | Create company |
| `block_iomad_company_admin_edit_companies` | Edit company |
| `block_iomad_company_admin_assign_courses` | Assign course to company |
| `block_iomad_company_admin_unassign_courses` | Unassign course from company |
| `block_iomad_company_admin_assign_users` | Assign user to company |
| `block_iomad_company_admin_unassign_users` | Unassign user from company |
| `block_iomad_company_admin_enrol_users` | Enrol users |
| `block_iomad_company_admin_allocate_licenses` | Allocate licences |
| `block_iomad_company_admin_move_users` | Move users |
| `block_iomad_company_admin_update_courses` | Update courses |

**CONFIRMED — INTERESTING, DO NOT USE YET:**

| Function | Purpose | Why not yet |
|---|---|---|
| `block_iomad_company_admin_check_token` | Token validity check | Not needed for F3's read-only calls; revisit if/when a health-check endpoint is built |
| `block_iomad_company_admin_sync_users` | User sync | A write/side-effecting operation family — out of scope until user provisioning is designed (F4+) |

## Live-verified: get_companies by code

A real, authenticated request was made against the running Iomad
instance and its response captured. No token or base URL is recorded
anywhere in this document, the codebase, or its tests — only the
function name, request parameters, and response body below, none of
which are secrets.

**Function:** `block_iomad_company_admin_get_companies`

**Request parameters:**
```
criteria[0][key]=code
criteria[0][value]=MYGURU-SHIKSHA-001
```

**Response:**
```json
{
  "companies": [
    {
      "id": 3,
      "name": "Shiksha Academy",
      "shortname": "SHIKSHA",
      "code": "MYGURU-SHIKSHA-001",
      "address": "Test data – UK",
      "city": "Staines Upon Thames",
      "region": "Surrey",
      "country": "GB",
      "suspended": 0,
      "parentid": 0,
      "hostname": "",
      "maxusers": 0,
      "custom1": "myguru_franchise",
      "custom2": "test",
      "custom3": "uk"
    }
  ],
  "warnings": []
}
```

**What this confirms:**
- The response envelope is `{ companies: [...], warnings: [...] }` — an
  object, not a bare array. (The adapter still accepts a bare array too,
  defensively, but that shape has never actually been observed live.)
- `id` is numeric (`3`, not `"3"`) — `IomadResponseAdapters.idToString()`
  already handled this correctly (it accepts numbers), so no fix was
  needed there, but this is now confirmed rather than assumed.
- `name` is the display name (`"Shiksha Academy"`) and is a genuinely
  different field from `shortname` (`"SHIKSHA"`) — both present
  simultaneously. The adapter's existing `name ?? shortname` fallback
  order is confirmed correct for this record (name was present, so it
  was used).
- `code` is a THIRD, distinct field from both `name` and `shortname`
  (`"MYGURU-SHIKSHA-001"`) — not previously modelled at all. Now captured
  as `IomadCompanySummary.code` (optional).
- `suspended` is NUMERIC (`0`) — not a JSON boolean. Now captured as
  `IomadCompanySummary.isSuspended` (optional; `true` only when the
  fetched value is a number and nonzero; `undefined` if the field is
  absent or not a number — never guessed, never treated as a JSON
  boolean).
- A long tail of other fields (`address`, `city`, `region`, `country`,
  `parentid`, `hostname`, `maxusers`, `custom1`–`custom3`) exist on the
  wire and are correctly discarded by the adapter — not promoted into
  `IomadCompanySummary`, not treated as part of the contract.

**What this does NOT confirm:**
- Whether `get_companies` called with **no** `criteria` (the request
  shape `listCompanies()` uses) is even accepted, or what scope of
  companies it would return. This live test only exercised the
  criteria-filtered, single-company-by-code lookup. `listCompanies()` is
  unchanged and remains explicitly UNVERIFIED.
- `get_company_courses` or `get_course_info` — neither was exercised by
  this test. Both remain entirely UNVERIFIED, unchanged from F3.
- What a genuinely suspended company's record looks like — the only
  example captured has `suspended: 0` (active). The *meaning* of a
  nonzero value (0 = active, non-zero = suspended) is taken as given
  per the confirmed business/technical fact this task was based on, not
  independently observed from a live nonzero example.
- Whether `custom1`/`custom2`/`custom3` (here `"myguru_franchise"`,
  `"test"`, `"uk"`) are a stable, meaningful convention this specific
  Iomad instance uses for classification, or incidental test-data
  values. Nothing in the codebase reads or relies on these fields — see
  "Organisation classification" in `docs/SYSTEM_OF_RECORD.md`, which
  remains `unclassified`-by-default regardless.

**Where this is implemented:** `IomadRestGateway.getCompanyByCode(code)`
(`netlify/functions/_lib/iomad/IomadRestGateway.ts`) — a new, narrow,
additive method alongside the existing `listCompanies()`/`getCompany()`.
It does not change `listCompanies()`'s behaviour, parameters, or the
`IomadCompanySyncService`/F4 sync algorithm, which still only calls
`listCompanies()`. See `netlify/functions/_lib/iomad/IomadRestClient.ts`'s
`buildCriteriaParams()` for the request-encoding helper
(`criteria[N][key]`/`criteria[N][value]`), and
`netlify/functions/_lib/iomad/__tests__/fixtures/shikshaAcademy.ts` for
the exact fixture used in tests.

## What repository evidence currently exists

Searched: `.env.example`, all of `src/`, all of `supabase/`, all of
`docs/`. Findings:

- `.env.example` declares two server-only variables — `IOMAD_BASE_URL` and
  `IOMAD_SERVICE_TOKEN` — both empty placeholders. No base URL, no token,
  no function name is present anywhere in the repository.
- `src/services/lms/LmsService.ts` defines the *platform-facing* contract
  (`createStudent`, `createTeacher`, `enrolStudent`, `assignTeacher`,
  `findUserByEmail`, `getCourses`, `getEnrolments`, `getCourseProgress`) —
  deliberately Iomad-agnostic naming, not Moodle/Iomad web-service function
  names. This is the *application* contract the gateway below sits behind,
  not evidence of the underlying Iomad function names.
- `supabase/migrations/0010_integration_jobs.sql`'s `operation_type` check
  constraint lists the command set this table is scoped to:
  `create_student`, `create_teacher`, `enrol_student`, `assign_teacher`,
  `create_link_company`, `sync_courses`, `sync_company`,
  `refresh_enrolment`, `refresh_progress`, `refresh_completion`. These are
  platform-side operation names, not Moodle/Iomad web-service function
  names either.

This was true of the repository at F2. F3 adds confirmed function names
from real discovery (above), sourced from the Iomad admin UI rather than
the repository — the repository itself still contains no fabricated
function names; every function name that now appears below is one of the
confirmed ones listed above, applied to the matching inventory row.

## Inventory matrix

Columns: Platform operation · Iomad/Moodle function name · Direction ·
Read/write · Required inputs · Returned external IDs · System of record ·
Idempotency expectation · Retry-safe? · Status · Tested?

### Companies

| Platform operation | Iomad/Moodle function | Direction | R/W | Required inputs | Returned external IDs | SoR | Idempotency | Retry-safe? | Status | Tested |
|---|---|---|---|---|---|---|---|---|---|---|
| List companies | `block_iomad_company_admin_get_companies` | Iomad → Platform | Read | none (no pagination params sent by F3 — UNVERIFIED whether the function accepts any) | company IDs | Iomad | n/a (read) | Yes | Confirmed function / not live-tested | No |
| Get company | *(none — derived from listCompanies() by filtering, see "Read-only gateway contract")* | Iomad → Platform | Read | company ID | company ID | Iomad | n/a (read) | Yes | No dedicated function confirmed | No |
| Create company | `block_iomad_company_admin_create_companies` | Platform → Iomad | Write | name, shortname, and Iomad-required fields (TBD from live schema) | company ID | Iomad | Should be keyed by `IntegrationJob.idempotency_key` (e.g. `create_link_company:{organisation_id}`) | Only if Iomad rejects/no-ops duplicate shortnames — TBD | Confirmed function — OUT OF F3 SCOPE | No |
| Update company | `block_iomad_company_admin_edit_companies` | Platform → Iomad | Write | company ID + changed fields | company ID | Iomad | Natural (full-state update) if function supports partial update — TBD | Likely yes | Confirmed function — OUT OF F3 SCOPE | No |
| Disable/delete company | *(no dedicated "disable" function confirmed — likely via `edit_companies` with a status/suspended field, TBD)* | Platform → Iomad | Write | company ID | company ID | Iomad | Natural (disable is idempotent by definition) | Likely yes | UNKNOWN — requires staging Iomad discovery | No |
| Company departments (if applicable) | `block_iomad_company_admin_get_departments` | Iomad → Platform | Read | company ID | department IDs | Iomad | n/a (read) | Yes | Confirmed function — OUT OF F3 SCOPE | No |
| Department users (if applicable) | `block_iomad_company_admin_get_department_users` | Iomad → Platform | Read | department ID | user IDs | Iomad | n/a (read) | Yes | Confirmed function — OUT OF F3 SCOPE | No |

### Users

| Platform operation | Iomad/Moodle function | Direction | R/W | Required inputs | Returned external IDs | SoR | Idempotency | Retry-safe? | Status | Tested |
|---|---|---|---|---|---|---|---|---|---|---|
| List/get users | *(no confirmed "list all users" function; `block_iomad_company_admin_get_user_companies` returns a given user's company memberships, not a user listing — different operation)* | Iomad → Platform | Read | user ID(s) or filter | user IDs | Iomad | n/a (read) | Yes | UNKNOWN — requires staging Iomad discovery | No |
| Get a user's company memberships | `block_iomad_company_admin_get_user_companies` | Iomad → Platform | Read | user ID | company IDs | Iomad | n/a (read) | Yes | Confirmed function — OUT OF F3 SCOPE | No |
| Create user | `block_iomad_company_admin_assign_users` may implicitly create, or a separate core `core_user_create_users` may be required — TBD | Platform → Iomad | Write | email/username + required profile fields (TBD) | user ID | Iomad | Keyed by `IntegrationJob.idempotency_key` (e.g. `create_student:{student_id}` / `create_teacher:{tutor_profile_id}`) — matches `LmsService.createStudent`/`createTeacher` call sites once built | Depends on whether Iomad errors or returns existing on duplicate username — TBD | UNKNOWN — requires staging Iomad discovery | No |
| Update user | UNKNOWN — requires staging Iomad discovery | Platform → Iomad | Write | user ID + changed fields | user ID | Iomad | Natural if partial-update supported — TBD | Likely yes | UNKNOWN — requires staging Iomad discovery | No |
| Suspend user | UNKNOWN — requires staging Iomad discovery | Platform → Iomad | Write | user ID | user ID | Iomad | Natural (suspend is idempotent) | Likely yes | UNKNOWN — requires staging Iomad discovery | No |
| Delete user | UNKNOWN — requires staging Iomad discovery | Platform → Iomad | Write | user ID | user ID | Iomad | Natural if already-deleted is a no-op — TBD | Likely yes | UNKNOWN — requires staging Iomad discovery | No |
| Assign user to company | `block_iomad_company_admin_assign_users` | Platform → Iomad | Write | user ID, company ID | n/a | Iomad | Should be a no-op if already assigned — TBD | Likely yes | Confirmed function — OUT OF F3 SCOPE | No |
| Remove user from company | `block_iomad_company_admin_unassign_users` | Platform → Iomad | Write | user ID, company ID | n/a | Iomad | Natural (removal is idempotent) | Likely yes | Confirmed function — OUT OF F3 SCOPE | No |
| Move user (between companies/departments) | `block_iomad_company_admin_move_users` | Platform → Iomad | Write | user ID, target company/department ID | n/a | Iomad | TBD | TBD | Confirmed function — OUT OF F3 SCOPE | No |
| Assign company/department manager (if available) | UNKNOWN — requires staging Iomad discovery | Platform → Iomad | Write | user ID, company/department ID | n/a | Iomad | TBD | TBD | Unknown — requires discovery to confirm feature availability | No |

### Courses

| Platform operation | Iomad/Moodle function | Direction | R/W | Required inputs | Returned external IDs | SoR | Idempotency | Retry-safe? | Status | Tested |
|---|---|---|---|---|---|---|---|---|---|---|
| List courses (all, unscoped by company) | *(no confirmed function — only "get course info" for a specific course and "get company courses" per-company are confirmed)* | Iomad → Platform | Read | none / filter | course IDs | Iomad | n/a (read) | Yes | UNKNOWN — requires staging Iomad discovery | No |
| Get course | `block_iomad_company_admin_get_course_info` | Iomad → Platform | Read | course ID | course ID | Iomad | n/a (read) | Yes | Confirmed function / not live-tested | No |
| Create/update course (if intended) | `block_iomad_company_admin_update_courses` for update; create function not separately confirmed | Platform → Iomad | Write | course fields (TBD) | course ID | Iomad | TBD | TBD | Confirmed function (update) — OUT OF F3 SCOPE; create UNKNOWN | No |
| Assign course to company | `block_iomad_company_admin_assign_courses` | Platform → Iomad | Write | course ID, company ID | n/a | Iomad | Should be a no-op if already assigned — TBD | Likely yes | Confirmed function — OUT OF F3 SCOPE | No |
| Unassign course from company | `block_iomad_company_admin_unassign_courses` | Platform → Iomad | Write | course ID, company ID | n/a | Iomad | Natural (unassign is idempotent) | Likely yes | Confirmed function — OUT OF F3 SCOPE | No |
| Retrieve company courses | `block_iomad_company_admin_get_company_courses` | Iomad → Platform | Read | company ID | course IDs | Iomad | n/a (read) | Yes | Confirmed function / not live-tested | No |
| Licence info | `block_iomad_company_admin_get_license_info` / `..._get_license_from_id` | Iomad → Platform | Read | company ID or licence ID | licence ID | Iomad | n/a (read) | Yes | Confirmed function — OUT OF F3 SCOPE | No |

### Enrolments

| Platform operation | Iomad/Moodle function | Direction | R/W | Required inputs | Returned external IDs | SoR | Idempotency | Retry-safe? | Status | Tested |
|---|---|---|---|---|---|---|---|---|---|---|
| Enrol user | `block_iomad_company_admin_enrol_users` | Platform → Iomad | Write | user ID, course ID | enrolment ID (if returned) | Iomad | Keyed by `IntegrationJob.idempotency_key` (e.g. `enrol_student:{student_id}:{course_id}`) — matches `LmsService.enrolStudent` | Should be a no-op if already enrolled — TBD | Confirmed function — OUT OF F3 SCOPE | No |
| Unenrol user | UNKNOWN — requires staging Iomad discovery (no dedicated unenrol function confirmed; may be a core Moodle enrol function rather than a `block_iomad_company_admin_*` one) | Platform → Iomad | Write | user ID, course ID | n/a | Iomad | Natural (unenrol is idempotent) | Likely yes | UNKNOWN — requires staging Iomad discovery | No |
| Retrieve enrolments | UNKNOWN — requires staging Iomad discovery | Iomad → Platform | Read | user ID or course ID | enrolment IDs | Iomad | n/a (read) | Yes | UNKNOWN — requires staging Iomad discovery | No |

### Learning

| Platform operation | Iomad/Moodle function | Direction | R/W | Required inputs | Returned external IDs | SoR | Idempotency | Retry-safe? | Status | Tested |
|---|---|---|---|---|---|---|---|---|---|---|
| Completion | UNKNOWN — requires staging Iomad discovery | Iomad → Platform | Read | user ID, course ID | n/a | Iomad | n/a (read) | Yes | Candidate | No |
| Grades | UNKNOWN — requires staging Iomad discovery | Iomad → Platform | Read | user ID, course ID | n/a | Iomad | n/a (read) | Yes | Candidate | No |
| Certificates | UNKNOWN — requires staging Iomad discovery | Iomad → Platform | Read | user ID, course ID | certificate ID (if applicable) | Iomad | n/a (read) | Yes | Unknown — depends on which certificate plugin (if any) is enabled | No |
| Activity/course progress (where available) | UNKNOWN — requires staging Iomad discovery | Iomad → Platform | Read | user ID, course ID | n/a | Iomad | n/a (read) | Yes | Candidate | No |

**Status vocabulary used across this matrix:**
- **Confirmed function / not live-tested** — the exact wsfunction name was
  recorded from the real Iomad admin UI (F3 discovery, above), but its
  parameter/response schema has not been exercised against a live call.
  These three rows (`get_companies`, `get_company_courses`,
  `get_course_info`) are the F3 implementation's actual scope.
- **Confirmed function — OUT OF F3 SCOPE** — the wsfunction name was
  recorded the same way, but F3 deliberately does not call it (mostly
  write operations; F3 is read-only).
- **Candidate** — no function name confirmed by F3 discovery; the
  *operation* is a well-known Moodle/Iomad capability (core Moodle web
  services and Iomad's company/enrolment extensions both generally
  support it), so it's reasonable to plan around it existing.
- **UNKNOWN — requires staging Iomad discovery** — neither the function
  name nor, in some cases, whether the capability is enabled at all has
  been confirmed for this instance.

None of the above is a claim that a function has been called against a
live Iomad instance — "Tested" stays "No" everywhere until the live-test
checklist below is actually run.

## API discovery checklist

**Status: partially complete.** The Companies function family (list
companies, company courses, course info, plus the confirmed-but-out-of-
scope departments/user/licence/write functions) was recorded from the
real Iomad admin UI in F3 — see "Confirmed discovery (F3)" above. Users
(list/get all users), Enrolments, and Learning (completion/grades/
certificates/progress) were **not** covered by that discovery pass and
remain open. The steps below still apply to whatever's left — do not
re-walk the Companies functions, they're done.

Manual steps to perform in the Iomad/Moodle admin UI. **Do not paste any
token or secret anywhere, including here.**

### Where to look

```
Site administration
  → Server
    → Web services
      → External services
        → Functions
```
and
```
Site administration
  → Server
    → Web services
      → Manage tokens
```
(For the second path: confirm a service token *exists* and which external
service it's scoped to. Do not copy the token value into any document,
chat, or file.)

### What to record for each enabled function

For every function found under **External services → Functions**, record:

- [ ] Function name (exact string, e.g. `core_user_create_users` or
      `local_iomad_*` if Iomad-specific — write down exactly what's shown)
- [ ] Description (as shown in the admin UI)
- [ ] Which external service it belongs to (there may be more than one
      service defined — record the service name too)
- [ ] Required permissions/capabilities (Moodle capability strings, e.g.
      `moodle/user:create`)
- [ ] Request parameters (names and types, from the function's
      documentation page if the admin UI links one, or from
      Site administration → Server → Web services → API documentation)
- [ ] Response shape (field names and types)
- [ ] Whether it is Moodle core (`core_*`) or Iomad-specific
      (`local_iomad_*`, `block_iomad_*`, or similar prefix)

### Suggested order

1. Companies: search the functions list for anything containing
   `company` (expect an Iomad-specific prefix).
2. Users: search for `core_user_*` and any Iomad-specific user/company
   assignment functions.
3. Courses: search for `core_course_*` and any Iomad-specific
   course-to-company assignment functions.
4. Enrolments: search for `enrol_*` and `core_enrol_*`.
5. Completion/grades/certificates: search for `core_completion_*`,
   `gradereport_*`, `core_grades_*`, and any certificate-plugin-specific
   functions (only present if that plugin is installed).

Record findings in a copy of the inventory matrix above, replacing
`UNKNOWN — requires staging Iomad discovery` with the confirmed function
name and flipping `Status` to `Confirmed` and `Tested` to `Yes` only once
an actual staging call has been made (not just observed as enabled).

## Read-only gateway contract

**Implemented in F3.** Two layers, split per the brief's architecture:

```
Platform service (future)
  → IomadGateway interface        src/integrations/iomad/IomadGateway.ts
  → REST implementation           netlify/functions/_lib/iomad/IomadRestGateway.ts
  → Moodle/Iomad REST transport   netlify/functions/_lib/iomad/IomadRestClient.ts
  → POST /webservice/rest/server.php (wstoken, wsfunction, moodlewsrestformat=json)
```

`src/integrations/iomad/IomadGateway.ts` defines **interfaces and types
only** — no network implementation, no tokens, no secrets. It's the
provider-agnostic contract, matching the same pattern `LmsService`
established for the application-facing boundary (`ARCHITECTURE.md`'s LMS
boundary diagram).

`netlify/functions/_lib/iomad/` holds the actual implementation —
server-only, never importable from `src/` (the same "zero import path
back into `src/`" rule already established for
`netlify/functions/_lib/validation.ts`):

- **`iomadConfig.ts`** — reads `IOMAD_BASE_URL`/`IOMAD_SERVICE_TOKEN` from
  `process.env`; returns an explicit `configured` | `not_configured`
  state. Missing env vars never throw or crash startup.
- **`IomadErrors.ts`** — safe typed errors (`not_configured`,
  `network_error`, `timeout`, `invalid_json`, `moodle_exception`,
  `unauthorized`, `unknown_response_schema`) and a log helper that only
  ever writes `{ wsfunction, code, httpStatus, correlationId }` — never
  the token, never a raw response body, never learner data.
- **`IomadRestClient.ts`** — the low-level REST transport. Has no
  Netlify-specific imports (only `fetch`/`AbortController`/`process.env`),
  so it can move to an AWS Lambda/ECS runtime later with no rewrite. A
  bounded timeout (default 8s) via `AbortController`; one safe retry on
  transient `network_error` only (never on `timeout`, `moodle_exception`,
  or `unauthorized` — those aren't transient in the same sense).
- **`IomadResponseAdapters.ts`** — defensive raw→normalized parsing.
  Explicitly commented **"response adapter pending live schema
  verification"**: field names (`id`/`name`/`shortname` for companies,
  `id`/`fullname`/`shortname` for courses) follow conventional
  Moodle/Iomad naming but are unverified for this instance. A response
  that doesn't match throws `unknown_response_schema` rather than
  guessing.
- **`IomadRestGateway.ts`** — the concrete `IomadGateway` implementation.
  Maps the three confirmed functions (see mapping table below);
  `getCompany()` is derived by filtering `listCompanies()` since no
  confirmed single-company function exists. `createIomadGateway()` is the
  composition entry point — always safe to construct; returns a gateway
  whose methods throw a safe `not_configured` error on first *use* if env
  vars are missing.

### Confirmed function mapping (F3 scope)

| `IomadGateway` method | Iomad wsfunction | Parameter key sent | Verified? |
|---|---|---|---|
| `listCompanies()` | `block_iomad_company_admin_get_companies` | none | Function name confirmed; no params sent (UNVERIFIED whether any are accepted/required) |
| `getCompany(id)` | *(none — derived)* | n/a | Filters the `listCompanies()` result client-side |
| `listCompanyCourses(companyId)` | `block_iomad_company_admin_get_company_courses` | `companyid` | Function name confirmed; **parameter key `companyid` is UNVERIFIED** — an assumption based on Moodle/Iomad naming convention |
| `getCourse(courseId)` | `block_iomad_company_admin_get_course_info` | `courseid` | Function name confirmed; **parameter key `courseid` is UNVERIFIED** |

Only these four files (plus their `__tests__/`) reference a raw
`block_iomad_company_admin_*` string. Nowhere else in the codebase does —
enforced by the security-audit tests described below.

### Security (F3)

- `IOMAD_BASE_URL`/`IOMAD_SERVICE_TOKEN` are server-only (`.env.example`,
  no `VITE_` prefix) and read in exactly one module
  (`iomadConfig.ts`) — enforced by a new assertion in
  `netlify/functions/_lib/__tests__/securityAudit.test.ts`
  (`process.env.IOMAD_SERVICE_TOKEN` referenced only there).
- A new assertion in `src/test/security/noSecretKeyInBrowser.test.ts`
  confirms no file under `src/` references `IOMAD_SERVICE_TOKEN` or
  declares a `VITE_IOMAD*` variable — the token can never reach the
  browser bundle.
- No error message, log line, or test fixture in the Iomad integration
  ever contains the token value or a raw Iomad exception message — every
  error factory in `IomadErrors.ts` returns a fixed, generic string; the
  contract tests assert this directly (mocked token value never appears
  in a thrown error's `.message`).

### Not implemented in F3 (confirmed available, deliberately deferred)

Every function under "CONFIRMED — OUT OF F3 SCOPE" and "CONFIRMED FUTURE
WRITE FUNCTIONS" above (departments, department users, user-company
lookup, licences, create/edit/disable company, assign/unassign
users/courses, enrol users, allocate licences, move users, update
courses) exists and is enabled on the target instance, but F3 makes zero
calls to any of them. `check_token` and `sync_users` are noted as
confirmed-but-not-to-be-used-yet per the brief.

## Company sync foundation (F4, revised after review)

**Implemented in F4.** Consumes F3's `listCompanies()` — nothing else.
No write-back to Iomad, no company creation/suspension calls.

```
IomadGateway.listCompanies()                netlify/functions/_lib/iomad/IomadRestGateway.ts (F3, unchanged)
  → { externalId, displayName }[]           netlify/functions/_lib/iomad/IomadResponseAdapters.ts (F3, unchanged)
  → IomadCompanySyncService.sync()          netlify/functions/_lib/companySync/IomadCompanySyncService.ts
  → OrganisationSyncRepository.syncCompany  netlify/functions/_lib/companySync/OrganisationSyncRepository.ts (interface)
  → SupabaseOrganisationSyncRepository      netlify/functions/_lib/companySync/SupabaseOrganisationSyncRepository.ts
  → sync_iomad_company() RPC (atomic)       supabase/migrations/0015_organisation_iomad_company_sync.sql
  → organisations / iomad_company_mappings
```

**Fields synced: `externalId` → `iomad_company_mappings.iomad_company_id`,
`displayName` → `organisations.name`. Nothing else.** This is a direct
consequence of F3's response adapter exposing only those two fields (see
"Read-only gateway contract" above) — the sync service has no access to a
company-suspended flag, shortname/code, or any other Iomad-side field,
because F3 doesn't expose one. `organisations.status` is set to
`'active'` unconditionally by every F4-created row; no code path sets
`'suspended'` from Iomad data. **Suspension sync is explicitly NOT
implemented — PENDING LIVE SCHEMA VERIFICATION**, same as every other
field below the two confirmed ones.

**Classification: every newly-discovered organisation is
`type: 'unclassified'`.** The single shared Iomad instance holds MyGuru
franchise companies, Corporate companies, future school tenants, and
potentially internal tenants — F4 has no verified signal in
`listCompanies()`'s response to distinguish which is which, and
deliberately does not infer it from company name, ID, or any other
heuristic. `organisations.type`'s check constraint is
`'unclassified' | 'myguru_franchise' | 'corporate' | 'school_future' | 'internal'`,
with `'unclassified'` as the column default. Assigning a real business
classification is future work — an explicit provisioning or admin
workflow, not part of sync.

**Atomicity (review fix):** the original design performed a separate
`INSERT` into `organisations` and then a separate `INSERT` into
`iomad_company_mappings` as two independent Supabase requests — if the
second failed, the first could succeed and leave an orphan organisation,
and a subsequent sync would then create a *second* organisation for the
same Iomad company, breaking the idempotency the unique `iomad_company_id`
constraint is meant to guarantee. This is now one atomic operation: the
`sync_iomad_company(p_iomad_company_id, p_display_name)` Postgres
function (`supabase/migrations/0015`) performs find-or-create-or-rename +
mark-synced entirely inside one database transaction. See "Transactional
RPC design" below for the full design and its SECURITY INVOKER
justification.

**Algorithm** (`IomadCompanySyncService.sync()`):
1. Call `listCompanies()`. If it throws, return a `CompanySyncResult` with
   all-zero counts and a safe `topLevelError` code (one of
   `IomadErrorCode` from `IomadErrors.ts`) — the run never partially
   applies when the fetch itself fails.
2. For each company (skipping a same-batch duplicate `externalId`, which
   would otherwise violate the table's unique constraint), call
   `repository.syncCompany({ iomadCompanyId, displayName })` — the one
   atomic RPC call above — and use its `wasCreated`/`nameChanged` flags to
   count the company as **created**, **updated**, or **unchanged**.
   - Any exception during this company's processing → caught, counted as
     **failed**, logged with only `{ iomadCompanyId, errorCode,
     correlationId }` (never a raw message, never the display name), and
     processing continues to the next company (F4 §6's "one company
     failure does not necessarily corrupt all other records"). Because
     `syncCompany()` is atomic, a failure here guarantees no partial
     organisation/mapping was left behind for that company.
3. If — and only if — the fetch returned at least one company, mark every
   mapping whose `iomadCompanyId` was NOT seen this run as `stale`
   (F4 §7: "do not delete on missing source"). **Deliberately skipped
   when the fetch returns zero companies** — an empty result is far more
   likely to indicate an upstream problem than a genuine "we now have
   zero companies" state, and mass-staling every known mapping on that
   basis would be actively harmful.

**Idempotency:** the external identity key is `iomad_company_id`
(never email/name — F1 Ground rule 2). Running the same company list
through `sync()` twice creates exactly one organisation/mapping pair per
company on the first run and updates/reuses that same pair on every
subsequent run — proven by tests, not just asserted (see
`netlify/functions/_lib/companySync/__tests__/IomadCompanySyncService.test.ts`
for the sequential case and "Transactional RPC design" below for the
concurrent case, which a JS-level fake cannot exercise — that guarantee
lives in the SQL function's advisory lock, verified by the SQL regression
tests instead).

**Persistence:** `supabase/migrations/0015_organisation_iomad_company_sync.sql`.
`organisations` and `iomad_company_mappings`, both RLS-enabled with
**admin read-only** policies — no anon/authenticated write policy exists
on either table. The only writer is `SupabaseOrganisationSyncRepository`,
calling `sync_iomad_company()` (and doing two simple, inherently
single-statement, single-table updates for `markFailed`/
`markMissingAsStale`) using the service-role key (bypasses RLS), the same
pattern `integration_jobs` (`0010`) already established.

**`markFailed()` (review fix):** Supabase-js reports a failed write
through the response's `error` field on normal resolution, not by
throwing a JS exception — the original implementation wrapped the call in
`try/catch` and silently discarded whatever happened, without ever
actually inspecting `error`. It now inspects `error` explicitly and logs
a safe DB error code (never raw detail/PII/secrets) when present; the
`try/catch` remains only as a backstop for a genuine
network/client-level exception, which is rare. Still best-effort, still
never throws into the sync loop — that contract is unchanged, just
implemented against what Supabase-js actually does.

**No server endpoint.** The brief's own guidance — "if authentication
wiring is not sufficiently clean yet, do NOT expose an endpoint and keep
F4 service-only… prefer safety over convenience" — applies directly here:
this repository has no existing pattern for an authenticated,
admin-only-triggered Netlify Function (every existing function is a
public anonymous-safe submission endpoint protected by rate-limiting/
honeypot, not by verifying an admin session server-side). Building that
verification cleanly is new infrastructure, not a small addition, so F4
stays service-only. `IomadCompanySyncService` can be invoked from a test,
a future authenticated endpoint, or a future scheduled job — nothing
about its design assumes a caller.

**`integration_jobs` reuse (not a new queue):** `0010`'s
`operation_type` check constraint already includes `sync_company`. F4
does not build a second queue system, and does not wire `sync_company`
jobs to anything yet — `IomadCompanySyncService.sync()` runs
synchronously (matches the brief: "it is acceptable for sync service to
run synchronously in tests" — and, for now, in any other caller too). A
future scheduled reconciliation job would create `integration_jobs` rows
with `operation_type = 'sync_company'` and a worker that calls
`IomadCompanySyncService.sync()` — not implemented in F4.

**Data minimisation (F4 §14):** only two fields are synchronised —
company external identity and a display name — chosen because they're
the only two fields needed for tenant identity and portal
display/routing, and because they're the only two fields F3's adapter
actually exposes. No learner data, no company-internal user lists, no
department data, and no licence data are replicated by this service, even
though the underlying Iomad functions for some of those exist (see
"Confirmed discovery (F3)" above) — F4 calls none of them.

### Transactional RPC design (F4 review fix)

`sync_iomad_company(p_iomad_company_id text, p_display_name text)` —
defined in `supabase/migrations/0015_organisation_iomad_company_sync.sql`,
called from `SupabaseOrganisationSyncRepository.syncCompany()` via
`supabase.rpc(...)`.

**Input:** the Iomad company external id (`p_iomad_company_id`, the only
identity key) and the normalized display name
(`p_display_name` — already run through F3's response adapter before it
reaches this function; the function itself does no Iomad-specific
parsing).

**What it does, atomically, in one transaction:**
1. Takes a transaction-scoped advisory lock keyed on
   `p_iomad_company_id` (`pg_advisory_xact_lock(hashtext(...))`) —
   serializes any two concurrent calls for the *same* company so they
   cannot both observe "doesn't exist yet" and race the unique
   constraint. The second caller blocks until the first commits, then
   sees the row the first created and takes the update branch instead.
2. Looks up the existing mapping (if any) for that company, with
   `for update of m` — locks the row for the rest of this transaction.
3. **Not found:** inserts a new `organisations` row
   (`type: 'unclassified'`, `status: 'active'`, `source: 'iomad_sync'`)
   and a new `iomad_company_mappings` row linking to it
   (`sync_status: 'synced'`), in that order, both inside this function
   call.
4. **Found:** updates `organisations.name` only if it actually differs
   (`is distinct from`) from what's fetched, and marks the mapping
   `synced` either way.
5. Returns the full resulting organisation + mapping row, plus
   `was_created`/`name_changed` flags the caller uses to report
   created/updated/unchanged.

**Idempotent and concurrency-safe:** a repeated call — sequential or
concurrent — for the same `iomad_company_id` returns/reuses the same
organisation+mapping pair. Sequential idempotency is proven by the
TypeScript-level tests (fake repository, in-memory). Concurrency-safety
is a property of the advisory lock + row lock inside the SQL function
itself — it can't be exercised by a JS-level fake, so it's covered
instead by the SQL regression tests confirming the lock and the
`for update` clause are actually present in the deployed function body.

**If any part fails, nothing partial remains:** the entire function body
runs as one PL/pgSQL call. An unhandled exception at any point (a
constraint violation, a bad input, anything) rolls back everything the
function did in that call — there is no statement boundary between the
organisation insert and the mapping insert for a partial failure to land
in, and no explicit `EXCEPTION` block that could accidentally swallow and
partially commit. Input validation
(`p_iomad_company_id`/`p_display_name` must be non-blank) raises before
any write is attempted.

**SECURITY INVOKER, not DEFINER — explicitly justified:** the only
intended caller is the service-role key, which already bypasses RLS and
has full read/write access to both tables — there is no privilege gap
for DEFINER to bridge (contrast with `is_admin()` in `0008`, which needs
DEFINER specifically to read `admin_profiles` under a caller's own,
possibly-restrictive, RLS context). INVOKER is not just "no worse" here —
it's a real defense-in-depth improvement: if `EXECUTE` were ever
mistakenly granted to `authenticated`, an INVOKER function still runs
under that caller's own RLS-restricted privileges and would fail to
write (neither table has an authenticated-write policy), whereas a
DEFINER function would not have had that protection.

**Not callable by anon/authenticated:** `revoke all ... from public;
grant execute ... to service_role;` — the same revoke-then-grant pattern
`0013`'s `create_tutor_application()` already established for
server-only RPCs. Confirmed by SQL regression tests, not just asserted.

**No Iomad write occurs.** The function only ever touches
`organisations`/`iomad_company_mappings` — no HTTP call, no reference to
any `block_iomad_company_admin_*` function, confirmed by a regression
test scanning the function body specifically.

**Rename + mark-synced atomicity:** handled by the same function's
"found" branch (step 4 above) rather than a second RPC — both the name
update and the mapping's `sync_status`/`last_synced_at` update happen
inside the same transaction as the row lock from step 2, so they cannot
partially commit relative to each other.

### Live schema gate (F4), updated after live verification

Resolved by the live-verified `get_companies`-by-code call (see
"Live-verified: get_companies by code" above):

- ~~exact company name field~~ — **RESOLVED**: `name` is confirmed
  present and used; `shortname` is a genuine fallback field, also
  confirmed present.
- ~~company suspension field~~ — **RESOLVED (field existence + type)**:
  `suspended` is confirmed present and NUMERIC (0 = active, non-zero =
  suspended). Now captured as `IomadCompanySummary.isSuspended`. **Still
  blocked:** actually *using* this field to sync `organisations.status`
  — that remains unimplemented (F4B), since the meaning of a nonzero
  value hasn't been independently observed from a live suspended-company
  example, only stated.
- ~~company code/shortname as a distinct field~~ — **RESOLVED**: `code`
  is confirmed as a THIRD field, distinct from both `name` and
  `shortname`. Now captured as `IomadCompanySummary.code`.
- ~~response envelope shape~~ — **RESOLVED**: confirmed
  `{ companies: [...], warnings: [...] }` (an object, not a bare array).

Still blocked — not synced, not assumed, not invented:

- deleted/inactive semantics — does a disabled company vanish from
  `get_companies` entirely, or just gain `suspended: 1`? Not observed;
  only an active (`suspended: 0`) example exists.
- exact scope of `get_companies` **called with no criteria** — "all
  companies" vs. "companies visible to this token" (matters once
  Corporate/franchise companies exist alongside MyGuru's own). The live
  test used a criteria filter; it says nothing about the unfiltered bulk
  call `listCompanies()` uses, which remains entirely UNVERIFIED —
  including whether it's even accepted without `criteria`.
- `get_company_courses` / `get_course_info` request and response shapes —
  neither has been exercised live; both remain exactly as UNVERIFIED as
  before this pass.

## F5A — Company course discovery foundation

**Scope: read-only discovery.** organisation → iomad_company_mapping →
Iomad company ID → `get_company_courses(companyId)` → course IDs →
`get_course_info()` → normalized read-only result. No user sync, no
enrolment, no licences, no SSO, no course create/update/delete, no write
of any kind. No persistence added — this is gateway + normalized model +
tests + a controlled CLI smoke-test tool only.

**Both contracts below are now LIVE VERIFIED (execution-tested against
the running Iomad instance).** The initial pass documented them from the
generated Iomad admin UI documentation only; a subsequent live-execution
pass corrected one of them where the generated documentation did not
match runtime behaviour — see "Correction: get_course_info's real
parameter contract" below.

Live-verified organisations this foundation has been exercised against
(F4C/F4D):
- Shiksha Academy — Iomad company ID `3`, code `MYGURU-SHIKSHA-001`
- Jupiter Test Academy — Iomad company ID `4`, code `MYGURU-JUPITER-TEST-001`

### Company course allocations — LIVE VERIFIED

**Function:** `block_iomad_company_admin_get_company_courses`

**Request parameters — confirmed by a real successful call:**
```
criteria[0][companyid]=4
criteria[0][shared]=0
```
A normal company-specific lookup uses `shared=0` — this is the
`IomadGateway.listCompanyCourses(companyId, shared = false)` default.

**Real response (Jupiter Test Academy, one allocated course):**
```json
{
  "companies": [
    {
      "id": 4,
      "name": "Jupiter Test Academy",
      "shortname": "JUPITERSCHOLAR",
      "code": "MYGURU-JUPITER-TEST-001",
      "address": "",
      "city": "southampton",
      "region": "",
      "postcode": "",
      "country": "GB",
      "custom1": "",
      "custom2": "",
      "custom3": "",
      "courses": [
        { "id": 4, "fullname": "Jupiter Test Mathematics", "customfields": [] }
      ]
    }
  ],
  "warnings": []
}
```

**Zero-course response — also confirmed live, a VALID SUCCESS state, not
an error.** Before "Jupiter Test Mathematics" was allocated to the
company, the same call returned the identical shape with `"courses": []`.
`normalizeCompanyCourseAllocations()` returns an empty array for this
case; `scripts/iomad-company-courses.ts` prints a clean
`{ companyId, courses: [] }` success result and does **not** call
`getCourseSettings()`/`get_course_info` at all in that case — there is
nothing to fetch settings for.

**Do not assume the `companies` array contains only the requested
company** — `normalizeCompanyCourseAllocations()`
(`netlify/functions/_lib/iomad/IomadResponseAdapters.ts`) actively finds
the entry matching the requested `companyId` rather than taking the
first/only element. A response with more than one matching entry is
treated as an unexpected/duplicate result and throws
`unknown_response_schema`, the same posture `getCompanyByCode()` already
uses for its own duplicate case.

**Normalized model** (`CompanyCourseAllocation`, in
`netlify/functions/_lib/iomad/IomadRestGateway.ts` and mirrored in
`src/integrations/iomad/IomadGateway.ts`):
```ts
interface CompanyCourseAllocation {
  externalCourseId: string;
  fullName: string;
  customFields?: Array<{ externalFieldId: string; name: string; value: string }>;
}
```
`address`/`city`/`region`/`postcode`/`country`/`custom1`/`custom2`/
`custom3` at the company level are never persisted or promoted into any
normalized type — discarded, per "do not persist unnecessary raw Iomad
metadata."

### Course settings/info — LIVE VERIFIED (contract corrected after live testing)

**Function:** `block_iomad_company_admin_get_course_info`

**Correction: get_course_info's real parameter contract.** The
*generated* Iomad admin UI documentation described a `courrseids[0]`
parameter (an upstream typo, `courrseids` not `courseids`). **Execution
testing against the running instance proved this generated documentation
did not match runtime behaviour.** Every parameterized variant tried
returned `invalid_parameter_exception`:
```
courrseids[0]=4   -> invalid_parameter_exception
courseids[0]=4    -> invalid_parameter_exception
courseid[0]=4     -> invalid_parameter_exception
```
**The real, successful request sends NO course-id parameter at all:**
```
wstoken=...
wsfunction=block_iomad_company_admin_get_course_info
moodlewsrestformat=json
```
This is a case where the generated API documentation was simply wrong
for this function's parameters — noted here explicitly, and in
`IomadRestGateway.getCourseSettings()`'s doc comment, so it isn't
rediscovered by surprise later. `buildCourseIdsParams()` (which built the
now-proven-wrong `courrseids[N]` parameters) has been **removed** from
`netlify/functions/_lib/iomad/IomadRestClient.ts` — a comment is left at
its former location explaining why, rather than leaving a working-looking
function nobody should call.

**Real response — a bare array covering the FULL available
collection, not scoped to any request parameter (Jupiter Test Academy
example):**
```json
[
  {
    "id": 2,
    "courseid": 3,
    "licensed": false,
    "shared": 0,
    "validlength": 0,
    "warnexpire": 0,
    "warncompletion": 0,
    "notifyperiod": 0
  },
  {
    "id": 3,
    "courseid": 4,
    "licensed": false,
    "shared": 0,
    "validlength": 0,
    "warnexpire": 0,
    "warncompletion": 0,
    "notifyperiod": 0
  }
]
```
Note `id` (the settings row's own id) and `courseid` (the course it
describes) are confirmed as two different fields —
`normalizeCourseSettings()` deliberately reads `externalCourseId` from
`courseid`, not `id`.

**The real runtime contract, therefore:** call `get_course_info` with no
course-id parameters, receive the full available course-info collection,
and filter the normalized collection **locally** by the caller's
requested course IDs. `IomadRestGateway.getCourseSettings(courseIds)`
implements exactly this — fetches everything, filters with a `Set`
lookup, and never exposes a course the caller didn't ask about.

**Type correction: `licensed` is a JSON boolean on the wire, not
numeric.** The real response above shows `"licensed": false` — a genuine
JSON boolean, confirmed by live execution. `normalizeLicensedFlag()` uses
a boolean value directly; numeric `0`/`1` is still accepted defensively
for forward/backward compatibility, but boolean is the confirmed,
documented-correct type and is never required to be numeric.

**`shared` remains numeric**, confirmed unchanged by the same live
response (`"shared": 0`) — normalized as `shared !== 0`, exactly as
originally specified, with no invented semantics beyond that. A JSON
boolean for `shared` is rejected (`unknown_response_schema`), not
guessed.

**Normalized model** (`IomadCourseSettings`):
```ts
interface IomadCourseSettings {
  externalCourseId: string;
  licensed: boolean;   // JSON boolean on the wire; numeric 0/1 also accepted defensively
  shared: boolean;     // shared !== 0, only ever derived from a number
  validLengthDays: number;
  warnExpireDays: number;
  warnCompletionDays: number;
  notifyPeriodDays: number;
}
```
The returned array may be **shorter** than the requested `courseIds` list
if the full collection has no matching entry for a requested course —
callers match on `externalCourseId`, never by array position.

**Relationship to F3's pre-existing `getCourse()`:** both this
`getCourseSettings()` and the F3-era `getCourse()` call the same
wsfunction (`block_iomad_company_admin_get_course_info`), but with
different, incompatible assumptions — `getCourse()` guessed a singular
`courseid` parameter and an `{ id, fullname }`-style response (entirely
unverified, F3-era convention-based guess, now known to be wrong about
the parameter at least, since NO course-id parameter is accepted);
`getCourseSettings()` reflects the live-verified contract. Per this
phase's "do not redesign" scope, `getCourse()` is left untouched rather
than removed — flagged here and in both functions' doc comments as a
known discrepancy to reconcile or retire later.

### Gateway

`IomadGateway` (both `netlify/functions/_lib/iomad/IomadRestGateway.ts`
and the mirrored `src/integrations/iomad/IomadGateway.ts` contract) gains:
- `listCompanyCourses(companyId: string, shared = false): Promise<CompanyCourseAllocation[]>`
  — the existing F3 method name, reused and corrected to the live-verified
  request/response shape (its F3-era implementation sent a bare
  `companyid` param with no `shared` and expected a flat course list —
  both were unverified guesses, now replaced and confirmed).
- `getCourseSettings(courseIds: string[]): Promise<IomadCourseSettings[]>`
  — new. Empty input returns `[]` without a network call. Internally
  calls `get_course_info` with no parameters and filters the full result
  locally to `courseIds` — see the correction above.

Both are read-only; neither this task nor any code added by it makes an
Iomad write call.

### Live test tooling

`scripts/iomad-company-courses.ts` — server-only, manual-run CLI smoke
test. Not invoked by the application, CI, or any test.

```
npx tsx scripts/iomad-company-courses.ts 4
```
or, resolving via the F4-confirmed code lookup first:
```
npx tsx scripts/iomad-company-courses.ts MYGURU-JUPITER-TEST-001
```

Reads `IOMAD_BASE_URL`/`IOMAD_SERVICE_TOKEN`/`IOMAD_ALLOW_INSECURE_HTTP`
only via `createIomadGateway()` — never directly. Prints only:
`companyId`, `courseId`, `fullName`, `licensed`, `shared`,
`validLengthDays`, `warnExpireDays`, `warnCompletionDays`,
`notifyPeriodDays` — never the token, raw HTTP headers, the raw upstream
response, company address, or `custom1`/`custom2`/`custom3`. For a
zero-course company, prints `{ companyId, courses: [] }` and does not
call `getCourseSettings()`.

### Error handling

Both adapters are defensive, matching the rest of this file's posture:
zero-course companies (a valid success, confirmed live — see above), an
empty response, a `warnings` array alongside data, non-2xx HTTP (already
handled generically by `IomadRestClient.ts`, unchanged), a Moodle
exception payload (same, unchanged), a duplicate/unexpected company match
(throws), and a missing course settings entry for a requested course
(silently shorter result after local filtering, not an error) are all
covered by tests — see
`netlify/functions/_lib/iomad/__tests__/IomadResponseAdapters.test.ts`
and `IomadRestGateway.test.ts`.

### Persistence — explicitly deferred

**No migration, no new table, no new Supabase code was added for F5A.**
Whether F5B needs `course catalogue` tables, `iomad_course_mappings`, or
`organisation_course_allocations` is an open decision to make now that
the live-verified payload shape is known — not started in this pass.
Migration `0015` remains untouched and immutable.

### Admin UI — explicitly deferred

No new UI was added. F4D's existing Organisations page is unchanged. A
future F5B/F5C phase may add an "Admin → Organisations → Courses" view —
not part of F5A.

## F5B — Course persistence and organisation course mapping

**Persists F5A's already-live-verified data into Supabase.** Iomad
remains the LMS source of truth — this phase adds a read-through cache
of it, nothing more. No user sync, no enrolment, no licences workflows,
no SSO, no public course pages, no public course discovery, no Iomad
write, no admin UI beyond what tests needed (F5C later adds the read
visibility — see below).

**Migration `0016_course_persistence_and_organisation_allocations.sql` —
DEPLOYED to myguru-staging and immutable.** A post-deployment hotfix,
`0017_fix_course_sync_column_ambiguity.sql`, is also deployed — see "F5B
hotfix — migration 0017" below. Neither modifies 0001-0015.

### Domain rule

A `course` is global — it exists independently of which organisation(s)
currently have access to it. An `organisation_course_allocation` is
tenant-specific — the same Iomad course allocated to two organisations
produces ONE course row and TWO allocation rows. Losing access never
deletes the course or its `iomad_course_mapping`; only the allocation is
marked `stale`.

### Schema

```
courses
  id, name, status ('active'|'inactive'), created_at, updated_at

iomad_course_mappings
  id, course_id (unique FK → courses), iomad_course_id (unique, text),
  sync_status, last_synced_at, last_error_code, created_at, updated_at

organisation_course_allocations
  id, organisation_id (FK → organisations), course_id (FK → courses),
  licensed (boolean), shared (boolean),
  valid_length_days, warn_expire_days, warn_completion_days, notify_period_days,
  sync_status, last_synced_at, last_error_code, created_at, updated_at
  unique (organisation_id, course_id)
```

`iomad_course_id` is `text`, not `bigint`/`int` as originally suggested —
deliberately consistent with 0015's `iomad_company_id` (also `text`):
`CompanyCourseAllocation.externalCourseId`/`IomadCourseSettings.externalCourseId`
are already normalised to strings by the F5A response adapter before they
ever reach this schema.

`licensed`/`shared` in the platform schema are plain Postgres booleans
regardless of Iomad's own wire representation — the F5A adapter has
already normalised `licensed` (a genuine JSON boolean on the wire) and
`shared` (numeric, `!== 0`) before this table is ever written to; see the
F5A section above.

RLS enabled on all three tables, admin-read-only policies (`is_admin()`),
same posture as 0015 — no anon/authenticated write policy on any of them.
Admin browser reads (an "Admin → Organisations → Courses" view) are
explicitly deferred to a future F5C, not part of F5B.

### Atomic sync: `sync_iomad_company_course()`

One course, one organisation, per call — the same "one atomic RPC call
per entity, looped by the service" architecture 0015's
`sync_iomad_company()` already established, not a single giant
multi-course RPC. Each course's success/failure is independent.

```
sync_iomad_company_course(
  p_organisation_id, p_iomad_course_id, p_course_name,
  p_licensed, p_shared,
  p_valid_length_days, p_warn_expire_days, p_warn_completion_days, p_notify_period_days
)
```

1. Transaction-scoped advisory lock keyed on `iomad_course_id` —
   serializes concurrent calls for the same course (e.g. two
   organisations both allocating it for the first time at once).
2. Lock and look up the existing `iomad_course_mappings` row for this
   `iomad_course_id`.
3. Absent → create `courses` + `iomad_course_mappings` in this same
   transaction (`was_course_created = true`).
4. Present → update `courses.name` only if it actually changed
   (`course_name_changed`), mark the mapping synced either way.
5. Lock and look up the existing `organisation_course_allocations` row
   for `(p_organisation_id, course_id)`.
6. Absent → insert a new allocation with the given settings
   (`was_allocation_created = true`).
7. Present → update the settings snapshot only if any field actually
   differs (`allocation_settings_changed`), mark synced either way.
8. Returns course/mapping/allocation ids plus the four outcome flags —
   the TypeScript service derives created/updated/unchanged from them
   (`created` if either the course or the allocation was new; `updated`
   if the name or settings changed; `unchanged` otherwise).

`SECURITY INVOKER`, not `DEFINER` — identical justification to 0015's
`sync_iomad_company()`: the only intended caller is the service-role key,
which already bypasses RLS and has full access, so DEFINER would only add
unnecessary privilege-escalation surface, and INVOKER gives real defense
in depth if EXECUTE were ever mistakenly granted more broadly. Revoked
from `public`, granted only to `service_role`. No Iomad write occurs —
only `courses`/`iomad_course_mappings`/`organisation_course_allocations`
are touched.

### Stale marking: `mark_stale_organisation_course_allocations()`

`(p_organisation_id, p_seen_iomad_course_ids)` → marks every allocation
for that organisation whose course is NOT in the seen list as `stale`.
Never deletes the allocation, the course, or the mapping. Scoped strictly
to one organisation — never touches another organisation's allocation of
the same course.

### Gateway / service

Builds directly on F5A's live-verified gateway — does not duplicate its
transport. `IomadCompanyCourseSyncService.syncOrganisationCourses(organisationId, iomadCompanyId)`:

```
listCompanyCourses(iomadCompanyId)   (F5A, live-verified)
  → getCourseSettings(courseIds)     (F5A, live-verified — only if >0 courses)
  → repository.syncCourse() per course (atomic RPC)
  → repository.markMissingAsStale() once, at the end
  → CourseSyncResult { companyId, fetched, created, updated, unchanged, failed, stale, timestamp }
```

Only ever calls `listCompanyCourses()`/`getCourseSettings()` on
`IomadGateway` — never any Iomad write function (enforced by test).

**Zero-course case:** succeeds, no exception, no new course created, no
`getCourseSettings()` call made. Unlike F4's bulk company sync (which
skips stale-marking on an empty result because that call isn't scoped to
one company), a zero-course response for `listCompanyCourses(iomadCompanyId)`
IS a confirmed complete snapshot for that specific organisation — so
existing allocations ARE marked stale in this case.

**Missing settings for one allocated course:** handled safely with
defaults (`licensed: false, shared: false`, all day-counts `0`) — not a
failure. A course allocated but genuinely missing a settings entry is
still created/updated with those safe defaults, matching F5A's own
established "expected, not exceptional" posture for this case.

**One course failure:** caught, counted as `failed`, logged with only
`{ iomadCourseId, errorCode }` (never a raw message or course name), and
processing continues to the next course — a failed `syncCourse()` call
cannot leave a half-created course/mapping/allocation, because it's
atomic.

### Live test tooling

`scripts/iomad-sync-company-courses.ts` — server-only, manual-run CLI.
Not invoked by the application, CI, or any test. Requires the
organisation to already exist (`scripts/iomad-sync-company.ts <code>`,
F4C, must have been run first) — looks it up by Iomad company ID rather
than creating one.

```
npx tsx scripts/iomad-sync-company-courses.ts 4
```

Prints only `{ companyId, created, updated, unchanged, stale, timestamp }`
— never the token, the Supabase key, a raw Iomad response, or any course
field beyond counts. **Not run as part of this task** — see "Live test
checklist" below for the exact manual steps.

### Idempotency — proven by tests, not just asserted

`netlify/functions/_lib/courseSync/__tests__/IomadCompanyCourseSyncService.test.ts`
covers, using the real live-verified Jupiter Test Mathematics fixture
(Iomad company id 4, course id 4): first sync (created), second identical
sync (unchanged, same course/allocation, no duplicates), rename (updated,
same course UUID), settings change (updated, same allocation), removed
from company (stale, course/mapping remain), multi-tenant (one course,
two independent allocations across two organisations), zero-course
(success, stale-marking runs, no `getCourseSettings()` call), one-failure
isolation, and missing-settings-defaults.

### F5B review fixes (pre-deployment)

Applied before 0016 was deployed, folded directly into that migration
(safe to edit in place at that time — see `docs/CURRENT_STATE.md` for the
full record):
1. **Missing course settings never fabricate false/zero.** A course
   allocated but missing a `getCourseSettings()` entry is reported
   `failed` with the safe code `missing_course_settings`; `syncCourse()`
   is not called for it, so any previously-stored true/non-zero settings
   are never silently overwritten. Its id still goes into the
   stale-marking "seen" list, since it IS still allocated.
2. **Stale/failed → synced counts as `updated`, not `unchanged`.** A new
   `allocation_status_changed` return flag captures the allocation's
   previous `sync_status`; a transition back to `synced` is reported as a
   real change even when the settings values are byte-for-byte identical
   to what was already stored.
3. **Non-negative CHECK constraints** on all four day-count columns
   (`valid_length_days`, `warn_expire_days`, `warn_completion_days`,
   `notify_period_days`) — no upper bound invented.

## F5B hotfix — migration 0017 (column-ambiguity fix)

**Status: DEPLOYED to myguru-staging.** A live persistence test against
the deployed 0016 surfaced a genuine PostgreSQL runtime defect:

```
ERROR: 42702: column reference "course_id" is ambiguous
DETAIL: It could refer to either a PL/pgSQL variable or a table column.
```

**Root cause:** `sync_iomad_company_course()`'s `returns table (course_id
uuid, ...)` implicitly creates a PL/pgSQL variable named `course_id` —
this collided with the real `organisation_course_allocations.course_id`
column in the one query that referenced it without a table alias:
```sql
where organisation_id = p_organisation_id and course_id = v_course_id
```
Every other reference to `course_id` in the function was already
alias-qualified (`m.course_id`, `a.course_id`), which is exactly why only
this one query ever raised the error.

**Fix — `0017_fix_course_sync_column_ambiguity.sql`:** a forward-only
`CREATE OR REPLACE FUNCTION`. **0016 itself was not edited** — it remains
deployed and immutable, exactly as delivered. The allocation lookup and
its corresponding update now alias `organisation_course_allocations` as
`oca`, with every column explicitly qualified
(`oca.organisation_id`, `oca.course_id`, `oca.id`, `oca.licensed`, etc.).
The `courses`/`iomad_course_mappings` single-table updates are also
defensively aliased (`c`, `m`), even though neither was actually
ambiguous (no other column name in the function collides with a
`RETURNS TABLE` output).

**Preserved exactly, unchanged:** the 9-parameter input signature, the
10-column `RETURNS TABLE` output (including F5B's `allocation_status_changed`
fix), `SECURITY INVOKER`, the transaction-scoped advisory lock
(`pg_advisory_xact_lock`, keyed on `iomad_course_id`), the
`service_role`-only `EXECUTE` grant (revoked from `public`), idempotent
course/allocation reuse, stale→synced handling, and multi-tenant
behaviour. No Iomad write occurs — proven by 24 SQL regression tests
(`supabase/migrations/__tests__/fixCourseSyncColumnAmbiguity.test.ts`),
including a regex check that the bare, ambiguous `course_id =
v_course_id` form no longer appears anywhere in the function body.

## F5C — Admin organisation course visibility

**Read-only visibility only.** Extends F4D's existing
`/admin/organisations` page: selecting an organisation now also shows its
persisted course allocations (F5B). No new migration (0016/0017 already
provide everything needed), no Iomad call from the browser, no
create/edit/delete, no sync trigger from the UI, no public course pages.

### Data access

Follows the exact F4D pattern:
```
AdminOrganisationsPage
  → AdminOrganisationsService.listOrganisationCourses(organisationId)
  → OrganisationRepository.listOrganisationCourses(organisationId)   (interface)
  → SupabaseOrganisationRepository.listOrganisationCourses(organisationId)
  → authenticated Supabase browser client
  → RLS admin-read policies (0016: courses_admin_read,
    iomad_course_mappings_admin_read, organisation_course_allocations_admin_read)
```

The query joins `organisation_course_allocations` → `courses` →
`iomad_course_mappings` in a single minimal-fields Supabase `select`,
reading only what the UI displays — no address, no custom fields (F5B
never persisted any in the first place). A missing course or missing
Iomad mapping is handled defensively: never throws, falls back to a safe
placeholder (`'Unknown course'` / `null` → `—` in the UI).

### Fields displayed

Per course: name, Iomad Course ID (or `—`), Allocation Status, Licensed
(Yes/No), Shared (Yes/No), Valid Length ("Not configured" when `0`,
otherwise "`N` days"), Expiry/Completion Warning and Notify Period (all
"`N` days"). Allocation status labels: `synced` → "Synced", `stale` →
"Stale", `failed` → **"Sync issue"** — deliberately not "Failed", a
distinct label set from the organisation-level sync status shown
elsewhere on the same page (which keeps "Failed" for that context).

### Security

Route protection is inherited unchanged from the existing `/admin`
`RequireAdmin` + `AdminLayout` subtree — F5C adds no new auth logic.
Proven by test: the course list is never fetched before authorization
completes, and none of the three touched/new files
(`AdminOrganisationsPage.tsx`, `SupabaseOrganisationRepository.ts`,
`AdminOrganisationsService.ts`) reference any Iomad wsfunction, the Iomad
token, or the Iomad gateway.

### Live test checklist (document only — not run as part of F5C)

1. Sign in to `/admin` on myguru-staging as an admin user.
2. Navigate to Organisations, select **Jupiter Test Academy**.
3. Confirm the Overview section shows Iomad Company ID `4`, Sync Status
   "Synced" (unchanged from F4D).
4. Confirm the Courses section shows **Courses (1)** with **Jupiter Test
   Mathematics**: Iomad Course ID `4`, Allocation Status "Synced",
   Licensed "No", Shared "No", Valid Length "Not configured", Expiry/
   Completion Warning and Notify Period all "0 days".
5. Select a different organisation and confirm the course list changes
   (does not show Jupiter Test Mathematics for an unrelated organisation).

Do not consider this live-verified until these steps are actually run
against staging.

## Live test checklist (document only — not run in F3)

Exact steps for when the Iomad AWS environment is next started. Nothing
in F3 performs any of these — the environment is intentionally stopped,
and no live network call has been made. This is the checklist to work
through once it's back up, in order.

**Update:** step 3 below (call `get_companies`) has been completed for
the criteria-filtered-by-code case — see "Live-verified: get_companies by
code" above. Steps 4–5 for that specific call are done; steps 6–10, and
step 3 for the OTHER call shapes (`listCompanies()`'s no-criteria form,
`get_company_courses`, `get_course_info`), remain outstanding.

1. **Confirm the API/service user and token exist.** In the Iomad admin
   UI, under **Site administration → Server → Web services → Manage
   tokens**, confirm a token is issued for the intended service account
   and is scoped to the `iomadservice` external service. Do not paste the
   token value anywhere (chat, docs, commits).
2. **Confirm `iomadservice` access is authorised** for that token/user —
   check the external service's "Authorised users" list includes the
   account the token belongs to.
3. **Call `block_iomad_company_admin_get_companies`** with the real
   token, no parameters, against the real base URL. Record the raw HTTP
   status and response body shape (not the full body if it contains
   anything sensitive — the shape/field names are what matters).
4. **Record the real request parameter shape** — confirm whether
   `get_companies` accepts/requires any parameters (F3's implementation
   currently sends none).
5. **Record the real response shape** — is it a bare array or a
   `{ companies: [...] }` envelope? What are the actual field names for
   id/name/shortname? Compare against
   `IomadResponseAdapters.normalizeCompany()`'s assumptions
   (`id`, `name`, `shortname`) and update the adapter if they differ.
6. **Call `block_iomad_company_admin_get_company_courses`** with a real
   company ID. Confirm the parameter key is actually `companyid` (current
   assumption in `IomadRestGateway.ts` — marked UNVERIFIED) and record
   the response envelope/field names, comparing against
   `normalizeCourse()`'s assumptions (`id`, `fullname`, `shortname`).
7. **Call `block_iomad_company_admin_get_course_info`** with a real
   course ID. Confirm the parameter key is actually `courseid` (also
   UNVERIFIED) and record whether the response is a bare object, a
   one-element array, or a `{ courses: [...] }` envelope — compare
   against `normalizeSingleCourse()`'s three-shape handling.
8. **Verify no secret leaks** — check server logs from steps 3, 6, and 7
   contain only `{ wsfunction, code, httpStatus, correlationId }` (per
   `IomadErrors.logIomadCallFailure`), never the token or a raw response
   body.
9. **Normalize mappings** — once the real shapes are confirmed, update
   `IomadResponseAdapters.ts` (and the parameter keys in
   `IomadRestGateway.ts`) to match reality rather than the current
   convention-based assumptions. Add/adjust unit tests to cover the
   confirmed shape.
10. **Only then mark the integration `live-tested`** — flip "Tested" to
    "Yes" for the three F3 rows in the inventory matrix above, and update
    this document's status line accordingly. Do not mark it live-tested
    based on unit tests with mocked HTTP responses alone (those already
    pass today and are not evidence of a live call).
11. **F4B — confirm the fields company-suspension sync needs before
    enabling it:** company suspension/active state field name and
    semantics, company code/shortname field name, and deleted/inactive
    semantics (does a disabled company disappear from `get_companies`
    entirely, or gain a status flag?). Also confirm whether
    `get_companies`' scope is "all companies" or "companies visible to
    this token" — relevant once Corporate/franchise companies exist
    alongside MyGuru's own (see Open Questions below). Only once these are
    confirmed should `IomadCompanySyncService`
    (`netlify/functions/_lib/companySync/`) be extended to sync
    `organisations.status` from Iomad — it is NOT implemented in F4, and
    every F4-created organisation has `status: 'active'` unconditionally.

## Portal filtering design

One Iomad catalogue feeds multiple portals via a metadata/mapping layer,
not by duplicating courses. Conceptually:

```
Course (Iomad, cached via IomadCourseMapping)
  → CourseAudience: myguru | corporate | both
  → (optional) company restriction, via IomadCompanyMapping
```

A MyGuru catalogue query filters Iomad's course list down to
`CourseAudience` rows tagged `myguru` or `both`; a Corporate catalogue
query does the same for `corporate`/`both`, optionally further restricted
to the requesting company's assigned courses (already an Iomad-native
concept — "retrieve company courses" in the Courses table above). The
final storage mechanism for `CourseAudience` is not decided here — see
Open Questions — only the mapping-layer *approach* (not duplicating course
rows per portal) is recommended, consistent with
`docs/PHASE_E_SCHEMA_RLS.md` §H's existing "dedicated FK-based mapping
table" precedent for the same class of problem.

## Sync principles

These invariants apply to all future Iomad integration work (F3+):

1. Iomad is authoritative for LMS-company state.
2. Portal-specific business data stays outside Iomad.
3. No direct DB-to-DB integration — API only.
4. External IDs are persisted (Ground rule 2, `SYSTEM_OF_RECORD.md`).
5. Integration jobs are retryable — `integration_jobs` (`0010`) already
   has `attempt_count`, `next_attempt_at`, `status` for this.
6. Sync operations should be idempotent where possible — reflected per-row
   in the inventory matrix's Idempotency column above.
7. Portal availability should not depend on Iomad responding to every page
   request — reads go through a cache/local representation, not a live
   call per page view.
8. Read-through cache/synchronised local representation is preferred over
   calling Iomad synchronously on every read.
9. Failures must be observable — `integration_jobs.last_error` (sanitised,
   per its existing column comment: "no secrets, no full request/response
   bodies") already provides the column for this.
10. Future admin UI should show sync status / last sync / error state —
    `integration_jobs.status`/`last_attempt_at`/`last_error` already
    provide the data this future UI would read; no new columns needed for
    this specific requirement.

## First future proof-of-concept (documented, not implemented)

**POC 1 — Company sync.** Create/rename/disable a company in Iomad → run
sync → platform `Organisation` (via `IomadCompanyMapping`) reflects the
change. **The read/create/update half of this is now implemented in
F4** — see "Company sync foundation (F4)" below — but that implementation
syncs only `displayName`; it cannot yet reflect an Iomad-side *rename*'s
full fidelity or *disable* at all, both because the live response schema
(does the field exist? what's it called?) is unverified. The
`integration_jobs`-based scheduling/job-queue half (`sync_company`
operation type) is also not wired up — F4's sync runs synchronously
in-process, not as a queued job.

**POC 2 — Course catalogue filtering.** Iomad course → catalogue sync →
MyGuru sees only MyGuru-relevant courses. F3 provides
`listCompanyCourses()`/`getCourse()` against the confirmed
`get_company_courses`/`get_course_info` functions; there is still no
confirmed "list all courses, unscoped by company" function (see the
Courses inventory row above), and the `CourseAudience` mapping design and
`integration_jobs`'s `sync_courses` operation are not wired to anything
yet. Not started in F4 — still an F5+ candidate.

## Open questions

Classified `BLOCKING before F4`, `NON-BLOCKING for read-only F3`
(historical — F3 is now built) / `NON-BLOCKING for read-only work`, or
`NON-BLOCKING / can defer`. Only genuinely unresolved architecture
decisions are listed — items already settled in `docs/decisions.md`
(pricing, brand name, DBS policy) are not repeated.

1. ~~**Exact enabled Iomad web-service functions and their
   parameter/response shapes.**~~ — **Resolved for F3's scope.** Function
   *names* are confirmed for companies/company-courses/course-info (see
   "Confirmed discovery (F3)"). Their exact request-parameter keys and
   response envelopes are still `UNVERIFIED` (see "Read-only gateway
   contract" and the live-test checklist) — that residual verification is
   `NON-BLOCKING for read-only F3 code to exist` (it already does, built
   defensively) but `BLOCKING before marking the integration
   live-tested` and before any F4 work that depends on the *exact* shape
   (e.g. building UI on top of real field values).
2. **Final B2C Iomad company strategy** (carried from `docs/decisions.md`).
   — `NON-BLOCKING for read-only work`. F3 only lists/gets existing
   companies and courses, and reading them doesn't require this strategy
   to be settled. It becomes `BLOCKING before B2C provisioning` — i.e.
   before any work that actually creates or assigns a B2C parent/student
   into an Iomad company (F4+, `block_iomad_company_admin_create_companies`/
   `..._assign_users`, both confirmed available but out of F3 scope) —
   because `IomadCompanyMapping`'s cardinality for that case depends on
   it.
3. **Student LMS username/email identity strategy** (carried from
   `docs/decisions.md`). — `NON-BLOCKING for read-only work`, same
   reasoning. Becomes `BLOCKING before student provisioning` — i.e.
   before `create`/`assign` functions are actually called for students.
   Not blocking for the tutor half at any point (`create_teacher`
   already has a defined email source per `LmsService.ts`'s
   `CreateTeacherInput`).
4. **`Course` local-cache shape: full mirrored row vs. thin
   `IomadCourseMapping` wrapper around a live/cached Iomad response.** —
   `NON-BLOCKING / can defer`. Doesn't block the read-only gateway's
   interface shape (already built); affects only how a future caching/
   sync layer (F4+) is implemented.
5. **Course authoring ownership** — whether courses are ever
   created/updated *from* the platform (confirmed available via
   `block_iomad_company_admin_update_courses`, no separate create
   function confirmed), or always authored directly in Iomad and only
   ever read by the platform. — `NON-BLOCKING / can defer`. Read-only
   sync (POC 2) doesn't need it resolved.
6. ~~**Whether Iomad company departments and manager-assignment features
   are enabled/relevant for VedasGuru's usage.**~~ — **Partially
   resolved.** Departments and department-users functions are confirmed
   available (`get_departments`, `get_department_users`). Whether a
   dedicated department-*manager*-assignment function exists was not
   confirmed by this discovery pass — remains `NON-BLOCKING / can defer`
   until a franchise/department-manager workflow is actually designed.
7. **Company suspension mechanics** — confirmed as a business requirement
   (company suspension must sync outward and stop LMS operational access
   without removing public portal content — see `docs/CURRENT_STATE.md`),
   but the exact Iomad-side mechanism (a `suspended` field on
   `edit_companies`, a dedicated suspend function, or something else) was
   not confirmed by F3 discovery, and F4 does not implement suspension
   sync (see "Live schema gate (F4)" above). — `NON-BLOCKING for
   read-only work`; `BLOCKING before implementing suspension sync`
   (F5+).
8. **Whether `block_iomad_company_admin_get_companies` is scoped to "all
   companies the token's user can see" vs. genuinely all companies on the
   instance**, and whether that differs once Corporate/franchise
   companies exist alongside MyGuru's own. — `NON-BLOCKING for read-only
   F3`; worth confirming during the live-test checklist (step 3) since it
   affects whether `listCompanies()` needs a scoping parameter later.
9. ~~**How `organisations.type` (`unclassified` | `myguru_franchise` |
   `corporate` | `school_future` | `internal`) gets assigned
   correctly**~~ — **Resolved (F4 review fix).** Every organisation
   discovered through generic sync is created `type: 'unclassified'` —
   `sync_iomad_company()` (`supabase/migrations/0015`) never infers
   franchise/Corporate/school from company name, ID, or any other
   heuristic. This removes the earlier mislabelling risk entirely rather
   than deferring it. **Still open:** *how* a real classification later
   gets assigned to an `unclassified` organisation — some future explicit
   provisioning or admin workflow, not designed yet. —
   `NON-BLOCKING / can defer` until that workflow is designed; nothing in
   F4 depends on it, and no company is ever mislabelled in the meantime.
10. **Franchise/company-manager-created learners in Iomad** — confirmed
    as a business requirement (franchise/company managers may create
    their own learners directly in Iomad, not exclusively through the
    platform), with no platform-side implication for F4's read-only
    company sync, but a real one for any future `IomadUserMapping` sync:
    that sync cannot assume the platform is the sole origin of Iomad user
    records. — `NON-BLOCKING / can defer` until user sync is designed.
