# Phase E1–E2 — Supabase Schema + RLS Design

Design only. No Supabase project connected, no real credentials, no
application code wired to Supabase. Migrations live in `supabase/migrations/`,
seed data in `supabase/seed.sql`. All fields are sourced from the existing
Phase D domain models/services — nothing invented beyond what the product
already collects.

## A. Schema summary

| Table | Purpose |
|---|---|
| `education_levels` | Seeded reference data: KS1/KS2/KS3/GCSE/A-Level, kept independently selectable (frozen decision) |
| `subjects` | Subject catalogue, admin enable/disable + ordering |
| `tutor_applications` | Private application workflow (`draft→submitted→under_review→more_information_required→approved/rejected`) |
| `tutor_application_qualifications` | Self-reported qualification lines (one row per line from the wizard's textarea) |
| `tutor_application_subjects` / `tutor_application_levels` | Junction tables for the application's selected subjects/levels |
| `tutor_application_status_history` | Audit trail for approve/reject/request-info |
| `tutor_profiles` | Public-safe profile (`draft→approved→published/unpublished`), separate from applications |
| `tutor_profile_subjects` / `tutor_profile_levels` | Junction tables for the profile's public subjects/levels |
| `tutor_profile_status_history` | Publish/unpublish audit trail |
| `tutor_verifications` | Private verification state (`identity`/`qualification`/`dbs` × `not_started`/`pending`/`verified`/`expired`/`failed`) |
| `public_tutor_verification_badges` (view) | Public-safe derived badges — only `state='verified'` rows on `published` profiles |
| `parent_contacts` | Parent/guardian contact, found-or-created by email, no auth account |
| `students` | A parent's child(ren) — no email, DOB, school, or address column |
| `matching_requests` | Find My Tutor submissions |
| `matching_request_status_history` | Audit trail |
| `enquiries` | General + "Request this tutor" enquiries |
| `admin_profiles` | Links `auth.users.id` → admin status (populated in E3, not now) |
| `integration_jobs` | Future Iomad outbox — schema only, unused |

## B. Relationship summary

- `tutor_applications` 1—0..1 `tutor_profiles` (nullable FK, `ON DELETE SET NULL` — a profile's existence never depends on the application surviving; approval does **not** auto-create this row, per the frozen decision)
- `tutor_applications` 1—* `tutor_application_qualifications`, and *—* `subjects`/`education_levels` via junctions
- `tutor_profiles` *—* `subjects`/`education_levels` via junctions; 1—* `tutor_verifications`
- `parent_contacts` 1—* `students` 1—* `matching_requests`; `matching_requests` *—1 `subjects`
- `enquiries` *—0..1 `tutor_profiles` (nullable — general enquiries have no tutor)
- `admin_profiles` 1—1 `auth.users` (E3)
- `*_status_history` tables each *—1 their parent entity, and *—0..1 `auth.users` (`changed_by`)

## C. ERD

```mermaid
erDiagram
    EDUCATION_LEVELS ||--o{ TUTOR_PROFILE_LEVELS : ""
    EDUCATION_LEVELS ||--o{ TUTOR_APPLICATION_LEVELS : ""
    SUBJECTS ||--o{ TUTOR_PROFILE_SUBJECTS : ""
    SUBJECTS ||--o{ TUTOR_APPLICATION_SUBJECTS : ""
    SUBJECTS ||--o{ MATCHING_REQUESTS : ""

    TUTOR_APPLICATIONS ||--o| TUTOR_PROFILES : "produces (admin action, not automatic)"
    TUTOR_APPLICATIONS ||--o{ TUTOR_APPLICATION_QUALIFICATIONS : ""
    TUTOR_APPLICATIONS ||--o{ TUTOR_APPLICATION_SUBJECTS : ""
    TUTOR_APPLICATIONS ||--o{ TUTOR_APPLICATION_LEVELS : ""
    TUTOR_APPLICATIONS ||--o{ TUTOR_APPLICATION_STATUS_HISTORY : ""

    TUTOR_PROFILES ||--o{ TUTOR_PROFILE_SUBJECTS : ""
    TUTOR_PROFILES ||--o{ TUTOR_PROFILE_LEVELS : ""
    TUTOR_PROFILES ||--o{ TUTOR_PROFILE_STATUS_HISTORY : ""
    TUTOR_PROFILES ||--o{ TUTOR_VERIFICATIONS : ""
    TUTOR_PROFILES ||--o{ ENQUIRIES : "optional"

    PARENT_CONTACTS ||--o{ STUDENTS : ""
    PARENT_CONTACTS ||--o{ MATCHING_REQUESTS : ""
    STUDENTS ||--o{ MATCHING_REQUESTS : ""
    MATCHING_REQUESTS ||--o{ MATCHING_REQUEST_STATUS_HISTORY : ""

    ADMIN_PROFILES }o--|| AUTH_USERS : ""
```

## D. RLS matrix

`service_role` bypasses RLS entirely (a Supabase/Postgres platform
guarantee) — it is omitted below as "always full access" rather than
repeated per row.

| Table | Anonymous | Authenticated non-admin | Admin | Service/server |
|---|---|---|---|---|
| `education_levels` | SELECT (all rows) | SELECT (all rows) | ALL | ALL |
| `subjects` | SELECT (`enabled=true`) | SELECT (`enabled=true`) | ALL | ALL |
| `tutor_applications` | — | — | ALL | ALL |
| `tutor_application_qualifications` / `_subjects` / `_levels` / `_status_history` | — | — | ALL | ALL |
| `tutor_profiles` | SELECT (`status='published'`) | SELECT (`status='published'`) | ALL | ALL |
| `tutor_profile_subjects` / `_levels` | SELECT (parent published) | SELECT (parent published) | ALL | ALL |
| `tutor_profile_status_history` | — | — | ALL | ALL |
| `tutor_verifications` | — | — | ALL | ALL |
| `public_tutor_verification_badges` (view) | SELECT | SELECT | SELECT (+ base table ALL) | ALL |
| `parent_contacts` / `students` | — | — | ALL | ALL |
| `matching_requests` / `_status_history` | — | — | ALL | ALL |
| `enquiries` | — | — | ALL | ALL |
| `admin_profiles` | — | SELECT own row only | ALL (own row via same policy — no separate "view all admins" screen built yet) | ALL |
| `integration_jobs` | — | — | SELECT | ALL |

"—" means **zero** granted operations, including INSERT — public writes go
through the server endpoint (Option B, §F below), not a direct anonymous
table grant. `is_admin()` (defined in `0001_extensions_and_helpers.sql`) is
what every admin policy calls; it checks `admin_profiles` server-side, never
a client-supplied role claim (Phase E1 §17).

## E. Workflow model

```
Tutor application:  submitted → under_review → (more_information_required ⇄ under_review) → approved | rejected
                                                                        │
                                                          admin action (NOT automatic)
                                                                        ▼
Tutor profile:                                    draft → approved → published ⇄ unpublished
```

Matching request: `submitted → reviewing → matched → contacted → closed`
(any status may also move to `closed`).

## F. Public form write strategy — recommendation: **Option B (server endpoint)** for all three

| | Matching request | Tutor application | Contact enquiry |
|---|---|---|---|
| Recommendation | Server endpoint | Server endpoint | Server endpoint |

**Why, for all three, not a mix:** every one of these writes touches more
than one table atomically (`parent_contacts` find-or-create + `students`
insert + `matching_requests` insert; `tutor_applications` +
`tutor_application_qualifications` + two junction tables). A raw anonymous
multi-table INSERT under RLS can't guarantee that atomically or validate
server-side before it happens. A single server endpoint also gives one
place to add rate-limiting/spam checks later without touching RLS policies
at all. This is also *simpler* than Option A once you account for the
find-or-create-parent-by-email logic in §8 — that upsert doesn't have a
clean anonymous-RLS shape, but is trivial in a server function using the
service-role key.

This means, correctly reflected in the RLS matrix above: **anon has zero
INSERT grants anywhere.** Not implemented in this session (§18 explicitly
says design only).

## G. Server-layer recommendation: **Netlify Functions**

Reasoning: the project is already hosted on Netlify with `netlify.toml`
configured (`functions = "netlify/functions"`, from Phase D). Netlify
Functions are plain Node/TypeScript, so the existing layered architecture
(`React → service → repository interface`) extends naturally — a Netlify
Function becomes a thin delivery wrapper calling the same application
services, per `ARCHITECTURE.md`'s existing rule that framework-specific
code stays a thin boundary. Supabase Edge Functions (Deno-based) would
split business logic across two different runtimes/vendors for no current
benefit, and would need their own secret management separate from
Netlify's. Netlify Functions also map directly onto AWS Lambda later
(`ARCHITECTURE.md`'s existing AWS portability table), which Edge Functions
don't as cleanly. Revisit only if a specific Supabase Edge Function
capability becomes genuinely necessary (none identified).

## H. Iomad mapping recommendation: **dedicated FK-based tables, not generic**

Consistent with Phase C.5's Correction 2 (which leaned this way already):
`student_lms_identity`, `tutor_lms_identity` are justified once real LMS
onboarding begins — each gets a proper `references students(id)` /
`references tutor_profiles(id)` FK, real integrity, no `entity_type` string
to get wrong. **Not created in this migration set** — no LMS onboarding
exists yet, and creating them now would be exactly the "unnecessary tables
merely because they might someday be useful" Phase E1 §12 warns against.
`organisation_lms_mapping` and `subject_course_mapping` are B2B/future-scope
per Phase C.5 §11 and not created either. The one deliberate exception in
this migration set is `integration_jobs.entity_id`, which stays
polymorphic-by-convention (documented inline in `0010`) because a generic
job queue genuinely can't have a single-table FK by definition — that's a
structurally different problem from the identity-mapping tables above.

## I. AWS portability review

No design choice here creates migration difficulty:
- UUID PKs, plain relational tables, standard PostgreSQL — all portable to RDS/Aurora as-is.
- `is_admin()` is a plain SQL function reading a plain table; the *mechanism* that populates `admin_profiles` changes under Cognito (E3+), not this schema.
- RLS policies are PostgreSQL-native (not a Supabase-proprietary feature) — they migrate to RDS/Aurora unchanged; only the auth-identity source (`auth.uid()`) would need an equivalent under Cognito, which is an E3+ concern, not a schema one.
- `integration_jobs` was already designed in Phase C.5 to map directly onto EventBridge/SQS/Lambda later — unchanged here.
- The one Supabase-specific surface is `auth.users` itself (referenced by `admin_profiles.user_id`, `*_status_history.changed_by`, `tutor_verifications.verified_by`) — expected and appropriate to isolate, since identity provider migration is always going to touch *something*; every other table has zero Supabase-specific coupling.

## J. Open decisions requiring you

1. **Parent/student dedup heuristic** — confirmed recommendation in §8/migration `0006`: never auto-merge, always create a new `students` row per submission, only `parent_contacts` is found-or-created by email. Flag if you'd rather something more aggressive.
2. **Rate-limiting/spam approach** for the future server endpoints (§18) — not designed in this session; needs a decision (e.g. Netlify's own rate limiting vs. a custom check) before E3+ implementation.
3. **When to actually provision Supabase** — see below; nothing to decide about the schema itself, just timing.

---

## What I need from you before E3 can begin

Per Phase E1 §22 — I have not created or configured a real Supabase
project, and have not fabricated any credentials. To move into E3
(Auth + real repository wiring), you'll need to provide:

- A Supabase project (URL + anon key, and separately the service-role key)
- Confirmation of which environment these migrations should first run
  against (a fresh local/staging Supabase project is the safe default)

`.env.example` already has the correct placeholder shape from Phase D
(`SUPABASE_URL=`, `SUPABASE_ANON_KEY=`, `SUPABASE_SERVICE_ROLE_KEY=`) — no
changes needed there.

---

## Final Audit Addendum

### 1. RLS security audit — 2 issues found and fixed

**Issue A (real, fixed):** `enable row level security` was batched into
`0009` for tables actually created in `0002`–`0008`. If migrations are ever
applied one file at a time rather than as one atomic batch, those tables
would sit with default Postgres grants and no RLS for the gap between their
own migration and `0009` — a real exposure window, not theoretical. **Fix:**
`enable row level security` now happens in each table's own creation
migration, immediately after `create table`. `0009` is policies-only. A
table with RLS enabled and zero policies default-denies everything except
the owner — that's the safe state to sit in during any gap, and now every
table reaches it immediately.

**Issue B (cosmetic, fixed):** `is_admin()` was defined in `0001`, before
`admin_profiles` existed (created in `0008`). Postgres doesn't error on
this (SQL-function bodies aren't validated against object existence until
executed), so it wasn't a functional bug, but it's a bad read-order. **Fix:**
moved `is_admin()` into `0008`, right after `admin_profiles` is created.

**Confirmed clean (no changes needed):**
- Every table has RLS enabled; no anonymous INSERT/UPDATE/DELETE grant
  exists anywhere — public writes are 100% server-endpoint-only.
- Draft/approved/unpublished `tutor_profiles` are unreachable by anon —
  policy filters strictly on `status = 'published'`.
- `tutor_verifications` has no anon/authenticated policy at all (not even a
  restrictive one) — the only public path is the derived view, which
  selects only `(tutor_profile_id, verification_type)` for `state='verified'`
  rows on published profiles. No pending/failed/evidence/admin-notes column
  is reachable through it.
- The one `using (true)` in the whole policy set is `education_levels`
  SELECT — non-sensitive, static reference data, read-only. Not excessive.
- `is_admin()` is `SECURITY DEFINER` with `set search_path = public`
  (mitigates search-path hijacking) and `auth.uid()` is explicitly
  schema-qualified. It takes no parameters, so there's no injection surface
  via arguments, and it only ever returns a boolean — never table contents.
- Authenticated-non-admin cannot self-escalate: `admin_profiles` has no
  INSERT/UPDATE policy for anyone except the (RLS-bypassing) service role;
  the only grant is `SELECT` on your own row.

### 2. Parent/contact dedup — refined recommendation

The `unique index on lower(email)` (already in `0006`) is sufficient for
DB-level case-insensitive uniqueness and supports a safe
`INSERT ... ON CONFLICT (lower(email))` upsert — no schema change needed.
Two behavioural rules for the **future E3 server endpoint** (not
implemented yet, documented here so it's decided correctly when it is):

- **`ON CONFLICT (lower(email)) DO NOTHING`, not `DO UPDATE`.** If a
  submission's name/phone differs from an existing contact's (shared family
  email, typo, different parent), silently overwriting the existing values
  based on an unauthenticated submission is the wrong default. Reuse the
  existing `parent_contacts` row's `id`, ignore the new submission's
  name/phone. An admin can manually correct contact details later if
  needed.
- **Uniform response regardless of found-vs-created.** The endpoint must
  return the same success shape either way — never anything that lets a
  caller distinguish "this email already existed" from "this is new". This
  closes the email-enumeration side-channel your prompt flagged. This is an
  application-layer rule (the Netlify Function's response), not something
  RLS can enforce — noting it here so it's not lost before E3.
- `students` are never deduped/merged automatically, at all — confirmed
  unchanged from the original recommendation. A new `students` row is
  created for every submission; only `parent_contacts` is found-or-created.
  The race-condition concern (two concurrent submissions from a brand-new
  email both missing on SELECT) is exactly what `ON CONFLICT` avoids —
  there's no separate SELECT-then-INSERT step to race on.

### 3. Public form write model — confirmed, with a least-privilege refinement

Confirmed: **Browser → Netlify Function → server-side validation →
Supabase**, for all three write paths. Anonymous React clients never
receive a privileged credential.

On which credential: Supabase's role model is anon/authenticated/
service_role — there isn't a lightweight way to mint a fourth,
narrowly-scoped Postgres role without meaningful extra operational
complexity (custom role provisioning outside the standard Supabase CLI
flow), which would be over-engineering for MVP scope. **Recommendation:**
the Netlify Functions use the service-role key, but least-privilege is
enforced at the *application* layer instead of the database-role layer —
each function performs exactly one narrow, hard-coded INSERT operation
(never a generic query executor, never dynamic SQL, never SELECT/UPDATE/
DELETE), the key is never exposed to the client, and it's used nowhere
else in the codebase. This is the standard, expected Supabase pattern for
this kind of endpoint. Flagging the trade-off explicitly rather than
asserting it's equivalent to true DB-level least privilege — if this
project's risk profile changes later, a genuinely restricted custom role is
the harder-line option to revisit, not needed now.

### 4. Rate-limiting recommendation

**MVP (build in E3–E6, no third-party dependency):**
- A honeypot hidden form field (bots fill it in, humans never see it;
  reject silently if populated) — zero dependency, catches unsophisticated
  scripted abuse.
- A minimum-time-since-page-load check (reject submissions faster than a
  human could plausibly have filled the form).
- A simple per-IP-and-email submission counter (e.g. reject a 4th
  submission of the same form type within a short rolling window),
  implemented as a small check against existing tables (e.g. counting
  recent rows by email/IP) inside the Netlify Function before insert — no
  new infrastructure required.

**Later, only if real abuse is observed:** Cloudflare Turnstile or
equivalent CAPTCHA. Not added now — no evidence of abuse yet, and it's a
worse first-touch experience for genuine parents/tutors than the MVP
measures above.

### 5–8. Integrity / AWS portability / Iomad boundary / Oak

- **Integrity:** re-reviewed the full migration set against the checklist
  in your prompt — cascade/restrict choices are appropriate (`RESTRICT` on
  anything with audit/history value, e.g. deleting a `subject` or `student`
  that's referenced by a `matching_request`; `CASCADE` only on
  clearly-dependent child rows like junction/qualification/history tables);
  KS1/KS2 remain separate with no `primary`/`reception` anywhere;
  `tutor_applications`/`tutor_profiles` and parent/student separation both
  hold; every table with an `updated_at` column has the trigger, and
  history/junction tables correctly don't need one. No changes required.
- **AWS portability:** no new Supabase-specific coupling introduced by the
  audit fixes — `is_admin()`/`auth.uid()` remain the only Supabase-specific
  surface, as before.
- **Iomad boundary:** unchanged — `integration_jobs` remains schema-only
  and unreferenced by any code; nothing in this session touched it.
- **Oak curriculum:** confirmed the `subjects`/`education_levels` schema
  doesn't block a future external-curriculum mapping table (it would follow
  the same "dedicated FK-based mapping table" pattern already recommended
  for Iomad in §H) — no table added, none needed yet.
