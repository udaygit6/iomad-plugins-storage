# System of Record (F1)

Status: contract design. No migrations created by this document — see
"Shared domain / mapping design" below for why, and `TARGET_ARCHITECTURE.md`
for the system this table describes.

## Ground rules (apply to every row below)

1. **Email is never a cross-system identity key.** Two systems sharing the
   same email string does not make them the same identity. This is already
   the pattern in the current schema — `docs/PHASE_E_SCHEMA_RLS.md` §J
   confirms `parent_contacts` is found-or-created by email *within* the
   platform, but that is a single-system dedup heuristic, not a
   cross-system identity claim. It does not extend to matching a platform
   parent to an Iomad user, a WooCommerce customer, or a Zoho lead.
2. **External IDs are persisted, not re-derived.** Any time the platform
   creates or references a record in another system (an Iomad user ID, a
   WooCommerce order ID, a Zoho lead ID), that ID is stored on the
   platform side. Nothing re-guesses an external ID from name/email at
   read time.
3. **No uncontrolled bidirectional sync loops.** Every entity below has
   exactly one system of record. Replication is one-directional per field
   set (see the Direction column). Where a workflow looks bidirectional
   (e.g. an Iomad admin renames a company, and the platform should reflect
   it), that is *read-and-reconcile on a schedule/event*, not two systems
   independently writing the same field and expecting convergence.

## Entity ownership table

| Entity | System of record | Replicated to | Direction | Notes |
|---|---|---|---|---|
| Platform login identity | VedasGuru platform (Supabase Auth today; target central IdP, TBD) | Iomad (as a provisioned LMS user, once relevant) | Platform → Iomad | Not Iomad → platform. Iomad never originates a login identity. |
| Portal roles | VedasGuru platform | — | n/a | Portal-scoped (e.g. "MyGuru admin"), not an Iomad concept. |
| Parent profile | MyGuru/platform (`parent_contacts`, existing) | — | n/a | Unchanged by F0–F2. |
| Student profile | MyGuru/platform (`students`, existing) | Iomad (as an LMS user, once provisioned) | Platform → Iomad | Student LMS identity strategy remains an open decision (`docs/decisions.md`) — provisioning direction is fixed regardless of how that identity is derived. |
| Tutor application | MyGuru/platform (`tutor_applications`, existing) | — | n/a | Private; never synced anywhere (existing domain-model rule, unchanged). |
| Tutor public profile | MyGuru/platform (`tutor_profiles`, existing) | Iomad (as an LMS teacher user, once relevant) | Platform → Iomad | Public-safe fields only, mirroring the same private/public split `tutor_applications`/`tutor_profiles` already enforce internally. |
| Tutor matching request | MyGuru/platform (`matching_requests`, existing) | — | n/a | Not an Iomad or commerce concern. |
| Organisation | VedasGuru platform — **persisted as of F4** (`organisations` table, `supabase/migrations/0015`) | — | n/a | Business/customer organisation metadata (who a B2B customer or household *is* commercially) — a different entity from, and never merged with, the Iomad company it may be linked to. See `TARGET_ARCHITECTURE.md` §2 "Company ownership". |
| Iomad company | Iomad | Platform (`Organisation`/`IomadCompanyMapping` — **persisted as of F4**, `supabase/migrations/0015`) | Iomad → Platform (read-through) | Authoritative for LMS tenant/company state. Initial sync direction is outward from Iomad: a create/rename/disable in Iomad syncs to the platform, not the reverse. A future VedasGuru admin UI manages companies by invoking Iomad's own APIs (so the change still originates in Iomad and flows outward the same way), not by writing an independent platform-side company record. F4 implements only the read-only `Iomad → Organisation` half (`IomadCompanySyncService`, `netlify/functions/_lib/companySync/`) — company create/rename/disable calls into Iomad remain unimplemented, and organisation `status` (active/suspended/inactive) is NOT wired to any Iomad-side suspension signal yet (PENDING LIVE SCHEMA VERIFICATION — see `docs/IOMAD_INTEGRATION_CONTRACT.md`). |
| Portal membership | VedasGuru platform (proposed) | — | n/a | "Which portal(s) can this platform user access" — not an Iomad concept. |
| LMS user | Iomad | Platform (`IomadUserMapping`, proposed) | Iomad → Platform (read-through) | Platform-side profile (parent/student/tutor) remains the identity source of truth; Iomad's user record is the *learning*-account record, linked via the mapping, not merged into it. |
| Course | Iomad | Platform (`Course`/`IomadCourseMapping`, proposed, read-through cache) | Iomad → Platform | Course *content and existence* is Iomad's; course *audience/portal visibility* is platform-owned metadata layered on top (§ Portal Filtering Design). |
| LMS enrolment | Iomad | Platform (read-through, for display) | Iomad → Platform | Platform never enrols by writing directly to an Iomad table; only via the Iomad API, and only the result is cached back. |
| Course progress | Iomad | Platform (read-through, for display) | Iomad → Platform | Never platform-authoritative. |
| Grades | Iomad | Platform (read-through, for display) | Iomad → Platform | Never platform-authoritative. |
| Completion | Iomad | Platform (read-through, for display) | Iomad → Platform | Never platform-authoritative. |
| Certificate | Iomad | Platform (read-through, for display) | Iomad → Platform | Never platform-authoritative. |
| Course entitlement | VedasGuru platform (proposed `Entitlement`) | Iomad (as the trigger for an enrolment) | Platform → Iomad | Entitlement is "this person is allowed access to this course" — a platform/commerce decision. Enrolment is Iomad's execution of that decision. They are deliberately two different entities, not one. |
| WooCommerce order | WooCommerce | Platform (`Entitlement`, derived) | WooCommerce → Platform | Not implemented now. An order never writes to Iomad directly — it produces a platform entitlement, which then drives enrolment. |
| Oak source content | Oak | Platform staging area, then Iomad (once approved) | Oak → Platform → Iomad | Not implemented now. Oak is never read live by a portal. |
| CRM lead | Zoho | — (or platform read for display only, if ever needed) | Zoho → Platform (optional, read-only) | Not implemented now. Zoho is never a source of portal-business-profile truth. |
| Accounting record | Zoho | — | n/a | Not implemented now. Out of platform scope entirely. |

## Shared domain / mapping design (proposed — not yet persisted)

These are conceptual entities for the platform layer described in
`TARGET_ARCHITECTURE.md`. None of them exist as migrations yet, and this
document does not create any. This mirrors the same discipline already
applied to `integration_jobs` in `0010`: schema-only preparation is
justified when a real workflow needs it; speculative tables are not
created "because they might someday be useful"
(`docs/PHASE_E_SCHEMA_RLS.md` §H explicitly warns against this, and F1
inherits that discipline rather than relaxing it).

All fields below are `proposed — not yet persisted`.

### Organisation
**Persisted as of F4** — `organisations` table, `supabase/migrations/0015_organisation_iomad_company_sync.sql`. No longer `proposed`.

Business/customer organisation metadata — distinct from the Iomad company
it may link to via `IomadCompanyMapping`. See `TARGET_ARCHITECTURE.md` §2
"Company ownership" for the ownership split.
- `id` (uuid)
- `name` (text)
- `type` — actual values shipped in F4 (revised after review):
  `unclassified` | `myguru_franchise` | `corporate` | `school_future` |
  `internal` (refined from this document's earlier illustrative
  `b2c_household`/`b2b_company`/`school` examples to match the F4 brief's
  actual business categories). **Every organisation created by generic
  Iomad sync is `unclassified`** — F4 has no verified signal to
  distinguish a franchise company from Corporate/school/internal from
  Iomad company data alone, and deliberately never infers it from name,
  ID, or any other heuristic. `unclassified` is also the column default.
  Assigning a real classification is a deliberate later step (an
  explicit provisioning or admin workflow), not part of sync.
- `status` — `active` | `suspended` | `inactive`. **Not yet wired to
  Iomad company suspension** — see the Iomad company row above and
  `docs/IOMAD_INTEGRATION_CONTRACT.md`'s live schema gate. F4 always
  creates rows with `status: 'active'`.
- `source` — `iomad_sync` | `manual`. Every F4-created row is
  `iomad_sync`; `manual` is reserved for a future admin-created-
  organisation flow that does not exist yet.
- `created_at`, `updated_at`

### Portal
`proposed — not yet persisted`
- `id`
- `slug` (e.g. `myguru`, `corporate`, `school`)
- `name`

### PlatformUser
`proposed — not yet persisted`
- `id`
- `external_identity_id` (FK to `ExternalIdentity`, the IdP-facing record)
- `created_at`

### PortalMembership
`proposed — not yet persisted`
- `id`
- `platform_user_id`
- `portal_id`
- `role`

### ExternalIdentity
`proposed — not yet persisted`
- `id`
- `platform_user_id`
- `provider` (e.g. `supabase_auth`, later the target IdP)
- `provider_user_id`

### IomadCompanyMapping
**Persisted as of F4** — `iomad_company_mappings` table, `supabase/migrations/0015_organisation_iomad_company_sync.sql`. No longer `proposed`.

Links a platform `Organisation` to the Iomad company that is authoritative
for its LMS tenant state. Populated atomically, alongside its
`Organisation`, by the `sync_iomad_company()` Postgres function (revised
after F4 review to close an orphan-record risk — see
`docs/IOMAD_INTEGRATION_CONTRACT.md`'s "Transactional RPC design"), called
from the outward Iomad → platform sync (`IomadCompanySyncService`,
`netlify/functions/_lib/companySync/`) — not by an independent
platform-side company creation flow.
- `id` (uuid)
- `organisation_id` (uuid, unique — one mapping per organisation in F4)
- `iomad_company_id` (text, unique — external ID, persisted per Ground rule 2; never email/name)
- `sync_status` — `pending` | `synced` | `failed` | `stale`. `stale` means
  this company was absent from the most recent sync run — the row is
  never deleted on that basis alone (F4 §7; a company that later
  reappears in a sync is resynced normally). This tracks **this
  synchronisation's health**, not the Iomad company's own
  operational/suspended state.
- `last_synced_at`
- `last_error_code` — a safe code only (e.g. an `IomadErrorCode` value
  from `netlify/functions/_lib/iomad/IomadErrors.ts`), never a raw
  message or response body
- `created_at`, `updated_at`

### IomadUserMapping
`proposed — not yet persisted`
- `id`
- `platform_user_id` (or `student_id` / tutor profile id, per Phase E1 §H's
  "dedicated FK-based tables, not generic" recommendation — this table's
  final shape should follow that precedent once real LMS onboarding
  begins, not a generic `entity_type`/`entity_id` pair)
- `iomad_user_id` (external ID)
- `role` (`student` | `teacher`, matching `LmsUser.role` in
  `src/services/lms/LmsService.ts`)
- `last_synced_at`

### Course
`proposed — not yet persisted`
- `id`
- `iomad_course_id` (external ID)
- `name`
- `last_synced_at`

### CourseAudience
`proposed — not yet persisted`
- `id`
- `course_id`
- `portal_id` (or a `both`/all-portals convention — see Portal Filtering
  Design)

### IomadCourseMapping
`proposed — not yet persisted`
- `id`
- `course_id`
- `iomad_course_id` (external ID; may be redundant with `Course.iomad_course_id`
  depending on whether `Course` is a full local cache row or a thin
  wrapper — an open question, not resolved here, see Open Questions)

### Entitlement
`proposed — not yet persisted`
- `id`
- `platform_user_id` (or student/tutor id)
- `course_id`
- `source` (e.g. `woocommerce_order`, `manual_admin_grant`)
- `status` (e.g. `active`, `revoked`)
- `created_at`

### IntegrationJob
**Already implemented** — not proposed. `supabase/migrations/0010_integration_jobs.sql`
already defines this exact concept: an `external_system`/`operation_type`/
`entity_type`+`entity_id`/`idempotency_key`/`status`/`attempt_count`/
`last_error`/`external_id` outbox table, RLS-enabled, admin-readable,
unreferenced by any application code today. F1 recommends reusing this
table as-is for the platform-layer job queue described in
`TARGET_ARCHITECTURE.md` rather than designing a second one — its
`operation_type` check constraint already lists exactly the command set
(`create_student`, `create_teacher`, `enrol_student`, `assign_teacher`,
`create_link_company`, `sync_courses`, `sync_company`, `refresh_enrolment`,
`refresh_progress`, `refresh_completion`) that F2's inventory below maps
onto. No new migration is needed for this entity in F0–F2.

## Why no migrations are created in F0–F2 (and what changed in F4)

Per the brief and per this repository's own established discipline
(`docs/PHASE_E_SCHEMA_RLS.md` §H, §12): a table is created when a real
workflow needs it, not in anticipation of one. F0–F2 is contract design —
at that point none of `Organisation`, `PlatformUser`, `PortalMembership`,
`ExternalIdentity`, `IomadCompanyMapping`, `IomadUserMapping`, `Course`,
`CourseAudience`, `IomadCourseMapping`, or `Entitlement` had a consuming
workflow yet. `IntegrationJob` was the one exception, and already existed
(`0010`) — reused, not recreated.

**F4 changed this for exactly two of those entities.** `Organisation` and
`IomadCompanyMapping` now have a real, F3-transport-backed consuming
workflow (`IomadCompanySyncService`), so — following the same discipline,
not relaxing it — `supabase/migrations/0015_organisation_iomad_company_sync.sql`
persists exactly those two tables, minimally, and nothing else on this
list. `PlatformUser`, `PortalMembership`, `ExternalIdentity`, `Course`,
`CourseAudience`, `IomadCourseMapping`, and `Entitlement` remain
`proposed — not yet persisted` — none of them has a consuming workflow
yet either.
