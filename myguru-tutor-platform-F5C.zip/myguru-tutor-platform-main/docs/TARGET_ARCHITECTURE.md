# Target Architecture (F0)

Status: **target contract, not yet implemented**. Nothing in this document
changes current MyGuru behaviour. It exists so every later phase (F3+)
builds toward the same shape instead of re-deriving it piecemeal.

This supersedes nothing in `ARCHITECTURE.md` — that document remains the
accurate description of MyGuru's internal layering today. This document
describes the *system-level* shape MyGuru sits inside, going forward.

## 1. System overview

VedasGuru is the umbrella brand. It owns identity and shared platform
services over time. MyGuru is the first portal built on that platform —
today it *is* the whole product; going forward it becomes one portal among
several, all backed by the same shared services and the same Iomad LMS
engine.

The core principle carried from the brief:

> Iomad is the central **learning** engine, not the backend for every
> business workflow.

Portals never query Iomad's database directly. All integration is
API/service based, in one direction of dependency:

```
Portal (MyGuru / Corporate / future School)
  → application service (portal-owned business logic)
  → platform integration layer (shared, brand-agnostic)
  → Iomad API (HTTP, never DB)
```

This is a direct extension of the pattern already in this codebase —
`ARCHITECTURE.md`'s `LmsService` interface boundary is the seam this whole
document generalises. `MockLmsService` today occupies the position an
`IomadLmsAdapter` will occupy later, reached through a platform layer
rather than called by a portal service directly.

```mermaid
flowchart TB
  subgraph Portals["Portals (VedasGuru brand)"]
    MG["MyGuru<br/>parent/student/tutor"]
    CORP["Corporate (future)<br/>B2B employee learning"]
    SCH["School (future)<br/>openSIS-adjacent"]
  end

  subgraph Platform["Shared platform services (VedasGuru)"]
    ID["Identity / SSO (target)"]
    CAT["Catalogue & entitlements"]
    INT["Integration layer<br/>(IomadGateway, jobs, mappings)"]
  end

  LMS["Iomad<br/>central LMS engine"]
  OAK["Oak<br/>upstream curriculum source (future)"]

  subgraph Adjacent["Adjacent integrations, not masters of LMS state"]
    WOO["WooCommerce<br/>commerce (future)"]
    ZOHO["Zoho<br/>CRM/marketing/accounting (future)"]
    SIS["openSIS<br/>optional SIS (future)"]
  end

  MG --> Platform
  CORP --> Platform
  SCH --> Platform
  Platform --> INT
  INT --> LMS
  OAK -.import, staging, review.-> LMS

  WOO -.entitlement events.-> Platform
  ZOHO -.leads/CRM sync.-> Platform
  SIS -.future SIS data.-> SCH
```

Two adjacency notes the diagram encodes but is worth stating explicitly:

- WooCommerce and Zoho integrate *with the platform layer*, not with Iomad.
  Neither ever becomes a system of record for LMS state (see
  `SYSTEM_OF_RECORD.md`).
- openSIS is optional and School-scoped. It is not a dependency of MyGuru
  or Corporate, and nothing in F0–F2 assumes it exists.

## 2. VedasGuru responsibility

- Umbrella brand across all portals.
- Eventual central identity/SSO hub — a person authenticates once against
  VedasGuru identity and that session is recognised by whichever portal
  they're in.
- Shared business/platform layer: entitlements, catalogue composition,
  cross-portal integration orchestration (the "application service →
  platform integration layer" boxes above).
- Owns the platform-side conceptual entities in F1 (`Organisation`,
  `Portal`, `PlatformUser`, `PortalMembership`, `ExternalIdentity`,
  `Entitlement`, `IntegrationJob`, and the Iomad/course mapping tables).

VedasGuru does **not** own LMS state (Iomad does) or commerce/CRM state
(WooCommerce/Zoho do). It composes and orchestrates; it is not itself a
second source of truth for any of those.

### Company ownership (VedasGuru `Organisation` vs. Iomad `Company`)

These are two different entities with two different scopes, not two
copies of the same thing:

- A VedasGuru **`Organisation`** is business/customer organisation
  metadata — who a B2B customer or household *is* as a commercial/CRM
  concept (name, type, relationship to the platform). This is
  platform-owned and platform-authoritative.
- An **Iomad `Company`** is LMS tenant/company state — the object Iomad
  itself uses to scope users, courses, and enrolments. Iomad remains
  authoritative for this, exactly as stated in §5.

The two are linked, not merged: an `Organisation` may have a linked Iomad
company (via `IomadCompanyMapping`, see `SYSTEM_OF_RECORD.md`), but the
`Organisation` row itself never becomes a second source of truth for LMS
tenant state, and the Iomad company row never becomes a second source of
truth for business/CRM metadata.

**Sync direction, initially:** an Iomad company create/rename/disable is
the trigger; it syncs *outward* to the platform (Iomad → `Organisation`/
`IomadCompanyMapping`), not the reverse. A future VedasGuru admin UI for
managing companies is expected to work by **invoking Iomad's own APIs**
(create/rename/disable a company *in Iomad*, then let that same outward
sync reflect the result back to the platform) rather than by writing an
independent company record that Iomad has to reconcile against. This
keeps Iomad the single write-path for LMS company state even once a
platform-side management UI exists — the UI is a client of Iomad's API,
not a second author of company truth.

**Implementation status (F4):** the create/rename half of this sync is
now built — `IomadCompanySyncService`
(`netlify/functions/_lib/companySync/`), persisting to `organisations`/
`iomad_company_mappings` atomically via the `sync_iomad_company()`
Postgres function (`supabase/migrations/0015_organisation_iomad_company_sync.sql`;
find-or-create-or-rename + mark-synced all in one transaction, closing an
earlier orphan-record risk found in review). It syncs only `displayName`
(Iomad company name → `Organisation.name`); **disable/suspend is not
implemented** — see `docs/IOMAD_INTEGRATION_CONTRACT.md`'s "Live schema
gate (F4)" for why (the Iomad-side suspension field is unconfirmed). No
admin UI exists yet to invoke Iomad's own APIs — that remains entirely
future work.

## 3. MyGuru responsibility

Unchanged from today, restated as a portal responsibility rather than "the
whole product":

- Parent/student/tutor experience — discovery, matching, enquiries.
- Tutor applications, tutor profile publishing (E7, already implemented).
- School-age learning portal UX.
- Non-LMS business workflows that are portal-specific stay MyGuru/platform
  side — they do not migrate into Iomad just because Iomad exists.

Future (not started): consuming the shared catalogue for "My Courses",
enrolment status, progress, certificates, and SSO launch into Iomad course
content — all through the platform integration layer, never a direct
MyGuru→Iomad call.

**Franchise tutors (F4 business requirement):** paid/franchise MyGuru
tutors may map to their own Iomad company, distinct from a shared MyGuru
company — i.e. "MyGuru" is not necessarily a single Iomad tenant. F4's
company sync (`docs/IOMAD_INTEGRATION_CONTRACT.md`) syncs whatever
companies Iomad returns; it does not distinguish a franchise tutor's
company from any other, and every synced organisation is created
`type: 'unclassified'` (revised after F4 review — no longer guessed as
`myguru_franchise`; see that document's "Company sync foundation (F4)"
section and Open Questions).

## 4. Corporate responsibility

Future B2B professional portal. Company employees; company-specific
course/access UX (Java/Python/Cloud/AI/Agentic AI/etc. tracks). Consumes
the same shared platform services and the same Iomad engine as MyGuru,
filtered to a different course audience (see Portal Filtering Design,
§13). Not implemented in any phase through F4.

**Confirmed (F4):** Corporate customers are separate Iomad
companies/tenants from MyGuru's own, and largely manage their own
employees/training directly against their Iomad tenant rather than
through MyGuru-administered workflows. One Iomad instance serves MyGuru,
Corporate, and future portals — this is a single shared LMS engine with
multiple companies/tenants inside it, not one Iomad instance per portal.

## 5. Iomad responsibility

Central LMS engine shared by all portals. System of record for:

- LMS companies/tenants
- LMS users (once provisioned)
- courses
- course/company assignment
- enrolments
- progress, completion, grades, certificates
- Moodle/Iomad plugins and learning activities

Iomad is reached exclusively via its web-service API. No portal, and no
platform service, connects to Iomad's underlying RDS database. Iomad is
already hosted on AWS today — this is one part of the target architecture
that is already true in production infrastructure terms, independent of
where MyGuru itself is hosted.

**Company suspension (F4 business requirement, not yet implemented):**
Iomad company suspension is authoritative for LMS operational access. A
suspended company's public website/content may remain visible; only
LMS login/operations/access should later be blocked, and reactivation
should resume operations without rebuilding the tenant. F4's company sync
does not implement any part of this yet — see
`docs/IOMAD_INTEGRATION_CONTRACT.md`'s "Live schema gate (F4)" for why
(the Iomad-side suspension field/mechanism is unconfirmed) — every
`organisations.status` row F4 creates is `'active'` unconditionally.

**Franchise/company-manager-created learners (F4 business requirement):**
franchise/company managers may create their own learners directly in
Iomad, not exclusively through the platform. This has no implication for
F4 (read-only company sync only), but means a future `IomadUserMapping`
sync cannot assume the platform is the sole origin of Iomad user records.

## 6. Oak responsibility

Upstream school curriculum/content source. Not implemented now. Later,
Oak content is imported/staged/reviewed before any approved content
becomes available *through* Iomad — Oak is never queried directly by a
portal, and MyGuru never renders Oak content that hasn't passed through
that staging/approval step and landed in Iomad.

## 7. WooCommerce responsibility

Future commerce engine. Owns products/orders/payments. The future flow is
`order → entitlement → durable Iomad enrolment`, mediated by the platform
layer:

```
WooCommerce order paid
  → platform: order → entitlement mapping
  → platform: entitlement → Iomad enrolment (via IntegrationJob)
```

Not implemented now. WooCommerce never writes to Iomad directly, and Iomad
enrolment state is never treated as WooCommerce's responsibility to
reconcile.

## 8. Zoho responsibility

CRM/marketing/accounting/business automation. Domain-scoped: leads,
marketing sequences, accounting records. Not implemented now. Zoho is an
adjacent integration off the platform layer, never a source of LMS or
portal-business-profile truth.

## 9. Optional openSIS responsibility

Optional future SIS provider, scoped to a future School/Academy product:
admissions, attendance, scheduling, transcripts, and similar
school-administration concerns. Not part of current implementation. The
architecture leaves room for it (it would sit adjacent to the School
portal, integrating with the platform layer the same way WooCommerce/Zoho
do) without any current component depending on it existing.

## 10. Temporary Netlify/Supabase role

Netlify + Supabase are **temporary development/staging infrastructure**
for MyGuru today — this is already true of the current codebase (Netlify
Functions for public writes, Supabase for data + RLS + auth substrate) and
does not change in F0–F2. Nothing in this phase adds new Supabase schema
or new Netlify functions.

## 11. Future AWS target

The final application platform will migrate to AWS. This target
architecture is written to remain portable to that migration:

- Iomad is already on AWS.
- `docs/PHASE_E_SCHEMA_RLS.md` §I already documents that the existing
  Supabase schema (UUID PKs, plain relational tables, PostgreSQL-native
  RLS) is RDS/Aurora-portable as-is, and that `integration_jobs` was
  designed from the start to map onto EventBridge/SQS/Lambda later.
- The one Supabase-specific surface already identified is `auth.users`
  (and everything that references it) — identity/SSO migration is a
  known, isolated future concern, not a schema-wide one.
- Netlify Functions map directly onto AWS Lambda (already noted in
  `docs/PHASE_E_SCHEMA_RLS.md`'s Netlify-vs-Edge-Functions reasoning).

No new AWS-specific coupling is introduced by F0–F2. This section states
the target; it does not begin the migration.

## Central identity / SSO — target, not decided

One central VedasGuru identity/SSO hub is the **target end state**. The
final production identity provider is **not chosen yet** in this document
— it is explicitly out of scope to choose Cognito (or any other IdP) at
this phase. Supabase Auth may continue to serve MyGuru during staging in
the interim; that is not a conflict with the target, since
`docs/PHASE_E_SCHEMA_RLS.md` §I already isolates `auth.users` as the one
identity-provider-coupled surface that will need an equivalent later,
whatever that later provider turns out to be.

## What this document deliberately does not do

- Does not choose Cognito or any other IdP.
- Does not implement SSO.
- Does not implement Oak, WooCommerce, Zoho, or openSIS integration.
- Does not redesign MyGuru's internal layering (`ARCHITECTURE.md` stands).
- Does not create database migrations.
