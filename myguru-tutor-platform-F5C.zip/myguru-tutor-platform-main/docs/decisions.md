# Outstanding Decisions (Phase D deliberately does not resolve these)

Carried forward from Phase D §57 — the application is built to remain
flexible around each of these, not to force an answer:

- Final brand name and logo (currently "MyGuru", a working name)
- Pricing model — `TutorPricing` exists as an optional field so the UI can
  render pricing later without a redesign, but nothing displays a price now
- Tutor contractual/legal relationship (employee/contractor/other)
- Final DBS/vetting policy — the UI supports a `dbs_checked` public badge,
  but nothing claims this has happened
- Introductory-session policy, tutor-change/cancellation policy — no
  guarantee language appears anywhere in the current copy (reconfirmed
  after the D6→D7 correction round removed the last remaining trace of this
  on the homepage and in the application wizard)
- Final B2C Iomad company strategy (Phase C.5 §11, Correction 4 — recommended
  but unverified)
- Student LMS username/email identity strategy (Phase C.5 Correction 1 —
  explicitly NOT defaulted to the parent's email anywhere in this codebase)
- Generic vs. dedicated external-system mapping table design (Phase C.5
  Correction 2 — not yet relevant, since no persistence layer exists in
  Phase D)
- Early Years/Reception scope — explicitly excluded from the matching
  flow's year-group options (D6→D7 correction 2) pending an explicit
  decision to expand scope; not silently added

None of the above block Phase D's public-site/application work, per the
Phase D §33/dependency analysis carried from Phase C.5.

## Resolved during Phase D

- **KS1/KS2 taxonomy** — resolved during the D4–D6 correction round.
  `EducationLevelSlug` is `'ks1' | 'ks2' | 'ks3' | 'gcse' | 'a-level'`; KS1
  and KS2 are independently selectable/filterable, even though the
  customer-facing homepage/marketing copy may still describe both under a
  general "Primary" umbrella in prose.
