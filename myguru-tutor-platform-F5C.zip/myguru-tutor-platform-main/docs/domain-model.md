# Domain Model Summary

Full types: `src/domain/models/types.ts`. Highlights and the reasoning
behind a few deliberate shapes:

## `TutorProfile` (public contract) vs `TutorApplication` (private)

Two separate types, not one type with a `isPublic` flag. `TutorProfile` has
no field capable of leaking private information — there is no `documents`,
`adminNotes`, `email`, `phone`, or "pending/failed verification" state
anywhere in its shape, so a bug can't accidentally render something private
on a public page. `TutorApplication` holds all of that, and nothing reads
it on the public site.

## `PublicVerificationBadge`

A closed union of only the badges that are safe to show once genuinely
earned (`qualification_checked | identity_checked | dbs_checked`). There is
deliberately no "pending" or "failed" member — Phase D §15 requires those
states never render publicly, and removing them from the type (rather than
just remembering not to render them) makes that a compile-time guarantee,
not a discipline problem.

## `Parent` and `Student` as separate entities

Mirrors Phase C.5's dual-identity requirement: a parent may have several
children, each with independent tutors/subjects/requests. `Student` has no
`email` field — Phase C.5 Correction 1 explicitly rules out defaulting to
the parent's email as a student identifier, and the student's eventual LMS
identity strategy is still an open business decision (`docs/decisions.md`).

## Workflow status unions

`TutorApplicationStatus`, `TutorProfileStatus`, `MatchingRequestStatus`,
`EnquiryStatus` are all string literal unions, not boolean combinations.
This rules out impossible states like `approved: true, rejected: true` by
construction, per Phase D §25.

## `LmsService` types

Kept deliberately minimal and Iomad-agnostic in naming (`LmsUser`,
`LmsCourse`, `LmsEnrolment`, `LmsProgress`) — nothing here mentions Moodle
or Iomad specifically, because this is the contract, not the adapter.
`CreateStudentInput` has no default email source, matching Phase C.5
Correction 1.
