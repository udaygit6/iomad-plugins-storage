# Phase D Implementation Notes — D1–D3 Checkpoint

## What's built

**D1 — Foundation**
- Vite + React + TypeScript project, strict TypeScript, `oxlint` (the
  project's scaffolded linter) passing clean
- `react-router-dom` with every MVP route from Phase B/D §8 wired (real
  pages for `/` and 404, honest placeholders elsewhere — see `docs/routes.md`)
- Design tokens ported from the approved Phase C Revision 2 HTML prototype
  into CSS custom properties (`src/styles/tokens.css`)
- Global layout shell: skip link, sticky `Header` with responsive nav +
  accessible mobile drawer, `Footer` with no unconfirmed legal claims
- `siteConfig.ts` as the single source of brand/contact/legal information

**D2 — Design system / components**
- `Button` (primary/outline/text variants, loading state, polymorphic
  button-or-link)
- `Badge` — generic `Tag` + `VerificationBadge` (renders only genuinely
  earned public badges, see `docs/domain-model.md`)
- `Accordion` — proper `aria-expanded`/`aria-controls`, used for the FAQ
- `Drawer` — Escape-close, focus-on-open, used for mobile nav
- `TutorCard` + `TutorCardSkeleton` — illustrated placeholder photography
  (duotone silhouette, not a stock photo or a real person), derived
  availability label via `useAvailabilityLabel` rather than a hard-coded string

**D3 — Public homepage**
- Full React rebuild of the approved Phase C Revision 2 homepage: hero
  (illustrated video-call composition, dual-weight CTAs), trust strip,
  "How It Works" (step list + live product-preview mock card), subjects
  (featured tile + strip, data-driven from `subjectRepository`), education
  journey, featured tutors (data-driven from `tutorRepository`, loading
  skeletons while fetching), "why matching" + vetting panel, FAQ
  (`Accordion`), final CTA
- Reviews section intentionally **not** mounted — see `ReviewsSection.tsx`
  and Phase D §11

## Verification performed

- `npx tsc --noEmit` — clean
- `npm run build` — clean production build (317KB JS / 98KB gzipped, 24KB CSS)
- `npm run lint` (oxlint) — 0 warnings, 0 errors across 30 files
- `vite preview` smoke test — homepage (`/`) and a client-routed path
  (`/tutors`) both return `200` locally, confirming Vite's SPA fallback
  behaves as expected; `public/_redirects` added so the same fallback works
  on Netlify specifically (Vite's dev/preview SPA fallback doesn't
  automatically carry over to a static host without it)

## What I could not verify in this environment

This sandbox has no headless browser and no network access beyond package
registries, so I could not capture an actual rendered screenshot or run a
real browser's console/accessibility inspection. The build, type-check,
lint, and HTTP-level route checks above are what I could genuinely confirm;
they are not a substitute for opening it in a real browser. I'd recommend
either `npm run dev` locally, or running this project through Claude Code
(which has real browser tooling) for the visual sign-off Phase D §54 asks for.

## Meaningful differences vs. the Phase C Revision 2 HTML prototype

| Prototype | React implementation | Why |
|---|---|---|
| Hard-coded tutor cards | Fetched via `tutorRepository.list()`, with a real loading-skeleton state | Prototype had no data layer; this demonstrates the actual loading/empty/error architecture Phase D §45 requires |
| Hard-coded subject grid | Fetched via `subjectRepository.list()` | Same reasoning — subjects are reference data, not hard-coded markup (§26) |
| "Taking students" written directly in HTML | Derived from `tutor.acceptingStudents` via `useAvailabilityLabel` | Phase D §16 — never hard-code the label |
| One monolithic HTML file | Componentised (`Header`, `Footer`, `TutorCard`, `Accordion`, etc.) | Prototype was a single-file design reference; a real app needs reusable, independently testable pieces |
| No routing | Full client-side routing, 404 handling, SPA fallback for Netlify | The prototype was one static page; this is a real multi-route application |

No visual/content decision was changed from the approved prototype —
copy, section order, and the "MyGuru" brand/positioning line are identical.

## Recommendation before continuing to D4–D6

Please review this checkpoint (folder architecture, route map, and the
homepage implementation — ideally opened in a real browser via `npm run dev`)
before I continue. Nothing here should be taken as visually approved by me;
I've verified it compiles, builds, lints, and serves correctly, not that it
looks right on a screen.
