# Phase D Implementation Notes — D4–D6 Checkpoint

## Corrections applied before D4 (per your review of D1–D3)

1. **Unresolved business-policy claims removed.** The intro-session step no
   longer asserts a policy ("A first session together, before deciding
   whether to continue" instead of describing a guaranteed introductory
   session). "Arranged around your schedule" → "Delivered by video call".
   Qualification-check claims broadened to "Tutor applications are reviewed
   before a profile can be published" everywhere they appeared. Regression
   tests added in `HomePage.test.tsx` assert this copy doesn't reappear.
2. **Brand fully centralised.** No component contains a literal "MyGuru"
   string anymore; everything reads `siteConfig.brandName`. `index.html`'s
   static title/meta (which can't run React) is now injected from
   `siteConfig` at build time via a small Vite `transformIndexHtml` plugin.
3. **No hard-coded brand hex outside tokens.** Added `--color-white`,
   `--color-on-gold-text`, `--color-live-indicator` tokens; every SVG
   fill/stroke/stopColor and every CSS rule now references a `var(--color-*)`.
4. **Application-service boundary established.** `TutorDiscoveryService` and
   `SubjectService` sit between pages and repositories; `HomePage` was
   rewired to use them. D4–D6 build on this: `MatchingService`,
   `TutorApplicationService`, and `EnquiryService` all own their feature's
   validation and submission-mapping logic, not the page components.
5. **Testing foundation added.** Vitest + React Testing Library installed;
   57 tests across 11 files by the end of D4–D6 (see below).

## D4 — Discovery

- **`TutorsPage`** — URL-synced filters (`?subject=&level=&accepting=1`,
  mapped via `filtersFromSearchParams`/`searchParamsFromFilters` in
  `TutorDiscoveryService`), desktop sticky sidebar, mobile filter `Drawer`,
  removable active-filter chips, result count, and genuine loading
  (skeleton)/results/empty/error states via a new reusable
  `TutorResultsSection`.
- **`TutorProfilePage`** — loading skeleton, not-found state (unpublished or
  bad slug), full profile content (about, teaching approach, experience,
  qualifications, languages), all verification badges the tutor actually
  has, and a sticky mobile CTA that doesn't block content. CTA is "Request
  this tutor", never "Book now" (Phase D §18 — no payment/booking exists).
- **`SubjectsPage`** / **`SubjectDetailPage`** / **`LevelPage`** — subject
  hub grid, and two near-identical landing patterns (subject and education
  stage) that each resolve their slug, show a not-found state if it doesn't
  exist, and reuse `TutorResultsSection` with a fixed filter.
- **`RequestTutorDrawer`** — the actual "Request this tutor" flow: a small
  form (name/email/message), client validation, submission via
  `EnquiryService`, and a genuine confirmation state.

## D5 — Matching (`/find-a-tutor`)

Seven steps (student → subject → help needed → goals *(optional)* →
availability → contact → review), built on two new pieces of shared
infrastructure reused again in D6:

- **`useWizard`** — a generic, data-agnostic step-navigation hook (current
  step, progress %, back/next/goToStep, first/last flags). Deliberately
  holds no form data itself, so it doesn't couple the matching flow's data
  shape to the application flow's.
- **`WizardShell`** — the shared visual chrome (progress bar, step title,
  footer with back/continue-or-submit) plus a shared `.form-field` /
  `.option-card` / `.review-block` style vocabulary used by both wizards.

Validation and the mapping from form data → `MatchingRequest` live in
`MatchingService`, not in `MatchingWizard.tsx` — the component only
coordinates which step is showing and what the user typed.

Per Phase B/D: **no account is created during this flow** (matches the
approved "no mandatory parent account at MVP" decision), and no date of
birth/school field exists anywhere in the form.

## D6 — Tutor application (`/apply`, `/become-a-tutor`)

Nine steps (about you → experience → education → subjects → levels →
approach → availability → supporting info → review), same `useWizard`/
`WizardShell` infrastructure. `TutorApplicationService` owns validation and
submission — including splitting the qualifications textarea into a clean
array and keeping the submitted shape free of `status`/`adminNotes` (those
are admin-side concerns added later by `updateStatus`, never sent by the
applicant).

The confirmation screen explicitly states the profile is **not** published
automatically — matching the approved separation between "application
submitted" and "platform approval" (Phase D §21).

`BecomeATutorPage` is a short recruitment landing page explaining the
review step before linking to `/apply`.

## Testing (correction 5, ongoing)

57 tests across 11 files:

| Area | File | What's covered |
|---|---|---|
| Hook | `useAvailabilityLabel.test.ts` | Pure label derivation |
| Hook | `useWizard.test.ts` | Step navigation, bounds, progress % |
| Validation | `formValidation.test.ts` | `required`/`requiredArray`/`validEmail`/`runValidators` |
| Service | `TutorDiscoveryService.test.ts` | `listFeatured` limits, filter delegation, not-found handling |
| Service | `SubjectService.test.ts` | Featured/others split logic |
| Service | `urlFilterMapping.test.ts` | URL↔filter round-trip |
| Service | `MatchingService.test.ts` | Per-step validation, submit mapping/trimming, optional-field omission |
| Service | `TutorApplicationService.test.ts` | Per-step validation, qualification-splitting, private-field exclusion |
| Component | `Accordion.test.tsx` | a11y toggle behaviour |
| Component | `TutorCard.test.tsx` | Public-safe rendering, badge/availability derivation |
| Route smoke | `HomePage.test.tsx` | CTAs present, brand sourced from config, unresolved-policy copy regression |

Not yet covered (reasonable to defer to the D10 quality pass rather than
block D7–D8 on it): component-level tests for `MatchingWizard`/
`ApplicationWizard` themselves (the step components), `TutorsPage`'s filter
interaction, and `TutorProfilePage`'s not-found/loading states. The
*logic* those pages depend on (services, validation, wizard navigation) is
tested; the remaining gap is UI-interaction tests for the pages that wire
that logic together.

## Verification performed

- `npx tsc --noEmit` — clean
- `npm run lint` (oxlint) — 0 warnings/errors across 65 files
- `npx vitest run` — 57/57 passing across 11 files
- `npm run build` — clean (106KB gzipped JS, 6.8KB gzipped CSS)
- HTTP smoke test against the production build: `/`, `/tutors`,
  `/tutors/sarah-m-maths`, `/find-a-tutor`, `/subjects`, `/subjects/maths`,
  `/levels/gcse`, `/become-a-tutor`, `/apply`, and a deliberately-invalid
  tutor slug (`/tutors/does-not-exist`) — all return 200, confirming the
  SPA fallback and client-side not-found handling work correctly

## What I still could not verify in this environment

Same limitation as the D1–D3 checkpoint: no headless browser here, so I
cannot capture a real screenshot or exercise the wizards/drawers with an
actual mouse/keyboard the way a person would. Recommend `npm run dev`
locally, or continuing in Claude Code, for the visual/interaction sign-off.
