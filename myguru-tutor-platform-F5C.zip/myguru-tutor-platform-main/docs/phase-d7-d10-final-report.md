# Phase D Implementation Notes — D7–D10 (Final Phase D Report)

## Corrections applied before D7 (per your review of D4–D6)

1. **KS1/KS2 taxonomy split.** `EducationLevelSlug` changed from
   `'primary' | 'ks3' | 'gcse' | 'a-level'` to
   `'ks1' | 'ks2' | 'ks3' | 'gcse' | 'a-level'`. Fixture data, tutor
   profiles, and the education-journey homepage section all updated. A
   regression test (`SubjectService.test.ts`) asserts `ks1`/`ks2` remain
   distinct, independently-selectable entries and that `'primary'` no
   longer appears as a slug anywhere.
2. **Reception removed from matching year-group options.** `YEAR_GROUP_OPTIONS`
   now starts at "Year 1" — Early Years/Reception was never an approved
   part of scope. A regression test guards this in `matchingOptions.test.ts`.
3. **Two remaining unresolved-policy phrases removed:** the application
   wizard's qualification hint now reads "You may be asked to provide
   supporting evidence during the application review process" (was
   asserting an operational check); the homepage's step 3 changed from
   "Meet your tutor / A first session together..." to "Review your match /
   We'll help identify tutors whose subject and level experience fit what
   you're looking for."
4. **Internal navigation via `<Link>`.** The one remaining internal
   `<a href="/find-a-tutor">` (on `TutorsPage`) was replaced with a Router
   `Link`. I also caught and fixed the same pattern myself while building
   `SafeguardingPage` in D7, before it was flagged.

## D7 — Remaining public pages

`AboutPage`, `HowItWorksPage` (updated to reflect the "Review your match"
step wording), `FaqPage` (a longer, standalone question set beyond the
homepage's condensed version — includes pricing, ages/stages, verification,
and timeline questions, all answered with the same neutral, nothing-claimed
approach as the rest of the site), `ContactPage` (a genuine working form via
`EnquiryService`, not a static mailto), `SafeguardingPage` (explicit about
what's confirmed today vs. still being finalised — no invented DBS policy),
and `LegalDraftPage` (one shared component powering Privacy/Cookies/Terms,
each visibly labelled "Draft — requires legal review before production").

## D8 — Admin shell

Built to Phase D §23/§24's brief specifically: enough to validate workflow,
not an enterprise admin platform.

- **`AdminLayout`** — sub-nav across the four required areas, plus an
  explicit warning banner: *"This admin area has no real authentication or
  access control yet... Data here is in-memory only and resets on page
  reload."* This is Phase D §56 in practice — no fake security theatre.
- **`AdminApplicationsPage`** — list + click-through detail panel, with
  Approve / Reject / Request-more-info actions. The status-transition rules
  live in a new `AdminApplicationsService`, not the component (tested).
- **`AdminMatchingRequestsPage`** / **`AdminEnquiriesPage`** — list +
  status-update dropdowns, via `AdminWorkflowServices`.
- **`AdminSubjectsPage`** — list with an enable/disable toggle **explicitly
  labelled as a demo, not persisted** — `SubjectRepository` has no write
  capability in this phase, and I chose not to silently invent one just to
  make the screen feel more finished than the underlying data layer
  actually is.

## D9 — Architecture boundary audit

Before starting the quality pass, I re-audited the whole codebase against
the boundaries established across D1–D6, rather than assuming they'd held:

- **No component imports a `Mock*` repository directly** — only
  `src/repositories/index.ts` (the composition root) does.
- **Zero real Supabase/Iomad coupling** — every "supabase"/"iomad" hit in
  the codebase is a comment explaining the boundary, confirmed by grep.
- **Brand centralisation held** — `siteConfig` is referenced in 21 files;
  zero literal "MyGuru" strings remain in any component.
- **Zero remaining internal `<a href>`** navigation.
- **Design tokens re-swept** — a handful of raw `#fff` hex values had crept
  back into CSS written during D4–D8 (`TutorFilterControls.css`,
  `WizardShell.css`, `SubjectsPage.css`) plus one in `AdminLayout.css`.
  Fixed by adding `--color-white` (reused, already existed) and a new
  `--color-error-100` token, then sweeping all raw hex out again. This is
  now a standing discipline this project maintains, not a one-time fix.

## D10 — Quality pass

**Accessibility:**
- Every `<input>` is either explicitly `id`+`htmlFor`-associated or
  implicitly associated via a wrapping `<label>` (verified across the whole
  codebase, not spot-checked).
- **Found and fixed a genuine heading-hierarchy gap:** `/find-a-tutor` and
  `/apply` had no page-level `<h1>` — the wizard's visible step title is an
  `<h2>` by design (it changes per step), so the page itself was missing
  its one required `<h1>`. Fixed with a visually-hidden (`sr-only`) `<h1>`
  on each page, preserving the approved visual design exactly while fixing
  the semantic gap.
- `Accordion`/`Drawer` already covered by tests for `aria-expanded`/
  `aria-controls`/Escape-close from earlier phases.
- `prefers-reduced-motion` handling remains in place globally.

**Responsive:** no new breakpoints were needed — D4–D8 reused the same
responsive patterns (container, `.tutors-layout`, `.profile-hero`,
`.journey-row`, mobile `Drawer`) established and already verified in D1–D6.

**Performance:** production bundle is 380KB JS / 111KB gzipped, 37KB CSS /
7KB gzipped, for the entire application (every route, all in one bundle —
no route-level code-splitting was introduced, which is a reasonable choice
at this size; revisit only if bundle size becomes a genuine problem later).

**SEO:** every route-level page component calls `PageMeta` with a real
title/description (verified programmatically, not by inspection) — zero
pages are missing it.

**Security principles (§56):** re-confirmed — no service-role/Iomad
credentials anywhere in the codebase, `.env.example` has placeholders only,
the admin area's lack of real access control is stated plainly rather than
implied to be secure.

## Final verification (re-run after every correction round, not just once)

- `npx tsc -b --noEmit --force` — clean. **Note:** earlier in this project I
  had been running plain `npx tsc --noEmit`, which — because this project's
  root `tsconfig.json` is a solution-style file with `"files": []` and only
  project references — was silently checking nothing. I caught this myself
  during D7/D8 when `npm run build` failed on an import-path bug that
  `tsc --noEmit` had reported as clean. `tsc -b --noEmit` (build mode,
  follows references) is the command that actually matches what
  `npm run build` checks, and is what I've used for every verification
  since.
- `npm run lint` (oxlint) — 0 warnings/errors, 80 files
- `npx vitest run` — **63/63 passing**, 13 files
- `npm run build` — clean, 111KB gzipped JS
- HTTP smoke test against the production build — every route in the app
  (public, matching/application flows, and the full `/admin/*` tree)
  returns 200

## What I still could not verify in this environment

Unchanged from every earlier checkpoint: no headless browser, no real
mouse/keyboard interaction testing. Recommend `npm run dev` locally or
Claude Code for the visual/interaction sign-off before this goes further.

---

# Final Phase D Deliverables (per your original brief §58)

## Application
A working React/TypeScript application with every MVP route from Phase B/D
§8 fully built — no placeholders remain. Responsive homepage, full tutor
discovery (filters, profiles), the complete matching and tutor-application
wizards, all remaining public/legal pages, and a lightweight admin shell.

## Architecture
- Domain models: `src/domain/models/types.ts` (see `docs/domain-model.md`)
- Repository interfaces + mock implementations: `src/repositories/`
- Application/feature services: `src/services/{tutors,subjects,matching,
  applications,enquiries,admin}` — the boundary established after the
  D1–D3 corrections and consistently extended through D8
- `LmsService` interface + `MockLmsService`: `src/services/lms/` — no real
  Iomad call anywhere in this codebase
- `useWizard` + `WizardShell`: shared infrastructure for both multi-step
  flows

## Quality
- Accessibility: reviewed and one genuine gap (missing page-level `<h1>` on
  two routes) found and fixed, not just asserted
- Responsive: consistent with the patterns verified in D1–D6
- Test results: **63/63 passing**, 13 files
- Lint result: 0 warnings/errors (oxlint, 80 files)
- Type-check result: clean (`tsc -b --noEmit`, the command that actually
  matches the build)
- Build result: clean, 111KB gzipped JS
- Known issues: see below

## Documentation
- `README.md`, `ARCHITECTURE.md` — updated
- `docs/routes.md` — every route's status, now all ✅
- `docs/domain-model.md` — domain type rationale
- `docs/decisions.md` — outstanding decisions, KS1/KS2 resolution noted
- `docs/phase-d-implementation.md` (D1–D3), `docs/phase-d4-d6-implementation.md`
  (D4–D6), this file (D7–D10) — kept as separate dated records rather than
  overwritten, per your "don't overwrite previous phase documents" instruction

## Known issues / honest limitations
1. **No headless browser in this environment** — every visual claim in
   this report is inferred from passing builds/tests/HTTP checks, not an
   actual screenshot or interaction test. This has been true and stated at
   every checkpoint.
2. **`AdminSubjectsPage`'s enable/disable toggle is demo-only** — not
   persisted, by design, because `SubjectRepository` has no write
   capability yet. Flagged in the UI itself, not hidden.
3. **No `robots`/`noindex` handling on `/admin/*`** — a minor SEO-hygiene
   gap worth a small fix before any real deployment, not addressed in this
   phase since admin routes have no inbound links and Phase D's SEO
   requirement (§40) was scoped to public pages.
4. **Bundle is one JS/CSS chunk** — no route-level code-splitting. Fine at
   current size; worth revisiting if the app grows substantially.

## Recommendations for the Supabase schema/RLS phase (Phase E)
- The `SubjectRepository` interface will need write methods
  (enable/disable, ordering) to back `AdminSubjectsPage` for real —
  currently the interface is read-only by design (Phase D didn't require
  admin subject CRUD to be real yet).
- `ExternalSystemMapping` / `SubjectCourseMapping` schema decisions are
  still open per Phase C.5's addendum (Corrections 1 and 2) — genuinely
  unresolved, not an oversight.
- Every repository interface in `src/repositories/interfaces/index.ts` is
  the exact contract a `Supabase*Repository` implementation needs to
  satisfy — no interface changes should be needed to wire Supabase in,
  only new implementing classes swapped in at the composition root
  (`src/repositories/index.ts`).

---

**STOP — this is the end of Phase D. Awaiting your review before Phase E
(Persistence / Supabase / RLS / Auth Design & Implementation).**
