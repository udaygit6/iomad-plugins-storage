# Route Map

All MVP routes from Phase B/D §8 are wired in `src/app/router.tsx`. Status
as of the D1–D3 checkpoint:

| Route | Status | Built in |
|---|---|---|
| `/` | ✅ Fully built | D3 |
| `/tutors` | ✅ Fully built (filters, drawer, chips, loading/empty/error states) | D4 |
| `/tutors/:slug` | ✅ Fully built (loading/not-found states, sticky mobile CTA, request drawer) | D4 |
| `/find-a-tutor` | ✅ Fully built (7-step matching wizard) | D5 |
| `/subjects` | ✅ Fully built | D4 |
| `/subjects/:slug` | ✅ Fully built (filtered tutor list) | D4 |
| `/levels/:level` | ✅ Fully built (filtered tutor list; now `ks1`/`ks2`/`ks3`/`gcse`/`a-level`) | D4 |
| `/how-it-works` | ✅ Fully built | D7 |
| `/about` | ✅ Fully built | D7 |
| `/become-a-tutor` | ✅ Fully built | D6 |
| `/apply` | ✅ Fully built (9-step application wizard) | D6 |
| `/contact` | ✅ Fully built (validated enquiry form) | D7 |
| `/faq` | ✅ Fully built (expanded question set) | D7 |
| `/safeguarding` | ✅ Fully built | D7 |
| `/privacy` | ✅ Fully built (draft — requires legal review) | D7 |
| `/cookies` | ✅ Fully built (draft — requires legal review) | D7 |
| `/terms` | ✅ Fully built (draft — requires legal review) | D7 |
| `/admin` → `/admin/applications` | ✅ Fully built (index redirect) | D8 |
| `/admin/applications` | ✅ Fully built (list + review + approve/reject/request-info) | D8 |
| `/admin/matching-requests` | ✅ Fully built (list + status transitions) | D8 |
| `/admin/enquiries` | ✅ Fully built (list + status transitions) | D8 |
| `/admin/subjects` | ✅ Fully built (list + demo-only enable/disable) | D8 |
| `*` (404) | ✅ Built | D1 |

Every MVP route from Phase B/D §8 is now fully built. No placeholders remain.

Intentionally **not** routes, per Phase B/C.5/D decisions carried forward:
`/why-choose-us` (folded into Home/About), a standalone `/consultation` page
(merged into the Find My Tutor flow), and a published `/pricing` page
(pricing remains unresolved — see `docs/decisions.md`).

Placeholder pages render a real page (via `PlaceholderPage.tsx`) stating
which sub-phase builds them, rather than a blank/broken route — this lets
navigation, the header, and the 404 handling be reviewed end-to-end now.
