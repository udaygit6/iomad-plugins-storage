import { describe, it, expect, vi } from 'vitest';
import { isHoneypotTriggered, isSubmittedTooFast, hashIp, getClientIp, checkRateLimit } from '../antiAbuse.js';

describe('isHoneypotTriggered', () => {
  it('is false when the honeypot field is empty', () => {
    expect(isHoneypotTriggered({ website: '' })).toBe(false);
  });
  it('is false when the honeypot field is absent', () => {
    expect(isHoneypotTriggered({})).toBe(false);
  });
  it('is true when a bot fills the honeypot field in', () => {
    expect(isHoneypotTriggered({ website: 'http://spam.example' })).toBe(true);
  });
});

describe('isSubmittedTooFast', () => {
  it('is false for a submission after a plausible delay', () => {
    expect(isSubmittedTooFast({ formLoadedAt: Date.now() - 10_000 })).toBe(false);
  });
  it('is true for a submission implausibly soon after load', () => {
    expect(isSubmittedTooFast({ formLoadedAt: Date.now() - 100 })).toBe(true);
  });
  it('is true when the timing signal is missing (itself suspicious)', () => {
    expect(isSubmittedTooFast({})).toBe(true);
  });
  it('is true when the timing signal is not a valid number', () => {
    expect(isSubmittedTooFast({ formLoadedAt: 'not-a-number' })).toBe(true);
  });
});

describe('hashIp', () => {
  it('produces a deterministic, non-reversible-looking hash', () => {
    const hash1 = hashIp('203.0.113.5');
    const hash2 = hashIp('203.0.113.5');
    expect(hash1).toBe(hash2);
    expect(hash1).not.toContain('203.0.113.5');
    expect(hash1).toHaveLength(64); // sha256 hex digest length
  });
  it('produces different hashes for different IPs', () => {
    expect(hashIp('1.1.1.1')).not.toBe(hashIp('2.2.2.2'));
  });
});

describe('getClientIp', () => {
  it('prefers the Netlify-specific header when present', () => {
    expect(getClientIp({ 'x-nf-client-connection-ip': '203.0.113.5' })).toBe('203.0.113.5');
  });
  it('falls back to x-forwarded-for, taking the first entry', () => {
    expect(getClientIp({ 'x-forwarded-for': '203.0.113.5, 70.41.3.18' })).toBe('203.0.113.5');
  });
  it('falls back to a fixed bucket when no IP header is present', () => {
    expect(getClientIp({})).toBe('unknown');
  });
});

function makeSupabaseMock(count: number, insertError: unknown = null) {
  const insert = vi.fn().mockResolvedValue({ error: insertError });
  const from = vi.fn().mockReturnValue({
    select: vi.fn().mockReturnValue({
      eq: vi.fn().mockReturnValue({
        gte: vi.fn().mockResolvedValue({ count, error: null }),
      }),
    }),
    insert,
  });
  return { from } as never;
}

describe('checkRateLimit', () => {
  it('allows the request and records it when under the limit', async () => {
    const supabase = makeSupabaseMock(2);
    const allowed = await checkRateLimit(supabase, 'submit-enquiry', '203.0.113.5');
    expect(allowed).toBe(true);
  });

  it('rejects the request once the limit is reached', async () => {
    const supabase = makeSupabaseMock(5);
    const allowed = await checkRateLimit(supabase, 'submit-enquiry', '203.0.113.5');
    expect(allowed).toBe(false);
  });

  it('fails open (allows) on a rate-limit read error, rather than blocking legitimate users on an infra fault', async () => {
    const from = vi.fn().mockReturnValue({
      select: vi.fn().mockReturnValue({
        eq: vi.fn().mockReturnValue({
          gte: vi.fn().mockResolvedValue({ count: null, error: { message: 'db unavailable' } }),
        }),
      }),
    });
    const allowed = await checkRateLimit({ from } as never, 'submit-enquiry', '203.0.113.5');
    expect(allowed).toBe(true);
  });
});
