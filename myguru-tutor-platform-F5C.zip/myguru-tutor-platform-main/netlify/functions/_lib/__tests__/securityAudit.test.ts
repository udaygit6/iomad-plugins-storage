import { describe, it, expect } from 'vitest';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join, sep } from 'node:path';

const FUNCTIONS_ROOT = join(__dirname, '..', '..'); // resolves to netlify/functions/

function walk(dir: string): string[] {
  const entries = readdirSync(dir);
  let files: string[] = [];
  for (const entry of entries) {
    const fullPath = join(dir, entry);
    const stat = statSync(fullPath);
    if (stat.isDirectory()) {
      files = files.concat(walk(fullPath));
    } else if (entry.endsWith('.ts') && !entry.endsWith('.test.ts')) {
      files.push(fullPath);
    }
  }
  return files;
}

const functionFiles = walk(FUNCTIONS_ROOT);

describe('Security audit — server function layer (netlify/functions/)', () => {
  it('the privileged key is read only via SUPABASE_SECRET_KEY, never a VITE_-prefixed variable', () => {
    const offenders = functionFiles.filter((f) => /VITE_SUPABASE_(SECRET|SERVICE)/.test(readFileSync(f, 'utf-8')));
    expect(offenders).toEqual([]);
  });

  it('SUPABASE_SECRET_KEY is referenced only inside the isolated server client module', () => {
    const referencingFiles = functionFiles.filter((f) => readFileSync(f, 'utf-8').includes('SUPABASE_SECRET_KEY'));
    expect(referencingFiles).toEqual([join(FUNCTIONS_ROOT, '_lib', 'supabaseServerClient.ts')]);
  });

  it('no function logs a full request body (personal data — matching requests/applications/enquiries contain names, emails, messages)', () => {
    const offenders = functionFiles.filter((f) => {
      const content = readFileSync(f, 'utf-8');
      return /console\.(log|error|warn)\([^)]*\bbody\b[^)]*\)/.test(content) && !content.includes('body.length');
    });
    expect(offenders).toEqual([]);
  });

  it('process.env.IOMAD_SERVICE_TOKEN is read only inside the isolated iomad config module', () => {
    const referencingFiles = functionFiles.filter((f) =>
      readFileSync(f, 'utf-8').includes('process.env.IOMAD_SERVICE_TOKEN'),
    );
    expect(referencingFiles).toEqual([join(FUNCTIONS_ROOT, '_lib', 'iomad', 'iomadConfig.ts')]);
  });

  it('no iomad module logs the token value (only wsfunction/httpStatus/code/correlationId)', () => {
    const iomadFiles = functionFiles.filter((f) => f.includes(`${join('_lib', 'iomad')}${sep}`));
    const offenders = iomadFiles.filter((f) => {
      const content = readFileSync(f, 'utf-8');
      return /console\.(log|error|warn)\([^)]*\btoken\b[^)]*\)/i.test(content);
    });
    expect(offenders).toEqual([]);
  });

  it('no companySync module logs the token value', () => {
    const companySyncFiles = functionFiles.filter((f) => f.includes(`${join('_lib', 'companySync')}${sep}`));
    expect(companySyncFiles.length).toBeGreaterThan(0);
    const offenders = companySyncFiles.filter((f) => {
      const content = readFileSync(f, 'utf-8');
      return /console\.(log|error|warn)\([^)]*\btoken\b[^)]*\)/i.test(content);
    });
    expect(offenders).toEqual([]);
  });

  it('the companySync sync service never calls anything on IomadGateway other than listCompanies/getCompanyByCode (read-only, no writes back to Iomad)', () => {
    const serviceFile = join(FUNCTIONS_ROOT, '_lib', 'companySync', 'IomadCompanySyncService.ts');
    const content = readFileSync(serviceFile, 'utf-8');
    const gatewayCalls = [...content.matchAll(/this\.gateway\.(\w+)\(/g)].map((m) => m[1]);
    expect(gatewayCalls.length).toBeGreaterThan(0);
    expect(new Set(gatewayCalls)).toEqual(new Set(['listCompanies', 'getCompanyByCode']));
  });

  it('no companySync file references an Iomad company create/edit/suspend/assign write function', () => {
    const companySyncFiles = functionFiles.filter((f) => f.includes(`${join('_lib', 'companySync')}${sep}`));
    const writeFunctionPattern =
      /block_iomad_company_admin_(create_companies|edit_companies|assign_users|unassign_users|assign_courses|unassign_courses|enrol_users|allocate_licenses|move_users|update_courses)/;
    const offenders = companySyncFiles.filter((f) => writeFunctionPattern.test(readFileSync(f, 'utf-8')));
    expect(offenders).toEqual([]);
  });

  it('syncByCompanyCode() (F4C single-company sync) never calls markMissingAsStale — that stays exclusive to the bulk sync() method', () => {
    const serviceFile = join(FUNCTIONS_ROOT, '_lib', 'companySync', 'IomadCompanySyncService.ts');
    const content = readFileSync(serviceFile, 'utf-8');
    const methodStart = content.indexOf('async syncByCompanyCode(');
    expect(methodStart).toBeGreaterThan(-1);
    // Isolate the method body: from its start to the next `private async` /
    // end-of-class boundary, so this check can't accidentally pass by
    // matching markMissingAsStale usage elsewhere in the file (e.g. in
    // sync()).
    const nextMethodStart = content.indexOf('private async syncOne(', methodStart);
    expect(nextMethodStart).toBeGreaterThan(methodStart);
    const methodBody = content.slice(methodStart, nextMethodStart);
    expect(methodBody).not.toContain('markMissingAsStale');
  });

  it('no courseSync module logs the token value', () => {
    const courseSyncFiles = functionFiles.filter((f) => f.includes(`${join('_lib', 'courseSync')}${sep}`));
    expect(courseSyncFiles.length).toBeGreaterThan(0);
    const offenders = courseSyncFiles.filter((f) => {
      const content = readFileSync(f, 'utf-8');
      return /console\.(log|error|warn)\([^)]*\btoken\b[^)]*\)/i.test(content);
    });
    expect(offenders).toEqual([]);
  });

  it('the courseSync sync service never calls anything on IomadGateway other than listCompanyCourses/getCourseSettings (read-only, no writes back to Iomad)', () => {
    const serviceFile = join(FUNCTIONS_ROOT, '_lib', 'courseSync', 'IomadCompanyCourseSyncService.ts');
    const content = readFileSync(serviceFile, 'utf-8');
    const gatewayCalls = [...content.matchAll(/this\.gateway\.(\w+)\(/g)].map((m) => m[1]);
    expect(gatewayCalls.length).toBeGreaterThan(0);
    expect(new Set(gatewayCalls)).toEqual(new Set(['listCompanyCourses', 'getCourseSettings']));
  });

  it('no courseSync file references an Iomad write function of any kind', () => {
    const courseSyncFiles = functionFiles.filter((f) => f.includes(`${join('_lib', 'courseSync')}${sep}`));
    const writeFunctionPattern =
      /block_iomad_company_admin_(create_companies|edit_companies|assign_users|unassign_users|assign_courses|unassign_courses|enrol_users|allocate_licenses|move_users|update_courses)/;
    const offenders = courseSyncFiles.filter((f) => writeFunctionPattern.test(readFileSync(f, 'utf-8')));
    expect(offenders).toEqual([]);
  });

  it('courseSync never references a raw Moodle/Iomad wsfunction string at all — it only ever calls the gateway methods, never a wsfunction directly', () => {
    const courseSyncFiles = functionFiles.filter((f) => f.includes(`${join('_lib', 'courseSync')}${sep}`));
    const offenders = courseSyncFiles.filter((f) => /block_iomad_company_admin_/.test(readFileSync(f, 'utf-8')));
    expect(offenders).toEqual([]);
  });
});
