import { describe, it, expect, vi, beforeEach } from 'vitest';

// Mock the server Supabase client module before importing the handler, so
// no real network/config is required to exercise the function's request
// handling logic.
vi.mock('../supabaseServerClient.js', () => ({
  getServerSupabaseClient: vi.fn(),
}));

import { getServerSupabaseClient } from '../supabaseServerClient.js';

function makeEvent(overrides: Partial<{ httpMethod: string; body: string | null; headers: Record<string, string> }> = {}) {
  return {
    httpMethod: 'POST',
    body: JSON.stringify({ name: 'Sarah', email: 'sarah@example.com', message: 'Hello' }),
    headers: {},
    ...overrides,
  } as never;
}

describe('submit-enquiry handler — request handling (no real Supabase call)', () => {
  beforeEach(() => {
    vi.resetModules();
    vi.mocked(getServerSupabaseClient).mockReset();
  });

  it('rejects non-POST methods with 405', async () => {
    const { handler } = await import('../../submit-enquiry.js');
    const result = (await handler(makeEvent({ httpMethod: 'GET' }), {} as never, {} as never)) as { statusCode: number };
    expect(result.statusCode).toBe(405);
  });

  it('returns a safe 503 when server Supabase config is missing, without leaking the config error', async () => {
    vi.mocked(getServerSupabaseClient).mockImplementation(() => {
      throw new Error('SUPABASE_URL / SUPABASE_SECRET_KEY missing');
    });
    const { handler } = await import('../../submit-enquiry.js');
    const result = (await handler(makeEvent(), {} as never, {} as never)) as { statusCode: number; body: string };
    expect(result.statusCode).toBe(503);
    expect(result.body).not.toContain('SUPABASE_SECRET_KEY');
  });

  it('rejects malformed JSON with a validation error, not a raw parse exception', async () => {
    vi.mocked(getServerSupabaseClient).mockReturnValue({} as never);
    const { handler } = await import('../../submit-enquiry.js');
    const result = (await handler(makeEvent({ body: '{not valid json' }), {} as never, {} as never)) as {
      statusCode: number;
      body: string;
    };
    expect(result.statusCode).toBe(400);
    expect(JSON.parse(result.body).error).toBe('invalid_request');
  });

  it('rejects a body containing an unexpected field (e.g. a caller trying to inject status)', async () => {
    vi.mocked(getServerSupabaseClient).mockReturnValue({} as never);
    const { handler } = await import('../../submit-enquiry.js');
    const event = makeEvent({
      body: JSON.stringify({ name: 'Sarah', email: 'sarah@example.com', message: 'Hi', status: 'resolved' }),
    });
    const result = (await handler(event, {} as never, {} as never)) as { statusCode: number };
    expect(result.statusCode).toBe(400);
  });
});
