import { describe, it, expect } from 'vitest';
import {
  ValidationError,
  normalizeEmail,
  requireString,
  optionalString,
  requireEnum,
  requireStringArray,
  parseJsonBody,
  assertNoUnexpectedFields,
} from '../validation.js';

describe('normalizeEmail', () => {
  it('lowercases and trims a valid email', () => {
    expect(normalizeEmail('  Sarah@Example.COM  ')).toBe('sarah@example.com');
  });
  it('rejects a malformed email', () => {
    expect(() => normalizeEmail('not-an-email')).toThrow(ValidationError);
  });
  it('rejects a non-string value', () => {
    expect(() => normalizeEmail(12345)).toThrow(ValidationError);
  });
  it('rejects an implausibly long email', () => {
    expect(() => normalizeEmail(`${'a'.repeat(250)}@example.com`)).toThrow(ValidationError);
  });
});

describe('requireString', () => {
  it('trims and returns a valid string', () => {
    expect(requireString('  hello  ', 'field')).toBe('hello');
  });
  it('rejects an empty/whitespace-only string', () => {
    expect(() => requireString('   ', 'field')).toThrow(ValidationError);
  });
  it('rejects a non-string value', () => {
    expect(() => requireString(42, 'field')).toThrow(ValidationError);
  });
  it('rejects a string exceeding the max length', () => {
    expect(() => requireString('a'.repeat(300), 'field', 200)).toThrow(ValidationError);
  });
});

describe('optionalString', () => {
  it('returns undefined for missing/empty values', () => {
    expect(optionalString(undefined, 'field')).toBeUndefined();
    expect(optionalString(null, 'field')).toBeUndefined();
    expect(optionalString('', 'field')).toBeUndefined();
  });
  it('trims and returns a provided value', () => {
    expect(optionalString('  hi  ', 'field')).toBe('hi');
  });
  it('rejects a non-string value', () => {
    expect(() => optionalString(42, 'field')).toThrow(ValidationError);
  });
});

describe('requireEnum', () => {
  const ALLOWED = ['a', 'b', 'c'] as const;
  it('accepts an allowed value', () => {
    expect(requireEnum('b', ALLOWED, 'field')).toBe('b');
  });
  it('rejects a value outside the allowed set', () => {
    expect(() => requireEnum('z', ALLOWED, 'field')).toThrow(ValidationError);
  });
  it('rejects a non-string value', () => {
    expect(() => requireEnum(123, ALLOWED, 'field')).toThrow(ValidationError);
  });
});

describe('requireStringArray', () => {
  it('trims each entry and returns the array', () => {
    expect(requireStringArray(['  a  ', 'b'], 'field')).toEqual(['a', 'b']);
  });
  it('rejects an empty array', () => {
    expect(() => requireStringArray([], 'field')).toThrow(ValidationError);
  });
  it('rejects a non-array value', () => {
    expect(() => requireStringArray('not-an-array', 'field')).toThrow(ValidationError);
  });
  it('rejects an array containing a non-string entry', () => {
    expect(() => requireStringArray(['a', 123], 'field')).toThrow(ValidationError);
  });
  it('rejects an array exceeding the max item count', () => {
    expect(() => requireStringArray(Array(25).fill('x'), 'field', 20)).toThrow(ValidationError);
  });
});

describe('parseJsonBody', () => {
  it('parses a valid JSON object body', () => {
    expect(parseJsonBody('{"name":"Sarah"}')).toEqual({ name: 'Sarah' });
  });
  it('rejects malformed JSON', () => {
    expect(() => parseJsonBody('{not valid json')).toThrow(ValidationError);
  });
  it('rejects an empty/null body', () => {
    expect(() => parseJsonBody(null)).toThrow(ValidationError);
    expect(() => parseJsonBody('')).toThrow(ValidationError);
  });
  it('rejects a JSON array body (not an object)', () => {
    expect(() => parseJsonBody('[1,2,3]')).toThrow(ValidationError);
  });
});

describe('assertNoUnexpectedFields', () => {
  it('passes when every field is allowed', () => {
    expect(() => assertNoUnexpectedFields({ name: 'a', email: 'b' }, ['name', 'email'])).not.toThrow();
  });
  it('rejects a body containing a field outside the allowed set (e.g. a caller trying to inject status)', () => {
    expect(() => assertNoUnexpectedFields({ name: 'a', status: 'approved' }, ['name'])).toThrow(ValidationError);
  });
});
