import { createHash } from 'node:crypto';
import type { SupabaseClient } from '@supabase/supabase-js';

/**
 * Anti-abuse checks for public submission endpoints. Every check here is
 * deliberately silent about *which* check failed — callers should surface
 * one generic rejection regardless of the reason, per Phase E4's
 * instruction that responses must not let an attacker distinguish which
 * anti-abuse mechanism triggered.
 */

const MIN_SUBMIT_TIME_MS = 3000; // a human can't plausibly fill any of these forms faster than this
const RATE_LIMIT_WINDOW_MS = 10 * 60 * 1000; // 10 minutes
const RATE_LIMIT_MAX_ATTEMPTS = 5; // per bucket (endpoint + hashed IP) per window

/** True if the honeypot field was filled in — real users never see or fill this field. */
export function isHoneypotTriggered(body: Record<string, unknown>, honeypotField = 'website'): boolean {
  const value = body[honeypotField];
  return typeof value === 'string' && value.trim().length > 0;
}

/** True if the form was submitted implausibly fast after it loaded. */
export function isSubmittedTooFast(body: Record<string, unknown>, formLoadedField = 'formLoadedAt'): boolean {
  const loadedAt = body[formLoadedField];
  if (typeof loadedAt !== 'number' || !Number.isFinite(loadedAt)) return true; // missing/invalid timing signal is itself suspicious
  const elapsed = Date.now() - loadedAt;
  return elapsed < MIN_SUBMIT_TIME_MS;
}

/** Hashes an IP address — the rate-limit ledger never stores a raw IP. */
export function hashIp(ip: string): string {
  return createHash('sha256').update(ip).digest('hex');
}

/**
 * Best-effort caller IP extraction. Netlify's exact header for this has
 * varied across runtime versions; checked defensively across the headers
 * most commonly used, falling back to a fixed bucket rather than throwing
 * if none are present (a missing IP should degrade rate-limiting, not
 * break submission entirely).
 */
export function getClientIp(headers: Record<string, string | string[] | undefined>): string {
  const candidates = [headers['x-nf-client-connection-ip'], headers['x-forwarded-for'], headers['client-ip']];
  for (const candidate of candidates) {
    const value = Array.isArray(candidate) ? candidate[0] : candidate;
    if (value) return value.split(',')[0].trim();
  }
  return 'unknown';
}

/**
 * Database-backed rate limit — NOT in-process memory, since Netlify
 * Function instances are ephemeral and don't share memory across
 * invocations/cold starts. Returns true if the caller is within the
 * allowed rate, false if they've exceeded it (and should be rejected).
 */
export async function checkRateLimit(supabase: SupabaseClient, endpoint: string, ip: string): Promise<boolean> {
  const bucketKey = `${endpoint}:${hashIp(ip)}`;
  const windowStart = new Date(Date.now() - RATE_LIMIT_WINDOW_MS).toISOString();

  const { count, error } = await supabase
    .from('rate_limit_events')
    .select('*', { count: 'exact', head: true })
    .eq('bucket_key', bucketKey)
    .gte('created_at', windowStart);

  if (error) {
    // Fail OPEN on a rate-limit infrastructure error, not closed — a
    // transient DB issue here should not itself become a denial-of-service
    // against legitimate submitters. The submission's own validation and
    // the RLS-enforced write path remain the real security boundary.
    console.error('checkRateLimit read failed:', error.message);
    return true;
  }

  if ((count ?? 0) >= RATE_LIMIT_MAX_ATTEMPTS) {
    return false;
  }

  const { error: insertError } = await supabase.from('rate_limit_events').insert({ bucket_key: bucketKey });
  if (insertError) {
    console.error('checkRateLimit write failed:', insertError.message);
  }
  return true;
}
