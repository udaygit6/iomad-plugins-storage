import type { IomadGateway } from '../iomad/IomadRestGateway.js';
import { IomadGatewayError } from '../iomad/IomadErrors.js';
import type { OrganisationSyncRepository } from './OrganisationSyncRepository.js';
import type { CompanySyncResult, SingleCompanySyncResult } from './types.js';

/**
 * F4 — Iomad company synchronisation.
 *
 *   IomadGateway.listCompanies()
 *     → normalised { externalId, displayName } (already defensive —
 *       see ../iomad/IomadResponseAdapters.ts; unchanged by F4)
 *     → OrganisationSyncRepository upsert (organisation + mapping)
 *     → CompanySyncResult
 *
 * LIVE SCHEMA GATE (see docs/IOMAD_INTEGRATION_CONTRACT.md): only
 * `externalId` and `displayName` are synced — the only two fields the F3
 * response adapter exposes. Suspension/status/shortname/code sync is
 * explicitly NOT implemented here — those Iomad-side fields are not
 * confirmed to exist in the live response shape yet. Every organisation
 * created by this service gets `status: 'active'` unconditionally; no
 * code path in this file ever sets `status: 'suspended'` from Iomad data.
 * Likewise, every organisation created by this service gets
 * `type: 'unclassified'` (enforced by `sync_iomad_company()` in
 * `supabase/migrations/0015`, not by this file) — F4 has no verified
 * signal to distinguish a franchise company from Corporate/school/
 * internal from Iomad data alone, and does not attempt to infer it from
 * name/email/ID heuristics, INCLUDING `custom1` (observed live as
 * `"myguru_franchise"` for one company — see
 * docs/IOMAD_INTEGRATION_CONTRACT.md's "Live-verified: get_companies by
 * code") — that field is never read by this file.
 *
 * Atomicity: `OrganisationSyncRepository.syncCompany()` performs the
 * find-or-create-or-rename step as one atomic database transaction (see
 * `sync_iomad_company()`), so a failure partway through never leaves a
 * half-created organisation or orphaned mapping. This file has no
 * multi-step orchestration to get wrong.
 *
 * No write-back to Iomad. No company creation/suspension calls into
 * Iomad. This service only ever calls `listCompanies()` (bulk sync,
 * `sync()`) or `getCompanyByCode()` (single-company sync,
 * `syncByCompanyCode()` — F4C) — nothing else on `IomadGateway`, and
 * never any Iomad write function.
 */
export class IomadCompanySyncService {
  private readonly gateway: IomadGateway;
  private readonly repository: OrganisationSyncRepository;

  constructor(gateway: IomadGateway, repository: OrganisationSyncRepository) {
    this.gateway = gateway;
    this.repository = repository;
  }

  async sync(correlationId?: string): Promise<CompanySyncResult> {
    const timestamp = new Date().toISOString();

    let companies: Array<{ externalId: string; displayName: string }>;
    try {
      companies = await this.gateway.listCompanies();
    } catch (err) {
      const code = errorCodeOf(err);
      logSafe('fetch_failed', { code, correlationId });
      return { fetched: 0, created: 0, updated: 0, unchanged: 0, failed: 0, timestamp, topLevelError: code };
    }

    const result: CompanySyncResult = {
      fetched: companies.length,
      created: 0,
      updated: 0,
      unchanged: 0,
      failed: 0,
      timestamp,
    };

    const seenIds = new Set<string>();

    for (const company of companies) {
      // A duplicate external id within the SAME batch (pathological, but
      // possible if Iomad's response ever contains one) must not create
      // a second organisation — the unique constraint on
      // iomad_company_id would reject it anyway, but checking here keeps
      // the summary counts honest and avoids a needless failed write.
      if (seenIds.has(company.externalId)) {
        result.unchanged++;
        continue;
      }
      seenIds.add(company.externalId);

      try {
        await this.syncOne(company, result);
      } catch (err) {
        result.failed++;
        const code = errorCodeOf(err);
        logSafe('company_sync_failed', { iomadCompanyId: company.externalId, code, correlationId });
        // Best-effort — markFailed never throws (see its doc comment).
        await this.repository.markFailed({ iomadCompanyId: company.externalId, errorCode: code });
      }
    }

    // Missing-from-source pass. Deliberately skipped when the fetch
    // returned zero companies — an empty result is far more likely to
    // indicate an upstream problem (token scope change, transient
    // filtering, a misconfigured request) than a genuine "we now have
    // zero companies" state, and staling every known mapping on that
    // basis would be actively harmful. See F4 §7.
    if (companies.length > 0) {
      try {
        await this.repository.markMissingAsStale(Array.from(seenIds));
      } catch (err) {
        logSafe('stale_marking_failed', { code: errorCodeOf(err), correlationId });
      }
    }

    return result;
  }

  /**
   * F4C — controlled single-company sync, for verifying the newly
   * live-verified `getCompanyByCode()` path end-to-end without touching
   * the bulk sync algorithm above.
   *
   * Deliberately does NOT call `markMissingAsStale()` — this operation
   * knows about exactly one requested company; it must never mark any
   * OTHER mapping stale as a side effect. Deliberately does NOT call
   * `listCompanies()` — the unfiltered bulk call remains unverified; this
   * method only ever uses the live-verified criteria-filtered lookup.
   *
   * On any failure (Iomad fetch failure, duplicate/unexpected result from
   * the gateway, or a repository write failure), performs NO database
   * write beyond the same best-effort `markFailed()` the bulk sync uses
   * for an already-known company — a not-yet-persisted company that
   * fails here simply isn't written at all.
   */
  async syncByCompanyCode(code: string, correlationId?: string): Promise<SingleCompanySyncResult> {
    const timestamp = new Date().toISOString();
    const trimmedCode = code.trim();

    if (trimmedCode.length === 0) {
      return { companyCode: code, iomadCompanyId: null, outcome: 'failed', timestamp, errorCode: 'invalid_input' };
    }

    let company: { externalId: string; displayName: string } | null;
    try {
      // The only Iomad call this method makes. If the gateway detects a
      // duplicate/unexpected result (more than one company for this
      // code), it throws `unknown_response_schema` here — caught below,
      // reported as a safe failure, and `repository.syncCompany()` is
      // never reached, so no DB write happens for that case either.
      company = await this.gateway.getCompanyByCode(trimmedCode);
    } catch (err) {
      const errorCode = errorCodeOf(err);
      logSafe('single_company_fetch_failed', { code: errorCode, correlationId });
      return { companyCode: trimmedCode, iomadCompanyId: null, outcome: 'failed', timestamp, errorCode };
    }

    if (!company) {
      // Not found — no database write of any kind.
      return { companyCode: trimmedCode, iomadCompanyId: null, outcome: 'not_found', timestamp };
    }

    try {
      const { wasCreated, nameChanged } = await this.repository.syncCompany({
        iomadCompanyId: company.externalId,
        displayName: company.displayName,
      });
      const outcome = wasCreated ? 'created' : nameChanged ? 'updated' : 'unchanged';
      return { companyCode: trimmedCode, iomadCompanyId: company.externalId, outcome, timestamp };
    } catch (err) {
      const errorCode = errorCodeOf(err);
      logSafe('single_company_sync_failed', { iomadCompanyId: company.externalId, code: errorCode, correlationId });
      // Best-effort — markFailed never throws (see its doc comment). A
      // no-op if syncCompany() failed before ever creating a mapping.
      await this.repository.markFailed({ iomadCompanyId: company.externalId, errorCode });
      return {
        companyCode: trimmedCode,
        iomadCompanyId: company.externalId,
        outcome: 'failed',
        timestamp,
        errorCode,
      };
    }
  }

  private async syncOne(
    company: { externalId: string; displayName: string },
    result: CompanySyncResult,
  ): Promise<void> {
    // syncCompany() is atomic (find-or-create-or-rename + mark-synced in
    // one DB transaction — see sync_iomad_company() in
    // supabase/migrations/0015) so there is no separate
    // find/create/update sequence to orchestrate here any more.
    const { wasCreated, nameChanged } = await this.repository.syncCompany({
      iomadCompanyId: company.externalId,
      displayName: company.displayName,
    });

    if (wasCreated) {
      result.created++;
    } else if (nameChanged) {
      result.updated++;
    } else {
      result.unchanged++;
    }
  }
}

function errorCodeOf(err: unknown): string {
  if (err instanceof IomadGatewayError) return err.code;
  return 'unknown_error';
}

/**
 * Server-log-only. Never PII, never a raw Iomad payload, never a
 * displayName — only the Iomad company external id, a safe status/code,
 * and an optional correlation id (F4 §8/§14 data-minimisation note).
 */
function logSafe(event: string, detail: { iomadCompanyId?: string; code: string; correlationId?: string }): void {
  console.error('[company-sync]', { event, ...detail });
}
