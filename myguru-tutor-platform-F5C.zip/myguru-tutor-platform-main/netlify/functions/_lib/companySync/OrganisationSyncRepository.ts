import type { Organisation, IomadCompanyMapping } from './types.js';

/**
 * Persistence boundary for company sync. `IomadCompanySyncService` depends
 * only on this interface, not on Supabase directly — makes the sync
 * algorithm fully unit-testable with an in-memory fake (see
 * `__tests__/IomadCompanySyncService.test.ts`) and keeps the door open for
 * a different persistence layer later (AWS migration, per
 * `docs/TARGET_ARCHITECTURE.md` §11) without touching the algorithm.
 */
export interface OrganisationSyncRepository {
  /**
   * Atomically find-or-create the organisation+mapping pair for one Iomad
   * company, updating the organisation's name if `displayName` differs
   * from what's stored and marking the mapping synced — all in a single
   * database transaction (see `sync_iomad_company()` in
   * `supabase/migrations/0015_organisation_iomad_company_sync.sql`).
   * Never leaves a half-created organisation or mapping if any part
   * fails, and is safe to call concurrently for the same
   * `iomadCompanyId` — repeated/concurrent calls reuse the same pair
   * rather than creating duplicates. New organisations are always
   * created `type: 'unclassified'` — this method has no way to infer
   * franchise/corporate/school classification from Iomad data alone.
   */
  syncCompany(input: {
    iomadCompanyId: string;
    displayName: string;
  }): Promise<{
    organisation: Organisation;
    mapping: IomadCompanyMapping;
    /** True if this call created a brand-new organisation+mapping pair. */
    wasCreated: boolean;
    /** True if an existing organisation's name was changed by this call.
     * Always false when `wasCreated` is true (nothing to compare a new
     * row's name against). */
    nameChanged: boolean;
  }>;

  /** Record a safe failure for one company. Best-effort: if no mapping
   * exists yet for this iomadCompanyId (e.g. its initial sync attempt is
   * what failed before any row was ever created), this is a safe no-op —
   * there is nothing to mark. Never throws; the caller does not need to
   * further guard this call. */
  markFailed(params: { iomadCompanyId: string; errorCode: string }): Promise<void>;

  /**
   * After a full `listCompanies()` pass, mark every mapping whose
   * `iomadCompanyId` is NOT in `seenIomadCompanyIds` as `stale` (never
   * `synced` → deleted; see F4 §7 "Do not delete on missing source").
   * Returns the count marked stale. Only ever called by the sync service
   * when the fetch returned at least one company (see that guard's
   * rationale in `IomadCompanySyncService.ts`).
   */
  markMissingAsStale(seenIomadCompanyIds: string[]): Promise<number>;
}
