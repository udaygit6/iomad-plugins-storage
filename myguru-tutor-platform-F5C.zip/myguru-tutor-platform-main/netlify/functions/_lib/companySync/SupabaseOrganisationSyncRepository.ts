import type { SupabaseClient } from '@supabase/supabase-js';
import type { OrganisationSyncRepository } from './OrganisationSyncRepository.js';
import type { Organisation, IomadCompanyMapping } from './types.js';

/**
 * Supabase-backed `OrganisationSyncRepository`. Always constructed with an
 * already-authenticated service-role client (`getServerSupabaseClient()`
 * from `../supabaseServerClient.js`) — this file never reads env vars or
 * a token itself, matching the existing separation between "get a client"
 * and "use a client" elsewhere in `netlify/functions/_lib/`.
 *
 * `syncCompany()` calls the `sync_iomad_company()` Postgres function
 * (`supabase/migrations/0015_organisation_iomad_company_sync.sql`) rather
 * than performing separate INSERT/UPDATE requests — that function runs
 * the whole find-or-create-or-rename operation as one atomic database
 * transaction (F4 review fix: the original two-request design could leave
 * an orphan organisation if the mapping insert failed). Writes bypass RLS
 * via the service-role key (the same platform guarantee
 * `integration_jobs`/`0010` already relies on) — see 0015 for the policy
 * that intentionally grants no anon/authenticated write access at all to
 * either table, and no EXECUTE on the RPC to anything but `service_role`.
 */

interface OrganisationRow {
  id: string;
  name: string;
  type: Organisation['type'];
  status: Organisation['status'];
  source: Organisation['source'];
  created_at: string;
  updated_at: string;
}

interface MappingRow {
  id: string;
  organisation_id: string;
  iomad_company_id: string;
  sync_status: IomadCompanyMapping['syncStatus'];
  last_synced_at: string | null;
  last_error_code: string | null;
  created_at: string;
  updated_at: string;
}

interface SyncIomadCompanyRpcRow {
  organisation_id: string;
  organisation_name: string;
  organisation_type: Organisation['type'];
  organisation_status: Organisation['status'];
  organisation_source: Organisation['source'];
  organisation_created_at: string;
  organisation_updated_at: string;
  mapping_id: string;
  mapping_sync_status: IomadCompanyMapping['syncStatus'];
  mapping_last_synced_at: string | null;
  mapping_last_error_code: string | null;
  mapping_created_at: string;
  mapping_updated_at: string;
  was_created: boolean;
  name_changed: boolean;
}

function mapOrganisation(row: OrganisationRow): Organisation {
  return {
    id: row.id,
    name: row.name,
    type: row.type,
    status: row.status,
    source: row.source,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function mapMapping(row: MappingRow): IomadCompanyMapping {
  return {
    id: row.id,
    organisationId: row.organisation_id,
    iomadCompanyId: row.iomad_company_id,
    syncStatus: row.sync_status,
    lastSyncedAt: row.last_synced_at,
    lastErrorCode: row.last_error_code,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

/**
 * Reshapes the flattened `sync_iomad_company()` RPC row into the same
 * per-table row shapes `mapOrganisation`/`mapMapping` already expect, so
 * both this RPC path and any future direct-table read share one mapping
 * implementation rather than two.
 */
function mapSyncCompanyRpcRow(
  row: SyncIomadCompanyRpcRow,
  iomadCompanyId: string,
): { organisation: Organisation; mapping: IomadCompanyMapping; wasCreated: boolean; nameChanged: boolean } {
  const organisation = mapOrganisation({
    id: row.organisation_id,
    name: row.organisation_name,
    type: row.organisation_type,
    status: row.organisation_status,
    source: row.organisation_source,
    created_at: row.organisation_created_at,
    updated_at: row.organisation_updated_at,
  });
  const mapping = mapMapping({
    id: row.mapping_id,
    organisation_id: row.organisation_id,
    iomad_company_id: iomadCompanyId,
    sync_status: row.mapping_sync_status,
    last_synced_at: row.mapping_last_synced_at,
    last_error_code: row.mapping_last_error_code,
    created_at: row.mapping_created_at,
    updated_at: row.mapping_updated_at,
  });
  return { organisation, mapping, wasCreated: row.was_created, nameChanged: row.name_changed };
}

// Exported for unit testing without a network call.
export const _mappers = { mapOrganisation, mapMapping, mapSyncCompanyRpcRow };

export class SupabaseOrganisationSyncRepository implements OrganisationSyncRepository {
  private readonly supabase: SupabaseClient;

  constructor(supabase: SupabaseClient) {
    this.supabase = supabase;
  }

  async syncCompany(input: { iomadCompanyId: string; displayName: string }): Promise<{
    organisation: Organisation;
    mapping: IomadCompanyMapping;
    wasCreated: boolean;
    nameChanged: boolean;
  }> {
    const { data, error } = await this.supabase.rpc('sync_iomad_company', {
      p_iomad_company_id: input.iomadCompanyId,
      p_display_name: input.displayName,
    });

    if (error) throw new Error(`syncCompany failed: ${error.code ?? 'unknown'}`);

    const row = (Array.isArray(data) ? data[0] : data) as SyncIomadCompanyRpcRow | undefined;
    if (!row) throw new Error('syncCompany failed: empty_response');

    return mapSyncCompanyRpcRow(row, input.iomadCompanyId);
  }

  async markFailed(params: { iomadCompanyId: string; errorCode: string }): Promise<void> {
    // Best-effort, deliberately never throws into the caller (see the
    // interface doc comment) — this is called from the sync loop's own
    // catch block and must not itself abort processing of the next
    // company.
    //
    // Supabase reports a failed write through the returned `error` field
    // on the normal (resolved) response, not by throwing — a query error
    // does not raise a JS exception. The try/catch below only guards
    // against a genuine client/network-level exception, which is rare;
    // the `error` field is what actually needs inspecting for the common
    // case, so it's checked explicitly rather than relied on to be caught
    // as a throw.
    try {
      const { error } = await this.supabase
        .from('iomad_company_mappings')
        .update({ sync_status: 'failed', last_error_code: params.errorCode })
        .eq('iomad_company_id', params.iomadCompanyId);

      if (error) {
        // Safe log only — a DB error code, never raw error detail, PII, or secrets.
        console.error('[company-sync] markFailed update returned an error', {
          iomadCompanyId: params.iomadCompanyId,
          dbErrorCode: error.code ?? 'unknown',
        });
      }
    } catch {
      console.error('[company-sync] markFailed threw', { iomadCompanyId: params.iomadCompanyId });
    }
  }

  async markMissingAsStale(seenIomadCompanyIds: string[]): Promise<number> {
    // Never touches rows that are already stale or failed — only demotes
    // currently-synced/pending mappings that were absent from this run.
    const { data, error } = await this.supabase
      .from('iomad_company_mappings')
      .update({ sync_status: 'stale' })
      .in('sync_status', ['synced', 'pending'])
      .not('iomad_company_id', 'in', `(${seenIomadCompanyIds.map((id) => `"${id}"`).join(',')})`)
      .select('id');
    if (error) throw new Error(`markMissingAsStale failed: ${error.code ?? 'unknown'}`);
    return (data ?? []).length;
  }
}
