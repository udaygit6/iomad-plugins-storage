import { describe, it, expect, vi } from 'vitest';
import { IomadCompanySyncService } from '../IomadCompanySyncService.js';
import { IomadGatewayError } from '../../iomad/IomadErrors.js';
import type {
  IomadGateway,
  IomadCompanySummary,
  IomadCourseSummary,
  CompanyCourseAllocation,
  IomadCourseSettings,
} from '../../iomad/IomadRestGateway.js';
import type { OrganisationSyncRepository } from '../OrganisationSyncRepository.js';
import type { Organisation, IomadCompanyMapping } from '../types.js';

/** Minimal fake IomadGateway — only listCompanies() matters for this service. */
class FakeIomadGateway implements IomadGateway {
  companies: IomadCompanySummary[] = [];
  listCompaniesError: Error | null = null;
  getCompanyByCodeError: Error | null = null;

  async listCompanies(): Promise<IomadCompanySummary[]> {
    if (this.listCompaniesError) throw this.listCompaniesError;
    return this.companies;
  }
  async getCompany(externalCompanyId: string): Promise<IomadCompanySummary | null> {
    return this.companies.find((c) => c.externalId === externalCompanyId) ?? null;
  }
  async getCompanyByCode(code: string): Promise<IomadCompanySummary | null> {
    if (this.getCompanyByCodeError) throw this.getCompanyByCodeError;
    return this.companies.find((c) => c.code === code) ?? null;
  }
  async listCompanyCourses(): Promise<CompanyCourseAllocation[]> {
    return [];
  }
  async getCourse(): Promise<IomadCourseSummary | null> {
    return null;
  }
  async getCourseSettings(): Promise<IomadCourseSettings[]> {
    return [];
  }
}

/**
 * In-memory fake repository. Models `syncCompany()` as the atomic
 * find-or-create-or-rename operation the real `sync_iomad_company()`
 * Postgres function performs — a single call that never leaves a
 * half-created pair, keyed only on `iomadCompanyId`, and classifies every
 * new organisation `'unclassified'` (never inferred from company data).
 */
class FakeOrganisationSyncRepository implements OrganisationSyncRepository {
  private orgs = new Map<string, Organisation>();
  private mappings = new Map<string, IomadCompanyMapping>(); // keyed by mapping id
  private byIomadId = new Map<string, string>(); // iomadCompanyId -> mapping id
  private idCounter = 0;
  failSyncForIomadId: string | null = null;
  markMissingAsStaleCallCount = 0;

  private nextId(prefix: string): string {
    this.idCounter += 1;
    return `${prefix}-${this.idCounter}`;
  }

  async syncCompany(input: { iomadCompanyId: string; displayName: string }) {
    if (this.failSyncForIomadId === input.iomadCompanyId) {
      throw new Error('simulated syncCompany failure');
    }

    const existingMappingId = this.byIomadId.get(input.iomadCompanyId);

    if (!existingMappingId) {
      const now = new Date().toISOString();
      const orgId = this.nextId('org');
      const organisation: Organisation = {
        id: orgId,
        name: input.displayName,
        type: 'unclassified',
        status: 'active',
        source: 'iomad_sync',
        createdAt: now,
        updatedAt: now,
      };
      const mappingId = this.nextId('map');
      const mapping: IomadCompanyMapping = {
        id: mappingId,
        organisationId: orgId,
        iomadCompanyId: input.iomadCompanyId,
        syncStatus: 'synced',
        lastSyncedAt: now,
        lastErrorCode: null,
        createdAt: now,
        updatedAt: now,
      };
      this.orgs.set(orgId, organisation);
      this.mappings.set(mappingId, mapping);
      this.byIomadId.set(input.iomadCompanyId, mappingId);

      return { organisation, mapping, wasCreated: true, nameChanged: false };
    }

    const mapping = this.mappings.get(existingMappingId)!;
    const organisation = this.orgs.get(mapping.organisationId)!;
    const nameChanged = organisation.name !== input.displayName;
    if (nameChanged) {
      const updated = { ...organisation, name: input.displayName, updatedAt: new Date().toISOString() };
      this.orgs.set(organisation.id, updated);
      const syncedMapping = { ...mapping, syncStatus: 'synced' as const, lastSyncedAt: new Date().toISOString() };
      this.mappings.set(mapping.id, syncedMapping);
      return { organisation: updated, mapping: syncedMapping, wasCreated: false, nameChanged: true };
    }
    const syncedMapping = { ...mapping, syncStatus: 'synced' as const, lastSyncedAt: new Date().toISOString() };
    this.mappings.set(mapping.id, syncedMapping);
    return { organisation, mapping: syncedMapping, wasCreated: false, nameChanged: false };
  }

  async markFailed(params: { iomadCompanyId: string; errorCode: string }): Promise<void> {
    const mappingId = this.byIomadId.get(params.iomadCompanyId);
    if (!mappingId) return; // no-op, per interface contract
    const mapping = this.mappings.get(mappingId);
    if (mapping) this.mappings.set(mappingId, { ...mapping, syncStatus: 'failed', lastErrorCode: params.errorCode });
  }

  async markMissingAsStale(seenIomadCompanyIds: string[]): Promise<number> {
    this.markMissingAsStaleCallCount++;
    let count = 0;
    for (const [iomadId, mappingId] of this.byIomadId.entries()) {
      if (seenIomadCompanyIds.includes(iomadId)) continue;
      const mapping = this.mappings.get(mappingId);
      if (mapping && (mapping.syncStatus === 'synced' || mapping.syncStatus === 'pending')) {
        this.mappings.set(mappingId, { ...mapping, syncStatus: 'stale' });
        count++;
      }
    }
    return count;
  }

  // Test helpers, not part of the interface.
  getOrganisationByIomadId(iomadCompanyId: string): Organisation | undefined {
    const mappingId = this.byIomadId.get(iomadCompanyId);
    if (!mappingId) return undefined;
    const mapping = this.mappings.get(mappingId);
    return mapping ? this.orgs.get(mapping.organisationId) : undefined;
  }
  getMappingByIomadId(iomadCompanyId: string): IomadCompanyMapping | undefined {
    const mappingId = this.byIomadId.get(iomadCompanyId);
    return mappingId ? this.mappings.get(mappingId) : undefined;
  }
  get organisationCount(): number {
    return this.orgs.size;
  }
  get mappingCount(): number {
    return this.mappings.size;
  }
}

describe('IomadCompanySyncService.sync', () => {
  it('first sync creates a new organisation + mapping for each company, classified unclassified', async () => {
    const gateway = new FakeIomadGateway();
    gateway.companies = [
      { externalId: '1', displayName: 'Acme Tutoring' },
      { externalId: '2', displayName: 'Beta Learning' },
    ];
    const repo = new FakeOrganisationSyncRepository();
    const service = new IomadCompanySyncService(gateway, repo);

    const result = await service.sync();

    expect(result).toMatchObject({ fetched: 2, created: 2, updated: 0, unchanged: 0, failed: 0 });
    expect(repo.organisationCount).toBe(2);
    expect(repo.getOrganisationByIomadId('1')?.name).toBe('Acme Tutoring');
    expect(repo.getOrganisationByIomadId('1')?.type).toBe('unclassified');
    expect(repo.getOrganisationByIomadId('2')?.type).toBe('unclassified');
  });

  it('never classifies a newly-discovered company as myguru_franchise or any other business type', async () => {
    const gateway = new FakeIomadGateway();
    gateway.companies = [
      { externalId: '1', displayName: 'MyGuru Franchise Ltd' }, // name alone must not drive classification
      { externalId: '2', displayName: 'Acme Corporate Solutions' },
    ];
    const repo = new FakeOrganisationSyncRepository();
    const service = new IomadCompanySyncService(gateway, repo);

    await service.sync();

    expect(repo.getOrganisationByIomadId('1')?.type).toBe('unclassified');
    expect(repo.getOrganisationByIomadId('2')?.type).toBe('unclassified');
  });

  it('second sync against the same company list updates/reuses the same mapping (no duplicates)', async () => {
    const gateway = new FakeIomadGateway();
    gateway.companies = [{ externalId: '1', displayName: 'Acme Tutoring' }];
    const repo = new FakeOrganisationSyncRepository();
    const service = new IomadCompanySyncService(gateway, repo);

    const first = await service.sync();
    const second = await service.sync();

    expect(first.created).toBe(1);
    expect(second.created).toBe(0);
    expect(second.unchanged).toBe(1);
    expect(repo.organisationCount).toBe(1);
    expect(repo.mappingCount).toBe(1);
  });

  it('duplicate Iomad company IDs within the same batch do not create duplicates', async () => {
    const gateway = new FakeIomadGateway();
    gateway.companies = [
      { externalId: '1', displayName: 'Acme Tutoring' },
      { externalId: '1', displayName: 'Acme Tutoring (dup)' },
    ];
    const repo = new FakeOrganisationSyncRepository();
    const service = new IomadCompanySyncService(gateway, repo);

    const result = await service.sync();

    expect(result.created).toBe(1);
    expect(repo.organisationCount).toBe(1);
    expect(repo.mappingCount).toBe(1);
  });

  it('a renamed company updates the organisation display name when displayName differs', async () => {
    const gateway = new FakeIomadGateway();
    gateway.companies = [{ externalId: '1', displayName: 'Acme Tutoring' }];
    const repo = new FakeOrganisationSyncRepository();
    const service = new IomadCompanySyncService(gateway, repo);
    await service.sync();

    gateway.companies = [{ externalId: '1', displayName: 'Acme Tutoring Ltd' }];
    const result = await service.sync();

    expect(result.updated).toBe(1);
    expect(result.unchanged).toBe(0);
    expect(repo.getOrganisationByIomadId('1')?.name).toBe('Acme Tutoring Ltd');
  });

  it('an unchanged displayName does not trigger an update (reports unchanged, not updated)', async () => {
    const gateway = new FakeIomadGateway();
    gateway.companies = [{ externalId: '1', displayName: 'Acme Tutoring' }];
    const repo = new FakeOrganisationSyncRepository();
    const service = new IomadCompanySyncService(gateway, repo);
    await service.sync();

    const result = await service.sync();

    expect(result.updated).toBe(0);
    expect(result.unchanged).toBe(1);
  });

  it('one company failure does not corrupt/block processing of other companies', async () => {
    const gateway = new FakeIomadGateway();
    gateway.companies = [
      { externalId: '1', displayName: 'Acme Tutoring' },
      { externalId: '2', displayName: 'Beta Learning' },
      { externalId: '3', displayName: 'Gamma Coaching' },
    ];
    const repo = new FakeOrganisationSyncRepository();
    repo.failSyncForIomadId = '2';
    const service = new IomadCompanySyncService(gateway, repo);

    const result = await service.sync();

    expect(result.fetched).toBe(3);
    expect(result.created).toBe(2);
    expect(result.failed).toBe(1);
    expect(repo.getOrganisationByIomadId('1')).toBeDefined();
    expect(repo.getOrganisationByIomadId('2')).toBeUndefined();
    expect(repo.getOrganisationByIomadId('3')).toBeDefined();
  });

  it('a failed syncCompany() call leaves no orphan organisation for that company (nothing partially created)', async () => {
    const gateway = new FakeIomadGateway();
    gateway.companies = [{ externalId: '1', displayName: 'Acme Tutoring' }];
    const repo = new FakeOrganisationSyncRepository();
    repo.failSyncForIomadId = '1';
    const service = new IomadCompanySyncService(gateway, repo);

    await service.sync();

    expect(repo.organisationCount).toBe(0);
    expect(repo.mappingCount).toBe(0);
  });

  it('a company missing from a later sync is marked stale, not deleted', async () => {
    const gateway = new FakeIomadGateway();
    gateway.companies = [
      { externalId: '1', displayName: 'Acme Tutoring' },
      { externalId: '2', displayName: 'Beta Learning' },
    ];
    const repo = new FakeOrganisationSyncRepository();
    const service = new IomadCompanySyncService(gateway, repo);
    await service.sync();

    gateway.companies = [{ externalId: '1', displayName: 'Acme Tutoring' }];
    await service.sync();

    expect(repo.getMappingByIomadId('2')?.syncStatus).toBe('stale');
    expect(repo.getOrganisationByIomadId('2')).toBeDefined(); // still exists — not deleted
    expect(repo.organisationCount).toBe(2);
  });

  it('does NOT run the missing-from-source pass when the fetch returns zero companies', async () => {
    const gateway = new FakeIomadGateway();
    gateway.companies = [{ externalId: '1', displayName: 'Acme Tutoring' }];
    const repo = new FakeOrganisationSyncRepository();
    const service = new IomadCompanySyncService(gateway, repo);
    await service.sync();

    gateway.companies = []; // simulate an empty/suspicious response
    const result = await service.sync();

    expect(result.fetched).toBe(0);
    // The previously-synced company must NOT have been marked stale by an
    // empty result — see the "do not stale-mark on empty fetch" guard.
    expect(repo.getMappingByIomadId('1')?.syncStatus).toBe('synced');
  });

  it('returns a safe topLevelError and zero counts when listCompanies() itself fails', async () => {
    const gateway = new FakeIomadGateway();
    gateway.listCompaniesError = new IomadGatewayError('network_error', 'Could not reach the Iomad service.');
    const repo = new FakeOrganisationSyncRepository();
    const service = new IomadCompanySyncService(gateway, repo);

    const result = await service.sync();

    expect(result).toMatchObject({ fetched: 0, created: 0, updated: 0, unchanged: 0, failed: 0 });
    expect(result.topLevelError).toBe('network_error');
    expect(repo.organisationCount).toBe(0);
  });

  it('does not throw when listCompanies() fails — errors are captured in the result, not propagated', async () => {
    const gateway = new FakeIomadGateway();
    gateway.listCompaniesError = new Error('boom');
    const repo = new FakeOrganisationSyncRepository();
    const service = new IomadCompanySyncService(gateway, repo);

    await expect(service.sync()).resolves.toMatchObject({ topLevelError: 'unknown_error' });
  });

  it('never logs a raw error message, token, or company displayName — only safe codes/ids', async () => {
    const errorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
    const gateway = new FakeIomadGateway();
    gateway.companies = [{ externalId: '1', displayName: 'Top Secret Tutoring Ltd' }];
    const repo = new FakeOrganisationSyncRepository();
    repo.failSyncForIomadId = '1';
    const service = new IomadCompanySyncService(gateway, repo);

    await service.sync();

    for (const call of errorSpy.mock.calls) {
      const serialized = JSON.stringify(call);
      expect(serialized).not.toContain('Top Secret Tutoring Ltd');
      expect(serialized).not.toContain('simulated syncCompany failure');
    }
    errorSpy.mockRestore();
  });
});

describe('IomadCompanySyncService.syncByCompanyCode — F4C controlled single-company sync', () => {
  const SHIKSHA: IomadCompanySummary = {
    externalId: '3',
    displayName: 'Shiksha Academy',
    code: 'MYGURU-SHIKSHA-001',
    isSuspended: false,
  };

  it('FIRST sync: no existing mapping → organisation created → mapping created → outcome created', async () => {
    const gateway = new FakeIomadGateway();
    gateway.companies = [SHIKSHA];
    const repo = new FakeOrganisationSyncRepository();
    const service = new IomadCompanySyncService(gateway, repo);

    const result = await service.syncByCompanyCode('MYGURU-SHIKSHA-001');

    expect(result).toMatchObject({
      companyCode: 'MYGURU-SHIKSHA-001',
      iomadCompanyId: '3',
      outcome: 'created',
    });
    expect(typeof result.timestamp).toBe('string');
    expect(repo.organisationCount).toBe(1);
    expect(repo.mappingCount).toBe(1);
    expect(repo.getOrganisationByIomadId('3')?.name).toBe('Shiksha Academy');
    expect(repo.getOrganisationByIomadId('3')?.type).toBe('unclassified');
  });

  it('SECOND sync of the same Iomad company: same mapping reused → no duplicate organisation → outcome unchanged', async () => {
    const gateway = new FakeIomadGateway();
    gateway.companies = [SHIKSHA];
    const repo = new FakeOrganisationSyncRepository();
    const service = new IomadCompanySyncService(gateway, repo);

    const first = await service.syncByCompanyCode('MYGURU-SHIKSHA-001');
    const second = await service.syncByCompanyCode('MYGURU-SHIKSHA-001');

    expect(first.outcome).toBe('created');
    expect(second.outcome).toBe('unchanged');
    expect(second.iomadCompanyId).toBe('3');
    expect(repo.organisationCount).toBe(1);
    expect(repo.mappingCount).toBe(1);
  });

  it('NAME CHANGE: same Iomad company ID, new displayName → same organisation → name updated → outcome updated', async () => {
    const gateway = new FakeIomadGateway();
    gateway.companies = [SHIKSHA];
    const repo = new FakeOrganisationSyncRepository();
    const service = new IomadCompanySyncService(gateway, repo);
    await service.syncByCompanyCode('MYGURU-SHIKSHA-001');

    gateway.companies = [{ ...SHIKSHA, displayName: 'Shiksha Academy Ltd' }];
    const result = await service.syncByCompanyCode('MYGURU-SHIKSHA-001');

    expect(result.outcome).toBe('updated');
    expect(result.iomadCompanyId).toBe('3');
    expect(repo.organisationCount).toBe(1);
    expect(repo.getOrganisationByIomadId('3')?.name).toBe('Shiksha Academy Ltd');
  });

  it('NOT FOUND: no matching company → outcome not_found → no database write', async () => {
    const gateway = new FakeIomadGateway();
    gateway.companies = []; // no company with this code
    const repo = new FakeOrganisationSyncRepository();
    const service = new IomadCompanySyncService(gateway, repo);

    const result = await service.syncByCompanyCode('DOES-NOT-EXIST');

    expect(result).toMatchObject({
      companyCode: 'DOES-NOT-EXIST',
      iomadCompanyId: null,
      outcome: 'not_found',
    });
    expect(repo.organisationCount).toBe(0);
    expect(repo.mappingCount).toBe(0);
  });

  it('IOMAD FAILURE: getCompanyByCode() throws → outcome failed, safe errorCode → no database write', async () => {
    const gateway = new FakeIomadGateway();
    gateway.getCompanyByCodeError = new IomadGatewayError('network_error', 'Could not reach the Iomad service.');
    const repo = new FakeOrganisationSyncRepository();
    const service = new IomadCompanySyncService(gateway, repo);

    const result = await service.syncByCompanyCode('MYGURU-SHIKSHA-001');

    expect(result).toMatchObject({
      companyCode: 'MYGURU-SHIKSHA-001',
      iomadCompanyId: null,
      outcome: 'failed',
      errorCode: 'network_error',
    });
    expect(repo.organisationCount).toBe(0);
    expect(repo.mappingCount).toBe(0);
  });

  it('DUPLICATE IOMAD RESPONSE: existing gateway protection (unknown_response_schema) remains effective → outcome failed → no database write', async () => {
    const gateway = new FakeIomadGateway();
    // Models IomadRestGateway.getCompanyByCode()'s own defensive check:
    // it throws unknown_response_schema when a code lookup returns more
    // than one company. This fake simulates that same failure mode
    // rather than re-testing IomadRestGateway itself (already covered in
    // netlify/functions/_lib/iomad/__tests__/IomadRestGateway.test.ts).
    gateway.getCompanyByCodeError = new IomadGatewayError(
      'unknown_response_schema',
      'The Iomad service returned an unexpected response shape for "block_iomad_company_admin_get_companies".',
    );
    const repo = new FakeOrganisationSyncRepository();
    const service = new IomadCompanySyncService(gateway, repo);

    const result = await service.syncByCompanyCode('MYGURU-SHIKSHA-001');

    expect(result.outcome).toBe('failed');
    expect(result.errorCode).toBe('unknown_response_schema');
    expect(repo.organisationCount).toBe(0);
    expect(repo.mappingCount).toBe(0);
  });

  it('a repository (database) write failure also results in no persisted organisation, safe failed outcome', async () => {
    const gateway = new FakeIomadGateway();
    gateway.companies = [SHIKSHA];
    const repo = new FakeOrganisationSyncRepository();
    repo.failSyncForIomadId = '3';
    const service = new IomadCompanySyncService(gateway, repo);

    const result = await service.syncByCompanyCode('MYGURU-SHIKSHA-001');

    expect(result.outcome).toBe('failed');
    expect(result.iomadCompanyId).toBe('3'); // company WAS found — the id is known even though the write failed
    expect(repo.organisationCount).toBe(0);
    expect(repo.mappingCount).toBe(0);
  });

  it('rejects an empty/blank company code without ever calling the gateway — no Iomad call, no database write', async () => {
    const gateway = new FakeIomadGateway();
    const getCompanyByCodeSpy = vi.spyOn(gateway, 'getCompanyByCode');
    const repo = new FakeOrganisationSyncRepository();
    const service = new IomadCompanySyncService(gateway, repo);

    const result = await service.syncByCompanyCode('   ');

    expect(result).toMatchObject({ outcome: 'failed', errorCode: 'invalid_input', iomadCompanyId: null });
    expect(getCompanyByCodeSpy).not.toHaveBeenCalled();
    expect(repo.organisationCount).toBe(0);
  });

  it('NEVER marks other mappings stale — markMissingAsStale is not called by syncByCompanyCode at all', async () => {
    const gateway = new FakeIomadGateway();
    gateway.companies = [SHIKSHA];
    const repo = new FakeOrganisationSyncRepository();
    const service = new IomadCompanySyncService(gateway, repo);

    await service.syncByCompanyCode('MYGURU-SHIKSHA-001');
    await service.syncByCompanyCode('MYGURU-SHIKSHA-001'); // second call too

    expect(repo.markMissingAsStaleCallCount).toBe(0);
  });

  it('does not call listCompanies() — only the criteria-filtered getCompanyByCode() path is used', async () => {
    const gateway = new FakeIomadGateway();
    gateway.companies = [SHIKSHA];
    const listCompaniesSpy = vi.spyOn(gateway, 'listCompanies');
    const repo = new FakeOrganisationSyncRepository();
    const service = new IomadCompanySyncService(gateway, repo);

    await service.syncByCompanyCode('MYGURU-SHIKSHA-001');

    expect(listCompaniesSpy).not.toHaveBeenCalled();
  });

  it('never logs or returns the token, raw Iomad payload, address, custom fields, or unnecessary company metadata', async () => {
    const errorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
    const gateway = new FakeIomadGateway();
    gateway.getCompanyByCodeError = new IomadGatewayError('network_error', 'Could not reach the Iomad service.');
    const repo = new FakeOrganisationSyncRepository();
    const service = new IomadCompanySyncService(gateway, repo);

    const result = await service.syncByCompanyCode('MYGURU-SHIKSHA-001');

    expect(Object.keys(result).sort()).toEqual(['companyCode', 'errorCode', 'iomadCompanyId', 'outcome', 'timestamp'].sort());
    for (const call of errorSpy.mock.calls) {
      const serialized = JSON.stringify(call);
      expect(serialized).not.toContain('super-secret');
      expect(serialized).not.toContain('address');
      expect(serialized).not.toContain('custom1');
    }
    errorSpy.mockRestore();
  });
});
