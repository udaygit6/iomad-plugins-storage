import { describe, it, expect } from 'vitest';
import { _mappers } from '../SupabaseOrganisationSyncRepository.js';

describe('SupabaseOrganisationSyncRepository row mapping', () => {
  it('maps an organisation row to camelCase', () => {
    const mapped = _mappers.mapOrganisation({
      id: 'org-1',
      name: 'Acme Tutoring',
      type: 'unclassified',
      status: 'active',
      source: 'iomad_sync',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-02T00:00:00Z',
    });

    expect(mapped).toEqual({
      id: 'org-1',
      name: 'Acme Tutoring',
      type: 'unclassified',
      status: 'active',
      source: 'iomad_sync',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-02T00:00:00Z',
    });
  });

  it('maps a mapping row to camelCase, including null last_synced_at/last_error_code', () => {
    const mapped = _mappers.mapMapping({
      id: 'map-1',
      organisation_id: 'org-1',
      iomad_company_id: '42',
      sync_status: 'pending',
      last_synced_at: null,
      last_error_code: null,
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    });

    expect(mapped).toEqual({
      id: 'map-1',
      organisationId: 'org-1',
      iomadCompanyId: '42',
      syncStatus: 'pending',
      lastSyncedAt: null,
      lastErrorCode: null,
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
    });
  });

  it('maps a failed mapping row, preserving the safe error code', () => {
    const mapped = _mappers.mapMapping({
      id: 'map-2',
      organisation_id: 'org-2',
      iomad_company_id: '43',
      sync_status: 'failed',
      last_synced_at: null,
      last_error_code: 'network_error',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    });

    expect(mapped.syncStatus).toBe('failed');
    expect(mapped.lastErrorCode).toBe('network_error');
  });
});

describe('SupabaseOrganisationSyncRepository — sync_iomad_company() RPC row mapping', () => {
  const baseRpcRow = {
    organisation_id: 'org-1',
    organisation_name: 'Acme Tutoring',
    organisation_type: 'unclassified' as const,
    organisation_status: 'active' as const,
    organisation_source: 'iomad_sync' as const,
    organisation_created_at: '2026-01-01T00:00:00Z',
    organisation_updated_at: '2026-01-01T00:00:00Z',
    mapping_id: 'map-1',
    mapping_sync_status: 'synced' as const,
    mapping_last_synced_at: '2026-01-01T00:00:00Z',
    mapping_last_error_code: null,
    mapping_created_at: '2026-01-01T00:00:00Z',
    mapping_updated_at: '2026-01-01T00:00:00Z',
    was_created: true,
    name_changed: false,
  };

  it('reshapes a flattened RPC row into full organisation + mapping objects', () => {
    const result = _mappers.mapSyncCompanyRpcRow(baseRpcRow, '42');

    expect(result.organisation).toEqual({
      id: 'org-1',
      name: 'Acme Tutoring',
      type: 'unclassified',
      status: 'active',
      source: 'iomad_sync',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
    });
    expect(result.mapping).toEqual({
      id: 'map-1',
      organisationId: 'org-1',
      iomadCompanyId: '42',
      syncStatus: 'synced',
      lastSyncedAt: '2026-01-01T00:00:00Z',
      lastErrorCode: null,
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
    });
  });

  it('passes through wasCreated/nameChanged flags unchanged', () => {
    const created = _mappers.mapSyncCompanyRpcRow(baseRpcRow, '42');
    expect(created.wasCreated).toBe(true);
    expect(created.nameChanged).toBe(false);

    const renamed = _mappers.mapSyncCompanyRpcRow({ ...baseRpcRow, was_created: false, name_changed: true }, '42');
    expect(renamed.wasCreated).toBe(false);
    expect(renamed.nameChanged).toBe(true);
  });

  it('always maps a new organisation as unclassified, never inferring a business type', () => {
    const result = _mappers.mapSyncCompanyRpcRow(
      { ...baseRpcRow, organisation_name: 'Acme Corporate Franchise School Ltd' },
      '42',
    );
    expect(result.organisation.type).toBe('unclassified');
  });
});
