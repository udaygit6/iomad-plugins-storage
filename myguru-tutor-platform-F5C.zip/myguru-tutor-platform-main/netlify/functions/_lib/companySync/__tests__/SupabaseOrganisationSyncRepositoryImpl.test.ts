import { describe, it, expect, vi } from 'vitest';
import type { SupabaseClient } from '@supabase/supabase-js';
import { SupabaseOrganisationSyncRepository } from '../SupabaseOrganisationSyncRepository.js';

/**
 * Focused tests for the actual `SupabaseOrganisationSyncRepository`
 * implementation (not just its row-mapping helpers — see
 * `SupabaseOrganisationSyncRepository.test.ts` for those). Uses a
 * minimal mocked Supabase client — no real network call, no real
 * Supabase project.
 */

function baseRpcRow(overrides: Record<string, unknown> = {}) {
  return {
    organisation_id: 'org-1',
    organisation_name: 'Acme Tutoring',
    organisation_type: 'unclassified',
    organisation_status: 'active',
    organisation_source: 'iomad_sync',
    organisation_created_at: '2026-01-01T00:00:00Z',
    organisation_updated_at: '2026-01-01T00:00:00Z',
    mapping_id: 'map-1',
    mapping_sync_status: 'synced',
    mapping_last_synced_at: '2026-01-01T00:00:00Z',
    mapping_last_error_code: null,
    mapping_created_at: '2026-01-01T00:00:00Z',
    mapping_updated_at: '2026-01-01T00:00:00Z',
    was_created: true,
    name_changed: false,
    ...overrides,
  };
}

function createMockSupabase() {
  const rpcMock = vi.fn();
  const eqMock = vi.fn();
  const updateMock = vi.fn(() => ({ eq: eqMock }));
  const fromMock = vi.fn(() => ({ update: updateMock }));
  const client = { rpc: rpcMock, from: fromMock } as unknown as SupabaseClient;
  return { client, rpcMock, fromMock, updateMock, eqMock };
}

describe('SupabaseOrganisationSyncRepository.syncCompany — real implementation, mocked client', () => {
  it('calls rpc("sync_iomad_company", { p_iomad_company_id, p_display_name }) exactly once, with exactly the given input', async () => {
    const { client, rpcMock } = createMockSupabase();
    rpcMock.mockResolvedValue({ data: [baseRpcRow()], error: null });

    const repo = new SupabaseOrganisationSyncRepository(client);
    await repo.syncCompany({ iomadCompanyId: '42', displayName: 'Acme Tutoring' });

    expect(rpcMock).toHaveBeenCalledTimes(1);
    expect(rpcMock).toHaveBeenCalledWith('sync_iomad_company', {
      p_iomad_company_id: '42',
      p_display_name: 'Acme Tutoring',
    });
  });

  it('does NOT call .from() at all — the RPC remains the only write path (no direct organisations/iomad_company_mappings insert or update)', async () => {
    const { client, rpcMock, fromMock } = createMockSupabase();
    rpcMock.mockResolvedValue({ data: [baseRpcRow()], error: null });

    const repo = new SupabaseOrganisationSyncRepository(client);
    await repo.syncCompany({ iomadCompanyId: '42', displayName: 'Acme Tutoring' });

    expect(fromMock).not.toHaveBeenCalled();
  });

  it('maps a returned RPC row into the correct organisation, mapping, and wasCreated/nameChanged flags', async () => {
    const { client, rpcMock } = createMockSupabase();
    rpcMock.mockResolvedValue({ data: [baseRpcRow({ was_created: false, name_changed: true })], error: null });

    const repo = new SupabaseOrganisationSyncRepository(client);
    const result = await repo.syncCompany({ iomadCompanyId: '42', displayName: 'Acme Tutoring Ltd' });

    expect(result.organisation).toEqual({
      id: 'org-1',
      name: 'Acme Tutoring',
      type: 'unclassified',
      status: 'active',
      source: 'iomad_sync',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
    });
    expect(result.mapping).toEqual({
      id: 'map-1',
      organisationId: 'org-1',
      iomadCompanyId: '42',
      syncStatus: 'synced',
      lastSyncedAt: '2026-01-01T00:00:00Z',
      lastErrorCode: null,
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
    });
    expect(result.wasCreated).toBe(false);
    expect(result.nameChanged).toBe(true);
  });

  it('also accepts a single-object (non-array) RPC response, not just an array', async () => {
    const { client, rpcMock } = createMockSupabase();
    rpcMock.mockResolvedValue({ data: baseRpcRow(), error: null });

    const repo = new SupabaseOrganisationSyncRepository(client);
    const result = await repo.syncCompany({ iomadCompanyId: '42', displayName: 'Acme Tutoring' });

    expect(result.organisation.id).toBe('org-1');
  });

  it('propagates a safe error when the RPC call itself returns an error, without leaking raw DB detail', async () => {
    const { client, rpcMock } = createMockSupabase();
    rpcMock.mockResolvedValue({
      data: null,
      error: {
        code: '23505',
        message:
          'duplicate key value violates unique constraint "iomad_company_mappings_iomad_company_id_key" DETAIL: Key (iomad_company_id)=(42) already exists.',
      },
    });

    const repo = new SupabaseOrganisationSyncRepository(client);
    try {
      await repo.syncCompany({ iomadCompanyId: '42', displayName: 'Acme Tutoring' });
      throw new Error('expected syncCompany to throw');
    } catch (err) {
      expect((err as Error).message).toContain('23505');
      expect((err as Error).message).not.toContain('duplicate key value violates');
      expect((err as Error).message).not.toContain('DETAIL');
      expect((err as Error).message).not.toContain('already exists');
    }
  });

  it('handles an empty-array RPC response safely — throws a safe, generic error, not a crash on undefined', async () => {
    const { client, rpcMock } = createMockSupabase();
    rpcMock.mockResolvedValue({ data: [], error: null });

    const repo = new SupabaseOrganisationSyncRepository(client);
    await expect(repo.syncCompany({ iomadCompanyId: '42', displayName: 'Acme Tutoring' })).rejects.toThrow(
      'empty_response',
    );
  });

  it('handles a null RPC data response safely — same generic empty-response error', async () => {
    const { client, rpcMock } = createMockSupabase();
    rpcMock.mockResolvedValue({ data: null, error: null });

    const repo = new SupabaseOrganisationSyncRepository(client);
    await expect(repo.syncCompany({ iomadCompanyId: '42', displayName: 'Acme Tutoring' })).rejects.toThrow(
      'empty_response',
    );
  });
});

describe('SupabaseOrganisationSyncRepository.markFailed — real implementation, mocked client', () => {
  it('targets the correct table/update/filter: iomad_company_mappings, sync_status=failed + last_error_code, eq iomad_company_id', async () => {
    const { client, fromMock, updateMock, eqMock } = createMockSupabase();
    eqMock.mockResolvedValue({ error: null });

    const repo = new SupabaseOrganisationSyncRepository(client);
    await repo.markFailed({ iomadCompanyId: '42', errorCode: 'network_error' });

    expect(fromMock).toHaveBeenCalledWith('iomad_company_mappings');
    expect(updateMock).toHaveBeenCalledWith({ sync_status: 'failed', last_error_code: 'network_error' });
    expect(eqMock).toHaveBeenCalledWith('iomad_company_id', '42');
  });

  it('does not throw when Supabase resolves normally with an error field (the standard failure-reporting path) — processing can continue', async () => {
    const { client, eqMock } = createMockSupabase();
    eqMock.mockResolvedValue({
      error: { code: '42501', message: 'permission denied for table iomad_company_mappings' },
    });

    const repo = new SupabaseOrganisationSyncRepository(client);
    await expect(repo.markFailed({ iomadCompanyId: '42', errorCode: 'network_error' })).resolves.toBeUndefined();
  });

  it('never propagates raw database error detail into logs — only a safe DB error code', async () => {
    const { client, eqMock } = createMockSupabase();
    eqMock.mockResolvedValue({
      error: {
        code: '42501',
        message: 'permission denied for table iomad_company_mappings DETAIL: something sensitive appears here',
      },
    });
    const errorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});

    const repo = new SupabaseOrganisationSyncRepository(client);
    await repo.markFailed({ iomadCompanyId: '42', errorCode: 'network_error' });

    for (const call of errorSpy.mock.calls) {
      const serialized = JSON.stringify(call);
      expect(serialized).not.toContain('permission denied');
      expect(serialized).not.toContain('something sensitive');
    }
    errorSpy.mockRestore();
  });

  it('resolves without throwing even when the underlying Supabase call itself throws (genuine client/network exception) — no exception escapes', async () => {
    const { client, eqMock } = createMockSupabase();
    eqMock.mockRejectedValue(new TypeError('fetch failed: ECONNRESET'));
    const errorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});

    const repo = new SupabaseOrganisationSyncRepository(client);
    await expect(repo.markFailed({ iomadCompanyId: '42', errorCode: 'network_error' })).resolves.toBeUndefined();

    errorSpy.mockRestore();
  });

  it('does not log anything on a clean, error-free update', async () => {
    const { client, eqMock } = createMockSupabase();
    eqMock.mockResolvedValue({ error: null });
    const errorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});

    const repo = new SupabaseOrganisationSyncRepository(client);
    await repo.markFailed({ iomadCompanyId: '42', errorCode: 'network_error' });

    expect(errorSpy).not.toHaveBeenCalled();
    errorSpy.mockRestore();
  });
});
