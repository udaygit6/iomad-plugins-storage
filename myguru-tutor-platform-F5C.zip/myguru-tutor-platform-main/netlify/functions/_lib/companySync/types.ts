/**
 * F4 — platform-side company synchronisation domain types.
 *
 * These mirror `docs/SYSTEM_OF_RECORD.md`'s F1 `Organisation` and
 * `IomadCompanyMapping` concepts, now actually persisted (see
 * `supabase/migrations/0015_organisation_iomad_company_sync.sql`).
 * Server-only — never imported from `src/` (same "zero import path back
 * into src/" rule as the rest of `netlify/functions/_lib/`).
 *
 * Deliberately minimal per the F4 brief: "Do NOT over-model yet." Keeps
 * the platform-owned `Organisation` concept separate from raw Iomad
 * company data — the mapping table is the seam between them, not a merge
 * of the two.
 */

export type OrganisationType = 'unclassified' | 'myguru_franchise' | 'corporate' | 'school_future' | 'internal';

export type OrganisationStatus = 'active' | 'suspended' | 'inactive';

/** How this organisation record came to exist. `iomad_sync` for every F4
 * row — `manual` is reserved for a future admin-created-organisation
 * flow that does not exist yet. */
export type OrganisationSource = 'iomad_sync' | 'manual';

export interface Organisation {
  id: string;
  name: string;
  /** New organisations discovered generically through Iomad F4 sync are
   * always created `'unclassified'` — F4 has no verified way to infer
   * franchise/corporate/school business classification from Iomad
   * company data, and does not attempt to (no name/email/ID heuristics).
   * Classification is a deliberate later step via an explicit
   * provisioning or admin workflow, not part of sync. */
  type: OrganisationType;
  status: OrganisationStatus;
  source: OrganisationSource;
  createdAt: string;
  updatedAt: string;
}

export type MappingSyncStatus = 'pending' | 'synced' | 'failed' | 'stale';

/**
 * `iomadCompanyId` is the external identity — never email/name (F1 Ground
 * rule 2 in `docs/SYSTEM_OF_RECORD.md`). `lastErrorCode` is always one of
 * `IomadErrorCode` (see `../iomad/IomadErrors.ts`) or a small
 * company-sync-specific code — never a raw message, never a stack trace.
 */
export interface IomadCompanyMapping {
  id: string;
  organisationId: string;
  iomadCompanyId: string;
  syncStatus: MappingSyncStatus;
  lastSyncedAt: string | null;
  lastErrorCode: string | null;
  createdAt: string;
  updatedAt: string;
}

/**
 * Summary of one bulk sync run (`sync()`). No PII, no raw Iomad payload —
 * just counts and a safe top-level error code for the case where the
 * fetch itself failed (see `IomadCompanySyncService.sync()`).
 */
export interface CompanySyncResult {
  fetched: number;
  created: number;
  updated: number;
  unchanged: number;
  failed: number;
  timestamp: string;
  /** Only set when `IomadGateway.listCompanies()` itself failed — the run
   * never got as far as processing individual companies. One of
   * `IomadErrorCode` (see `../iomad/IomadErrors.ts`). */
  topLevelError?: string;
}

/**
 * Summary of a single-company sync run (`syncByCompanyCode` — F4C).
 * Intentionally minimal and safe to print/log as-is: no PII, no raw
 * Iomad payload, no address/custom fields, no token.
 */
export interface SingleCompanySyncResult {
  companyCode: string;
  /** The Iomad numeric company id (as a string), or null if the company
   * was not found, or if the fetch itself failed before any id was
   * known. */
  iomadCompanyId: string | null;
  outcome: 'created' | 'updated' | 'unchanged' | 'not_found' | 'failed';
  timestamp: string;
  /** Only set when outcome === 'failed'. One of `IomadErrorCode` (see
   * ../iomad/IomadErrors.ts) or 'invalid_input'/'unknown_error' — never a
   * raw message. */
  errorCode?: string;
}
