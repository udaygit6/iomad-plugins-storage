import type { IomadGateway } from '../iomad/IomadRestGateway.js';
import { IomadGatewayError } from '../iomad/IomadErrors.js';
import type { OrganisationCourseSyncRepository } from './OrganisationCourseSyncRepository.js';
import type { CourseSyncResult } from './types.js';

/**
 * F5B — Iomad organisation-course synchronisation.
 *
 *   IomadGateway.listCompanyCourses(iomadCompanyId)   (F5A, live-verified)
 *     → normalised { externalCourseId, fullName }
 *     → IomadGateway.getCourseSettings(courseIds)     (F5A, live-verified)
 *     → normalised { licensed, shared, validLengthDays, ... }
 *     → OrganisationCourseSyncRepository.syncCourse() (atomic RPC, F5B)
 *     → CourseSyncResult
 *
 * Builds directly on F5A's live-verified gateway — does not duplicate
 * its transport. Only ever calls `listCompanyCourses()` and
 * `getCourseSettings()` on `IomadGateway`; never any Iomad write
 * function.
 *
 * Domain rule (F5B): a course is global, an allocation is
 * tenant-specific. This service never deletes a course or its mapping —
 * a course missing from a later sync only marks THIS organisation's
 * allocation `stale` (via `repository.markMissingAsStale`), leaving the
 * course and any other organisation's allocation to it untouched.
 *
 * Atomicity: `OrganisationCourseSyncRepository.syncCourse()` performs the
 * find-or-create-course + rename + upsert-allocation step as one atomic
 * database transaction (see `sync_iomad_company_course()`), so a failure
 * partway through never leaves a half-created course, mapping, or
 * allocation.
 *
 * Pre-deployment review fixes:
 * (1) A course allocated but missing a `getCourseSettings()` entry is
 *     NEVER synced with fabricated `{ licensed: false, shared: false,
 *     ...: 0 }` defaults — a missing entry means unknown/incomplete
 *     upstream data, not "Iomad said false/zero". `syncCourse()` is
 *     simply not called for that course this run; any existing
 *     allocation's settings are left completely untouched, the course is
 *     reported `failed` with the safe code `missing_course_settings`,
 *     and — critically — its id still goes into the stale-marking
 *     "seen" list, since it IS still allocated.
 * (2) An existing allocation whose `sync_status` transitions back to
 *     `synced` from anything else (`stale`, `failed`) is reported
 *     `updated`, even if its settings values are byte-for-byte identical
 *     to what was already stored — see `allocationStatusChanged` from
 *     `syncCourse()`. This file has no multi-step orchestration to get wrong.
 */
export class IomadCompanyCourseSyncService {
  private readonly gateway: IomadGateway;
  private readonly repository: OrganisationCourseSyncRepository;

  constructor(gateway: IomadGateway, repository: OrganisationCourseSyncRepository) {
    this.gateway = gateway;
    this.repository = repository;
  }

  async syncOrganisationCourses(
    organisationId: string,
    iomadCompanyId: string,
    correlationId?: string,
  ): Promise<CourseSyncResult> {
    const timestamp = new Date().toISOString();

    let allocations: Array<{ externalCourseId: string; fullName: string }>;
    try {
      // F5A live-verified: criteria[0][companyid]/criteria[0][shared]=0.
      allocations = await this.gateway.listCompanyCourses(iomadCompanyId);
    } catch (err) {
      const code = errorCodeOf(err);
      logSafe('fetch_courses_failed', { iomadCompanyId, code, correlationId });
      return {
        companyId: iomadCompanyId,
        fetched: 0,
        created: 0,
        updated: 0,
        unchanged: 0,
        failed: 0,
        stale: 0,
        timestamp,
        topLevelError: code,
      };
    }

    const result: CourseSyncResult = {
      companyId: iomadCompanyId,
      fetched: allocations.length,
      created: 0,
      updated: 0,
      unchanged: 0,
      failed: 0,
      stale: 0,
      timestamp,
    };

    if (allocations.length === 0) {
      // Zero-course is a VALID SUCCESS state (F5A, live-verified) — no
      // getCourseSettings() call is made (nothing to fetch settings
      // for). This IS a confirmed complete snapshot for this specific
      // organisation (the company-courses call succeeded and scoped to
      // exactly this company), so existing allocations are marked stale
      // — unlike F4's bulk company sync, which skips stale-marking on an
      // empty result because that call is NOT scoped to one company and
      // an empty result there is more likely a fetch problem than a
      // genuine "zero" state.
      try {
        result.stale = await this.repository.markMissingAsStale(organisationId, []);
      } catch (err) {
        logSafe('stale_marking_failed', { iomadCompanyId, code: errorCodeOf(err), correlationId });
      }
      return result;
    }

    const courseIds = allocations.map((a) => a.externalCourseId);

    let settingsByCourseId: Map<string, { licensed: boolean; shared: boolean; validLengthDays: number; warnExpireDays: number; warnCompletionDays: number; notifyPeriodDays: number }>;
    try {
      // F5A live-verified: NO course-id parameter is sent; the full
      // available settings collection is fetched and filtered locally
      // by IomadRestGateway.getCourseSettings() itself.
      const settingsList = await this.gateway.getCourseSettings(courseIds);
      settingsByCourseId = new Map(settingsList.map((s) => [s.externalCourseId, s]));
    } catch (err) {
      // The settings fetch failed entirely — every allocated course for
      // this run is reported failed; no partial DB write is attempted
      // for any of them without a settings snapshot to write.
      const code = errorCodeOf(err);
      logSafe('fetch_settings_failed', { iomadCompanyId, code, correlationId });
      result.failed = allocations.length;
      return result;
    }

    const seenIds: string[] = [];

    for (const allocation of allocations) {
      // A duplicate external course id within the SAME batch must not be
      // synced twice — same defensive posture as F4's company sync.
      if (seenIds.includes(allocation.externalCourseId)) {
        result.unchanged++;
        continue;
      }
      // Kept in the seen list unconditionally — this course IS still
      // allocated (per the just-fetched listCompanyCourses() result)
      // even if its settings entry below turns out to be missing. It
      // must never be marked stale merely because get_course_info didn't
      // return a settings row for it this run (review fix #1).
      seenIds.push(allocation.externalCourseId);

      const settings = settingsByCourseId.get(allocation.externalCourseId);

      if (!settings) {
        // Review fix #1: a missing get_course_info entry means UNKNOWN /
        // incomplete upstream data — it does NOT mean Iomad explicitly
        // returned false/zero. Fabricating { licensed: false, shared:
        // false, ...: 0 } and persisting it would silently overwrite
        // known-good previously-synced state (e.g. licensed: true,
        // validLengthDays: 365) with false/zero. So: do NOT call
        // syncCourse at all for this course this run — any existing
        // allocation row's settings are left completely untouched.
        // Report it as failed/incomplete with a safe, specific error
        // code, and best-effort mark the existing allocation (if any)
        // failed — markFailed only ever touches sync_status/
        // last_error_code, never the settings columns, so it cannot
        // corrupt previously-stored values either.
        result.failed++;
        logSafe('missing_course_settings', {
          iomadCourseId: allocation.externalCourseId,
          code: 'missing_course_settings',
          correlationId,
        });
        await this.repository.markFailed({
          organisationId,
          iomadCourseId: allocation.externalCourseId,
          errorCode: 'missing_course_settings',
        });
        continue;
      }

      try {
        const { wasCourseCreated, courseNameChanged, wasAllocationCreated, allocationSettingsChanged, allocationStatusChanged } =
          await this.repository.syncCourse({
            organisationId,
            iomadCourseId: allocation.externalCourseId,
            courseName: allocation.fullName,
            licensed: settings.licensed,
            shared: settings.shared,
            validLengthDays: settings.validLengthDays,
            warnExpireDays: settings.warnExpireDays,
            warnCompletionDays: settings.warnCompletionDays,
            notifyPeriodDays: settings.notifyPeriodDays,
          });

        if (wasCourseCreated || wasAllocationCreated) {
          result.created++;
        } else if (courseNameChanged || allocationSettingsChanged || allocationStatusChanged) {
          // Review fix #2: a status transition (e.g. stale/failed back
          // to synced) is itself a meaningful change, even when the
          // settings VALUES are byte-for-byte identical to what was
          // already stored.
          result.updated++;
        } else {
          result.unchanged++;
        }
      } catch (err) {
        result.failed++;
        const code = errorCodeOf(err);
        logSafe('course_sync_failed', { iomadCourseId: allocation.externalCourseId, code, correlationId });
        // Best-effort — markFailed never throws (see its doc comment).
        await this.repository.markFailed({
          organisationId,
          iomadCourseId: allocation.externalCourseId,
          errorCode: code,
        });
      }
    }

    try {
      result.stale = await this.repository.markMissingAsStale(organisationId, seenIds);
    } catch (err) {
      logSafe('stale_marking_failed', { iomadCompanyId, code: errorCodeOf(err), correlationId });
    }

    return result;
  }
}

function errorCodeOf(err: unknown): string {
  if (err instanceof IomadGatewayError) return err.code;
  return 'unknown_error';
}

/**
 * Server-log-only. Never PII, never a raw Iomad payload, never a course
 * fullName — only the Iomad company/course external id, a safe
 * status/code, and an optional correlation id.
 */
function logSafe(
  event: string,
  detail: { iomadCompanyId?: string; iomadCourseId?: string; code: string; correlationId?: string },
): void {
  console.error('[course-sync]', { event, ...detail });
}
