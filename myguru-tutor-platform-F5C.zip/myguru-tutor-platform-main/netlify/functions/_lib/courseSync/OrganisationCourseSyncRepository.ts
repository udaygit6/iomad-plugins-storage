/**
 * Persistence boundary for course sync. `IomadCompanyCourseSyncService`
 * depends only on this interface, not on Supabase directly — makes the
 * sync algorithm fully unit-testable with an in-memory fake and keeps the
 * door open for a different persistence layer later.
 */
export interface OrganisationCourseSyncRepository {
  /**
   * Atomically find-or-create the course+mapping pair for one Iomad
   * course, updating the course's name if `courseName` differs from
   * what's stored, and upserting the (organisation, course) allocation
   * with the given settings snapshot — all in a single database
   * transaction (see `sync_iomad_company_course()` in
   * `supabase/migrations/0016_course_persistence_and_organisation_allocations.sql`).
   * Never leaves a half-created course/mapping/allocation if any part
   * fails, and is safe to call concurrently for the same
   * `iomadCourseId` — repeated/concurrent calls reuse the same course
   * rather than creating duplicates. The SAME `iomadCourseId` synced for
   * a DIFFERENT `organisationId` creates a second, independent
   * allocation row against the same course (the multi-tenant case).
   */
  syncCourse(input: {
    organisationId: string;
    iomadCourseId: string;
    courseName: string;
    licensed: boolean;
    shared: boolean;
    validLengthDays: number;
    warnExpireDays: number;
    warnCompletionDays: number;
    notifyPeriodDays: number;
  }): Promise<{
    courseId: string;
    allocationId: string;
    /** True if this call created a brand-new course+mapping pair (first
     * time ANY organisation has synced this Iomad course). */
    wasCourseCreated: boolean;
    /** True if an existing course's name was changed by this call. */
    courseNameChanged: boolean;
    /** True if this call created a brand-new allocation row for THIS
     * organisation (independent of whether the course itself was new —
     * a second organisation allocating an already-known course is
     * `wasCourseCreated: false, wasAllocationCreated: true`). */
    wasAllocationCreated: boolean;
    /** True if an existing allocation's settings snapshot (licensed,
     * shared, or any day-count field) changed. */
    allocationSettingsChanged: boolean;
    /** True if the allocation's PREVIOUS `sync_status` was anything
     * other than `'synced'` (e.g. `'stale'` or `'failed'`) and this call
     * brought it back to `'synced'` — a meaningful change even when
     * `allocationSettingsChanged` is false (identical settings
     * reappearing after being stale/failed). Kept separate from
     * `allocationSettingsChanged` so the two distinct reasons for an
     * "updated" outcome stay distinguishable. */
    allocationStatusChanged: boolean;
  }>;

  /** Record a safe failure for one (organisation, course) pairing.
   * Best-effort: if no mapping/allocation exists yet, this is a safe
   * no-op — there is nothing to mark. Never throws; the caller does not
   * need to further guard this call. */
  markFailed(params: { organisationId: string; iomadCourseId: string; errorCode: string }): Promise<void>;

  /**
   * After a full `listCompanyCourses()` pass for one organisation, mark
   * every allocation for that organisation whose course is NOT in
   * `seenIomadCourseIds` as `stale` (never deleted — the course and its
   * mapping are untouched; F5B's "course is global, allocation is
   * tenant-specific" domain rule). Returns the count marked stale.
   */
  markMissingAsStale(organisationId: string, seenIomadCourseIds: string[]): Promise<number>;
}
