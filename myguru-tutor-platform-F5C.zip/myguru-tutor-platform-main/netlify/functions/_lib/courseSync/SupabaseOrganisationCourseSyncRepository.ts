import type { SupabaseClient } from '@supabase/supabase-js';
import type { OrganisationCourseSyncRepository } from './OrganisationCourseSyncRepository.js';

/**
 * Supabase-backed `OrganisationCourseSyncRepository`. Always constructed
 * with an already-authenticated service-role client
 * (`getServerSupabaseClient()` from `../supabaseServerClient.js`).
 *
 * `syncCourse()` calls the `sync_iomad_company_course()` Postgres
 * function (`supabase/migrations/0016_course_persistence_and_organisation_allocations.sql`)
 * — the whole find-or-create-course + rename + upsert-allocation
 * operation runs as one atomic database transaction, the same pattern
 * `SupabaseOrganisationSyncRepository.syncCompany()` (F4) already
 * established. Writes bypass RLS via the service-role key — see 0016 for
 * the policy that grants no anon/authenticated write access at all, and
 * no EXECUTE on either RPC to anything but `service_role`.
 */

interface SyncCourseRpcRow {
  course_id: string;
  course_name: string;
  course_status: 'active' | 'inactive';
  mapping_id: string;
  allocation_id: string;
  was_course_created: boolean;
  course_name_changed: boolean;
  was_allocation_created: boolean;
  allocation_settings_changed: boolean;
  allocation_status_changed: boolean;
}

export class SupabaseOrganisationCourseSyncRepository implements OrganisationCourseSyncRepository {
  private readonly supabase: SupabaseClient;

  constructor(supabase: SupabaseClient) {
    this.supabase = supabase;
  }

  async syncCourse(input: {
    organisationId: string;
    iomadCourseId: string;
    courseName: string;
    licensed: boolean;
    shared: boolean;
    validLengthDays: number;
    warnExpireDays: number;
    warnCompletionDays: number;
    notifyPeriodDays: number;
  }): Promise<{
    courseId: string;
    allocationId: string;
    wasCourseCreated: boolean;
    courseNameChanged: boolean;
    wasAllocationCreated: boolean;
    allocationSettingsChanged: boolean;
    allocationStatusChanged: boolean;
  }> {
    const { data, error } = await this.supabase.rpc('sync_iomad_company_course', {
      p_organisation_id: input.organisationId,
      p_iomad_course_id: input.iomadCourseId,
      p_course_name: input.courseName,
      p_licensed: input.licensed,
      p_shared: input.shared,
      p_valid_length_days: input.validLengthDays,
      p_warn_expire_days: input.warnExpireDays,
      p_warn_completion_days: input.warnCompletionDays,
      p_notify_period_days: input.notifyPeriodDays,
    });

    if (error) throw new Error(`syncCourse failed: ${error.code ?? 'unknown'}`);

    const row = (Array.isArray(data) ? data[0] : data) as SyncCourseRpcRow | undefined;
    if (!row) throw new Error('syncCourse failed: empty_response');

    return {
      courseId: row.course_id,
      allocationId: row.allocation_id,
      wasCourseCreated: row.was_course_created,
      courseNameChanged: row.course_name_changed,
      wasAllocationCreated: row.was_allocation_created,
      allocationSettingsChanged: row.allocation_settings_changed,
      allocationStatusChanged: row.allocation_status_changed,
    };
  }

  async markFailed(params: { organisationId: string; iomadCourseId: string; errorCode: string }): Promise<void> {
    // Best-effort, deliberately never throws into the caller (see the
    // interface doc comment). Two straightforward table operations
    // (look up the course by iomad id, then update the allocation) — not
    // an RPC, matching the same posture as F4's markFailed. A no-op if
    // either the mapping or the allocation doesn't exist yet.
    try {
      const { data: mapping, error: mappingError } = await this.supabase
        .from('iomad_course_mappings')
        .select('course_id')
        .eq('iomad_course_id', params.iomadCourseId)
        .maybeSingle();

      if (mappingError) {
        console.error('[course-sync] markFailed mapping lookup returned an error', {
          iomadCourseId: params.iomadCourseId,
          dbErrorCode: mappingError.code ?? 'unknown',
        });
        return;
      }
      if (!mapping) return; // no mapping yet — nothing to mark, safe no-op

      const { error } = await this.supabase
        .from('organisation_course_allocations')
        .update({ sync_status: 'failed', last_error_code: params.errorCode })
        .eq('organisation_id', params.organisationId)
        .eq('course_id', (mapping as { course_id: string }).course_id);

      if (error) {
        console.error('[course-sync] markFailed allocation update returned an error', {
          iomadCourseId: params.iomadCourseId,
          dbErrorCode: error.code ?? 'unknown',
        });
      }
    } catch {
      console.error('[course-sync] markFailed threw', { iomadCourseId: params.iomadCourseId });
    }
  }

  async markMissingAsStale(organisationId: string, seenIomadCourseIds: string[]): Promise<number> {
    const { data, error } = await this.supabase.rpc('mark_stale_organisation_course_allocations', {
      p_organisation_id: organisationId,
      p_seen_iomad_course_ids: seenIomadCourseIds,
    });
    if (error) throw new Error(`markMissingAsStale failed: ${error.code ?? 'unknown'}`);
    return typeof data === 'number' ? data : 0;
  }
}
