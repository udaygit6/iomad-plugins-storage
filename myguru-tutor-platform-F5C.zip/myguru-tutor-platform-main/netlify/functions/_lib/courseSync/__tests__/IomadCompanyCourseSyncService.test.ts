import { describe, it, expect, vi } from 'vitest';
import { IomadCompanyCourseSyncService } from '../IomadCompanyCourseSyncService.js';
import { IomadGatewayError } from '../../iomad/IomadErrors.js';
import type {
  IomadGateway,
  IomadCompanySummary,
  CompanyCourseAllocation,
  IomadCourseSettings,
} from '../../iomad/IomadRestGateway.js';
import type { OrganisationCourseSyncRepository } from '../OrganisationCourseSyncRepository.js';

const ORG_ID = 'org-jupiter-1';
const COMPANY_ID = '4';

/** Minimal fake IomadGateway — only listCompanyCourses()/getCourseSettings() matter here. */
class FakeIomadGateway implements IomadGateway {
  courseAllocations: CompanyCourseAllocation[] = [];
  courseSettings: IomadCourseSettings[] = [];
  listCompanyCoursesError: Error | null = null;
  getCourseSettingsError: Error | null = null;

  async listCompanies(): Promise<IomadCompanySummary[]> {
    return [];
  }
  async getCompany(): Promise<IomadCompanySummary | null> {
    return null;
  }
  async getCompanyByCode(): Promise<IomadCompanySummary | null> {
    return null;
  }
  async listCompanyCourses(): Promise<CompanyCourseAllocation[]> {
    if (this.listCompanyCoursesError) throw this.listCompanyCoursesError;
    return this.courseAllocations;
  }
  async getCourse() {
    return null;
  }
  async getCourseSettings(): Promise<IomadCourseSettings[]> {
    if (this.getCourseSettingsError) throw this.getCourseSettingsError;
    return this.courseSettings;
  }
}

const DEFAULT_SETTINGS = {
  licensed: false,
  shared: false,
  validLengthDays: 0,
  warnExpireDays: 0,
  warnCompletionDays: 0,
  notifyPeriodDays: 0,
};

type FakeAllocation = { id: string; organisationId: string; courseId: string; syncStatus: 'pending' | 'synced' | 'failed' | 'stale' } & typeof DEFAULT_SETTINGS;

/** In-memory fake repository, modelling the atomic sync_iomad_company_course RPC (including the pre-deployment review fix: allocation_status_changed). */
class FakeOrganisationCourseSyncRepository implements OrganisationCourseSyncRepository {
  private courses = new Map<string, { id: string; name: string }>(); // keyed by course id
  private byIomadCourseId = new Map<string, string>(); // iomadCourseId -> course id
  private allocations = new Map<string, FakeAllocation>(); // keyed by allocation id
  private byOrgCourse = new Map<string, string>(); // `${organisationId}:${courseId}` -> allocation id
  private idCounter = 0;
  failSyncForIomadCourseId: string | null = null;

  private nextId(prefix: string): string {
    this.idCounter += 1;
    return `${prefix}-${this.idCounter}`;
  }

  async syncCourse(input: {
    organisationId: string;
    iomadCourseId: string;
    courseName: string;
    licensed: boolean;
    shared: boolean;
    validLengthDays: number;
    warnExpireDays: number;
    warnCompletionDays: number;
    notifyPeriodDays: number;
  }) {
    if (this.failSyncForIomadCourseId === input.iomadCourseId) {
      throw new Error('simulated syncCourse failure');
    }

    let courseId = this.byIomadCourseId.get(input.iomadCourseId);
    let wasCourseCreated = false;
    let courseNameChanged = false;

    if (!courseId) {
      courseId = this.nextId('course');
      this.courses.set(courseId, { id: courseId, name: input.courseName });
      this.byIomadCourseId.set(input.iomadCourseId, courseId);
      wasCourseCreated = true;
    } else {
      const course = this.courses.get(courseId)!;
      if (course.name !== input.courseName) {
        course.name = input.courseName;
        courseNameChanged = true;
      }
    }

    const allocKey = `${input.organisationId}:${courseId}`;
    let allocationId = this.byOrgCourse.get(allocKey);
    let wasAllocationCreated = false;
    let allocationSettingsChanged = false;
    let allocationStatusChanged = false;

    const newSettings = {
      licensed: input.licensed,
      shared: input.shared,
      validLengthDays: input.validLengthDays,
      warnExpireDays: input.warnExpireDays,
      warnCompletionDays: input.warnCompletionDays,
      notifyPeriodDays: input.notifyPeriodDays,
    };

    if (!allocationId) {
      allocationId = this.nextId('alloc');
      this.allocations.set(allocationId, {
        id: allocationId,
        organisationId: input.organisationId,
        courseId,
        syncStatus: 'synced',
        ...newSettings,
      });
      this.byOrgCourse.set(allocKey, allocationId);
      wasAllocationCreated = true;
    } else {
      const existing = this.allocations.get(allocationId)!;
      const changed =
        existing.licensed !== newSettings.licensed ||
        existing.shared !== newSettings.shared ||
        existing.validLengthDays !== newSettings.validLengthDays ||
        existing.warnExpireDays !== newSettings.warnExpireDays ||
        existing.warnCompletionDays !== newSettings.warnCompletionDays ||
        existing.notifyPeriodDays !== newSettings.notifyPeriodDays;
      if (changed) {
        Object.assign(existing, newSettings);
        allocationSettingsChanged = true;
      }
      // Review fix #2: a status transition back to 'synced' is itself a
      // change, independent of whether the settings values changed.
      allocationStatusChanged = existing.syncStatus !== 'synced';
      existing.syncStatus = 'synced';
    }

    return {
      courseId,
      allocationId,
      wasCourseCreated,
      courseNameChanged,
      wasAllocationCreated,
      allocationSettingsChanged,
      allocationStatusChanged,
    };
  }

  async markFailed(params: { organisationId: string; iomadCourseId: string; errorCode: string }): Promise<void> {
    // Mirrors the real repository's best-effort semantics: only ever
    // touches sync_status — never the settings columns, so it can never
    // corrupt previously-stored true/non-zero values (review fix #1).
    const courseId = this.byIomadCourseId.get(params.iomadCourseId);
    if (!courseId) return; // no course/mapping yet — safe no-op
    const allocationId = this.byOrgCourse.get(`${params.organisationId}:${courseId}`);
    if (!allocationId) return; // no allocation yet — safe no-op
    const allocation = this.allocations.get(allocationId);
    if (allocation) allocation.syncStatus = 'failed';
  }

  async markMissingAsStale(organisationId: string, seenIomadCourseIds: string[]): Promise<number> {
    let count = 0;
    for (const [allocKey, allocationId] of this.byOrgCourse.entries()) {
      const [orgId, courseId] = allocKey.split(':');
      if (orgId !== organisationId) continue;
      const iomadCourseId = [...this.byIomadCourseId.entries()].find(([, cId]) => cId === courseId)?.[0];
      if (iomadCourseId && seenIomadCourseIds.includes(iomadCourseId)) continue;
      const alloc = this.allocations.get(allocationId);
      if (alloc && (alloc.syncStatus === 'synced' || alloc.syncStatus === 'pending')) {
        alloc.syncStatus = 'stale';
        count++;
      }
    }
    return count;
  }

  // Test helpers.
  getCourseByIomadId(iomadCourseId: string) {
    const courseId = this.byIomadCourseId.get(iomadCourseId);
    return courseId ? this.courses.get(courseId) : undefined;
  }
  getAllocation(organisationId: string, iomadCourseId: string) {
    const courseId = this.byIomadCourseId.get(iomadCourseId);
    if (!courseId) return undefined;
    const allocationId = this.byOrgCourse.get(`${organisationId}:${courseId}`);
    return allocationId ? this.allocations.get(allocationId) : undefined;
  }
  get courseCount(): number {
    return this.courses.size;
  }
  get allocationCount(): number {
    return this.allocations.size;
  }
}

describe('IomadCompanyCourseSyncService.syncOrganisationCourses', () => {
  it('FIRST SYNC: creates course, mapping (implicit), and allocation — outcome created', async () => {
    const gateway = new FakeIomadGateway();
    gateway.courseAllocations = [{ externalCourseId: '4', fullName: 'Jupiter Test Mathematics' }];
    gateway.courseSettings = [{ externalCourseId: '4', ...DEFAULT_SETTINGS }];
    const repo = new FakeOrganisationCourseSyncRepository();
    const service = new IomadCompanyCourseSyncService(gateway, repo);

    const result = await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    expect(result).toMatchObject({ companyId: COMPANY_ID, fetched: 1, created: 1, updated: 0, unchanged: 0, failed: 0 });
    expect(repo.courseCount).toBe(1);
    expect(repo.allocationCount).toBe(1);
    expect(repo.getCourseByIomadId('4')?.name).toBe('Jupiter Test Mathematics');
  });

  it('SECOND IDENTICAL SYNC: same course UUID, same allocation, no duplicates — outcome unchanged', async () => {
    const gateway = new FakeIomadGateway();
    gateway.courseAllocations = [{ externalCourseId: '4', fullName: 'Jupiter Test Mathematics' }];
    gateway.courseSettings = [{ externalCourseId: '4', ...DEFAULT_SETTINGS }];
    const repo = new FakeOrganisationCourseSyncRepository();
    const service = new IomadCompanyCourseSyncService(gateway, repo);

    const first = await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);
    const firstCourseId = repo.getCourseByIomadId('4')?.id;
    const second = await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    expect(first.created).toBe(1);
    expect(second.unchanged).toBe(1);
    expect(second.created).toBe(0);
    expect(repo.courseCount).toBe(1);
    expect(repo.allocationCount).toBe(1);
    expect(repo.getCourseByIomadId('4')?.id).toBe(firstCourseId);
  });

  it('COURSE RENAME: same iomad_course_id, different fullname — same course UUID, name updated, outcome updated', async () => {
    const gateway = new FakeIomadGateway();
    gateway.courseAllocations = [{ externalCourseId: '4', fullName: 'Jupiter Test Mathematics' }];
    gateway.courseSettings = [{ externalCourseId: '4', ...DEFAULT_SETTINGS }];
    const repo = new FakeOrganisationCourseSyncRepository();
    const service = new IomadCompanyCourseSyncService(gateway, repo);
    await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);
    const originalCourseId = repo.getCourseByIomadId('4')?.id;

    gateway.courseAllocations = [{ externalCourseId: '4', fullName: 'Jupiter Test Mathematics (Renamed)' }];
    const result = await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    expect(result.updated).toBe(1);
    expect(repo.getCourseByIomadId('4')?.name).toBe('Jupiter Test Mathematics (Renamed)');
    expect(repo.getCourseByIomadId('4')?.id).toBe(originalCourseId);
    expect(repo.courseCount).toBe(1);
  });

  it('SETTINGS CHANGE: licensed/shared/validity changes — same allocation, settings updated, outcome updated', async () => {
    const gateway = new FakeIomadGateway();
    gateway.courseAllocations = [{ externalCourseId: '4', fullName: 'Jupiter Test Mathematics' }];
    gateway.courseSettings = [{ externalCourseId: '4', ...DEFAULT_SETTINGS }];
    const repo = new FakeOrganisationCourseSyncRepository();
    const service = new IomadCompanyCourseSyncService(gateway, repo);
    await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);
    const originalAllocationId = repo.getAllocation(ORG_ID, '4')?.id;

    gateway.courseSettings = [{ externalCourseId: '4', ...DEFAULT_SETTINGS, licensed: true, validLengthDays: 365 }];
    const result = await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    expect(result.updated).toBe(1);
    expect(repo.getAllocation(ORG_ID, '4')?.licensed).toBe(true);
    expect(repo.getAllocation(ORG_ID, '4')?.validLengthDays).toBe(365);
    expect(repo.getAllocation(ORG_ID, '4')?.id).toBe(originalAllocationId);
  });

  it('REMOVED FROM COMPANY: course missing from latest allocation — allocation becomes stale, course remains', async () => {
    const gateway = new FakeIomadGateway();
    gateway.courseAllocations = [{ externalCourseId: '4', fullName: 'Jupiter Test Mathematics' }];
    gateway.courseSettings = [{ externalCourseId: '4', ...DEFAULT_SETTINGS }];
    const repo = new FakeOrganisationCourseSyncRepository();
    const service = new IomadCompanyCourseSyncService(gateway, repo);
    await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    gateway.courseAllocations = []; // course no longer allocated to this company
    const result = await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    expect(result.stale).toBe(1);
    expect(repo.courseCount).toBe(1); // course itself still exists
    expect(repo.getCourseByIomadId('4')).toBeDefined();
  });

  it('MULTI-TENANT: same Iomad course allocated to two organisations — one course, two allocations', async () => {
    const gateway = new FakeIomadGateway();
    gateway.courseAllocations = [{ externalCourseId: '4', fullName: 'Jupiter Test Mathematics' }];
    gateway.courseSettings = [{ externalCourseId: '4', ...DEFAULT_SETTINGS }];
    const repo = new FakeOrganisationCourseSyncRepository();
    const service = new IomadCompanyCourseSyncService(gateway, repo);

    const firstOrgResult = await service.syncOrganisationCourses('org-A', COMPANY_ID);
    const secondOrgResult = await service.syncOrganisationCourses('org-B', COMPANY_ID);

    expect(firstOrgResult.created).toBe(1);
    // Second org: course already exists (wasCourseCreated: false) but
    // THIS organisation's allocation is new (wasAllocationCreated: true)
    // — still reported as "created" from this org's perspective.
    expect(secondOrgResult.created).toBe(1);
    expect(repo.courseCount).toBe(1); // one global course
    expect(repo.allocationCount).toBe(2); // two independent allocations
    expect(repo.getAllocation('org-A', '4')).toBeDefined();
    expect(repo.getAllocation('org-B', '4')).toBeDefined();
  });

  it('ZERO COURSE CASE: succeeds, no exception, no new course, existing allocations may be marked stale (confirmed complete snapshot)', async () => {
    const gateway = new FakeIomadGateway();
    gateway.courseAllocations = [{ externalCourseId: '4', fullName: 'Jupiter Test Mathematics' }];
    gateway.courseSettings = [{ externalCourseId: '4', ...DEFAULT_SETTINGS }];
    const repo = new FakeOrganisationCourseSyncRepository();
    const service = new IomadCompanyCourseSyncService(gateway, repo);
    await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    gateway.courseAllocations = [];
    const result = await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    expect(result.fetched).toBe(0);
    expect(result.created).toBe(0);
    expect(result.failed).toBe(0);
    expect(result.stale).toBe(1);
    expect(repo.courseCount).toBe(1); // course not deleted
  });

  it('ZERO COURSE CASE: does not call getCourseSettings() when there are zero allocated courses', async () => {
    const gateway = new FakeIomadGateway();
    gateway.courseAllocations = [];
    const getCourseSettingsSpy = vi.spyOn(gateway, 'getCourseSettings');
    const repo = new FakeOrganisationCourseSyncRepository();
    const service = new IomadCompanyCourseSyncService(gateway, repo);

    await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    expect(getCourseSettingsSpy).not.toHaveBeenCalled();
  });

  it('one course failure does not corrupt/block processing of other courses', async () => {
    const gateway = new FakeIomadGateway();
    gateway.courseAllocations = [
      { externalCourseId: '4', fullName: 'Jupiter Test Mathematics' },
      { externalCourseId: '5', fullName: 'Jupiter Test Science' },
    ];
    gateway.courseSettings = [
      { externalCourseId: '4', ...DEFAULT_SETTINGS },
      { externalCourseId: '5', ...DEFAULT_SETTINGS },
    ];
    const repo = new FakeOrganisationCourseSyncRepository();
    repo.failSyncForIomadCourseId = '4';
    const service = new IomadCompanyCourseSyncService(gateway, repo);

    const result = await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    expect(result.failed).toBe(1);
    expect(result.created).toBe(1);
    expect(repo.getCourseByIomadId('4')).toBeUndefined();
    expect(repo.getCourseByIomadId('5')).toBeDefined();
  });

  it('REVIEW FIX #1: missing settings for a newly-allocated course — reported failed with missing_course_settings, no course/allocation created', async () => {
    const gateway = new FakeIomadGateway();
    gateway.courseAllocations = [{ externalCourseId: '4', fullName: 'Jupiter Test Mathematics' }];
    gateway.courseSettings = []; // no settings entry returned for course 4
    const repo = new FakeOrganisationCourseSyncRepository();
    const service = new IomadCompanyCourseSyncService(gateway, repo);

    const result = await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    expect(result.failed).toBe(1);
    expect(result.created).toBe(0);
    // Crucially: syncCourse() was never called with fabricated defaults —
    // no course or allocation exists at all for this iomad course id.
    expect(repo.getCourseByIomadId('4')).toBeUndefined();
    expect(repo.getAllocation(ORG_ID, '4')).toBeUndefined();
  });

  it('REVIEW FIX #1: an already-allocated course whose settings go missing on a later sync does NOT overwrite its previously-stored true/non-zero settings', async () => {
    const gateway = new FakeIomadGateway();
    gateway.courseAllocations = [{ externalCourseId: '4', fullName: 'Jupiter Test Mathematics' }];
    gateway.courseSettings = [
      { externalCourseId: '4', licensed: true, shared: true, validLengthDays: 365, warnExpireDays: 30, warnCompletionDays: 14, notifyPeriodDays: 7 },
    ];
    const repo = new FakeOrganisationCourseSyncRepository();
    const service = new IomadCompanyCourseSyncService(gateway, repo);
    await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);
    expect(repo.getAllocation(ORG_ID, '4')).toMatchObject({ licensed: true, validLengthDays: 365 });

    // Course is STILL allocated (still in listCompanyCourses' result),
    // but get_course_info returned no settings entry for it this run.
    gateway.courseSettings = [];
    const result = await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    expect(result.failed).toBe(1);
    // The previously-stored true/non-zero values must be completely
    // untouched — NOT silently overwritten with false/0.
    expect(repo.getAllocation(ORG_ID, '4')).toMatchObject({
      licensed: true,
      shared: true,
      validLengthDays: 365,
      warnExpireDays: 30,
      warnCompletionDays: 14,
      notifyPeriodDays: 7,
    });
  });

  it('REVIEW FIX #1: a course with missing settings is still kept in the seen list — never marked stale merely because settings are missing', async () => {
    const gateway = new FakeIomadGateway();
    gateway.courseAllocations = [{ externalCourseId: '4', fullName: 'Jupiter Test Mathematics' }];
    gateway.courseSettings = [{ externalCourseId: '4', ...DEFAULT_SETTINGS, licensed: true }];
    const repo = new FakeOrganisationCourseSyncRepository();
    const service = new IomadCompanyCourseSyncService(gateway, repo);
    await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    gateway.courseSettings = []; // settings missing this run, but course is still in courseAllocations
    const result = await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    expect(result.stale).toBe(0); // NOT marked stale
    expect(repo.getAllocation(ORG_ID, '4')?.licensed).toBe(true); // settings untouched
  });

  it('REVIEW FIX #1: uses the safe error code missing_course_settings, never exposing raw response data', async () => {
    const errorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
    const gateway = new FakeIomadGateway();
    gateway.courseAllocations = [{ externalCourseId: '4', fullName: 'Jupiter Test Mathematics' }];
    gateway.courseSettings = [];
    const repo = new FakeOrganisationCourseSyncRepository();
    const service = new IomadCompanyCourseSyncService(gateway, repo);

    await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    const serialized = JSON.stringify(errorSpy.mock.calls);
    expect(serialized).toContain('missing_course_settings');
    errorSpy.mockRestore();
  });

  it('REVIEW FIX #2: an allocation transitioning from stale to synced with IDENTICAL settings is reported updated, not unchanged', async () => {
    const gateway = new FakeIomadGateway();
    gateway.courseAllocations = [{ externalCourseId: '4', fullName: 'Jupiter Test Mathematics' }];
    gateway.courseSettings = [{ externalCourseId: '4', ...DEFAULT_SETTINGS }];
    const repo = new FakeOrganisationCourseSyncRepository();
    const service = new IomadCompanyCourseSyncService(gateway, repo);
    await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);
    const originalCourseId = repo.getCourseByIomadId('4')?.id;
    const originalAllocationId = repo.getAllocation(ORG_ID, '4')?.id;

    // Course disappears from the company — allocation becomes stale.
    gateway.courseAllocations = [];
    const staleResult = await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);
    expect(staleResult.stale).toBe(1);
    expect(repo.getAllocation(ORG_ID, '4')?.syncStatus).toBe('stale');

    // Course reappears with IDENTICAL settings.
    gateway.courseAllocations = [{ externalCourseId: '4', fullName: 'Jupiter Test Mathematics' }];
    const result = await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    expect(result.updated).toBe(1);
    expect(result.unchanged).toBe(0);
    expect(repo.getAllocation(ORG_ID, '4')?.syncStatus).toBe('synced');
    expect(repo.getCourseByIomadId('4')?.id).toBe(originalCourseId);
    expect(repo.getAllocation(ORG_ID, '4')?.id).toBe(originalAllocationId);
  });

  it('REVIEW FIX #2: an allocation transitioning from failed to synced with IDENTICAL settings is reported updated, not unchanged', async () => {
    const gateway = new FakeIomadGateway();
    gateway.courseAllocations = [{ externalCourseId: '4', fullName: 'Jupiter Test Mathematics' }];
    gateway.courseSettings = [{ externalCourseId: '4', ...DEFAULT_SETTINGS }];
    const repo = new FakeOrganisationCourseSyncRepository();
    const service = new IomadCompanyCourseSyncService(gateway, repo);
    await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    // Force a failure on the next sync, marking the allocation 'failed'.
    repo.failSyncForIomadCourseId = '4';
    const failedResult = await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);
    expect(failedResult.failed).toBe(1);
    expect(repo.getAllocation(ORG_ID, '4')?.syncStatus).toBe('failed');

    // Now succeeds again with identical settings.
    repo.failSyncForIomadCourseId = null;
    const result = await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    expect(result.updated).toBe(1);
    expect(result.unchanged).toBe(0);
    expect(repo.getAllocation(ORG_ID, '4')?.syncStatus).toBe('synced');
  });

  it('REVIEW FIX #2: an allocation that stays synced with identical settings is reported unchanged (baseline, unaffected by the fix)', async () => {
    const gateway = new FakeIomadGateway();
    gateway.courseAllocations = [{ externalCourseId: '4', fullName: 'Jupiter Test Mathematics' }];
    gateway.courseSettings = [{ externalCourseId: '4', ...DEFAULT_SETTINGS }];
    const repo = new FakeOrganisationCourseSyncRepository();
    const service = new IomadCompanyCourseSyncService(gateway, repo);
    await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    const result = await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    expect(result.updated).toBe(0);
    expect(result.unchanged).toBe(1);
    expect(repo.getAllocation(ORG_ID, '4')?.syncStatus).toBe('synced');
  });

  it('duplicate Iomad course IDs within the same batch do not create duplicates', async () => {
    const gateway = new FakeIomadGateway();
    gateway.courseAllocations = [
      { externalCourseId: '4', fullName: 'Jupiter Test Mathematics' },
      { externalCourseId: '4', fullName: 'Jupiter Test Mathematics (dup)' },
    ];
    gateway.courseSettings = [{ externalCourseId: '4', ...DEFAULT_SETTINGS }];
    const repo = new FakeOrganisationCourseSyncRepository();
    const service = new IomadCompanyCourseSyncService(gateway, repo);

    const result = await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    expect(result.created).toBe(1);
    expect(repo.courseCount).toBe(1);
  });

  it('returns a safe topLevelError when listCompanyCourses() itself fails', async () => {
    const gateway = new FakeIomadGateway();
    gateway.listCompanyCoursesError = new IomadGatewayError('network_error', 'Could not reach the Iomad service.');
    const repo = new FakeOrganisationCourseSyncRepository();
    const service = new IomadCompanyCourseSyncService(gateway, repo);

    const result = await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    expect(result).toMatchObject({ fetched: 0, created: 0, updated: 0, unchanged: 0, failed: 0 });
    expect(result.topLevelError).toBe('network_error');
  });

  it('reports every allocated course as failed when getCourseSettings() itself fails', async () => {
    const gateway = new FakeIomadGateway();
    gateway.courseAllocations = [
      { externalCourseId: '4', fullName: 'Jupiter Test Mathematics' },
      { externalCourseId: '5', fullName: 'Jupiter Test Science' },
    ];
    gateway.getCourseSettingsError = new IomadGatewayError('upstream_http_error', 'Server error.');
    const repo = new FakeOrganisationCourseSyncRepository();
    const service = new IomadCompanyCourseSyncService(gateway, repo);

    const result = await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    expect(result.failed).toBe(2);
    expect(repo.courseCount).toBe(0);
  });

  it('never logs a raw error message, token, or course fullName — only safe codes/ids', async () => {
    const errorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
    const gateway = new FakeIomadGateway();
    gateway.courseAllocations = [{ externalCourseId: '4', fullName: 'Top Secret Course Name' }];
    gateway.courseSettings = [{ externalCourseId: '4', ...DEFAULT_SETTINGS }];
    const repo = new FakeOrganisationCourseSyncRepository();
    repo.failSyncForIomadCourseId = '4';
    const service = new IomadCompanyCourseSyncService(gateway, repo);

    await service.syncOrganisationCourses(ORG_ID, COMPANY_ID);

    for (const call of errorSpy.mock.calls) {
      const serialized = JSON.stringify(call);
      expect(serialized).not.toContain('Top Secret Course Name');
      expect(serialized).not.toContain('simulated syncCourse failure');
    }
    errorSpy.mockRestore();
  });
});
