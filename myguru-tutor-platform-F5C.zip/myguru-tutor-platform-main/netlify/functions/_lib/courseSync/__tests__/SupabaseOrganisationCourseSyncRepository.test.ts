import { describe, it, expect, vi } from 'vitest';
import type { SupabaseClient } from '@supabase/supabase-js';
import { SupabaseOrganisationCourseSyncRepository } from '../SupabaseOrganisationCourseSyncRepository.js';

function baseRpcRow(overrides: Record<string, unknown> = {}) {
  return {
    course_id: 'course-1',
    course_name: 'Jupiter Test Mathematics',
    course_status: 'active',
    mapping_id: 'map-1',
    allocation_id: 'alloc-1',
    was_course_created: true,
    course_name_changed: false,
    was_allocation_created: true,
    allocation_settings_changed: false,
    allocation_status_changed: false,
    ...overrides,
  };
}

function createMockSupabase() {
  const rpcMock = vi.fn();
  const maybeSingleMock = vi.fn();
  const eqLookupMock = vi.fn(() => ({ maybeSingle: maybeSingleMock }));
  const selectMock = vi.fn(() => ({ eq: eqLookupMock }));
  const updateEqSecondMock = vi.fn();
  const updateEqFirstMock = vi.fn(() => ({ eq: updateEqSecondMock }));
  const updateMock = vi.fn(() => ({ eq: updateEqFirstMock }));
  const fromMock = vi.fn((_table: string) => ({ select: selectMock, update: updateMock }));
  const client = { rpc: rpcMock, from: fromMock } as unknown as SupabaseClient;
  return {
    client,
    rpcMock,
    fromMock,
    selectMock,
    eqLookupMock,
    maybeSingleMock,
    updateMock,
    updateEqFirstMock,
    updateEqSecondMock,
  };
}

describe('SupabaseOrganisationCourseSyncRepository.syncCourse', () => {
  it('calls rpc("sync_iomad_company_course", {...}) with exactly the given input', async () => {
    const { client, rpcMock } = createMockSupabase();
    rpcMock.mockResolvedValue({ data: [baseRpcRow()], error: null });

    const repo = new SupabaseOrganisationCourseSyncRepository(client);
    await repo.syncCourse({
      organisationId: 'org-1',
      iomadCourseId: '4',
      courseName: 'Jupiter Test Mathematics',
      licensed: false,
      shared: false,
      validLengthDays: 0,
      warnExpireDays: 0,
      warnCompletionDays: 0,
      notifyPeriodDays: 0,
    });

    expect(rpcMock).toHaveBeenCalledTimes(1);
    expect(rpcMock).toHaveBeenCalledWith('sync_iomad_company_course', {
      p_organisation_id: 'org-1',
      p_iomad_course_id: '4',
      p_course_name: 'Jupiter Test Mathematics',
      p_licensed: false,
      p_shared: false,
      p_valid_length_days: 0,
      p_warn_expire_days: 0,
      p_warn_completion_days: 0,
      p_notify_period_days: 0,
    });
  });

  it('does NOT call .from() at all — the RPC remains the only write path for syncCourse', async () => {
    const { client, rpcMock, fromMock } = createMockSupabase();
    rpcMock.mockResolvedValue({ data: [baseRpcRow()], error: null });

    const repo = new SupabaseOrganisationCourseSyncRepository(client);
    await repo.syncCourse({
      organisationId: 'org-1',
      iomadCourseId: '4',
      courseName: 'Jupiter Test Mathematics',
      licensed: false,
      shared: false,
      validLengthDays: 0,
      warnExpireDays: 0,
      warnCompletionDays: 0,
      notifyPeriodDays: 0,
    });

    expect(fromMock).not.toHaveBeenCalled();
  });

  it('maps a returned RPC row into the correct outcome flags and ids, including allocationStatusChanged', async () => {
    const { client, rpcMock } = createMockSupabase();
    rpcMock.mockResolvedValue({
      data: [
        baseRpcRow({
          was_course_created: false,
          course_name_changed: true,
          was_allocation_created: false,
          allocation_settings_changed: true,
          allocation_status_changed: true,
        }),
      ],
      error: null,
    });

    const repo = new SupabaseOrganisationCourseSyncRepository(client);
    const result = await repo.syncCourse({
      organisationId: 'org-1',
      iomadCourseId: '4',
      courseName: 'Jupiter Test Mathematics (Renamed)',
      licensed: true,
      shared: false,
      validLengthDays: 365,
      warnExpireDays: 30,
      warnCompletionDays: 14,
      notifyPeriodDays: 7,
    });

    expect(result).toEqual({
      courseId: 'course-1',
      allocationId: 'alloc-1',
      wasCourseCreated: false,
      courseNameChanged: true,
      wasAllocationCreated: false,
      allocationSettingsChanged: true,
      allocationStatusChanged: true,
    });
  });

  it('maps allocationStatusChanged: true even when allocationSettingsChanged is false (stale/failed back to synced with identical settings)', async () => {
    const { client, rpcMock } = createMockSupabase();
    rpcMock.mockResolvedValue({
      data: [baseRpcRow({ was_allocation_created: false, allocation_settings_changed: false, allocation_status_changed: true })],
      error: null,
    });

    const repo = new SupabaseOrganisationCourseSyncRepository(client);
    const result = await repo.syncCourse({
      organisationId: 'org-1',
      iomadCourseId: '4',
      courseName: 'Jupiter Test Mathematics',
      licensed: false,
      shared: false,
      validLengthDays: 0,
      warnExpireDays: 0,
      warnCompletionDays: 0,
      notifyPeriodDays: 0,
    });

    expect(result.allocationSettingsChanged).toBe(false);
    expect(result.allocationStatusChanged).toBe(true);
  });

  it('accepts a single-object (non-array) RPC response, not just an array', async () => {
    const { client, rpcMock } = createMockSupabase();
    rpcMock.mockResolvedValue({ data: baseRpcRow(), error: null });

    const repo = new SupabaseOrganisationCourseSyncRepository(client);
    const result = await repo.syncCourse({
      organisationId: 'org-1',
      iomadCourseId: '4',
      courseName: 'Jupiter Test Mathematics',
      licensed: false,
      shared: false,
      validLengthDays: 0,
      warnExpireDays: 0,
      warnCompletionDays: 0,
      notifyPeriodDays: 0,
    });
    expect(result.courseId).toBe('course-1');
  });

  it('propagates a safe error when the RPC call itself returns an error, without leaking raw DB detail', async () => {
    const { client, rpcMock } = createMockSupabase();
    rpcMock.mockResolvedValue({
      data: null,
      error: { code: '23505', message: 'duplicate key value violates unique constraint DETAIL: sensitive info' },
    });

    const repo = new SupabaseOrganisationCourseSyncRepository(client);
    try {
      await repo.syncCourse({
        organisationId: 'org-1',
        iomadCourseId: '4',
        courseName: 'Jupiter Test Mathematics',
        licensed: false,
        shared: false,
        validLengthDays: 0,
        warnExpireDays: 0,
        warnCompletionDays: 0,
        notifyPeriodDays: 0,
      });
      throw new Error('expected syncCourse to throw');
    } catch (err) {
      expect((err as Error).message).toContain('23505');
      expect((err as Error).message).not.toContain('duplicate key value violates');
      expect((err as Error).message).not.toContain('sensitive info');
    }
  });

  it('handles an empty-array RPC response safely — throws a safe, generic error', async () => {
    const { client, rpcMock } = createMockSupabase();
    rpcMock.mockResolvedValue({ data: [], error: null });

    const repo = new SupabaseOrganisationCourseSyncRepository(client);
    await expect(
      repo.syncCourse({
        organisationId: 'org-1',
        iomadCourseId: '4',
        courseName: 'Jupiter Test Mathematics',
        licensed: false,
        shared: false,
        validLengthDays: 0,
        warnExpireDays: 0,
        warnCompletionDays: 0,
        notifyPeriodDays: 0,
      }),
    ).rejects.toThrow('empty_response');
  });
});

describe('SupabaseOrganisationCourseSyncRepository.markFailed', () => {
  it('looks up the course by iomad_course_id, then updates the allocation for the given organisation', async () => {
    const { client, fromMock, eqLookupMock, maybeSingleMock, updateMock, updateEqFirstMock, updateEqSecondMock } =
      createMockSupabase();
    maybeSingleMock.mockResolvedValue({ data: { course_id: 'course-1' }, error: null });
    updateEqSecondMock.mockResolvedValue({ error: null });

    const repo = new SupabaseOrganisationCourseSyncRepository(client);
    await repo.markFailed({ organisationId: 'org-1', iomadCourseId: '4', errorCode: 'network_error' });

    expect(fromMock).toHaveBeenCalledWith('iomad_course_mappings');
    expect(eqLookupMock).toHaveBeenCalledWith('iomad_course_id', '4');
    expect(fromMock).toHaveBeenCalledWith('organisation_course_allocations');
    expect(updateMock).toHaveBeenCalledWith({ sync_status: 'failed', last_error_code: 'network_error' });
    expect(updateEqFirstMock).toHaveBeenCalledWith('organisation_id', 'org-1');
    expect(updateEqSecondMock).toHaveBeenCalledWith('course_id', 'course-1');
  });

  it('is a safe no-op when no mapping exists yet for this iomadCourseId', async () => {
    const { client, maybeSingleMock, updateMock } = createMockSupabase();
    maybeSingleMock.mockResolvedValue({ data: null, error: null });

    const repo = new SupabaseOrganisationCourseSyncRepository(client);
    await expect(
      repo.markFailed({ organisationId: 'org-1', iomadCourseId: '4', errorCode: 'network_error' }),
    ).resolves.toBeUndefined();
    expect(updateMock).not.toHaveBeenCalled();
  });

  it('does not throw when the mapping lookup itself returns an error', async () => {
    const { client, maybeSingleMock } = createMockSupabase();
    maybeSingleMock.mockResolvedValue({ data: null, error: { code: '42501', message: 'permission denied' } });

    const repo = new SupabaseOrganisationCourseSyncRepository(client);
    await expect(
      repo.markFailed({ organisationId: 'org-1', iomadCourseId: '4', errorCode: 'network_error' }),
    ).resolves.toBeUndefined();
  });

  it('does not throw even when the underlying call itself throws (genuine client/network exception)', async () => {
    const { client, maybeSingleMock } = createMockSupabase();
    maybeSingleMock.mockRejectedValue(new TypeError('fetch failed'));

    const repo = new SupabaseOrganisationCourseSyncRepository(client);
    await expect(
      repo.markFailed({ organisationId: 'org-1', iomadCourseId: '4', errorCode: 'network_error' }),
    ).resolves.toBeUndefined();
  });

  it('never logs raw database error detail — only a safe error code', async () => {
    const { client, maybeSingleMock, updateEqSecondMock } = createMockSupabase();
    maybeSingleMock.mockResolvedValue({ data: { course_id: 'course-1' }, error: null });
    updateEqSecondMock.mockResolvedValue({ error: { code: '42501', message: 'permission denied for table DETAIL: sensitive' } });
    const errorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});

    const repo = new SupabaseOrganisationCourseSyncRepository(client);
    await repo.markFailed({ organisationId: 'org-1', iomadCourseId: '4', errorCode: 'network_error' });

    for (const call of errorSpy.mock.calls) {
      const serialized = JSON.stringify(call);
      expect(serialized).not.toContain('permission denied');
      expect(serialized).not.toContain('sensitive');
    }
    errorSpy.mockRestore();
  });
});

describe('SupabaseOrganisationCourseSyncRepository.markMissingAsStale', () => {
  it('calls rpc("mark_stale_organisation_course_allocations", {...}) with exactly the given input', async () => {
    const { client, rpcMock } = createMockSupabase();
    rpcMock.mockResolvedValue({ data: 2, error: null });

    const repo = new SupabaseOrganisationCourseSyncRepository(client);
    const count = await repo.markMissingAsStale('org-1', ['4', '5']);

    expect(rpcMock).toHaveBeenCalledWith('mark_stale_organisation_course_allocations', {
      p_organisation_id: 'org-1',
      p_seen_iomad_course_ids: ['4', '5'],
    });
    expect(count).toBe(2);
  });

  it('propagates a safe error on RPC failure', async () => {
    const { client, rpcMock } = createMockSupabase();
    rpcMock.mockResolvedValue({ data: null, error: { code: '42501', message: 'permission denied DETAIL: x' } });

    const repo = new SupabaseOrganisationCourseSyncRepository(client);
    try {
      await repo.markMissingAsStale('org-1', []);
      throw new Error('expected markMissingAsStale to throw');
    } catch (err) {
      expect((err as Error).message).toContain('42501');
      expect((err as Error).message).not.toContain('permission denied');
    }
  });

  it('returns 0 for a non-numeric response defensively', async () => {
    const { client, rpcMock } = createMockSupabase();
    rpcMock.mockResolvedValue({ data: null, error: null });

    const repo = new SupabaseOrganisationCourseSyncRepository(client);
    expect(await repo.markMissingAsStale('org-1', [])).toBe(0);
  });
});
