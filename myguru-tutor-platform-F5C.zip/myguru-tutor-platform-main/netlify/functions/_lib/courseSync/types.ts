/**
 * F5B — platform-side course persistence domain types.
 *
 * Persists F5A's already-live-verified Iomad company-course-allocation
 * and course-settings data (see
 * `supabase/migrations/0016_course_persistence_and_organisation_allocations.sql`).
 * Server-only — never imported from `src/`.
 *
 * Domain rule: a `Course` is global; an `OrganisationCourseAllocation` is
 * tenant-specific. Losing access never deletes the course or its
 * `IomadCourseMapping` — only the allocation is marked `stale`.
 */

export type CourseStatus = 'active' | 'inactive';

export interface Course {
  id: string;
  name: string;
  status: CourseStatus;
  createdAt: string;
  updatedAt: string;
}

export type CourseSyncStatus = 'pending' | 'synced' | 'failed' | 'stale';

/** `iomadCourseId` is the external identity — never email/name (F1 Ground
 * rule 2 in `docs/SYSTEM_OF_RECORD.md`). */
export interface IomadCourseMapping {
  id: string;
  courseId: string;
  iomadCourseId: string;
  syncStatus: CourseSyncStatus;
  lastSyncedAt: string | null;
  lastErrorCode: string | null;
  createdAt: string;
  updatedAt: string;
}

/**
 * Tenant-specific: which organisation has access to which course, under
 * what F5A-live-verified licensing/settings snapshot. Unique per
 * (organisationId, courseId) — the SAME course allocated to two
 * organisations produces two of these rows, not two courses.
 */
export interface OrganisationCourseAllocation {
  id: string;
  organisationId: string;
  courseId: string;
  licensed: boolean;
  shared: boolean;
  validLengthDays: number;
  warnExpireDays: number;
  warnCompletionDays: number;
  notifyPeriodDays: number;
  syncStatus: CourseSyncStatus;
  lastSyncedAt: string | null;
  lastErrorCode: string | null;
  createdAt: string;
  updatedAt: string;
}

/**
 * Summary of one `syncOrganisationCourses()` run. No PII, no raw Iomad
 * payload — just counts and a safe top-level error code for the case
 * where the initial fetch itself failed.
 */
export interface CourseSyncResult {
  companyId: string;
  fetched: number;
  created: number;
  updated: number;
  unchanged: number;
  failed: number;
  stale: number;
  timestamp: string;
  /** Only set when `listCompanyCourses()`/`getCourseSettings()` itself
   * failed entirely — the run never got as far as processing individual
   * courses (or aborted partway when the settings fetch failed). One of
   * `IomadErrorCode` (see `../iomad/IomadErrors.ts`) or 'unknown_error'. */
  topLevelError?: string;
}
