const JSON_HEADERS = { 'Content-Type': 'application/json' };

export function jsonResponse(statusCode: number, body: unknown) {
  return { statusCode, headers: JSON_HEADERS, body: JSON.stringify(body) };
}

/**
 * A single generic response used for EVERY anti-abuse rejection (honeypot,
 * too-fast submission, rate limit) and for the generic "something went
 * wrong" fallback — deliberately identical in every case so a caller can't
 * distinguish which check triggered (Phase E4 requirement).
 */
export function genericUnableToProcess() {
  return jsonResponse(400, { error: 'unable_to_process' });
}

/** For genuine field-level validation failures — still no internal details, but distinct from anti-abuse rejections. */
export function validationFailed(message: string) {
  return jsonResponse(400, { error: 'invalid_request', message });
}

export function methodNotAllowed() {
  return jsonResponse(405, { error: 'method_not_allowed' });
}

export function serverMisconfigured() {
  // Never include the underlying error/config detail in the response body.
  return jsonResponse(503, { error: 'service_unavailable' });
}

export function success(body: unknown = { ok: true }) {
  return jsonResponse(200, body);
}
