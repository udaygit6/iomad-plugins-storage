/**
 * Safe, typed errors for the Iomad integration.
 *
 * Every message here is generic by design — never includes the token,
 * raw response bodies, stack traces, or any Iomad-reported exception
 * detail beyond the wsfunction name (not a secret; it already appears in
 * docs/IOMAD_INTEGRATION_CONTRACT.md).
 */

export type IomadErrorCode =
  | 'not_configured'
  | 'invalid_config'
  | 'network_error'
  | 'timeout'
  | 'invalid_json'
  | 'moodle_exception'
  | 'unauthorized'
  | 'upstream_http_error'
  | 'unknown_response_schema';

export class IomadGatewayError extends Error {
  readonly code: IomadErrorCode;

  constructor(code: IomadErrorCode, message: string) {
    super(message);
    this.name = 'IomadGatewayError';
    this.code = code;
  }
}

export function notConfiguredError(): IomadGatewayError {
  return new IomadGatewayError('not_configured', 'Iomad integration is not configured.');
}

/**
 * IOMAD_BASE_URL is present but fails validation (malformed, or not
 * https:). Deliberately does not echo the invalid value back — that
 * value isn't a secret, but there's no reason to reflect arbitrary
 * configuration content into an error surface either.
 */
export function invalidConfigError(): IomadGatewayError {
  return new IomadGatewayError('invalid_config', 'Iomad integration is misconfigured.');
}

export function networkError(): IomadGatewayError {
  return new IomadGatewayError('network_error', 'Could not reach the Iomad service.');
}

export function timeoutError(): IomadGatewayError {
  return new IomadGatewayError('timeout', 'The Iomad service did not respond in time.');
}

export function invalidJsonError(): IomadGatewayError {
  return new IomadGatewayError('invalid_json', 'The Iomad service returned an unreadable response.');
}

export function moodleExceptionError(wsfunction: string): IomadGatewayError {
  return new IomadGatewayError('moodle_exception', `The Iomad service rejected the "${wsfunction}" request.`);
}

export function unauthorizedError(): IomadGatewayError {
  return new IomadGatewayError('unauthorized', 'The Iomad service rejected the configured credentials.');
}

/**
 * Any non-2xx HTTP response other than 401/403 (which get the dedicated
 * `unauthorized` error). Deliberately does not include the response body
 * or status-specific detail beyond what's already logged server-side via
 * `logIomadCallFailure` — a 500 and a 404 both surface identically to
 * callers as "something went wrong upstream," which is all a caller
 * needs to decide whether to retry/report.
 */
export function upstreamHttpError(): IomadGatewayError {
  return new IomadGatewayError('upstream_http_error', 'The Iomad service returned an unexpected error.');
}

export function unknownResponseSchemaError(wsfunction: string): IomadGatewayError {
  return new IomadGatewayError(
    'unknown_response_schema',
    `The Iomad service returned an unexpected response shape for "${wsfunction}".`,
  );
}

/**
 * Server-log-only diagnostic — function name, HTTP status (if known), our
 * own error code, and an optional correlation id. Never the token, never
 * a raw payload, never learner data.
 */
export function logIomadCallFailure(
  wsfunction: string,
  code: IomadErrorCode,
  httpStatus?: number,
  correlationId?: string,
): void {
  console.error('[iomad]', { wsfunction, code, httpStatus, correlationId });
}
