import { unknownResponseSchemaError } from './IomadErrors.js';

/**
 * Raw-response-to-application-type adapters.
 *
 * PARTIALLY LIVE-VERIFIED (companies). A real authenticated call to
 * `block_iomad_company_admin_get_companies`, filtered by
 * `criteria[0][key]=code`, against the running Iomad instance returned:
 *
 *   { "companies": [ { "id": 3, "name": "Shiksha Academy",
 *       "shortname": "SHIKSHA", "code": "MYGURU-SHIKSHA-001", "suspended": 0,
 *       ... } ], "warnings": [] }
 *
 * (See docs/IOMAD_INTEGRATION_CONTRACT.md's "Live-verified: get_companies
 * by code" for the full example.) This confirms, for companies:
 *   - the response envelope is `{ companies: [...], warnings: [...] }`
 *   - `id` is numeric
 *   - `name` is the display name (and `shortname`/`code` are separate,
 *     distinct fields — `code` is NOT the same as `shortname`)
 *   - `suspended` is NUMERIC (0 = active, non-zero = suspended) — NOT a
 *     JSON boolean. Nothing in this file currently reads `suspended` for
 *     any decision (F4's organisation sync does not consume it — see
 *     docs/IOMAD_INTEGRATION_CONTRACT.md's live schema gate), but
 *     `normalizeCompany` below captures it defensively and correctly
 *     as a number-derived boolean, never assuming a JSON boolean, so
 *     that future work building on this adapter starts from a correct
 *     reading rather than reintroducing that mistake.
 *
 * This live confirmation was for the CRITERIA-FILTERED, single-company
 * lookup (`getCompanyByCode`, below) — it does NOT confirm that calling
 * `get_companies` with NO criteria (the unfiltered bulk call
 * `listCompanies()` uses) behaves the same way, returns all companies, or
 * is even accepted without parameters. That call remains UNVERIFIED.
 *
 * `normalizeCourse`/`normalizeSingleCourse` below (backing the F3-era
 * `getCourse()` method, using the field names `id`/`fullname`/`shortname`
 * per conventional Moodle/Iomad web-service naming) remain entirely
 * UNVERIFIED — not the same code path as the LIVE VERIFIED
 * `normalizeCompanyCourseAllocations()`/`normalizeCourseSettings()`
 * further down, which back the newer, execution-tested F5A methods
 * (`listCompanyCourses()`/`getCourseSettings()`). See
 * docs/IOMAD_INTEGRATION_CONTRACT.md's F5A section for the full
 * live-verification record, including the `get_course_info` parameter
 * correction (no course-id parameter at all — see that function's own
 * doc comment below).
 *
 * These adapters are defensive on purpose: a response that doesn't match
 * the expected shape throws `unknown_response_schema` rather than
 * guessing or silently returning partial/undefined fields. Unknown
 * fields (e.g. `address`, `city`, `region`, `country`, `parentid`,
 * `hostname`, `maxusers`, `custom1..3` in the live example above) are
 * never promoted into the return type — they are discarded, not treated
 * as an architectural contract.
 */

interface RawCompanyCandidate {
  id?: unknown;
  name?: unknown;
  shortname?: unknown;
  code?: unknown;
  suspended?: unknown;
}

interface RawCourseCandidate {
  id?: unknown;
  fullname?: unknown;
  shortname?: unknown;
}

/**
 * F5A — LIVE VERIFIED (execution-tested against the running Iomad
 * instance) shape for `block_iomad_company_admin_get_company_courses`:
 *
 *   { companies: [ { id, name, shortname, code, address, city, region,
 *       postcode, country, custom1, custom2, custom3,
 *       courses: [ { id, fullname, customfields: [ { id, name, value } ] } ]
 *   } ], warnings?: [...] }
 *
 * Confirmed with a real Jupiter Test Academy example (company id 4,
 * one allocated course "Jupiter Test Mathematics", `customfields: []`)
 * and a real zero-courses example (`courses: []`, a valid success, not
 * an error). See docs/IOMAD_INTEGRATION_CONTRACT.md's F5A section for
 * the full live-verification record.
 */
interface RawCompanyCourseAllocationEntry {
  id?: unknown;
  fullname?: unknown;
  customfields?: unknown;
}

interface RawCustomField {
  id?: unknown;
  name?: unknown;
  value?: unknown;
}

/**
 * F5A — LIVE VERIFIED (execution) shape for
 * `block_iomad_company_admin_get_course_info`: a BARE ARRAY of course
 * settings objects, each `{ id, courseid, licensed, shared, validlength,
 * warnexpire, warncompletion, notifyperiod }`. Note this is a materially
 * different confirmed shape from what `normalizeCourse`/
 * `normalizeSingleCourse` above assume (`{ id, fullname }`-style course
 * *identity* info) — those two functions back the pre-existing, still
 * entirely UNVERIFIED `getCourse()` method from F3, built on a guess at
 * conventional Moodle field naming. `normalizeCourseSettings` below is a
 * separate, newer adapter reflecting F5A's live-verified contract for the
 * SAME wsfunction, used by the new `getCourseSettings()` method. They
 * remain unreconciled (`getCourse()` is left as-is, not removed) — see
 * docs/IOMAD_INTEGRATION_CONTRACT.md's F5A section.
 *
 * Also LIVE VERIFIED: `get_course_info` takes NO course-id request
 * parameter at all. The generated API documentation described a
 * `courrseids[N]` parameter; execution testing proved every parameterized
 * variant tried (`courrseids[0]`, `courseids[0]`, `courseid[0]`) fails
 * with `invalid_parameter_exception`. The real call returns the FULL
 * available course-settings collection; `IomadRestGateway.getCourseSettings()`
 * filters it locally to the requested course IDs — this file's job is
 * only to normalize each entry, not to know which ones were asked for.
 */
interface RawCourseSettingsCandidate {
  id?: unknown;
  courseid?: unknown;
  licensed?: unknown;
  shared?: unknown;
  validlength?: unknown;
  warnexpire?: unknown;
  warncompletion?: unknown;
  notifyperiod?: unknown;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null;
}

function idToString(id: unknown): string | null {
  if (typeof id === 'number' && Number.isFinite(id)) return String(id);
  if (typeof id === 'string' && id.trim().length > 0) return id;
  return null;
}

export function normalizeCompany(
  raw: unknown,
  wsfunction: string,
): { externalId: string; displayName: string; code?: string; isSuspended?: boolean } {
  if (!isRecord(raw)) throw unknownResponseSchemaError(wsfunction);
  const candidate = raw as RawCompanyCandidate;
  const externalId = idToString(candidate.id);
  const displayName = candidate.name ?? candidate.shortname;
  if (externalId === null || typeof displayName !== 'string' || displayName.trim().length === 0) {
    throw unknownResponseSchemaError(wsfunction);
  }
  const result: { externalId: string; displayName: string; code?: string; isSuspended?: boolean } = {
    externalId,
    displayName,
  };
  if (typeof candidate.code === 'string' && candidate.code.trim().length > 0) {
    result.code = candidate.code;
  }
  // CONFIRMED numeric (0 = active, non-zero = suspended) — see file
  // header. Only ever derived from an actual number; a missing or
  // non-numeric value leaves `isSuspended` undefined rather than
  // guessing, and is never treated as a JSON boolean.
  if (typeof candidate.suspended === 'number') {
    result.isSuspended = candidate.suspended !== 0;
  }
  return result;
}

export function normalizeCompanyList(
  raw: unknown,
  wsfunction: string,
): Array<{ externalId: string; displayName: string; code?: string; isSuspended?: boolean }> {
  // CONFIRMED envelope (companies, live-verified): `{ companies: [...],
  // warnings: [...] }` — see file header. The bare-array shape is kept as
  // a defensive fallback only; it has never actually been observed from
  // a live call. A `warnings` array alongside `companies` is expected and
  // harmless — this function only ever reads `.companies`.
  const list = Array.isArray(raw)
    ? raw
    : isRecord(raw) && Array.isArray((raw as Record<string, unknown>).companies)
      ? ((raw as Record<string, unknown>).companies as unknown[])
      : null;
  if (list === null) throw unknownResponseSchemaError(wsfunction);
  return list.map((item) => normalizeCompany(item, wsfunction));
}

export function normalizeCourse(raw: unknown, wsfunction: string): { externalId: string; displayName: string } {
  if (!isRecord(raw)) throw unknownResponseSchemaError(wsfunction);
  const candidate = raw as RawCourseCandidate;
  const externalId = idToString(candidate.id);
  const displayName = candidate.fullname ?? candidate.shortname;
  if (externalId === null || typeof displayName !== 'string' || displayName.trim().length === 0) {
    throw unknownResponseSchemaError(wsfunction);
  }
  return { externalId, displayName };
}

/**
 * `get_course_info` is queried for a single course, but whether it
 * returns a bare object, a one-element array, or a `{ courses: [...] }`
 * envelope is UNVERIFIED (Moodle's own `core_course_get_courses` uses the
 * array-even-for-one-id convention, and `block_iomad_company_admin_*`
 * functions may or may not follow it). All three shapes are accepted
 * defensively; an empty list is treated as "not found" (`null`), not an
 * error.
 */
export function normalizeSingleCourse(
  raw: unknown,
  wsfunction: string,
): { externalId: string; displayName: string } | null {
  if (Array.isArray(raw)) {
    if (raw.length === 0) return null;
    return normalizeCourse(raw[0], wsfunction);
  }
  if (isRecord(raw) && Array.isArray((raw as Record<string, unknown>).courses)) {
    const list = (raw as Record<string, unknown>).courses as unknown[];
    if (list.length === 0) return null;
    return normalizeCourse(list[0], wsfunction);
  }
  return normalizeCourse(raw, wsfunction);
}

export function normalizeCourseList(
  raw: unknown,
  wsfunction: string,
): Array<{ externalId: string; displayName: string }> {
  // Same envelope uncertainty as normalizeCompanyList — UNVERIFIED.
  const list = Array.isArray(raw)
    ? raw
    : isRecord(raw) && Array.isArray((raw as Record<string, unknown>).courses)
      ? ((raw as Record<string, unknown>).courses as unknown[])
      : null;
  if (list === null) throw unknownResponseSchemaError(wsfunction);
  return list.map((item) => normalizeCourse(item, wsfunction));
}

// ---------------------------------------------------------------------------
// F5A — company course allocations (LIVE VERIFIED, execution-tested)
// ---------------------------------------------------------------------------

function extractCompaniesArrayForCourses(raw: unknown, wsfunction: string): unknown[] {
  // Unlike normalizeCompanyList, the documented get_company_courses shape
  // is ALWAYS the { companies: [...] } envelope — no bare-array form is
  // documented for this function. A bare array is still accepted
  // defensively (same posture as the rest of this file), but is not
  // itself part of the documented contract.
  if (Array.isArray(raw)) return raw;
  if (isRecord(raw) && Array.isArray((raw as Record<string, unknown>).companies)) {
    return (raw as Record<string, unknown>).companies as unknown[];
  }
  throw unknownResponseSchemaError(wsfunction);
}

function normalizeCustomFields(
  raw: unknown,
): Array<{ externalFieldId: string; name: string; value: string }> | undefined {
  if (!Array.isArray(raw)) return undefined;
  const fields: Array<{ externalFieldId: string; name: string; value: string }> = [];
  for (const item of raw) {
    if (!isRecord(item)) continue; // malformed entry — dropped, not fatal (auxiliary metadata only)
    const candidate = item as RawCustomField;
    const externalFieldId = idToString(candidate.id);
    if (externalFieldId === null || typeof candidate.name !== 'string' || typeof candidate.value !== 'string') {
      continue; // malformed entry — dropped, not fatal
    }
    fields.push({ externalFieldId, name: candidate.name, value: candidate.value });
  }
  return fields.length > 0 ? fields : undefined;
}

function normalizeCompanyCourseAllocationEntry(
  raw: unknown,
  wsfunction: string,
): { externalCourseId: string; fullName: string; customFields?: Array<{ externalFieldId: string; name: string; value: string }> } {
  if (!isRecord(raw)) throw unknownResponseSchemaError(wsfunction);
  const candidate = raw as RawCompanyCourseAllocationEntry;
  const externalCourseId = idToString(candidate.id);
  if (externalCourseId === null || typeof candidate.fullname !== 'string' || candidate.fullname.trim().length === 0) {
    throw unknownResponseSchemaError(wsfunction);
  }
  const result: {
    externalCourseId: string;
    fullName: string;
    customFields?: Array<{ externalFieldId: string; name: string; value: string }>;
  } = { externalCourseId, fullName: candidate.fullname };
  const customFields = normalizeCustomFields(candidate.customfields);
  if (customFields) result.customFields = customFields;
  return result;
}

/**
 * Normalizes `block_iomad_company_admin_get_company_courses`'s documented
 * response for ONE requested company. Per the brief: "Do not assume the
 * company array contains more than the requested company" — this
 * function actively looks up the entry matching `companyId` rather than
 * blindly taking the first (or only) element.
 *
 * - No matching company entry → treated as zero courses (`[]`), not an
 *   error — covers both "company has no courses" and "company filter
 *   matched nothing" the same safe way.
 * - MORE than one entry matching `companyId` → an unexpected/duplicate
 *   result; throws rather than silently picking one (same posture as
 *   `getCompanyByCode`'s duplicate handling).
 * - A matched company with no `courses` key at all → treated as zero
 *   courses (defensive). A matched company where `courses` is present but
 *   not an array → a genuinely malformed shape; throws.
 * - Each course entry is validated individually; `customfields` entries
 *   that don't match the expected shape are dropped, not fatal — they're
 *   auxiliary metadata, not core course identity.
 */
export function normalizeCompanyCourseAllocations(
  raw: unknown,
  wsfunction: string,
  companyId: string,
): Array<{ externalCourseId: string; fullName: string; customFields?: Array<{ externalFieldId: string; name: string; value: string }> }> {
  const companies = extractCompaniesArrayForCourses(raw, wsfunction);
  const matches = companies.filter((c) => isRecord(c) && idToString((c as Record<string, unknown>).id) === companyId);

  if (matches.length > 1) throw unknownResponseSchemaError(wsfunction);
  const matched = matches[0];
  if (!matched || !isRecord(matched)) return [];

  const coursesRaw = (matched as Record<string, unknown>).courses;
  if (coursesRaw === undefined) return [];
  if (!Array.isArray(coursesRaw)) throw unknownResponseSchemaError(wsfunction);

  return coursesRaw.map((item) => normalizeCompanyCourseAllocationEntry(item, wsfunction));
}

// ---------------------------------------------------------------------------
// F5A — course settings (LIVE VERIFIED, execution-tested)
// ---------------------------------------------------------------------------

function normalizeSharedFlag(value: unknown): boolean | null {
  // LIVE VERIFIED: `shared` is numeric on the wire (e.g. `shared: 0`).
  // Normalized as `shared !== 0`, only ever derived from an actual
  // number — never coerced from a JSON boolean or any other type; a
  // non-numeric value is treated as malformed (null), not guessed. Do
  // not invent semantics beyond this.
  return typeof value === 'number' ? value !== 0 : null;
}

function normalizeLicensedFlag(value: unknown): boolean | null {
  // LIVE VERIFIED: `licensed` is returned as a genuine JSON BOOLEAN on
  // the real Iomad instance (observed: `licensed: false`) — unlike
  // `shared` above (and `suspended` on companies), which are confirmed
  // NUMERIC. Boolean is the primary, documented-correct type here and
  // must not be rejected or coerced. Numeric 0/1 is still accepted
  // defensively for forward/backward compatibility (e.g. a differently
  // configured Iomad instance or plugin version), but boolean is what
  // this specific instance actually sends — do not require numeric.
  if (typeof value === 'boolean') return value;
  if (typeof value === 'number') return value !== 0;
  return null;
}

function toFiniteDayCount(value: unknown): number | null {
  return typeof value === 'number' && Number.isFinite(value) ? value : null;
}

function normalizeCourseSettingsEntry(raw: unknown, wsfunction: string): {
  externalCourseId: string;
  licensed: boolean;
  shared: boolean;
  validLengthDays: number;
  warnExpireDays: number;
  warnCompletionDays: number;
  notifyPeriodDays: number;
} {
  if (!isRecord(raw)) throw unknownResponseSchemaError(wsfunction);
  const candidate = raw as RawCourseSettingsCandidate;

  // The settings row's own `id` and the `courseid` it describes are
  // confirmed as two DIFFERENT fields — externalCourseId is deliberately
  // taken from `courseid`, not `id`.
  const externalCourseId = idToString(candidate.courseid);
  const licensed = normalizeLicensedFlag(candidate.licensed);
  const shared = normalizeSharedFlag(candidate.shared);
  const validLengthDays = toFiniteDayCount(candidate.validlength);
  const warnExpireDays = toFiniteDayCount(candidate.warnexpire);
  const warnCompletionDays = toFiniteDayCount(candidate.warncompletion);
  const notifyPeriodDays = toFiniteDayCount(candidate.notifyperiod);

  if (
    externalCourseId === null ||
    licensed === null ||
    shared === null ||
    validLengthDays === null ||
    warnExpireDays === null ||
    warnCompletionDays === null ||
    notifyPeriodDays === null
  ) {
    throw unknownResponseSchemaError(wsfunction);
  }

  return { externalCourseId, licensed, shared, validLengthDays, warnExpireDays, warnCompletionDays, notifyPeriodDays };
}

/**
 * Normalizes `block_iomad_company_admin_get_course_info`'s LIVE VERIFIED
 * response: a bare array of course settings objects, covering the FULL
 * available collection (the real call takes no course-id filter — see
 * the interface-level doc comment above and
 * `IomadRestGateway.getCourseSettings()`, which filters this function's
 * output locally to the caller's requested course IDs). A requested
 * course absent from the collection simply won't appear after that local
 * filter — callers must not assume a 1:1 positional correspondence with
 * their input; match on `externalCourseId` instead.
 */
export function normalizeCourseSettings(
  raw: unknown,
  wsfunction: string,
): Array<{
  externalCourseId: string;
  licensed: boolean;
  shared: boolean;
  validLengthDays: number;
  warnExpireDays: number;
  warnCompletionDays: number;
  notifyPeriodDays: number;
}> {
  if (!Array.isArray(raw)) throw unknownResponseSchemaError(wsfunction);
  return raw.map((item) => normalizeCourseSettingsEntry(item, wsfunction));
}
