import type { IomadConfigured } from './iomadConfig.js';
import {
  IomadGatewayError,
  invalidJsonError,
  logIomadCallFailure,
  moodleExceptionError,
  networkError,
  timeoutError,
  unauthorizedError,
  upstreamHttpError,
} from './IomadErrors.js';

/**
 * Low-level Moodle/Iomad REST transport.
 *
 *   POST {baseUrl}/webservice/rest/server.php
 *     wstoken=<server-side token>
 *     wsfunction=<function>
 *     moodlewsrestformat=json
 *     ...params
 *
 * Deliberately has no Netlify-specific imports (no `@netlify/functions`
 * types, no Handler types) — only `fetch`/`AbortController`/`process.env`
 * via the config it's given, so this file can move to an AWS Lambda/ECS
 * runtime later with no rewrite (F3 §8 portability requirement).
 *
 * Global web services are confirmed enabled on the target Iomad instance,
 * REST enabled, SOAP disabled (docs/IOMAD_INTEGRATION_CONTRACT.md) — this
 * client only ever speaks REST.
 */

const REST_PATH = '/webservice/rest/server.php';
const DEFAULT_TIMEOUT_MS = 8000;

export interface IomadRestCallOptions {
  wsfunction: string;
  /** UNVERIFIED per-function unless documented otherwise at the call
   * site: exact parameter keys are not yet confirmed against the live
   * Iomad instance. Callers document which keys are assumptions (or, for
   * criteria-based lookups — see `buildCriteriaParams` — confirmed) at
   * the call site (see IomadRestGateway.ts). */
  params?: Record<string, string>;
  timeoutMs?: number;
  correlationId?: string;
}

/**
 * Encodes a Moodle/Iomad `criteria` array parameter using the bracketed
 * form-field convention (`criteria[0][fieldA]`, `criteria[0][fieldB]`,
 * `criteria[1][fieldA]`, ...). Each element of `criteria` becomes one
 * indexed criterion; every own-key of that element becomes a bracketed
 * field under that index.
 *
 * CONFIRMED (execution), both cases:
 * - Single-field: `block_iomad_company_admin_get_companies` filtered by
 *   `criteria[0][key]=<code>` (see
 *   docs/IOMAD_INTEGRATION_CONTRACT.md's "Live-verified: get_companies by
 *   code").
 * - Multi-field-per-index: `block_iomad_company_admin_get_company_courses`
 *   filtered by `criteria[0][companyid]=<id>` and
 *   `criteria[0][shared]=<0|1>` together under the SAME index — live
 *   execution-verified against the real Iomad instance, including the
 *   zero-courses response case (see
 *   docs/IOMAD_INTEGRATION_CONTRACT.md's F5A section).
 */
export function buildCriteriaParams(criteria: Array<Record<string, string>>): Record<string, string> {
  const params: Record<string, string> = {};
  criteria.forEach((criterion, index) => {
    for (const [field, value] of Object.entries(criterion)) {
      params[`criteria[${index}][${field}]`] = value;
    }
  });
  return params;
}

/**
 * REMOVED (F5A live-correction pass) — this repository previously
 * exported `buildCourseIdsParams()` to encode
 * `block_iomad_company_admin_get_course_info`'s documented
 * `courrseids[N]` parameter. Execution testing against the real Iomad
 * instance proved this parameter — and every other spelling tried
 * (`courrseids[0]`, `courseids[0]`, `courseid[0]`) — fails with
 * `invalid_parameter_exception`. The real, successful call sends NO
 * course-id parameter at all; `IomadRestGateway.getCourseSettings()`
 * fetches the full available collection and filters locally instead. See
 * docs/IOMAD_INTEGRATION_CONTRACT.md's F5A section for the full
 * correction record — this comment is left here, at the same location
 * the function used to live, specifically so nobody reintroduces this
 * parameter without reading why it was removed.
 */

function isMoodleExceptionPayload(json: unknown): boolean {
  // Moodle web services report failures as an HTTP 200 body shaped like
  // { exception, errorcode, message } rather than a non-2xx status.
  return typeof json === 'object' && json !== null && 'exception' in json;
}

async function performCall(config: IomadConfigured, options: IomadRestCallOptions): Promise<unknown> {
  const { wsfunction, params = {}, timeoutMs = DEFAULT_TIMEOUT_MS, correlationId } = options;

  const body = new URLSearchParams({
    wstoken: config.token,
    wsfunction,
    moodlewsrestformat: 'json',
    ...params,
  });

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  let response: Response;
  try {
    response = await fetch(`${config.baseUrl.replace(/\/$/, '')}${REST_PATH}`, {
      method: 'POST',
      body,
      signal: controller.signal,
    });
  } catch (err) {
    clearTimeout(timer);
    if (err instanceof Error && err.name === 'AbortError') {
      logIomadCallFailure(wsfunction, 'timeout', undefined, correlationId);
      throw timeoutError();
    }
    logIomadCallFailure(wsfunction, 'network_error', undefined, correlationId);
    throw networkError();
  }
  clearTimeout(timer);

  if (response.status === 401 || response.status === 403) {
    logIomadCallFailure(wsfunction, 'unauthorized', response.status, correlationId);
    throw unauthorizedError();
  }

  // Any other non-2xx status (4xx or 5xx) — do not parse or read the body
  // into an error message; the response could be an HTML error page, a
  // proxy error, or anything else that isn't safe/useful to surface.
  // Server logs get the status; callers get a generic safe error.
  if (!response.ok) {
    logIomadCallFailure(wsfunction, 'upstream_http_error', response.status, correlationId);
    throw upstreamHttpError();
  }

  let json: unknown;
  try {
    json = await response.json();
  } catch {
    logIomadCallFailure(wsfunction, 'invalid_json', response.status, correlationId);
    throw invalidJsonError();
  }

  if (isMoodleExceptionPayload(json)) {
    logIomadCallFailure(wsfunction, 'moodle_exception', response.status, correlationId);
    throw moodleExceptionError(wsfunction);
  }

  return json;
}

/**
 * One small safe retry on transient network failure only — matching F3
 * §7 ("zero or one small safe retry ... for idempotent GET-like REST
 * operations"). Never retries `timeout`, `moodle_exception`,
 * `unauthorized`, or `upstream_http_error` (including 5xx) — none of
 * those are transient in the way a single dropped connection is: a 5xx
 * indicates the upstream service itself is failing, and retrying
 * immediately against a struggling server has no established benefit in
 * F3's scope and risks compounding load. Revisit with backoff/jitter in
 * a later phase if real-world 5xx behaviour justifies it.
 */
export async function callIomadRest(config: IomadConfigured, options: IomadRestCallOptions): Promise<unknown> {
  try {
    return await performCall(config, options);
  } catch (err) {
    if (err instanceof IomadGatewayError && err.code === 'network_error') {
      return performCall(config, options);
    }
    throw err;
  }
}
