import { getIomadConfig, type IomadConfigured } from './iomadConfig.js';
import { invalidConfigError, notConfiguredError, unknownResponseSchemaError } from './IomadErrors.js';
import { buildCriteriaParams, callIomadRest } from './IomadRestClient.js';
import {
  normalizeCompanyCourseAllocations,
  normalizeCompanyList,
  normalizeCourseSettings,
  normalizeSingleCourse,
} from './IomadResponseAdapters.js';

/**
 * Server-side, read-only implementation of the `IomadGateway` contract
 * defined in `src/integrations/iomad/IomadGateway.ts`. This file does NOT
 * import that one — `netlify/functions/` has zero import path back into
 * `src/` (see `netlify/functions/_lib/validation.ts`'s header for the
 * established precedent) — so the shape below is kept in sync by hand
 * with that interface rather than by a shared import.
 *
 * Confirmed/documented Iomad function mapping (docs/IOMAD_INTEGRATION_CONTRACT.md):
 *   listCompanies         → block_iomad_company_admin_get_companies (no
 *                           criteria — UNVERIFIED whether this call form
 *                           works/what it returns)
 *   getCompanyByCode      → block_iomad_company_admin_get_companies,
 *                           filtered by `criteria[0][key]=code` —
 *                           CONFIRMED (execution), live-tested
 *   getCompany            → derived from listCompanies() — no confirmed
 *                           single-company-by-id function exists
 *   listCompanyCourses    → block_iomad_company_admin_get_company_courses,
 *                           filtered by `criteria[0][companyid]`/
 *                           `criteria[0][shared]` — F5A: LIVE VERIFIED
 *                           (execution) against the real Iomad instance,
 *                           including the zero-courses case
 *   getCourse             → block_iomad_company_admin_get_course_info,
 *                           singular `courseid` param — F3-era guess,
 *                           entirely UNVERIFIED, superseded in practice
 *                           by getCourseSettings below (same wsfunction,
 *                           live-verified contract) but left untouched —
 *                           no redesign in F5A
 *   getCourseSettings     → block_iomad_company_admin_get_course_info,
 *                           called with NO course-id parameters at all —
 *                           F5A: LIVE VERIFIED (execution). The generated
 *                           API documentation described a `courrseids[N]`
 *                           parameter; execution testing proved every
 *                           parameterized variant tried
 *                           (`courrseids[0]`, `courseids[0]`,
 *                           `courseid[0]`) fails with
 *                           `invalid_parameter_exception`. The real
 *                           runtime contract takes no course-id
 *                           parameter at all, returns the full available
 *                           course-settings collection, and callers
 *                           filter locally — see the method below and
 *                           docs/IOMAD_INTEGRATION_CONTRACT.md's F5A
 *                           section for the full correction record.
 *
 * Only this file (and its siblings in this folder) may reference a raw
 * Moodle/Iomad wsfunction name — nowhere else in the codebase should a
 * `block_iomad_company_admin_*` string appear.
 */

export interface IomadCompanySummary {
  externalId: string;
  displayName: string;
  /** Iomad's own `code` field — CONFIRMED present and distinct from
   * `shortname` (live example: `code: "MYGURU-SHIKSHA-001"`,
   * `shortname: "SHIKSHA"`). Optional because not every code path that
   * produces an `IomadCompanySummary` is guaranteed to have observed it
   * (defensive — absent rather than guessed). */
  code?: string;
  /** CONFIRMED numeric on the wire (0 = active, non-zero = suspended) —
   * never a JSON boolean. Derived only from an actual number; undefined
   * if the field was absent or non-numeric — never assumed. NOT
   * currently consumed by any sync/business logic (F4's organisation
   * sync ignores this entirely — see
   * docs/IOMAD_INTEGRATION_CONTRACT.md's live schema gate); capturing it
   * here is adapter-contract fidelity only, not a behaviour change. */
  isSuspended?: boolean;
}

export interface IomadCourseSummary {
  externalId: string;
  displayName: string;
}

/**
 * F5A — one course allocated to a company, as returned nested inside
 * `block_iomad_company_admin_get_company_courses`'s response. DOCUMENTED,
 * NOT YET execution-verified — see file header.
 */
export interface CompanyCourseAllocation {
  externalCourseId: string;
  fullName: string;
  /** Present only if Iomad returned at least one well-formed custom
   * field for this course. Malformed individual entries are dropped, not
   * fatal — see `normalizeCustomFields` in IomadResponseAdapters.ts. */
  customFields?: Array<{ externalFieldId: string; name: string; value: string }>;
}

/**
 * F5A — one course's licensing/settings row, as returned by
 * `block_iomad_company_admin_get_course_info`. DOCUMENTED, NOT YET
 * execution-verified — see file header. `licensed`/`shared` are derived
 * strictly from a numeric wire value (`!== 0`) — never assumed boolean.
 */
export interface IomadCourseSettings {
  externalCourseId: string;
  licensed: boolean;
  shared: boolean;
  validLengthDays: number;
  warnExpireDays: number;
  warnCompletionDays: number;
  notifyPeriodDays: number;
}

export interface ListCompaniesOptions {
  page?: number;
}

export interface IomadGateway {
  listCompanies(options?: ListCompaniesOptions): Promise<IomadCompanySummary[]>;
  getCompany(externalCompanyId: string): Promise<IomadCompanySummary | null>;

  /** CONFIRMED — live-tested lookup by Iomad company `code` (not the
   * numeric id). See "Live-verified: get_companies by code" in
   * docs/IOMAD_INTEGRATION_CONTRACT.md. */
  getCompanyByCode(code: string): Promise<IomadCompanySummary | null>;

  /**
   * F5A — courses allocated to a company. `shared` defaults to `false`
   * (`criteria[0][shared]=0`, a "normal company-specific lookup" per the
   * live-verified contract). LIVE VERIFIED (execution), including the
   * zero-courses case (a valid success, not an error).
   */
  listCompanyCourses(companyId: string, shared?: boolean): Promise<CompanyCourseAllocation[]>;

  getCourse(externalCourseId: string): Promise<IomadCourseSummary | null>;

  /**
   * F5A — course settings/licensing info for one or more courses.
   * LIVE VERIFIED (execution): the real `get_course_info` call takes NO
   * course-id parameter at all — every parameterized variant tried
   * (`courrseids[0]`, `courseids[0]`, `courseid[0]`) failed with
   * `invalid_parameter_exception`. This method fetches the full
   * available settings collection and filters it locally to `courseIds`
   * — callers never see settings for a course they didn't ask about.
   * Returns possibly fewer entries than `courseIds` if a requested course
   * has no settings record — do not assume positional correspondence.
   * Empty input returns an empty array without making a network call.
   */
  getCourseSettings(courseIds: string[]): Promise<IomadCourseSettings[]>;
}

const WSFUNCTION = {
  getCompanies: 'block_iomad_company_admin_get_companies',
  getCompanyCourses: 'block_iomad_company_admin_get_company_courses',
  getCourseInfo: 'block_iomad_company_admin_get_course_info',
} as const;

export class IomadRestGateway implements IomadGateway {
  private readonly config: IomadConfigured;

  constructor(config: IomadConfigured) {
    this.config = config;
  }

  async listCompanies(_options?: ListCompaniesOptions): Promise<IomadCompanySummary[]> {
    // UNVERIFIED: no criteria/pagination params are sent for this
    // unfiltered bulk call. Only the CRITERIA-FILTERED single-company
    // lookup (getCompanyByCode, below) has actually been live-tested —
    // this no-criteria call's behaviour (does it return all companies?
    // is it even accepted?) remains unconfirmed.
    const raw = await callIomadRest(this.config, { wsfunction: WSFUNCTION.getCompanies });
    return normalizeCompanyList(raw, WSFUNCTION.getCompanies);
  }

  async getCompany(externalCompanyId: string): Promise<IomadCompanySummary | null> {
    // No confirmed single-company-by-id function exists as of F3/F4 —
    // derived by filtering listCompanies(). See file header and
    // docs/IOMAD_INTEGRATION_CONTRACT.md. (The one confirmed lookup,
    // getCompanyByCode below, filters by CODE, not by this numeric id.)
    const companies = await this.listCompanies();
    return companies.find((c) => c.externalId === externalCompanyId) ?? null;
  }

  async getCompanyByCode(code: string): Promise<IomadCompanySummary | null> {
    // CONFIRMED — live-tested against the real Iomad instance:
    // criteria[0][key]=code, criteria[0][value]=<code>, response
    // { companies: [...], warnings: [...] }. See
    // docs/IOMAD_INTEGRATION_CONTRACT.md's "Live-verified: get_companies
    // by code".
    const raw = await callIomadRest(this.config, {
      wsfunction: WSFUNCTION.getCompanies,
      params: buildCriteriaParams([{ key: 'code', value: code }]),
    });
    const companies = normalizeCompanyList(raw, WSFUNCTION.getCompanies);
    if (companies.length === 0) return null;
    if (companies.length > 1) {
      // A code-based lookup returning more than one company is an
      // unexpected/duplicate result — a code is expected to identify at
      // most one company. Do not silently guess which one is correct.
      throw unknownResponseSchemaError(WSFUNCTION.getCompanies);
    }
    return companies[0];
  }

  async listCompanyCourses(companyId: string, shared = false): Promise<CompanyCourseAllocation[]> {
    // F5A — LIVE VERIFIED (execution): criteria[0][companyid],
    // criteria[0][shared] together under the same criterion index,
    // including the zero-courses case (a company with no allocated
    // courses returns `courses: []`, a valid success, not an error). See
    // file header and docs/IOMAD_INTEGRATION_CONTRACT.md.
    const raw = await callIomadRest(this.config, {
      wsfunction: WSFUNCTION.getCompanyCourses,
      params: buildCriteriaParams([{ companyid: companyId, shared: shared ? '1' : '0' }]),
    });
    return normalizeCompanyCourseAllocations(raw, WSFUNCTION.getCompanyCourses, companyId);
  }

  async getCourse(externalCourseId: string): Promise<IomadCourseSummary | null> {
    // UNVERIFIED: parameter key assumed `courseid` pending live schema
    // confirmation against the real Iomad instance.
    const raw = await callIomadRest(this.config, {
      wsfunction: WSFUNCTION.getCourseInfo,
      params: { courseid: externalCourseId },
    });
    return normalizeSingleCourse(raw, WSFUNCTION.getCourseInfo);
  }

  async getCourseSettings(courseIds: string[]): Promise<IomadCourseSettings[]> {
    // Nothing requested → nothing to fetch or filter. Also covers F5A's
    // zero-courses case: listCompanyCourses() returning no course IDs
    // must not trigger this call at all — callers (e.g.
    // scripts/iomad-company-courses.ts) already short-circuit before
    // reaching here, and this guard is a second, independent line of
    // defence against ever calling get_course_info unnecessarily.
    if (courseIds.length === 0) return [];

    // F5A — LIVE VERIFIED (execution): the generated API documentation
    // described a `courrseids[N]` parameter. Execution testing proved
    // EVERY parameterized variant tried — `courrseids[0]`, `courseids[0]`,
    // `courseid[0]` — fails with `invalid_parameter_exception`. The real,
    // successful call sends NO course-id parameter at all
    // (wstoken/wsfunction/moodlewsrestformat only) and returns the FULL
    // available course-settings collection, which is filtered LOCALLY to
    // the requested `courseIds` below. Do not reintroduce a course-id
    // parameter here without new live evidence — see
    // docs/IOMAD_INTEGRATION_CONTRACT.md's F5A section for the full
    // correction record.
    const raw = await callIomadRest(this.config, { wsfunction: WSFUNCTION.getCourseInfo });
    const allSettings = normalizeCourseSettings(raw, WSFUNCTION.getCourseInfo);

    const requested = new Set(courseIds);
    return allSettings.filter((settings) => requested.has(settings.externalCourseId));
  }
}

/**
 * Gateway that is always safe to construct — missing or invalid
 * configuration must never crash application startup (F3 §5). Every
 * method throws the same safe error (`not_configured` or
 * `invalid_config`) on first *use*, not at construction.
 */
class NotConfiguredIomadGateway implements IomadGateway {
  private readonly error: () => Error;

  constructor(error: () => Error) {
    this.error = error;
  }

  async listCompanies(): Promise<IomadCompanySummary[]> {
    throw this.error();
  }
  async getCompany(): Promise<IomadCompanySummary | null> {
    throw this.error();
  }
  async getCompanyByCode(): Promise<IomadCompanySummary | null> {
    throw this.error();
  }
  async listCompanyCourses(): Promise<CompanyCourseAllocation[]> {
    throw this.error();
  }
  async getCourse(): Promise<IomadCourseSummary | null> {
    throw this.error();
  }
  async getCourseSettings(): Promise<IomadCourseSettings[]> {
    throw this.error();
  }
}

/**
 * Composition entry point for server-side callers. Always succeeds —
 * returns a working gateway only if `IOMAD_BASE_URL`/`IOMAD_SERVICE_TOKEN`
 * are both set AND `IOMAD_BASE_URL` passes validation (parses as a URL,
 * uses `https:`). Otherwise returns a gateway that safely errors on
 * first call — `not_configured` if nothing is set, `invalid_config` if
 * `IOMAD_BASE_URL` is set but malformed or non-https.
 */
export function createIomadGateway(): IomadGateway {
  const config = getIomadConfig();
  if (config.status === 'not_configured') {
    return new NotConfiguredIomadGateway(notConfiguredError);
  }
  if (config.status === 'invalid_config') {
    return new NotConfiguredIomadGateway(invalidConfigError);
  }
  return new IomadRestGateway(config);
}
