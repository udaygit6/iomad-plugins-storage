import { describe, it, expect } from 'vitest';
import {
  normalizeCompany,
  normalizeCompanyCourseAllocations,
  normalizeCompanyList,
  normalizeCourse,
  normalizeCourseList,
  normalizeCourseSettings,
  normalizeSingleCourse,
} from '../IomadResponseAdapters.js';
import { IomadGatewayError } from '../IomadErrors.js';
import {
  SHIKSHA_ACADEMY_RAW_COMPANY,
  SHIKSHA_ACADEMY_RAW_RESPONSE,
  SHIKSHA_ACADEMY_NORMALIZED,
} from './fixtures/shikshaAcademy.js';

const FN = 'block_iomad_company_admin_get_companies';

describe('normalizeCompany — verified live fixture (Shiksha Academy)', () => {
  it('maps the real live get_companies-by-code response to the expected normalized shape', () => {
    expect(normalizeCompany(SHIKSHA_ACADEMY_RAW_COMPANY, FN)).toEqual(SHIKSHA_ACADEMY_NORMALIZED);
  });

  it('reads suspended: 0 as isSuspended: false — numeric, never assumed boolean', () => {
    const result = normalizeCompany(SHIKSHA_ACADEMY_RAW_COMPANY, FN);
    expect(result.isSuspended).toBe(false);
  });

  it('reads a nonzero suspended value as isSuspended: true', () => {
    const result = normalizeCompany({ ...SHIKSHA_ACADEMY_RAW_COMPANY, suspended: 1 }, FN);
    expect(result.isSuspended).toBe(true);
  });

  it('does not assume isSuspended when suspended is a JSON boolean rather than numeric (defensive — never guesses)', () => {
    // Guards against ever reintroducing a boolean assumption: if a future
    // response shape somehow sent `suspended: true`/`false` instead of a
    // number, this must NOT be silently treated as if it were the numeric
    // 0/1 convention — isSuspended stays undefined rather than guessing.
    const result = normalizeCompany({ ...SHIKSHA_ACADEMY_RAW_COMPANY, suspended: false }, FN);
    expect(result.isSuspended).toBeUndefined();
  });

  it('leaves isSuspended undefined when suspended is absent entirely', () => {
    const { suspended: _suspended, ...withoutSuspended } = SHIKSHA_ACADEMY_RAW_COMPANY;
    const result = normalizeCompany(withoutSuspended, FN);
    expect(result.isSuspended).toBeUndefined();
  });

  it('captures code as a field distinct from shortname', () => {
    const result = normalizeCompany(SHIKSHA_ACADEMY_RAW_COMPANY, FN);
    expect(result.code).toBe('MYGURU-SHIKSHA-001');
    expect(result.displayName).not.toBe(result.code);
  });

  it('discards unknown/extra fields from the live payload (address, city, region, country, parentid, hostname, maxusers, custom1-3)', () => {
    const result = normalizeCompany(SHIKSHA_ACADEMY_RAW_COMPANY, FN);
    expect(result).not.toHaveProperty('address');
    expect(result).not.toHaveProperty('city');
    expect(result).not.toHaveProperty('custom1');
    expect(Object.keys(result).sort()).toEqual(['code', 'displayName', 'externalId', 'isSuspended'].sort());
  });
});

describe('normalizeCompanyList — verified live envelope (Shiksha Academy)', () => {
  it('parses the real { companies: [...], warnings: [...] } envelope', () => {
    expect(normalizeCompanyList(SHIKSHA_ACADEMY_RAW_RESPONSE, FN)).toEqual([SHIKSHA_ACADEMY_NORMALIZED]);
  });

  it('does not choke on a non-empty warnings array alongside companies', () => {
    const withWarnings = { companies: [SHIKSHA_ACADEMY_RAW_COMPANY], warnings: [{ item: 'company', warningcode: 'x' }] };
    expect(normalizeCompanyList(withWarnings, FN)).toEqual([SHIKSHA_ACADEMY_NORMALIZED]);
  });

  it('handles an empty companies array safely (no match found for a code)', () => {
    expect(normalizeCompanyList({ companies: [], warnings: [] }, FN)).toEqual([]);
  });
});

describe('normalizeCompany', () => {
  it('maps a well-formed record to { externalId, displayName }', () => {
    expect(normalizeCompany({ id: 1, name: 'Acme Tutoring' }, FN)).toEqual({
      externalId: '1',
      displayName: 'Acme Tutoring',
    });
  });

  it('falls back to shortname when name is absent', () => {
    expect(normalizeCompany({ id: 2, shortname: 'acme' }, FN)).toEqual({ externalId: '2', displayName: 'acme' });
  });

  it('accepts a string id', () => {
    expect(normalizeCompany({ id: 'abc-123', name: 'Acme' }, FN)).toEqual({
      externalId: 'abc-123',
      displayName: 'Acme',
    });
  });

  it('throws unknown_response_schema when id is missing', () => {
    expect(() => normalizeCompany({ name: 'Acme' }, FN)).toThrow(IomadGatewayError);
    try {
      normalizeCompany({ name: 'Acme' }, FN);
    } catch (err) {
      expect((err as IomadGatewayError).code).toBe('unknown_response_schema');
    }
  });

  it('throws unknown_response_schema when both name and shortname are missing', () => {
    expect(() => normalizeCompany({ id: 1 }, FN)).toThrow(IomadGatewayError);
  });

  it('throws unknown_response_schema for a non-object value', () => {
    expect(() => normalizeCompany('not an object', FN)).toThrow(IomadGatewayError);
    expect(() => normalizeCompany(null, FN)).toThrow(IomadGatewayError);
  });
});

describe('normalizeCompanyList', () => {
  it('accepts a bare array', () => {
    expect(normalizeCompanyList([{ id: 1, name: 'Acme' }], FN)).toEqual([{ externalId: '1', displayName: 'Acme' }]);
  });

  it('accepts a { companies: [...] } envelope', () => {
    expect(normalizeCompanyList({ companies: [{ id: 1, name: 'Acme' }] }, FN)).toEqual([
      { externalId: '1', displayName: 'Acme' },
    ]);
  });

  it('throws unknown_response_schema for neither shape', () => {
    expect(() => normalizeCompanyList({ unexpected: true }, FN)).toThrow(IomadGatewayError);
  });
});

describe('normalizeCourse', () => {
  it('maps a well-formed record to { externalId, displayName }', () => {
    expect(normalizeCourse({ id: 10, fullname: 'GCSE Maths' }, FN)).toEqual({
      externalId: '10',
      displayName: 'GCSE Maths',
    });
  });

  it('falls back to shortname when fullname is absent', () => {
    expect(normalizeCourse({ id: 10, shortname: 'gcse-maths' }, FN)).toEqual({
      externalId: '10',
      displayName: 'gcse-maths',
    });
  });

  it('throws unknown_response_schema when id is missing', () => {
    expect(() => normalizeCourse({ fullname: 'GCSE Maths' }, FN)).toThrow(IomadGatewayError);
  });
});

describe('normalizeCourseList', () => {
  it('accepts a bare array', () => {
    expect(normalizeCourseList([{ id: 10, fullname: 'GCSE Maths' }], FN)).toEqual([
      { externalId: '10', displayName: 'GCSE Maths' },
    ]);
  });

  it('accepts a { courses: [...] } envelope', () => {
    expect(normalizeCourseList({ courses: [{ id: 10, fullname: 'GCSE Maths' }] }, FN)).toEqual([
      { externalId: '10', displayName: 'GCSE Maths' },
    ]);
  });

  it('throws unknown_response_schema for neither shape', () => {
    expect(() => normalizeCourseList({ unexpected: true }, FN)).toThrow(IomadGatewayError);
  });
});

describe('normalizeSingleCourse', () => {
  it('accepts a bare object', () => {
    expect(normalizeSingleCourse({ id: 10, fullname: 'GCSE Maths' }, FN)).toEqual({
      externalId: '10',
      displayName: 'GCSE Maths',
    });
  });

  it('accepts a one-element array and returns the first item', () => {
    expect(normalizeSingleCourse([{ id: 10, fullname: 'GCSE Maths' }], FN)).toEqual({
      externalId: '10',
      displayName: 'GCSE Maths',
    });
  });

  it('accepts a { courses: [...] } envelope', () => {
    expect(normalizeSingleCourse({ courses: [{ id: 10, fullname: 'GCSE Maths' }] }, FN)).toEqual({
      externalId: '10',
      displayName: 'GCSE Maths',
    });
  });

  it('returns null for an empty array (not found, not an error)', () => {
    expect(normalizeSingleCourse([], FN)).toBeNull();
  });

  it('returns null for an empty { courses: [] } envelope', () => {
    expect(normalizeSingleCourse({ courses: [] }, FN)).toBeNull();
  });

  it('throws unknown_response_schema for a malformed non-empty response', () => {
    expect(() => normalizeSingleCourse({ id: 10 }, FN)).toThrow(IomadGatewayError);
  });
});

const COURSES_FN = 'block_iomad_company_admin_get_company_courses';

describe('normalizeCompanyCourseAllocations (F5A — LIVE VERIFIED, execution-tested)', () => {
  it('maps the exact real Jupiter Test Academy response (company id 4, one allocated course)', () => {
    const raw = {
      companies: [
        {
          id: 4,
          name: 'Jupiter Test Academy',
          shortname: 'JUPITERSCHOLAR',
          code: 'MYGURU-JUPITER-TEST-001',
          address: '',
          city: 'southampton',
          region: '',
          postcode: '',
          country: 'GB',
          custom1: '',
          custom2: '',
          custom3: '',
          courses: [{ id: 4, fullname: 'Jupiter Test Mathematics', customfields: [] }],
        },
      ],
      warnings: [],
    };

    expect(normalizeCompanyCourseAllocations(raw, COURSES_FN, '4')).toEqual([
      { externalCourseId: '4', fullName: 'Jupiter Test Mathematics' },
    ]);
  });

  it('LIVE VERIFIED: a company with zero allocated courses (courses: []) is a valid success, not an error — the real pre-allocation Jupiter response', () => {
    const raw = {
      companies: [
        {
          id: 4,
          name: 'Jupiter Test Academy',
          shortname: 'JUPITERSCHOLAR',
          code: 'MYGURU-JUPITER-TEST-001',
          address: '',
          city: 'southampton',
          region: '',
          postcode: '',
          country: 'GB',
          custom1: '',
          custom2: '',
          custom3: '',
          courses: [],
        },
      ],
      warnings: [],
    };

    expect(normalizeCompanyCourseAllocations(raw, COURSES_FN, '4')).toEqual([]);
  });

  it('maps the documented { companies: [ { id, courses: [...] } ] } envelope for the requested company', () => {
    const raw = {
      companies: [
        {
          id: 4,
          name: 'Jupiter Test Academy',
          shortname: 'JUPITER',
          code: 'MYGURU-JUPITER-TEST-001',
          courses: [
            { id: 101, fullname: 'Intro to Testing' },
            { id: 102, fullname: 'Advanced Testing' },
          ],
        },
      ],
      warnings: [],
    };

    expect(normalizeCompanyCourseAllocations(raw, COURSES_FN, '4')).toEqual([
      { externalCourseId: '101', fullName: 'Intro to Testing' },
      { externalCourseId: '102', fullName: 'Advanced Testing' },
    ]);
  });

  it('captures well-formed customfields', () => {
    const raw = {
      companies: [
        {
          id: 4,
          courses: [
            {
              id: 101,
              fullname: 'Intro to Testing',
              customfields: [{ id: 1, name: 'Level', value: 'Beginner' }],
            },
          ],
        },
      ],
    };

    expect(normalizeCompanyCourseAllocations(raw, COURSES_FN, '4')).toEqual([
      {
        externalCourseId: '101',
        fullName: 'Intro to Testing',
        customFields: [{ externalFieldId: '1', name: 'Level', value: 'Beginner' }],
      },
    ]);
  });

  it('drops malformed individual customfields entries without failing the whole course (auxiliary metadata only)', () => {
    const raw = {
      companies: [
        {
          id: 4,
          courses: [
            {
              id: 101,
              fullname: 'Intro to Testing',
              customfields: [
                { id: 1, name: 'Level', value: 'Beginner' },
                { id: 2, name: 'Missing value' }, // malformed — dropped
                'not even an object', // malformed — dropped
              ],
            },
          ],
        },
      ],
    };

    const result = normalizeCompanyCourseAllocations(raw, COURSES_FN, '4');
    expect(result[0].customFields).toEqual([{ externalFieldId: '1', name: 'Level', value: 'Beginner' }]);
  });

  it('omits customFields entirely when none are well-formed or present', () => {
    const raw = { companies: [{ id: 4, courses: [{ id: 101, fullname: 'Intro to Testing' }] }] };
    const result = normalizeCompanyCourseAllocations(raw, COURSES_FN, '4');
    expect(result[0]).not.toHaveProperty('customFields');
  });

  it('does NOT assume the company array contains only the requested company — picks the matching entry', () => {
    const raw = {
      companies: [
        { id: 3, courses: [{ id: 999, fullname: 'Should not appear' }] },
        { id: 4, courses: [{ id: 101, fullname: 'Intro to Testing' }] },
      ],
    };
    expect(normalizeCompanyCourseAllocations(raw, COURSES_FN, '4')).toEqual([
      { externalCourseId: '101', fullName: 'Intro to Testing' },
    ]);
  });

  it('a company with zero courses (empty courses array) returns an empty result, not an error', () => {
    const raw = { companies: [{ id: 4, courses: [] }] };
    expect(normalizeCompanyCourseAllocations(raw, COURSES_FN, '4')).toEqual([]);
  });

  it('a company entry with no courses key at all is treated as zero courses defensively', () => {
    const raw = { companies: [{ id: 4 }] };
    expect(normalizeCompanyCourseAllocations(raw, COURSES_FN, '4')).toEqual([]);
  });

  it('no matching company in the response is treated as zero courses, not an error', () => {
    const raw = { companies: [{ id: 999, courses: [{ id: 1, fullname: 'Other' }] }] };
    expect(normalizeCompanyCourseAllocations(raw, COURSES_FN, '4')).toEqual([]);
  });

  it('an empty companies array is treated as zero courses', () => {
    expect(normalizeCompanyCourseAllocations({ companies: [] }, COURSES_FN, '4')).toEqual([]);
  });

  it('throws unknown_response_schema when more than one entry matches the requested company id (duplicate/unexpected)', () => {
    const raw = { companies: [{ id: 4, courses: [] }, { id: 4, courses: [] }] };
    expect(() => normalizeCompanyCourseAllocations(raw, COURSES_FN, '4')).toThrow(IomadGatewayError);
  });

  it('throws unknown_response_schema when the matched company has a non-array courses value (genuinely malformed)', () => {
    const raw = { companies: [{ id: 4, courses: 'not an array' }] };
    expect(() => normalizeCompanyCourseAllocations(raw, COURSES_FN, '4')).toThrow(IomadGatewayError);
  });

  it('throws unknown_response_schema for a malformed individual course entry (missing fullname)', () => {
    const raw = { companies: [{ id: 4, courses: [{ id: 101 }] }] };
    expect(() => normalizeCompanyCourseAllocations(raw, COURSES_FN, '4')).toThrow(IomadGatewayError);
  });

  it('accepts a bare array as a defensive fallback, even though only the object envelope is documented', () => {
    const raw = [{ id: 4, courses: [{ id: 101, fullname: 'Intro to Testing' }] }];
    expect(normalizeCompanyCourseAllocations(raw, COURSES_FN, '4')).toEqual([
      { externalCourseId: '101', fullName: 'Intro to Testing' },
    ]);
  });

  it('throws unknown_response_schema for a wholly malformed response (neither array nor { companies })', () => {
    expect(() => normalizeCompanyCourseAllocations({ nonsense: true }, COURSES_FN, '4')).toThrow(IomadGatewayError);
  });
});

const COURSE_INFO_FN = 'block_iomad_company_admin_get_course_info';

describe('normalizeCourseSettings (F5A — LIVE VERIFIED, execution-tested)', () => {
  it('maps the live-verified bare-array response to the normalized settings shape (real Jupiter Test Academy example)', () => {
    // Exact real response from the live instance for company id 4.
    const raw = [
      { id: 2, courseid: 3, licensed: false, shared: 0, validlength: 0, warnexpire: 0, warncompletion: 0, notifyperiod: 0 },
      { id: 3, courseid: 4, licensed: false, shared: 0, validlength: 0, warnexpire: 0, warncompletion: 0, notifyperiod: 0 },
    ];

    expect(normalizeCourseSettings(raw, COURSE_INFO_FN)).toEqual([
      {
        externalCourseId: '3',
        licensed: false,
        shared: false,
        validLengthDays: 0,
        warnExpireDays: 0,
        warnCompletionDays: 0,
        notifyPeriodDays: 0,
      },
      {
        externalCourseId: '4',
        licensed: false,
        shared: false,
        validLengthDays: 0,
        warnExpireDays: 0,
        warnCompletionDays: 0,
        notifyPeriodDays: 0,
      },
    ]);
  });

  it('LIVE VERIFIED: licensed is a genuine JSON boolean on the wire — used directly, never required to be numeric', () => {
    const raw = [
      { courseid: 101, licensed: false, shared: 0, validlength: 0, warnexpire: 0, warncompletion: 0, notifyperiod: 0 },
    ];
    expect(normalizeCourseSettings(raw, COURSE_INFO_FN)[0].licensed).toBe(false);
  });

  it('licensed: true (boolean) is also accepted and used directly', () => {
    const raw = [
      { courseid: 101, licensed: true, shared: 0, validlength: 0, warnexpire: 0, warncompletion: 0, notifyperiod: 0 },
    ];
    expect(normalizeCourseSettings(raw, COURSE_INFO_FN)[0].licensed).toBe(true);
  });

  it('licensed: numeric 0/1 is still accepted defensively for compatibility, normalized via !== 0', () => {
    const raw = [
      { courseid: 101, licensed: 1, shared: 0, validlength: 0, warnexpire: 0, warncompletion: 0, notifyperiod: 0 },
    ];
    expect(normalizeCourseSettings(raw, COURSE_INFO_FN)[0].licensed).toBe(true);
  });

  it('LIVE VERIFIED: shared remains numeric (shared !== 0) — a JSON boolean for shared is rejected, not guessed', () => {
    const raw = [
      { courseid: 101, licensed: false, shared: true, validlength: 0, warnexpire: 0, warncompletion: 0, notifyperiod: 0 },
    ];
    expect(() => normalizeCourseSettings(raw, COURSE_INFO_FN)).toThrow(IomadGatewayError);
  });

  it('shared numeric 0/1 normalizes correctly', () => {
    const raw = [
      { courseid: 101, licensed: false, shared: 1, validlength: 0, warnexpire: 0, warncompletion: 0, notifyperiod: 0 },
    ];
    expect(normalizeCourseSettings(raw, COURSE_INFO_FN)[0].shared).toBe(true);
  });

  it('handles multiple course settings entries (multiple settings records parsed)', () => {
    const raw = [
      { courseid: 101, licensed: false, shared: 0, validlength: 1, warnexpire: 1, warncompletion: 1, notifyperiod: 1 },
      { courseid: 102, licensed: true, shared: 1, validlength: 2, warnexpire: 2, warncompletion: 2, notifyperiod: 2 },
    ];
    const result = normalizeCourseSettings(raw, COURSE_INFO_FN);
    expect(result).toHaveLength(2);
    expect(result[0].externalCourseId).toBe('101');
    expect(result[1].externalCourseId).toBe('102');
  });

  it('uses courseid (not the settings row\'s own id) as externalCourseId', () => {
    const raw = [{ id: 999, courseid: 101, licensed: false, shared: 0, validlength: 0, warnexpire: 0, warncompletion: 0, notifyperiod: 0 }];
    expect(normalizeCourseSettings(raw, COURSE_INFO_FN)[0].externalCourseId).toBe('101');
  });

  it('handles an empty array response (the full collection happened to be empty)', () => {
    expect(normalizeCourseSettings([], COURSE_INFO_FN)).toEqual([]);
  });

  it('throws unknown_response_schema for a non-array response (the live-verified contract is always a bare array)', () => {
    expect(() => normalizeCourseSettings({ courseid: 101 }, COURSE_INFO_FN)).toThrow(IomadGatewayError);
  });

  it('throws unknown_response_schema when a day-count field is missing', () => {
    const raw = [{ courseid: 101, licensed: false, shared: 0, warnexpire: 0, warncompletion: 0, notifyperiod: 0 }];
    expect(() => normalizeCourseSettings(raw, COURSE_INFO_FN)).toThrow(IomadGatewayError);
  });

  it('throws unknown_response_schema when courseid is missing entirely', () => {
    const raw = [{ licensed: false, shared: 0, validlength: 0, warnexpire: 0, warncompletion: 0, notifyperiod: 0 }];
    expect(() => normalizeCourseSettings(raw, COURSE_INFO_FN)).toThrow(IomadGatewayError);
  });
});
