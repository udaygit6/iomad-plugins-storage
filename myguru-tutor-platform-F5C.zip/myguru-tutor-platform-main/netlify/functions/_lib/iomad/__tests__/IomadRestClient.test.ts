import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { buildCriteriaParams, callIomadRest } from '../IomadRestClient.js';
import { IomadGatewayError } from '../IomadErrors.js';
import type { IomadConfigured } from '../iomadConfig.js';
import { SHIKSHA_ACADEMY_RAW_RESPONSE } from './fixtures/shikshaAcademy.js';

const config: IomadConfigured = {
  status: 'configured',
  baseUrl: 'https://iomad.example.com',
  token: 'super-secret-token-value',
};

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });
}

describe('buildCriteriaParams', () => {
  it('encodes a single criterion as criteria[0][key]/criteria[0][value] — the verified live request format', () => {
    expect(buildCriteriaParams([{ key: 'code', value: 'MYGURU-SHIKSHA-001' }])).toEqual({
      'criteria[0][key]': 'code',
      'criteria[0][value]': 'MYGURU-SHIKSHA-001',
    });
  });

  it('encodes multiple criteria with incrementing indices', () => {
    expect(
      buildCriteriaParams([
        { key: 'code', value: 'MYGURU-SHIKSHA-001' },
        { key: 'name', value: 'Shiksha Academy' },
      ]),
    ).toEqual({
      'criteria[0][key]': 'code',
      'criteria[0][value]': 'MYGURU-SHIKSHA-001',
      'criteria[1][key]': 'name',
      'criteria[1][value]': 'Shiksha Academy',
    });
  });

  it('returns an empty object for an empty criteria list', () => {
    expect(buildCriteriaParams([])).toEqual({});
  });

  it('F5A: encodes multiple fields under the SAME criterion index (get_company_courses documented shape)', () => {
    expect(buildCriteriaParams([{ companyid: '4', shared: '0' }])).toEqual({
      'criteria[0][companyid]': '4',
      'criteria[0][shared]': '0',
    });
  });
});

describe('callIomadRest — verified live request/response shape (get_companies by code)', () => {
  it('sends the exact verified request shape and returns the verified response body untouched', async () => {
    const fetchMock = vi.fn().mockResolvedValue(jsonResponse(SHIKSHA_ACADEMY_RAW_RESPONSE));
    vi.stubGlobal('fetch', fetchMock);

    const result = await callIomadRest(config, {
      wsfunction: 'block_iomad_company_admin_get_companies',
      params: buildCriteriaParams([{ key: 'code', value: 'MYGURU-SHIKSHA-001' }]),
    });

    const body = fetchMock.mock.calls[0][1]?.body as URLSearchParams;
    expect(body.get('wsfunction')).toBe('block_iomad_company_admin_get_companies');
    expect(body.get('criteria[0][key]')).toBe('code');
    expect(body.get('criteria[0][value]')).toBe('MYGURU-SHIKSHA-001');
    expect(result).toEqual(SHIKSHA_ACADEMY_RAW_RESPONSE);

    vi.unstubAllGlobals();
  });
});

describe('callIomadRest', () => {
  beforeEach(() => {
    vi.stubGlobal('fetch', vi.fn());
  });

  afterEach(() => {
    vi.unstubAllGlobals();
    vi.restoreAllMocks();
  });

  it('POSTs to the correct REST endpoint with wstoken/wsfunction/moodlewsrestformat', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValueOnce(jsonResponse([{ id: 1, name: 'Acme' }]));

    await callIomadRest(config, { wsfunction: 'block_iomad_company_admin_get_companies' });

    expect(fetchMock).toHaveBeenCalledTimes(1);
    const [url, init] = fetchMock.mock.calls[0];
    expect(url).toBe('https://iomad.example.com/webservice/rest/server.php');
    expect(init?.method).toBe('POST');
    const body = init?.body as URLSearchParams;
    expect(body.get('wstoken')).toBe('super-secret-token-value');
    expect(body.get('wsfunction')).toBe('block_iomad_company_admin_get_companies');
    expect(body.get('moodlewsrestformat')).toBe('json');
  });

  it('includes extra params in the request body', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValueOnce(jsonResponse([]));

    await callIomadRest(config, {
      wsfunction: 'block_iomad_company_admin_get_company_courses',
      params: { companyid: '42' },
    });

    const body = fetchMock.mock.calls[0][1]?.body as URLSearchParams;
    expect(body.get('companyid')).toBe('42');
  });

  it('normalizes a trailing slash on baseUrl', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValueOnce(jsonResponse([]));

    await callIomadRest(
      { ...config, baseUrl: 'https://iomad.example.com/' },
      { wsfunction: 'block_iomad_company_admin_get_companies' },
    );

    const [url] = fetchMock.mock.calls[0];
    expect(url).toBe('https://iomad.example.com/webservice/rest/server.php');
  });

  it('returns parsed JSON on success', async () => {
    const fetchMock = vi.mocked(fetch);
    const payload = [{ id: 1, name: 'Acme' }];
    fetchMock.mockResolvedValueOnce(jsonResponse(payload));

    const result = await callIomadRest(config, { wsfunction: 'block_iomad_company_admin_get_companies' });
    expect(result).toEqual(payload);
  });

  it('throws a safe unauthorized error on HTTP 401, without leaking the token', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(jsonResponse({ error: 'nope' }, 401));

    try {
      await callIomadRest(config, { wsfunction: 'block_iomad_company_admin_get_companies' });
      throw new Error('expected callIomadRest to throw');
    } catch (err) {
      expect(err).toBeInstanceOf(IomadGatewayError);
      expect((err as IomadGatewayError).code).toBe('unauthorized');
      expect((err as Error).message).not.toContain('super-secret-token-value');
    }
  });

  it('throws a safe unauthorized error on HTTP 403', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(jsonResponse({}, 403));

    await expect(callIomadRest(config, { wsfunction: 'block_iomad_company_admin_get_companies' })).rejects.toMatchObject(
      { code: 'unauthorized' },
    );
  });

  it('throws a safe moodle_exception error when the payload has an exception field, even on HTTP 200', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(
      jsonResponse({ exception: 'moodle_exception', errorcode: 'invalidtoken', message: 'Invalid token' }),
    );

    try {
      await callIomadRest(config, { wsfunction: 'block_iomad_company_admin_get_course_info' });
      throw new Error('expected callIomadRest to throw');
    } catch (err) {
      expect(err).toBeInstanceOf(IomadGatewayError);
      expect((err as IomadGatewayError).code).toBe('moodle_exception');
      expect((err as Error).message).not.toContain('Invalid token');
      expect((err as Error).message).not.toContain('super-secret-token-value');
    }
  });

  it('throws a safe invalid_json error when the response body is not valid JSON', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(new Response('not json', { status: 200 }));

    await expect(callIomadRest(config, { wsfunction: 'block_iomad_company_admin_get_companies' })).rejects.toMatchObject(
      { code: 'invalid_json' },
    );
  });

  it('throws a safe timeout error when the request is aborted', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockImplementation(() => {
      const err = new Error('The operation was aborted');
      err.name = 'AbortError';
      return Promise.reject(err);
    });

    await expect(
      callIomadRest(config, { wsfunction: 'block_iomad_company_admin_get_companies', timeoutMs: 5 }),
    ).rejects.toMatchObject({ code: 'timeout' });
  });

  it('retries exactly once on a transient network error, then succeeds', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock
      .mockRejectedValueOnce(new TypeError('fetch failed'))
      .mockResolvedValueOnce(jsonResponse([{ id: 1, name: 'Acme' }]));

    const result = await callIomadRest(config, { wsfunction: 'block_iomad_company_admin_get_companies' });
    expect(fetchMock).toHaveBeenCalledTimes(2);
    expect(result).toEqual([{ id: 1, name: 'Acme' }]);
  });

  it('throws a safe network_error after the retry also fails', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockRejectedValue(new TypeError('fetch failed'));

    await expect(callIomadRest(config, { wsfunction: 'block_iomad_company_admin_get_companies' })).rejects.toMatchObject(
      { code: 'network_error' },
    );
    expect(fetchMock).toHaveBeenCalledTimes(2);
  });

  it('does NOT retry a moodle_exception (not transient)', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(jsonResponse({ exception: 'moodle_exception' }));

    await expect(callIomadRest(config, { wsfunction: 'block_iomad_company_admin_get_companies' })).rejects.toMatchObject(
      { code: 'moodle_exception' },
    );
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it('does NOT retry an unauthorized error (not transient)', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(jsonResponse({}, 401));

    await expect(callIomadRest(config, { wsfunction: 'block_iomad_company_admin_get_companies' })).rejects.toMatchObject(
      { code: 'unauthorized' },
    );
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it('throws a safe upstream_http_error on HTTP 500', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(new Response('Internal Server Error', { status: 500 }));

    try {
      await callIomadRest(config, { wsfunction: 'block_iomad_company_admin_get_companies' });
      throw new Error('expected callIomadRest to throw');
    } catch (err) {
      expect(err).toBeInstanceOf(IomadGatewayError);
      expect((err as IomadGatewayError).code).toBe('upstream_http_error');
    }
  });

  it('throws a safe upstream_http_error on HTTP 502', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(new Response('Bad Gateway', { status: 502 }));

    await expect(callIomadRest(config, { wsfunction: 'block_iomad_company_admin_get_companies' })).rejects.toMatchObject(
      { code: 'upstream_http_error' },
    );
  });

  it('throws a safe upstream_http_error on HTTP 503', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(new Response('Service Unavailable', { status: 503 }));

    await expect(callIomadRest(config, { wsfunction: 'block_iomad_company_admin_get_companies' })).rejects.toMatchObject(
      { code: 'upstream_http_error' },
    );
  });

  it('throws a safe upstream_http_error on other non-2xx statuses (e.g. 404)', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(new Response('Not Found', { status: 404 }));

    await expect(callIomadRest(config, { wsfunction: 'block_iomad_company_admin_get_companies' })).rejects.toMatchObject(
      { code: 'upstream_http_error' },
    );
  });

  it('the upstream_http_error message contains no token or raw response body content', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(new Response('super-secret-internal-detail: db connection refused', { status: 500 }));

    try {
      await callIomadRest(config, { wsfunction: 'block_iomad_company_admin_get_companies' });
      throw new Error('expected callIomadRest to throw');
    } catch (err) {
      expect((err as Error).message).not.toContain('super-secret-token-value');
      expect((err as Error).message).not.toContain('db connection refused');
      expect((err as Error).message).not.toContain('super-secret-internal-detail');
    }
  });

  it('does NOT parse the response body for a non-2xx status (body is never touched/read)', async () => {
    const fetchMock = vi.mocked(fetch);
    const bodyJsonSpy = vi.fn(() => Promise.resolve({ should: 'never be read' }));
    fetchMock.mockResolvedValue({
      ok: false,
      status: 500,
      json: bodyJsonSpy,
    } as unknown as Response);

    await expect(callIomadRest(config, { wsfunction: 'block_iomad_company_admin_get_companies' })).rejects.toMatchObject(
      { code: 'upstream_http_error' },
    );
    expect(bodyJsonSpy).not.toHaveBeenCalled();
  });

  it('a non-2xx response is never returned to the caller as if it were successful data', async () => {
    const fetchMock = vi.mocked(fetch);
    // A malicious/broken upstream could return 200-shaped JSON on a 500 —
    // the client must key off response.status, not just "did json() parse".
    fetchMock.mockResolvedValue(jsonResponse([{ id: 1, name: 'Acme' }], 500));

    let threw = false;
    try {
      const result = await callIomadRest(config, { wsfunction: 'block_iomad_company_admin_get_companies' });
      expect(result).toBeUndefined(); // should never reach here
    } catch (err) {
      threw = true;
      expect((err as IomadGatewayError).code).toBe('upstream_http_error');
    }
    expect(threw).toBe(true);
  });

  it('does NOT retry a 500 (5xx is not treated as transient in F3)', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(new Response('Internal Server Error', { status: 500 }));

    await expect(callIomadRest(config, { wsfunction: 'block_iomad_company_admin_get_companies' })).rejects.toMatchObject(
      { code: 'upstream_http_error' },
    );
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });
});
