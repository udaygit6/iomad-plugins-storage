import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { createIomadGateway, IomadRestGateway } from '../IomadRestGateway.js';
import { IomadGatewayError } from '../IomadErrors.js';
import type { IomadConfigured } from '../iomadConfig.js';
import {
  SHIKSHA_ACADEMY_RAW_COMPANY,
  SHIKSHA_ACADEMY_RAW_RESPONSE,
  SHIKSHA_ACADEMY_NORMALIZED,
} from './fixtures/shikshaAcademy.js';

const ORIGINAL_ENV = { ...process.env };

const config: IomadConfigured = {
  status: 'configured',
  baseUrl: 'https://iomad.example.com',
  token: 'super-secret-token-value',
};

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });
}

describe('IomadRestGateway — confirmed function mapping', () => {
  beforeEach(() => {
    vi.stubGlobal('fetch', vi.fn());
  });

  afterEach(() => {
    vi.unstubAllGlobals();
    vi.restoreAllMocks();
  });

  it('listCompanies() calls block_iomad_company_admin_get_companies', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(jsonResponse([{ id: 1, name: 'Acme' }]));

    const gateway = new IomadRestGateway(config);
    const companies = await gateway.listCompanies();

    const body = fetchMock.mock.calls[0][1]?.body as URLSearchParams;
    expect(body.get('wsfunction')).toBe('block_iomad_company_admin_get_companies');
    expect(companies).toEqual([{ externalId: '1', displayName: 'Acme' }]);
  });

  it('listCompanyCourses() calls block_iomad_company_admin_get_company_courses with the F5A criteria[0][companyid] param (superseded F3 request-shape test — see the F5A-labelled tests below for current behavior)', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(jsonResponse({ companies: [{ id: 42, courses: [{ id: 10, fullname: 'GCSE Maths' }] }] }));

    const gateway = new IomadRestGateway(config);
    const courses = await gateway.listCompanyCourses('42');

    const body = fetchMock.mock.calls[0][1]?.body as URLSearchParams;
    expect(body.get('wsfunction')).toBe('block_iomad_company_admin_get_company_courses');
    expect(body.get('criteria[0][companyid]')).toBe('42');
    expect(courses).toEqual([{ externalCourseId: '10', fullName: 'GCSE Maths' }]);
  });

  it('getCourse() calls block_iomad_company_admin_get_course_info with a courseid param', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(jsonResponse({ id: 10, fullname: 'GCSE Maths' }));

    const gateway = new IomadRestGateway(config);
    const course = await gateway.getCourse('10');

    const body = fetchMock.mock.calls[0][1]?.body as URLSearchParams;
    expect(body.get('wsfunction')).toBe('block_iomad_company_admin_get_course_info');
    expect(body.get('courseid')).toBe('10');
    expect(course).toEqual({ externalId: '10', displayName: 'GCSE Maths' });
  });

  it('getCourse() returns null when the course is not found (empty response)', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(jsonResponse([]));

    const gateway = new IomadRestGateway(config);
    expect(await gateway.getCourse('999')).toBeNull();
  });

  it('getCompany() is derived from listCompanies() — no separate wsfunction call', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(
      jsonResponse([
        { id: 1, name: 'Acme' },
        { id: 2, name: 'Beta' },
      ]),
    );

    const gateway = new IomadRestGateway(config);
    const company = await gateway.getCompany('2');

    expect(fetchMock).toHaveBeenCalledTimes(1);
    const body = fetchMock.mock.calls[0][1]?.body as URLSearchParams;
    expect(body.get('wsfunction')).toBe('block_iomad_company_admin_get_companies');
    expect(company).toEqual({ externalId: '2', displayName: 'Beta' });
  });

  it('getCompany() returns null when no company matches', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(jsonResponse([{ id: 1, name: 'Acme' }]));

    const gateway = new IomadRestGateway(config);
    expect(await gateway.getCompany('does-not-exist')).toBeNull();
  });

  it('getCompanyByCode() sends the verified live request shape (criteria[0][key]=code) and returns the verified normalized company', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(jsonResponse(SHIKSHA_ACADEMY_RAW_RESPONSE));

    const gateway = new IomadRestGateway(config);
    const company = await gateway.getCompanyByCode('MYGURU-SHIKSHA-001');

    const body = fetchMock.mock.calls[0][1]?.body as URLSearchParams;
    expect(body.get('wsfunction')).toBe('block_iomad_company_admin_get_companies');
    expect(body.get('criteria[0][key]')).toBe('code');
    expect(body.get('criteria[0][value]')).toBe('MYGURU-SHIKSHA-001');
    expect(company).toEqual(SHIKSHA_ACADEMY_NORMALIZED);
  });

  it('getCompanyByCode() returns null when the companies array is empty (no match for that code)', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(jsonResponse({ companies: [], warnings: [] }));

    const gateway = new IomadRestGateway(config);
    expect(await gateway.getCompanyByCode('DOES-NOT-EXIST')).toBeNull();
  });

  it('getCompanyByCode() throws a safe unknown_response_schema error on more than one result (unexpected/duplicate)', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(
      jsonResponse({
        companies: [SHIKSHA_ACADEMY_RAW_COMPANY, { ...SHIKSHA_ACADEMY_RAW_COMPANY, id: 4 }],
        warnings: [],
      }),
    );

    const gateway = new IomadRestGateway(config);
    await expect(gateway.getCompanyByCode('MYGURU-SHIKSHA-001')).rejects.toMatchObject({
      code: 'unknown_response_schema',
    });
  });

  it('getCompanyByCode() does not break on a non-empty warnings array', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(
      jsonResponse({ companies: [SHIKSHA_ACADEMY_RAW_COMPANY], warnings: [{ warningcode: 'x' }] }),
    );

    const gateway = new IomadRestGateway(config);
    const company = await gateway.getCompanyByCode('MYGURU-SHIKSHA-001');
    expect(company).toEqual(SHIKSHA_ACADEMY_NORMALIZED);
  });

  it('getCompanyByCode() propagates a safe non-2xx error without leaking token/response body', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(new Response('Internal Server Error', { status: 500 }));

    const gateway = new IomadRestGateway(config);
    try {
      await gateway.getCompanyByCode('MYGURU-SHIKSHA-001');
      throw new Error('expected getCompanyByCode to throw');
    } catch (err) {
      expect((err as IomadGatewayError).code).toBe('upstream_http_error');
      expect((err as Error).message).not.toContain('super-secret-token-value');
    }
  });

  it('listCompanyCourses() sends criteria[0][companyid]/criteria[0][shared]=0 by default and maps the documented company-courses envelope (F5A, not yet execution-verified)', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(
      jsonResponse({
        companies: [
          { id: 4, courses: [{ id: 101, fullname: 'Intro to Testing' }] },
        ],
      }),
    );

    const gateway = new IomadRestGateway(config);
    const allocations = await gateway.listCompanyCourses('4');

    const body = fetchMock.mock.calls[0][1]?.body as URLSearchParams;
    expect(body.get('wsfunction')).toBe('block_iomad_company_admin_get_company_courses');
    expect(body.get('criteria[0][companyid]')).toBe('4');
    expect(body.get('criteria[0][shared]')).toBe('0');
    expect(allocations).toEqual([{ externalCourseId: '101', fullName: 'Intro to Testing' }]);
  });

  it('listCompanyCourses(companyId, true) sends criteria[0][shared]=1', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(jsonResponse({ companies: [{ id: 4, courses: [] }] }));

    const gateway = new IomadRestGateway(config);
    await gateway.listCompanyCourses('4', true);

    const body = fetchMock.mock.calls[0][1]?.body as URLSearchParams;
    expect(body.get('criteria[0][shared]')).toBe('1');
  });

  it('listCompanyCourses() returns an empty array for a company with zero courses', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(jsonResponse({ companies: [{ id: 4, courses: [] }] }));

    const gateway = new IomadRestGateway(config);
    expect(await gateway.listCompanyCourses('4')).toEqual([]);
  });

  it('LIVE VERIFIED: getCourseSettings() calls get_course_info with NO course-id parameter at all, then filters the full response locally to the requested IDs', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(
      jsonResponse([
        { courseid: 101, licensed: false, shared: 1, validlength: 365, warnexpire: 30, warncompletion: 14, notifyperiod: 7 },
        { courseid: 102, licensed: true, shared: 0, validlength: 100, warnexpire: 10, warncompletion: 5, notifyperiod: 2 },
        { courseid: 999, licensed: false, shared: 0, validlength: 0, warnexpire: 0, warncompletion: 0, notifyperiod: 0 },
      ]),
    );

    const gateway = new IomadRestGateway(config);
    const settings = await gateway.getCourseSettings(['101', '102']);

    const body = fetchMock.mock.calls[0][1]?.body as URLSearchParams;
    expect(body.get('wsfunction')).toBe('block_iomad_company_admin_get_course_info');
    // Live-verified: no courrseids[]/courseids[]/courseid[] parameter of
    // any kind — those all fail with invalid_parameter_exception.
    expect(body.get('courrseids[0]')).toBeNull();
    expect(body.get('courseids[0]')).toBeNull();
    expect(body.get('courseid[0]')).toBeNull();
    expect(body.get('courseid')).toBeNull();
    expect([...body.keys()]).toEqual(['wstoken', 'wsfunction', 'moodlewsrestformat']);

    // Locally filtered: course 999 was in the full response but not
    // requested, and must not appear.
    expect(settings).toEqual([
      {
        externalCourseId: '101',
        licensed: false,
        shared: true,
        validLengthDays: 365,
        warnExpireDays: 30,
        warnCompletionDays: 14,
        notifyPeriodDays: 7,
      },
      {
        externalCourseId: '102',
        licensed: true,
        shared: false,
        validLengthDays: 100,
        warnExpireDays: 10,
        warnCompletionDays: 5,
        notifyPeriodDays: 2,
      },
    ]);
  });

  it('maps the exact real Jupiter Test Mathematics settings fixture (companyId 4, courseId 4)', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(
      jsonResponse([
        { id: 2, courseid: 3, licensed: false, shared: 0, validlength: 0, warnexpire: 0, warncompletion: 0, notifyperiod: 0 },
        { id: 3, courseid: 4, licensed: false, shared: 0, validlength: 0, warnexpire: 0, warncompletion: 0, notifyperiod: 0 },
      ]),
    );

    const gateway = new IomadRestGateway(config);
    const settings = await gateway.getCourseSettings(['4']);

    expect(settings).toEqual([
      {
        externalCourseId: '4',
        licensed: false,
        shared: false,
        validLengthDays: 0,
        warnExpireDays: 0,
        warnCompletionDays: 0,
        notifyPeriodDays: 0,
      },
    ]);
  });

  it('getCourseSettings([]) returns an empty array without making a network call', async () => {
    const fetchMock = vi.mocked(fetch);

    const gateway = new IomadRestGateway(config);
    const settings = await gateway.getCourseSettings([]);

    expect(settings).toEqual([]);
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it('getCourseSettings() returns fewer entries than requested when the full collection has no matching course — missing settings handled defensively, not an error', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(
      jsonResponse([
        { courseid: 101, licensed: false, shared: 0, validlength: 1, warnexpire: 1, warncompletion: 1, notifyperiod: 1 },
      ]),
    );

    const gateway = new IomadRestGateway(config);
    const settings = await gateway.getCourseSettings(['101', '999']);

    expect(settings).toHaveLength(1);
    expect(settings[0].externalCourseId).toBe('101');
  });

  it('getCourseSettings() propagates a safe non-2xx error without leaking token/response body', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(new Response('Internal Server Error', { status: 500 }));

    const gateway = new IomadRestGateway(config);
    try {
      await gateway.getCourseSettings(['101']);
      throw new Error('expected getCourseSettings to throw');
    } catch (err) {
      expect((err as IomadGatewayError).code).toBe('upstream_http_error');
      expect((err as Error).message).not.toContain('super-secret-token-value');
    }
  });

  it('propagates a safe error (not the raw exception detail) on a moodle exception response', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(jsonResponse({ exception: 'moodle_exception', message: 'invalid token' }));

    const gateway = new IomadRestGateway(config);
    try {
      await gateway.listCompanies();
      throw new Error('expected listCompanies to throw');
    } catch (err) {
      expect(err).toBeInstanceOf(IomadGatewayError);
      expect((err as Error).message).not.toContain('invalid token');
      expect((err as Error).message).not.toContain('super-secret-token-value');
    }
  });
});

describe('createIomadGateway — configuration states', () => {
  beforeEach(() => {
    vi.stubGlobal('fetch', vi.fn());
    delete process.env.IOMAD_BASE_URL;
    delete process.env.IOMAD_SERVICE_TOKEN;
  });

  afterEach(() => {
    vi.unstubAllGlobals();
    vi.restoreAllMocks();
    process.env = { ...ORIGINAL_ENV };
  });

  it('never throws at construction time, even with no configuration', () => {
    expect(() => createIomadGateway()).not.toThrow();
  });

  it('returns a gateway that throws a safe not_configured error on first use when env vars are missing', async () => {
    const gateway = createIomadGateway();
    await expect(gateway.listCompanies()).rejects.toMatchObject({ code: 'not_configured' });
    // Never made a network call — configuration is checked before any fetch.
    expect(fetch).not.toHaveBeenCalled();
  });

  it('returns a working gateway when both env vars are set', async () => {
    process.env.IOMAD_BASE_URL = 'https://iomad.example.com';
    process.env.IOMAD_SERVICE_TOKEN = 'test-token';
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(jsonResponse([{ id: 1, name: 'Acme' }]));

    const gateway = createIomadGateway();
    const companies = await gateway.listCompanies();
    expect(companies).toEqual([{ externalId: '1', displayName: 'Acme' }]);
  });

  it('the not_configured error carries no token/config detail, only the safe error code', async () => {
    const gateway = createIomadGateway();
    try {
      await gateway.getCourse('1');
      throw new Error('expected getCourse to throw');
    } catch (err) {
      expect(err).toBeInstanceOf(IomadGatewayError);
      expect((err as IomadGatewayError).code).toBe('not_configured');
      expect((err as Error).message).toBe('Iomad integration is not configured.');
    }
  });

  it('returns a gateway that throws a safe invalid_config error when IOMAD_BASE_URL is malformed', async () => {
    process.env.IOMAD_BASE_URL = 'not a url';
    process.env.IOMAD_SERVICE_TOKEN = 'test-token';

    const gateway = createIomadGateway();
    await expect(gateway.listCompanies()).rejects.toMatchObject({ code: 'invalid_config' });
    expect(fetch).not.toHaveBeenCalled();
  });

  it('returns a gateway that throws a safe invalid_config error when IOMAD_BASE_URL is http:// (not https)', async () => {
    process.env.IOMAD_BASE_URL = 'http://iomad.example.com';
    process.env.IOMAD_SERVICE_TOKEN = 'test-token';

    const gateway = createIomadGateway();
    await expect(gateway.getCourse('1')).rejects.toMatchObject({ code: 'invalid_config' });
    expect(fetch).not.toHaveBeenCalled();
  });

  it('the invalid_config error never echoes the malformed/invalid IOMAD_BASE_URL value', async () => {
    process.env.IOMAD_BASE_URL = 'http://leaked-internal-host.example.com';
    process.env.IOMAD_SERVICE_TOKEN = 'test-token';

    const gateway = createIomadGateway();
    try {
      await gateway.listCompanies();
      throw new Error('expected listCompanies to throw');
    } catch (err) {
      expect((err as Error).message).not.toContain('leaked-internal-host');
      expect((err as Error).message).not.toContain('test-token');
    }
  });
});
