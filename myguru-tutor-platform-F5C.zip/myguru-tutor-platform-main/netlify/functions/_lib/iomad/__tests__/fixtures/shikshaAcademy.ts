/**
 * VERIFIED FIXTURE — captured from a real, authenticated call against the
 * running Iomad instance:
 *
 *   wsfunction: block_iomad_company_admin_get_companies
 *   request:    criteria[0][key]=code, criteria[0][value]=MYGURU-SHIKSHA-001
 *
 * See docs/IOMAD_INTEGRATION_CONTRACT.md's "Live-verified: get_companies
 * by code" section for the full write-up. This file contains NO
 * credentials — no token, no base URL — only the response body, which
 * itself contains no secrets (it's UK test data for a fictitious
 * franchise company).
 */

export const SHIKSHA_ACADEMY_RAW_COMPANY = {
  id: 3,
  name: 'Shiksha Academy',
  shortname: 'SHIKSHA',
  code: 'MYGURU-SHIKSHA-001',
  address: 'Test data – UK',
  city: 'Staines Upon Thames',
  region: 'Surrey',
  country: 'GB',
  suspended: 0,
  parentid: 0,
  hostname: '',
  maxusers: 0,
  custom1: 'myguru_franchise',
  custom2: 'test',
  custom3: 'uk',
} as const;

export const SHIKSHA_ACADEMY_RAW_RESPONSE = {
  companies: [SHIKSHA_ACADEMY_RAW_COMPANY],
  warnings: [] as unknown[],
} as const;

/** The expected NORMALIZED shape after `normalizeCompany`/`getCompanyByCode`. */
export const SHIKSHA_ACADEMY_NORMALIZED = {
  externalId: '3',
  displayName: 'Shiksha Academy',
  code: 'MYGURU-SHIKSHA-001',
  isSuspended: false,
} as const;
