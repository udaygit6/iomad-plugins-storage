import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { getIomadConfig } from '../iomadConfig.js';

const ORIGINAL_ENV = { ...process.env };

describe('getIomadConfig', () => {
  beforeEach(() => {
    delete process.env.IOMAD_BASE_URL;
    delete process.env.IOMAD_SERVICE_TOKEN;
  });

  afterEach(() => {
    process.env = { ...ORIGINAL_ENV };
  });

  it('reports not_configured with both names when neither env var is set', () => {
    const config = getIomadConfig();
    expect(config.status).toBe('not_configured');
    expect(config.status === 'not_configured' && config.missing).toEqual(['IOMAD_BASE_URL', 'IOMAD_SERVICE_TOKEN']);
  });

  it('reports not_configured with only the missing name when one is set', () => {
    process.env.IOMAD_BASE_URL = 'https://iomad.example.com';
    const config = getIomadConfig();
    expect(config.status).toBe('not_configured');
    expect(config.status === 'not_configured' && config.missing).toEqual(['IOMAD_SERVICE_TOKEN']);
  });

  it('reports configured when both env vars are set', () => {
    process.env.IOMAD_BASE_URL = 'https://iomad.example.com';
    process.env.IOMAD_SERVICE_TOKEN = 'test-token-value';
    const config = getIomadConfig();
    expect(config.status).toBe('configured');
    expect(config.status === 'configured' && config.baseUrl).toBe('https://iomad.example.com');
    expect(config.status === 'configured' && config.token).toBe('test-token-value');
  });

  it('treats a whitespace-only value as missing', () => {
    process.env.IOMAD_BASE_URL = '   ';
    process.env.IOMAD_SERVICE_TOKEN = 'test-token-value';
    const config = getIomadConfig();
    expect(config.status).toBe('not_configured');
  });

  it('does not throw when reading configuration (missing env must never crash startup)', () => {
    expect(() => getIomadConfig()).not.toThrow();
  });
});

describe('getIomadConfig — IOMAD_BASE_URL validation', () => {
  beforeEach(() => {
    delete process.env.IOMAD_BASE_URL;
    delete process.env.IOMAD_SERVICE_TOKEN;
    process.env.IOMAD_SERVICE_TOKEN = 'test-token-value';
  });

  afterEach(() => {
    process.env = { ...ORIGINAL_ENV };
  });

  it('accepts a well-formed https URL', () => {
    process.env.IOMAD_BASE_URL = 'https://iomad.example.com';
    const config = getIomadConfig();
    expect(config.status).toBe('configured');
  });

  it('accepts a well-formed https URL with a path/port', () => {
    process.env.IOMAD_BASE_URL = 'https://iomad.example.com:8443/lms';
    const config = getIomadConfig();
    expect(config.status).toBe('configured');
  });

  it('rejects a malformed URL as invalid_config', () => {
    process.env.IOMAD_BASE_URL = 'not a url';
    const config = getIomadConfig();
    expect(config.status).toBe('invalid_config');
    expect(config.status === 'invalid_config' && config.reason).toBe('malformed_url');
  });

  it('rejects an http:// URL as invalid_config (insecure_scheme)', () => {
    process.env.IOMAD_BASE_URL = 'http://iomad.example.com';
    const config = getIomadConfig();
    expect(config.status).toBe('invalid_config');
    expect(config.status === 'invalid_config' && config.reason).toBe('insecure_scheme');
  });

  it('rejects a non-http(s) scheme as invalid_config', () => {
    process.env.IOMAD_BASE_URL = 'ftp://iomad.example.com';
    const config = getIomadConfig();
    expect(config.status).toBe('invalid_config');
    expect(config.status === 'invalid_config' && config.reason).toBe('insecure_scheme');
  });

  it('does not throw for a malformed or insecure URL (still no crash on bad config)', () => {
    process.env.IOMAD_BASE_URL = 'http://iomad.example.com';
    expect(() => getIomadConfig()).not.toThrow();
    process.env.IOMAD_BASE_URL = 'not a url';
    expect(() => getIomadConfig()).not.toThrow();
  });

  it('still reports not_configured (not invalid_config) when IOMAD_BASE_URL is simply missing', () => {
    delete process.env.IOMAD_BASE_URL;
    const config = getIomadConfig();
    expect(config.status).toBe('not_configured');
  });
});

describe('getIomadConfig — IOMAD_ALLOW_INSECURE_HTTP test-only opt-in (F4C)', () => {
  beforeEach(() => {
    delete process.env.IOMAD_BASE_URL;
    delete process.env.IOMAD_SERVICE_TOKEN;
    delete process.env.IOMAD_ALLOW_INSECURE_HTTP;
    process.env.IOMAD_SERVICE_TOKEN = 'test-token-value';
    process.env.IOMAD_BASE_URL = 'http://iomad.example.com';
  });

  afterEach(() => {
    process.env = { ...ORIGINAL_ENV };
  });

  it('still rejects http:// by default (opt-in unset)', () => {
    const config = getIomadConfig();
    expect(config.status).toBe('invalid_config');
  });

  it('accepts http:// when IOMAD_ALLOW_INSECURE_HTTP is exactly "true"', () => {
    process.env.IOMAD_ALLOW_INSECURE_HTTP = 'true';
    const config = getIomadConfig();
    expect(config.status).toBe('configured');
    expect(config.status === 'configured' && config.baseUrl).toBe('http://iomad.example.com');
  });

  it('rejects http:// for any value other than the exact string "true" (no loose truthy check)', () => {
    for (const value of ['1', 'TRUE', 'True', 'yes', 'on', ' true', 'true ']) {
      process.env.IOMAD_ALLOW_INSECURE_HTTP = value;
      const config = getIomadConfig();
      expect(config.status).toBe('invalid_config');
    }
  });

  it('rejects http:// when IOMAD_ALLOW_INSECURE_HTTP is set to "false"', () => {
    process.env.IOMAD_ALLOW_INSECURE_HTTP = 'false';
    const config = getIomadConfig();
    expect(config.status).toBe('invalid_config');
  });

  it('does NOT weaken https:// validation — https always passes regardless of the opt-in', () => {
    process.env.IOMAD_BASE_URL = 'https://iomad.example.com';
    delete process.env.IOMAD_ALLOW_INSECURE_HTTP;
    expect(getIomadConfig().status).toBe('configured');
  });

  it('the opt-in has no VITE_-prefixed equivalent anywhere in this module', () => {
    // Static guard: this file must never read a VITE_-prefixed variable
    // for this purpose. A grep-based repo-wide version of this same
    // assertion also exists in the security-audit tests.
    expect(process.env.VITE_IOMAD_ALLOW_INSECURE_HTTP).toBeUndefined();
  });
});
