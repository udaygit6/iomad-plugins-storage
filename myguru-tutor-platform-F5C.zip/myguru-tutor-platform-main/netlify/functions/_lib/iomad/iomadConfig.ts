/**
 * Iomad server-side configuration.
 *
 * Reads IOMAD_BASE_URL / IOMAD_SERVICE_TOKEN from process.env only. Both
 * are server-only environment variables (see .env.example and
 * docs/IOMAD_INTEGRATION_CONTRACT.md) — never VITE_-prefixed, never read
 * from src/ (enforced by security-audit tests in this repo and in
 * src/test/security/noSecretKeyInBrowser.test.ts).
 *
 * Missing configuration must never crash application startup: this
 * module only reads and reports state. Callers decide what to do with
 * `not_configured`/`invalid_config` — the current caller
 * (`IomadRestGateway.createIomadGateway()`) returns a gateway whose
 * methods throw a safe error on first use, not at construction/import
 * time.
 *
 * IOMAD_BASE_URL is validated before a `configured` state is ever
 * returned: it must parse as a URL and must use `https:`. This is
 * deliberately NOT a host allowlist — the final Iomad hostname isn't
 * fixed yet — just a minimum sanity/transport-security check so a typo'd
 * or accidentally-http URL fails fast with a safe error instead of
 * silently sending the token in plaintext or to an unparseable target.
 *
 * HTTP TEST MODE (F4C): a temporary dummy-data Iomad test endpoint is
 * plain HTTP. `https:` remains the secure-by-default requirement — `http:`
 * is only ever accepted when `IOMAD_ALLOW_INSECURE_HTTP` is set to the
 * exact string `'true'` (server-only env var, never `VITE_`-prefixed, no
 * browser equivalent). Unset, empty, or any other value (`'1'`, `'TRUE'`,
 * `'yes'`, etc.) leaves HTTP rejected — this is an explicit opt-in, not a
 * loose truthy check, and it must be set deliberately for this temporary
 * test scenario, not left on by habit.
 */

export interface IomadConfigured {
  readonly status: 'configured';
  readonly baseUrl: string;
  readonly token: string;
}

export interface IomadNotConfigured {
  readonly status: 'not_configured';
  readonly missing: ReadonlyArray<'IOMAD_BASE_URL' | 'IOMAD_SERVICE_TOKEN'>;
}

/**
 * IOMAD_BASE_URL is present but fails validation. Distinct from
 * `not_configured` (nothing set) — here something is set, but it isn't
 * safe/usable. `reason` is for server-side diagnostics only; it never
 * echoes the invalid value itself.
 */
export interface IomadInvalidConfig {
  readonly status: 'invalid_config';
  readonly reason: 'malformed_url' | 'insecure_scheme';
}

export type IomadConfig = IomadConfigured | IomadNotConfigured | IomadInvalidConfig;

function validateBaseUrl(baseUrl: string): IomadInvalidConfig | null {
  let parsed: URL;
  try {
    parsed = new URL(baseUrl);
  } catch {
    return { status: 'invalid_config', reason: 'malformed_url' };
  }
  if (parsed.protocol === 'https:') return null;
  if (parsed.protocol === 'http:' && process.env.IOMAD_ALLOW_INSECURE_HTTP === 'true') {
    // Explicit, server-side-only, test-only opt-in — see file header
    // "HTTP TEST MODE". Never weakens the default: https: is still
    // required unless this exact env var is set to the exact string
    // 'true'.
    return null;
  }
  return { status: 'invalid_config', reason: 'insecure_scheme' };
}

export function getIomadConfig(): IomadConfig {
  const baseUrl = process.env.IOMAD_BASE_URL?.trim();
  const token = process.env.IOMAD_SERVICE_TOKEN?.trim();

  const missing: Array<'IOMAD_BASE_URL' | 'IOMAD_SERVICE_TOKEN'> = [];
  if (!baseUrl) missing.push('IOMAD_BASE_URL');
  if (!token) missing.push('IOMAD_SERVICE_TOKEN');

  if (missing.length > 0) {
    return { status: 'not_configured', missing };
  }

  // Non-null by construction above (both required checks passed).
  const validationError = validateBaseUrl(baseUrl as string);
  if (validationError) return validationError;

  return { status: 'configured', baseUrl: baseUrl as string, token: token as string };
}
