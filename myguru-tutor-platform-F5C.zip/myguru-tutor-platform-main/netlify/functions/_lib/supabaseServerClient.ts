import { createClient, type SupabaseClient } from '@supabase/supabase-js';

/**
 * Server-only Supabase client. This file must NEVER be imported from
 * src/ (browser code) — only from netlify/functions/*.ts. Verified by a
 * repo-wide grep in the security-audit test (see
 * netlify/functions/_lib/__tests__/noSecretKeyInBrowser.test.ts).
 *
 * Environment variable naming (Phase E4 §"Environment model"):
 *   SUPABASE_URL         — server-only, no VITE_ prefix
 *   SUPABASE_SECRET_KEY   — server-only, no VITE_ prefix, full-privilege key
 *
 * A note on naming, documented here rather than assumed silently: Supabase
 * has, at various points, called this key `service_role` (a JWT) and more
 * recently a "secret key" (a differently-formatted string) as part of a
 * newer API-key model — mirroring the anon → "publishable key" rename
 * already used for VITE_SUPABASE_PUBLISHABLE_KEY in Phase E3. This project
 * uses the `SUPABASE_SECRET_KEY` env var name per the E4 brief. If the
 * linked Supabase project's actual dashboard still labels this value
 * "service_role", that is the value that belongs in this variable — only
 * the env var *name* is fixed by this codebase, not which literal string
 * Supabase's dashboard currently calls it. Isolated here so that if
 * Supabase changes this again, only this file's env var name needs to
 * change, not every function.
 */

let client: SupabaseClient | null = null;

export function getServerSupabaseClient(): SupabaseClient {
  if (client) return client;

  const url = process.env.SUPABASE_URL;
  const secretKey = process.env.SUPABASE_SECRET_KEY;

  if (!url || !secretKey) {
    // Never logged with the variable's value — names only, and only server-side console (not returned to the browser).
    throw new Error('Server Supabase configuration is missing (SUPABASE_URL / SUPABASE_SECRET_KEY).');
  }

  client = createClient(url, secretKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  return client;
}
