/**
 * Server-side validation helpers shared by every public submission
 * function. Deliberately independent of src/domain/validation — that
 * module is browser-bundle code; this one runs only in the Netlify
 * Function runtime and must have zero import path back into src/ that
 * could pull server-only code into the client bundle.
 */

export class ValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ValidationError';
  }
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const MAX_SHORT_LENGTH = 200;
const MAX_LONG_LENGTH = 5000;

export function normalizeEmail(value: unknown): string {
  if (typeof value !== 'string') throw new ValidationError('invalid_email');
  const trimmed = value.trim().toLowerCase();
  if (!EMAIL_RE.test(trimmed) || trimmed.length > MAX_SHORT_LENGTH) {
    throw new ValidationError('invalid_email');
  }
  return trimmed;
}

export function requireString(value: unknown, field: string, maxLength = MAX_SHORT_LENGTH): string {
  if (typeof value !== 'string' || value.trim().length === 0) {
    throw new ValidationError(`missing_${field}`);
  }
  const trimmed = value.trim();
  if (trimmed.length > maxLength) {
    throw new ValidationError(`${field}_too_long`);
  }
  return trimmed;
}

export function optionalString(value: unknown, field: string, maxLength = MAX_LONG_LENGTH): string | undefined {
  if (value === undefined || value === null || value === '') return undefined;
  if (typeof value !== 'string') throw new ValidationError(`invalid_${field}`);
  const trimmed = value.trim();
  if (trimmed.length === 0) return undefined;
  if (trimmed.length > maxLength) throw new ValidationError(`${field}_too_long`);
  return trimmed;
}

export function requireEnum<T extends string>(value: unknown, allowed: readonly T[], field: string): T {
  if (typeof value !== 'string' || !allowed.includes(value as T)) {
    throw new ValidationError(`invalid_${field}`);
  }
  return value as T;
}

export function requireStringArray(value: unknown, field: string, maxItems = 20): string[] {
  if (!Array.isArray(value) || value.length === 0) {
    throw new ValidationError(`missing_${field}`);
  }
  if (value.length > maxItems) {
    throw new ValidationError(`${field}_too_many`);
  }
  return value.map((v) => {
    if (typeof v !== 'string' || v.trim().length === 0 || v.length > MAX_SHORT_LENGTH) {
      throw new ValidationError(`invalid_${field}`);
    }
    return v.trim();
  });
}

/**
 * Parses a JSON request body, rejecting malformed JSON with a
 * ValidationError rather than letting a raw parse error escape.
 */
export function parseJsonBody(rawBody: string | null | undefined): Record<string, unknown> {
  if (!rawBody) throw new ValidationError('empty_body');
  let parsed: unknown;
  try {
    parsed = JSON.parse(rawBody);
  } catch {
    throw new ValidationError('malformed_json');
  }
  if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
    throw new ValidationError('malformed_json');
  }
  return parsed as Record<string, unknown>;
}

/**
 * Rejects a payload containing any key outside the allowed set — a caller
 * trying to smuggle in e.g. `status`, `adminNotes`, or an `id` should fail
 * loudly rather than have those fields silently ignored (which could mask
 * a real integration bug) or, worse, silently accepted somewhere else.
 */
export function assertNoUnexpectedFields(body: Record<string, unknown>, allowed: readonly string[]): void {
  const allowedSet = new Set(allowed);
  for (const key of Object.keys(body)) {
    if (!allowedSet.has(key)) {
      throw new ValidationError('unexpected_field');
    }
  }
}
