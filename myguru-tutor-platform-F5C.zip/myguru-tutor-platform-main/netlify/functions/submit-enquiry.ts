import type { Handler } from '@netlify/functions';
import { getServerSupabaseClient } from './_lib/supabaseServerClient.js';
import { parseJsonBody, assertNoUnexpectedFields, requireString, optionalString, normalizeEmail, ValidationError } from './_lib/validation.js';
import { isHoneypotTriggered, isSubmittedTooFast, getClientIp, checkRateLimit } from './_lib/antiAbuse.js';
import { jsonResponse, genericUnableToProcess, validationFailed, methodNotAllowed, serverMisconfigured, success } from './_lib/http.js';

const ALLOWED_FIELDS = ['name', 'email', 'message', 'relatedTutorSlug', 'website', 'formLoadedAt'] as const;

/**
 * Hard-coded allowed write path: creates exactly one `enquiries` row. A
 * single-table insert needs no RPC/transaction (unlike matching requests
 * and tutor applications) — this covers both the general Contact-page form
 * and the "Request this tutor" enquiry from a tutor profile, since the
 * existing Enquiry domain model already supports an optional
 * relatedTutorSlug for exactly that case.
 */
export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') return methodNotAllowed();

  let supabase;
  try {
    supabase = getServerSupabaseClient();
  } catch (err) {
    console.error('submit-enquiry: server config error:', err instanceof Error ? err.message : err);
    return serverMisconfigured();
  }

  let body: Record<string, unknown>;
  try {
    body = parseJsonBody(event.body);
    assertNoUnexpectedFields(body, ALLOWED_FIELDS);
  } catch (err) {
    if (err instanceof ValidationError) return validationFailed(err.message);
    return validationFailed('malformed_request');
  }

  if (isHoneypotTriggered(body) || isSubmittedTooFast(body)) {
    return genericUnableToProcess();
  }
  const ip = getClientIp(event.headers as Record<string, string | string[] | undefined>);
  const withinRate = await checkRateLimit(supabase, 'submit-enquiry', ip);
  if (!withinRate) return genericUnableToProcess();

  try {
    const name = requireString(body.name, 'name');
    const email = normalizeEmail(body.email);
    const message = requireString(body.message, 'message', 3000);
    const relatedTutorSlug = optionalString(body.relatedTutorSlug, 'relatedTutorSlug', 200);

    let relatedTutorProfileId: string | null = null;
    if (relatedTutorSlug) {
      const { data: tutor, error: tutorError } = await supabase
        .from('tutor_profiles')
        .select('id')
        .eq('slug', relatedTutorSlug)
        .eq('status', 'published')
        .maybeSingle();
      if (tutorError) {
        console.error('submit-enquiry: tutor lookup failed:', tutorError.message);
        return jsonResponse(502, { error: 'submission_failed' });
      }
      if (!tutor) return validationFailed('invalid_relatedTutorSlug');
      relatedTutorProfileId = tutor.id as string;
    }

    const { data, error } = await supabase
      .from('enquiries')
      .insert({ name, email, message, related_tutor_profile_id: relatedTutorProfileId })
      .select('id')
      .single();

    if (error) {
      console.error('submit-enquiry: insert failed:', error.message);
      return jsonResponse(502, { error: 'submission_failed' });
    }

    return success({ ok: true, id: data.id as string });
  } catch (err) {
    if (err instanceof ValidationError) return validationFailed(err.message);
    console.error('submit-enquiry: unexpected error:', err instanceof Error ? err.message : err);
    return jsonResponse(500, { error: 'internal_error' });
  }
};
