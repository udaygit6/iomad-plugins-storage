import type { Handler } from '@netlify/functions';
import { getServerSupabaseClient } from './_lib/supabaseServerClient.js';
import {
  parseJsonBody,
  assertNoUnexpectedFields,
  requireString,
  optionalString,
  requireEnum,
  normalizeEmail,
  ValidationError,
} from './_lib/validation.js';
import { isHoneypotTriggered, isSubmittedTooFast, getClientIp, checkRateLimit } from './_lib/antiAbuse.js';
import { jsonResponse, genericUnableToProcess, validationFailed, methodNotAllowed, serverMisconfigured, success } from './_lib/http.js';

const HELP_NEEDED_VALUES = ['catching_up', 'exam_preparation', 'confidence', 'homework_support', 'specific_topic', 'other'] as const;

const ALLOWED_FIELDS = [
  'parentName',
  'parentEmail',
  'parentPhone',
  'studentFirstName',
  'yearGroupLabel',
  'subjectSlug',
  'helpNeeded',
  'goalsNote',
  'availabilityNote',
  // Anti-abuse signals — real form fields, not part of the domain model.
  'website',
  'formLoadedAt',
] as const;

/**
 * Hard-coded allowed write path: this function creates exactly one
 * matching request (plus its parent/student/status-history rows, via the
 * create_matching_request RPC — see supabase/migrations/0012). The caller
 * can never supply an id, a status, or any other server-controlled value —
 * those simply aren't parameters this function reads from the body at all.
 */
export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') return methodNotAllowed();

  let supabase;
  try {
    supabase = getServerSupabaseClient();
  } catch (err) {
    console.error('submit-matching-request: server config error:', err instanceof Error ? err.message : err);
    return serverMisconfigured();
  }

  let body: Record<string, unknown>;
  try {
    body = parseJsonBody(event.body);
    assertNoUnexpectedFields(body, ALLOWED_FIELDS);
  } catch (err) {
    if (err instanceof ValidationError) return validationFailed(err.message);
    return validationFailed('malformed_request');
  }

  // Anti-abuse — every trigger returns the identical generic response.
  if (isHoneypotTriggered(body) || isSubmittedTooFast(body)) {
    return genericUnableToProcess();
  }
  const ip = getClientIp(event.headers as Record<string, string | string[] | undefined>);
  const withinRate = await checkRateLimit(supabase, 'submit-matching-request', ip);
  if (!withinRate) return genericUnableToProcess();

  try {
    const parentName = requireString(body.parentName, 'parentName');
    const parentEmail = normalizeEmail(body.parentEmail);
    const parentPhone = optionalString(body.parentPhone, 'parentPhone', 40);
    const studentFirstName = requireString(body.studentFirstName, 'studentFirstName');
    const yearGroupLabel = requireString(body.yearGroupLabel, 'yearGroupLabel', 40);
    const subjectSlug = requireString(body.subjectSlug, 'subjectSlug', 80);
    const helpNeeded = requireEnum(body.helpNeeded, HELP_NEEDED_VALUES, 'helpNeeded');
    const goalsNote = optionalString(body.goalsNote, 'goalsNote');
    const availabilityNote = requireString(body.availabilityNote, 'availabilityNote', 500);

    const { data, error } = await supabase.rpc('create_matching_request', {
      p_parent_name: parentName,
      p_parent_email: parentEmail,
      p_parent_phone: parentPhone ?? null,
      p_student_first_name: studentFirstName,
      p_year_group_label: yearGroupLabel,
      p_subject_slug: subjectSlug,
      p_help_needed: helpNeeded,
      p_goals_note: goalsNote ?? null,
      p_availability_note: availabilityNote,
    });

    if (error) {
      if (error.message?.includes('invalid_subject_slug')) return validationFailed('invalid_subjectSlug');
      console.error('submit-matching-request: RPC failed:', error.message);
      return jsonResponse(502, { error: 'submission_failed' });
    }

    return success({ ok: true, id: data as string });
  } catch (err) {
    if (err instanceof ValidationError) return validationFailed(err.message);
    console.error('submit-matching-request: unexpected error:', err instanceof Error ? err.message : err);
    return jsonResponse(500, { error: 'internal_error' });
  }
};
