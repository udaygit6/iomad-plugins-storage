import type { Handler } from '@netlify/functions';
import { getServerSupabaseClient } from './_lib/supabaseServerClient.js';
import {
  parseJsonBody,
  assertNoUnexpectedFields,
  requireString,
  optionalString,
  requireStringArray,
  normalizeEmail,
  ValidationError,
} from './_lib/validation.js';
import { isHoneypotTriggered, isSubmittedTooFast, getClientIp, checkRateLimit } from './_lib/antiAbuse.js';
import { jsonResponse, genericUnableToProcess, validationFailed, methodNotAllowed, serverMisconfigured, success } from './_lib/http.js';

const ALLOWED_FIELDS = [
  'fullName',
  'email',
  'phone',
  'aboutYou',
  'teachingExperience',
  'education',
  'qualifications',
  'subjectSlugs',
  'educationLevelSlugs',
  'teachingApproach',
  'availabilityNotes',
  'supportingDocumentsNote',
  'website',
  'formLoadedAt',
] as const;

/**
 * Hard-coded allowed write path: creates exactly one tutor_applications row
 * (plus qualifications/subject/level junction rows and a status-history
 * row), via the create_tutor_application RPC — see
 * supabase/migrations/0012. The caller can never supply status,
 * adminNotes, reviewedAt, or anything that would make this application
 * appear already reviewed/approved — none of those are read from the body.
 */
export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') return methodNotAllowed();

  let supabase;
  try {
    supabase = getServerSupabaseClient();
  } catch (err) {
    console.error('submit-tutor-application: server config error:', err instanceof Error ? err.message : err);
    return serverMisconfigured();
  }

  let body: Record<string, unknown>;
  try {
    body = parseJsonBody(event.body);
    assertNoUnexpectedFields(body, ALLOWED_FIELDS);
  } catch (err) {
    if (err instanceof ValidationError) return validationFailed(err.message);
    return validationFailed('malformed_request');
  }

  if (isHoneypotTriggered(body) || isSubmittedTooFast(body)) {
    return genericUnableToProcess();
  }
  const ip = getClientIp(event.headers as Record<string, string | string[] | undefined>);
  const withinRate = await checkRateLimit(supabase, 'submit-tutor-application', ip);
  if (!withinRate) return genericUnableToProcess();

  try {
    const fullName = requireString(body.fullName, 'fullName');
    const email = normalizeEmail(body.email);
    const phone = optionalString(body.phone, 'phone', 40);
    const aboutYou = requireString(body.aboutYou, 'aboutYou', 3000);
    const teachingExperience = requireString(body.teachingExperience, 'teachingExperience', 3000);
    const education = requireString(body.education, 'education', 3000);
    const qualifications = Array.isArray(body.qualifications) ? requireStringArray(body.qualifications, 'qualifications', 30) : [];
    const subjectSlugs = requireStringArray(body.subjectSlugs, 'subjectSlugs');
    const educationLevelSlugs = requireStringArray(body.educationLevelSlugs, 'educationLevelSlugs');
    const teachingApproach = requireString(body.teachingApproach, 'teachingApproach', 3000);
    const availabilityNotes = requireString(body.availabilityNotes, 'availabilityNotes', 1000);
    const supportingDocumentsNote = optionalString(body.supportingDocumentsNote, 'supportingDocumentsNote');

    const { data, error } = await supabase.rpc('create_tutor_application', {
      p_full_name: fullName,
      p_email: email,
      p_phone: phone ?? null,
      p_about_you: aboutYou,
      p_teaching_experience: teachingExperience,
      p_education: education,
      p_qualifications: qualifications,
      p_subject_slugs: subjectSlugs,
      p_education_level_slugs: educationLevelSlugs,
      p_teaching_approach: teachingApproach,
      p_availability_notes: availabilityNotes,
      p_supporting_documents_note: supportingDocumentsNote ?? null,
    });

    if (error) {
      if (error.message?.includes('invalid_subject_slug')) return validationFailed('invalid_subjectSlugs');
      if (error.message?.includes('invalid_education_level_slug')) return validationFailed('invalid_educationLevelSlugs');
      console.error('submit-tutor-application: RPC failed:', error.message);
      return jsonResponse(502, { error: 'submission_failed' });
    }

    return success({ ok: true, id: data as string });
  } catch (err) {
    if (err instanceof ValidationError) return validationFailed(err.message);
    console.error('submit-tutor-application: unexpected error:', err instanceof Error ? err.message : err);
    return jsonResponse(500, { error: 'internal_error' });
  }
};
