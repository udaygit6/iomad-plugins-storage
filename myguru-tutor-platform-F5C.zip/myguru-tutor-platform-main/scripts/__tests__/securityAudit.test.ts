import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';

const SCRIPT_PATH = join(__dirname, '..', 'iomad-sync-company.ts');
const scriptContent = readFileSync(SCRIPT_PATH, 'utf-8');

describe('Security audit — scripts/iomad-sync-company.ts (F4C manual CLI runner)', () => {
  it('never reads IOMAD_SERVICE_TOKEN, SUPABASE_SECRET_KEY, or SUPABASE_URL directly — only via the existing config/client modules', () => {
    expect(scriptContent).not.toContain('process.env.IOMAD_SERVICE_TOKEN');
    expect(scriptContent).not.toContain('process.env.SUPABASE_SECRET_KEY');
    expect(scriptContent).not.toContain('process.env.SUPABASE_URL');
    expect(scriptContent).not.toContain('process.env.IOMAD_BASE_URL');
  });

  it('declares no VITE_-prefixed variable of any kind', () => {
    expect(scriptContent).not.toMatch(/VITE_/);
  });

  it('imports only from the existing netlify/functions/_lib modules — no import path to src/', () => {
    expect(scriptContent).not.toMatch(/from ['"](\.\.\/)*src\//);
    expect(scriptContent).toContain('../netlify/functions/_lib/iomad/IomadRestGateway.js');
    expect(scriptContent).toContain('../netlify/functions/_lib/supabaseServerClient.js');
    expect(scriptContent).toContain('../netlify/functions/_lib/companySync/SupabaseOrganisationSyncRepository.js');
    expect(scriptContent).toContain('../netlify/functions/_lib/companySync/IomadCompanySyncService.js');
  });

  it('calls only syncByCompanyCode() on the sync service — never the bulk sync() method', () => {
    expect(scriptContent).toContain('.syncByCompanyCode(');
    expect(scriptContent).not.toMatch(/\.sync\(\s*\)/);
  });

  it('never logs a raw caught error object — only fixed string literals passed to fail()/console.error', () => {
    // Every console.error call must be passed a JSON.stringify(...) of a
    // literal object, never a bare caught error/exception variable.
    const consoleErrorCalls = [...scriptContent.matchAll(/console\.error\(([^;]*)\)/g)].map((m) => m[1]);
    for (const call of consoleErrorCalls) {
      expect(call).toContain('JSON.stringify');
      expect(call).not.toMatch(/\berr\b/);
    }
  });

  it('contains no hard-coded secret-like literal (a long opaque string assigned to a token/key-sounding variable)', () => {
    expect(scriptContent).not.toMatch(/(token|secret|key)\s*[:=]\s*['"][A-Za-z0-9_-]{16,}['"]/i);
  });

  it('documents all required and optional environment variables, using the existing names (not invented duplicates)', () => {
    expect(scriptContent).toContain('IOMAD_BASE_URL');
    expect(scriptContent).toContain('IOMAD_SERVICE_TOKEN');
    expect(scriptContent).toContain('SUPABASE_URL');
    expect(scriptContent).toContain('SUPABASE_SECRET_KEY');
    // Must NOT invent a differently-named Supabase key variable.
    expect(scriptContent).not.toContain('SUPABASE_SERVICE_ROLE_KEY');
  });
});

const COURSES_SCRIPT_PATH = join(__dirname, '..', 'iomad-company-courses.ts');
const coursesScriptContent = readFileSync(COURSES_SCRIPT_PATH, 'utf-8');

describe('Security audit — scripts/iomad-company-courses.ts (F5A manual CLI smoke-test, live-corrected)', () => {
  it('never reads IOMAD_SERVICE_TOKEN or IOMAD_BASE_URL directly — only via createIomadGateway()', () => {
    expect(coursesScriptContent).not.toContain('process.env.IOMAD_SERVICE_TOKEN');
    expect(coursesScriptContent).not.toContain('process.env.IOMAD_BASE_URL');
    expect(coursesScriptContent).not.toContain('process.env.IOMAD_ALLOW_INSECURE_HTTP');
  });

  it('declares no VITE_-prefixed variable of any kind', () => {
    expect(coursesScriptContent).not.toMatch(/VITE_/);
  });

  it('imports only from the existing netlify/functions/_lib/iomad module — no import path to src/, no Supabase involvement (read-only Iomad discovery, no persistence)', () => {
    expect(coursesScriptContent).not.toMatch(/from ['"](\.\.\/)*src\//);
    expect(coursesScriptContent).toContain('../netlify/functions/_lib/iomad/IomadRestGateway.js');
    expect(coursesScriptContent).not.toContain('supabaseServerClient');
    expect(coursesScriptContent).not.toContain('companySync');
  });

  it('calls only read-only gateway methods — getCompanyByCode, listCompanyCourses, getCourseSettings — never a write function', () => {
    expect(coursesScriptContent).toContain('.getCompanyByCode(');
    expect(coursesScriptContent).toContain('.listCompanyCourses(');
    expect(coursesScriptContent).toContain('.getCourseSettings(');
    expect(coursesScriptContent).not.toMatch(/block_iomad_company_admin_(create|edit|assign|unassign|enrol|allocate|move|update)/);
  });

  it('handles a zero-course company as a clean success — returns/prints an empty courses array and never calls getCourseSettings() in that case', () => {
    // LIVE VERIFIED (F5A correction pass): a company with zero allocated
    // courses is a valid success state, not an error. This guard must
    // exist so the script returns cleanly before reaching
    // getCourseSettings() at all — never issuing an unnecessary
    // get_course_info call for a company with nothing to look up.
    const guardIndex = coursesScriptContent.indexOf('if (allocations.length === 0)');
    expect(guardIndex).toBeGreaterThan(-1);
    const settingsCallIndex = coursesScriptContent.indexOf('.getCourseSettings(');
    expect(settingsCallIndex).toBeGreaterThan(guardIndex); // guard appears BEFORE the settings call
    const guardBlock = coursesScriptContent.slice(guardIndex, coursesScriptContent.indexOf('return;', guardIndex));
    expect(guardBlock).toContain('courses: []');
    // Checks the actual executable line, not the surrounding comment
    // prose (which legitimately says "not an error" while explaining the
    // guard's purpose).
    expect(guardBlock).toContain('console.log(');
    expect(guardBlock).not.toMatch(/console\.error/);
    expect(guardBlock).not.toContain("{ error:");
  });

  it('the sanitised output object literal (SanitisedCourseRow) never includes address or custom1/2/3 fields as actual data', () => {
    // Prose in the header comment legitimately mentions "address" and
    // "headers" while describing what's excluded — this checks the
    // actual output-construction code, not the whole file, to avoid a
    // false failure on that protective documentation.
    const outputConstruction = coursesScriptContent.slice(
      coursesScriptContent.indexOf('const rows: SanitisedCourseRow[]'),
      coursesScriptContent.indexOf('console.log(JSON.stringify(rows'),
    );
    expect(outputConstruction).not.toContain('address');
    expect(outputConstruction).not.toMatch(/custom[123]/);
    expect(outputConstruction).not.toContain('headers');
  });

  it('only prints the documented sanitised fields: companyId, courseId, fullName, licensed, shared, validLengthDays, warnExpireDays, warnCompletionDays, notifyPeriodDays', () => {
    const requiredFields = [
      'companyId',
      'courseId',
      'fullName',
      'licensed',
      'shared',
      'validLengthDays',
      'warnExpireDays',
      'warnCompletionDays',
      'notifyPeriodDays',
    ];
    for (const field of requiredFields) {
      expect(coursesScriptContent).toContain(field);
    }
  });

  it('never logs a raw caught error object — only fixed string literals passed to fail()/console.error', () => {
    const consoleErrorCalls = [...coursesScriptContent.matchAll(/console\.error\(([^;]*)\)/g)].map((m) => m[1]);
    for (const call of consoleErrorCalls) {
      expect(call).toContain('JSON.stringify');
      expect(call).not.toMatch(/\berr\b/);
    }
  });

  it('contains no hard-coded secret-like literal', () => {
    expect(coursesScriptContent).not.toMatch(/(token|secret|key)\s*[:=]\s*['"][A-Za-z0-9_-]{16,}['"]/i);
  });
});

const SYNC_COURSES_SCRIPT_PATH = join(__dirname, '..', 'iomad-sync-company-courses.ts');
const syncCoursesScriptContent = readFileSync(SYNC_COURSES_SCRIPT_PATH, 'utf-8');

describe('Security audit — scripts/iomad-sync-company-courses.ts (F5B manual CLI sync runner)', () => {
  it('never reads IOMAD_SERVICE_TOKEN, SUPABASE_SECRET_KEY, SUPABASE_URL, or IOMAD_BASE_URL directly — only via the existing config/client modules', () => {
    expect(syncCoursesScriptContent).not.toContain('process.env.IOMAD_SERVICE_TOKEN');
    expect(syncCoursesScriptContent).not.toContain('process.env.SUPABASE_SECRET_KEY');
    expect(syncCoursesScriptContent).not.toContain('process.env.SUPABASE_URL');
    expect(syncCoursesScriptContent).not.toContain('process.env.IOMAD_BASE_URL');
  });

  it('declares no VITE_-prefixed variable of any kind', () => {
    expect(syncCoursesScriptContent).not.toMatch(/VITE_/);
  });

  it('imports only from the existing netlify/functions/_lib modules — no import path to src/', () => {
    expect(syncCoursesScriptContent).not.toMatch(/from ['"](\.\.\/)*src\//);
    expect(syncCoursesScriptContent).toContain('../netlify/functions/_lib/iomad/IomadRestGateway.js');
    expect(syncCoursesScriptContent).toContain('../netlify/functions/_lib/supabaseServerClient.js');
    expect(syncCoursesScriptContent).toContain(
      '../netlify/functions/_lib/courseSync/SupabaseOrganisationCourseSyncRepository.js',
    );
    expect(syncCoursesScriptContent).toContain('../netlify/functions/_lib/courseSync/IomadCompanyCourseSyncService.js');
  });

  it('calls only syncOrganisationCourses() on the sync service', () => {
    expect(syncCoursesScriptContent).toContain('.syncOrganisationCourses(');
  });

  it('never references an Iomad write function of any kind', () => {
    expect(syncCoursesScriptContent).not.toMatch(/block_iomad_company_admin_(create|edit|assign|unassign|enrol|allocate|move|update)/);
  });

  it('never logs a raw caught error object — only fixed string literals passed to fail()/console.error', () => {
    const consoleErrorCalls = [...syncCoursesScriptContent.matchAll(/console\.error\(([^;]*)\)/g)].map((m) => m[1]);
    for (const call of consoleErrorCalls) {
      expect(call).toContain('JSON.stringify');
      expect(call).not.toMatch(/\berr\b/);
    }
  });

  it('contains no hard-coded secret-like literal', () => {
    expect(syncCoursesScriptContent).not.toMatch(/(token|secret|key)\s*[:=]\s*['"][A-Za-z0-9_-]{16,}['"]/i);
  });

  it('documents all required and optional environment variables, using the existing names (not invented duplicates)', () => {
    expect(syncCoursesScriptContent).toContain('IOMAD_BASE_URL');
    expect(syncCoursesScriptContent).toContain('IOMAD_SERVICE_TOKEN');
    expect(syncCoursesScriptContent).toContain('SUPABASE_URL');
    expect(syncCoursesScriptContent).toContain('SUPABASE_SECRET_KEY');
    expect(syncCoursesScriptContent).not.toContain('SUPABASE_SERVICE_ROLE_KEY');
  });

  it('only prints the documented sanitised summary fields: companyId, created, updated, unchanged, stale, timestamp', () => {
    const outputConstruction = syncCoursesScriptContent.slice(
      syncCoursesScriptContent.indexOf('console.log('),
      syncCoursesScriptContent.indexOf('if (result.topLevelError'),
    );
    for (const field of ['companyId', 'created', 'updated', 'unchanged', 'stale', 'timestamp']) {
      expect(outputConstruction).toContain(field);
    }
    // Never the full raw result spread — no `...result` anywhere in the
    // output construction, matching the "explicit field list" pattern.
    expect(outputConstruction).not.toContain('...result,');
    expect(outputConstruction).not.toContain('...result}');
  });
});
