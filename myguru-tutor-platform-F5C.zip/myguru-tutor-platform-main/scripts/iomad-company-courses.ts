/**
 * F5A — controlled, server-only, read-only Iomad company-course
 * discovery smoke-test runner. Manual use only — NOT invoked by the
 * application, NOT run in CI, NOT run automatically anywhere in this
 * repository.
 *
 * Usage (from the repo root), by numeric Iomad company ID:
 *   npx tsx scripts/iomad-company-courses.ts 4
 *
 * Or by company code (resolved via the F4-confirmed getCompanyByCode()
 * lookup first — reuses that path cleanly rather than duplicating it):
 *   npx tsx scripts/iomad-company-courses.ts MYGURU-JUPITER-TEST-001
 *
 * Required environment variables (server-side only — see .env.example):
 *   IOMAD_BASE_URL
 *   IOMAD_SERVICE_TOKEN
 *
 * Optional, temporary, test-only:
 *   IOMAD_ALLOW_INSECURE_HTTP=true   — ONLY for a temporary http:// test
 *                                      endpoint; must be exactly "true";
 *                                      leave unset otherwise. HTTPS stays
 *                                      the default; this does not weaken
 *                                      that default.
 *
 * This script makes REAL Iomad API calls when run with real credentials
 * — it is READ-ONLY (no Iomad write operation anywhere in this file or
 * anything it calls). It is not run automatically by any test, build, or
 * CI step — it must be invoked manually, deliberately, by a person who
 * has reviewed what it does.
 *
 * Flow (F5A, DOCUMENTED but NOT YET execution-verified until this script
 * is actually run against the live instance — see
 * docs/IOMAD_INTEGRATION_CONTRACT.md's F5A section):
 *   [company code →] getCompanyByCode() → companyId
 *   companyId → listCompanyCourses(companyId) → course allocations
 *   course IDs → getCourseSettings(courseIds) → course settings
 *   → sanitised console output only
 *
 * Prints ONLY the fields listed in the F5A brief: companyId, courseId,
 * fullName, licensed, shared, validLengthDays, warnExpireDays,
 * warnCompletionDays, notifyPeriodDays. NEVER the token, raw HTTP
 * headers, the raw upstream response, company address, or
 * custom1/custom2/custom3 — those are simply never read into anything
 * this script has a variable for, not filtered out after the fact.
 */

import { createIomadGateway } from '../netlify/functions/_lib/iomad/IomadRestGateway.js';

interface SanitisedCourseRow {
  companyId: string;
  courseId: string;
  fullName: string;
  licensed: boolean | null;
  shared: boolean | null;
  validLengthDays: number | null;
  warnExpireDays: number | null;
  warnCompletionDays: number | null;
  notifyPeriodDays: number | null;
}

function fail(message: string): never {
  // Safe by construction — every call site passes a fixed, hard-coded
  // string literal, never a caught error or any value that could carry a
  // secret or raw response detail.
  console.error(JSON.stringify({ error: message }));
  process.exit(1);
}

function looksNumeric(value: string): boolean {
  return /^\d+$/.test(value);
}

async function main(): Promise<void> {
  const arg = process.argv[2]?.trim();
  if (!arg) {
    fail('Usage: iomad-company-courses.ts <iomad-company-id-or-code> (e.g. 4, or MYGURU-JUPITER-TEST-001)');
    return;
  }

  const gateway = createIomadGateway();

  let companyId: string;
  if (looksNumeric(arg)) {
    companyId = arg;
  } else {
    // Reuses the F4-confirmed code lookup rather than duplicating it.
    const company = await gateway.getCompanyByCode(arg);
    if (!company) {
      fail(`No Iomad company found for code "${arg}".`);
      return;
    }
    companyId = company.externalId;
  }

  const allocations = await gateway.listCompanyCourses(companyId);

  if (allocations.length === 0) {
    // A company with zero allocated courses is a VALID SUCCESS state
    // (live-verified — see docs/IOMAD_INTEGRATION_CONTRACT.md's F5A
    // section), not an error. Return cleanly and do NOT call
    // getCourseSettings()/get_course_info at all — there is nothing to
    // fetch settings for, and that call is unnecessary here.
    console.log(JSON.stringify({ companyId, courses: [] }, null, 2));
    return;
  }

  const courseIds = allocations.map((a) => a.externalCourseId);
  const settingsList = await gateway.getCourseSettings(courseIds);
  const settingsByCourseId = new Map(settingsList.map((s) => [s.externalCourseId, s]));

  const rows: SanitisedCourseRow[] = allocations.map((allocation) => {
    const settings = settingsByCourseId.get(allocation.externalCourseId);
    return {
      companyId,
      courseId: allocation.externalCourseId,
      fullName: allocation.fullName,
      licensed: settings?.licensed ?? null,
      shared: settings?.shared ?? null,
      validLengthDays: settings?.validLengthDays ?? null,
      warnExpireDays: settings?.warnExpireDays ?? null,
      warnCompletionDays: settings?.warnCompletionDays ?? null,
      notifyPeriodDays: settings?.notifyPeriodDays ?? null,
    };
  });

  // Sanitised, minimal output only — see file header. Deliberately built
  // as fresh objects (SanitisedCourseRow) rather than spreading gateway
  // results as-is, so adding a field upstream can't silently widen what
  // this script prints without a deliberate change here too.
  console.log(JSON.stringify(rows, null, 2));
}

main().catch((_err: unknown) => {
  // Never print the caught error directly — it could be a library
  // exception carrying request/response detail. Only ever a fixed,
  // generic message.
  console.error(JSON.stringify({ error: 'unexpected_failure' }));
  process.exitCode = 1;
});
