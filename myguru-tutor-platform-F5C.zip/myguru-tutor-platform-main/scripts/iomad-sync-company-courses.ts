/**
 * F5B — controlled, server-only organisation-course sync runner. Manual
 * use only — NOT invoked by the application, NOT run in CI, NOT run
 * automatically anywhere in this repository.
 *
 * Usage (from the repo root):
 *   npx tsx scripts/iomad-sync-company-courses.ts 4
 *
 * Required environment variables (server-side only — see .env.example;
 * these preserve the EXISTING names already used elsewhere in this
 * repo, not new ones):
 *   IOMAD_BASE_URL
 *   IOMAD_SERVICE_TOKEN
 *   SUPABASE_URL
 *   SUPABASE_SECRET_KEY
 *
 * Optional, temporary, test-only:
 *   IOMAD_ALLOW_INSECURE_HTTP=true   — ONLY for a temporary http:// test
 *                                      endpoint; must be exactly "true";
 *                                      leave unset otherwise.
 *
 * This script performs a REAL Iomad API call (read-only — F5A's
 * live-verified `listCompanyCourses`/`getCourseSettings`) and a REAL
 * Supabase write (F5B's `sync_iomad_company_course`/
 * `mark_stale_organisation_course_allocations` RPCs) when run with real
 * credentials. It is not run automatically by any test, build, or CI
 * step — it must be invoked manually, deliberately, by a person who has
 * reviewed what it does.
 *
 * Requires the organisation to already exist — i.e.
 * `scripts/iomad-sync-company.ts <code>` (F4C) must have been run for
 * this company first. This script does not create organisations; it
 * looks up the existing one by Iomad company ID.
 *
 * Reuses F5A's gateway exactly as designed — does not duplicate its
 * transport. No Iomad write occurs anywhere in this script or anything
 * it calls.
 *
 * Prints ONLY a small, sanitised JSON result to stdout — never the
 * token, the Supabase key, a raw Iomad response, or any course/company
 * field beyond counts and identifiers.
 */

import { createIomadGateway } from '../netlify/functions/_lib/iomad/IomadRestGateway.js';
import { getServerSupabaseClient } from '../netlify/functions/_lib/supabaseServerClient.js';
import { SupabaseOrganisationCourseSyncRepository } from '../netlify/functions/_lib/courseSync/SupabaseOrganisationCourseSyncRepository.js';
import { IomadCompanyCourseSyncService } from '../netlify/functions/_lib/courseSync/IomadCompanyCourseSyncService.js';

function fail(message: string): never {
  // Safe by construction — every call site below passes a fixed,
  // hard-coded string literal, never a caught error or any value that
  // could contain a secret or raw response detail.
  console.error(JSON.stringify({ error: message }));
  process.exit(1);
}

async function main(): Promise<void> {
  const companyId = process.argv[2]?.trim();
  if (!companyId) {
    fail('Usage: iomad-sync-company-courses.ts <iomad-company-id> (e.g. 4)');
    return;
  }

  let supabase: ReturnType<typeof getServerSupabaseClient>;
  try {
    supabase = getServerSupabaseClient();
  } catch {
    fail('Supabase is not configured (SUPABASE_URL / SUPABASE_SECRET_KEY) — see .env.example.');
    return;
  }

  // Look up the existing organisation for this Iomad company. This
  // script does not create organisations — run
  // scripts/iomad-sync-company.ts <code> (F4C) first if none exists yet.
  const { data: mapping, error: mappingError } = await supabase
    .from('iomad_company_mappings')
    .select('organisation_id')
    .eq('iomad_company_id', companyId)
    .maybeSingle();

  if (mappingError) {
    fail('Could not look up the organisation for this Iomad company ID.');
    return;
  }
  if (!mapping) {
    fail(
      `No organisation found for Iomad company ID "${companyId}". Run scripts/iomad-sync-company.ts <code> first.`,
    );
    return;
  }

  const organisationId = (mapping as { organisation_id: string }).organisation_id;

  const gateway = createIomadGateway();
  const repository = new SupabaseOrganisationCourseSyncRepository(supabase);
  const service = new IomadCompanyCourseSyncService(gateway, repository);

  const result = await service.syncOrganisationCourses(organisationId, companyId);

  // Sanitised, minimal output only — see file header. Deliberately
  // reconstructs a fresh object rather than spreading `result` as-is.
  console.log(
    JSON.stringify(
      {
        companyId: result.companyId,
        created: result.created,
        updated: result.updated,
        unchanged: result.unchanged,
        stale: result.stale,
        timestamp: result.timestamp,
        ...(result.topLevelError ? { error: result.topLevelError } : {}),
      },
      null,
      2,
    ),
  );

  if (result.topLevelError || result.failed > 0) {
    process.exitCode = 1;
  }
}

main().catch((_err: unknown) => {
  // Never print the caught error directly — it could be a library
  // exception carrying request/response detail. Only ever a fixed,
  // generic message.
  console.error(JSON.stringify({ error: 'unexpected_failure' }));
  process.exitCode = 1;
});
