/**
 * F4C — controlled, server-only, single-company Iomad → platform sync
 * runner. Manual use only — NOT invoked by the application, NOT run in
 * CI, NOT run automatically anywhere in this repository.
 *
 * Usage (from the repo root):
 *   npx tsx scripts/iomad-sync-company.ts MYGURU-SHIKSHA-001
 *
 * Required environment variables (server-side only — see .env.example;
 * these preserve the EXISTING names already used elsewhere in this repo,
 * not new ones):
 *   IOMAD_BASE_URL
 *   IOMAD_SERVICE_TOKEN
 *   SUPABASE_URL
 *   SUPABASE_SECRET_KEY
 *
 * Optional, temporary, test-only:
 *   IOMAD_ALLOW_INSECURE_HTTP=true   — ONLY for a temporary http:// test
 *                                      endpoint; must be exactly "true";
 *                                      leave unset in every other case.
 *
 * This script performs a REAL Iomad API call and a REAL Supabase write
 * when run with real credentials. It is not run automatically by any
 * test, build, or CI step in this repository — it must be invoked
 * manually, deliberately, by a person who has reviewed what it does.
 *
 * Reuses the existing F4 repository/RPC path exactly as designed:
 *   getCompanyByCode(code) → syncCompany() → sync_iomad_company() RPC
 * Does NOT call the bulk sync()/listCompanies()/markMissingAsStale() —
 * this script touches exactly the one company it's given, nothing else.
 * No migration is created or modified by this script; it only calls the
 * existing, already-applied `sync_iomad_company()` RPC via the ordinary
 * repository path.
 *
 * Prints ONLY a small, sanitised JSON result to stdout — never the
 * token, the Supabase key, a raw Iomad response, HTTP headers, or any
 * company field beyond its Iomad id, sync outcome, and timestamp (see
 * IomadCompanySyncService.syncByCompanyCode(), which already limits what
 * comes back to exactly this shape — this script does not need to, and
 * does not, do any additional filtering of sensitive fields itself,
 * because none reach it in the first place).
 */

import { createIomadGateway } from '../netlify/functions/_lib/iomad/IomadRestGateway.js';
import { getServerSupabaseClient } from '../netlify/functions/_lib/supabaseServerClient.js';
import { SupabaseOrganisationSyncRepository } from '../netlify/functions/_lib/companySync/SupabaseOrganisationSyncRepository.js';
import { IomadCompanySyncService } from '../netlify/functions/_lib/companySync/IomadCompanySyncService.js';

function fail(message: string): never {
  // Safe by construction — every call site below passes a fixed,
  // hard-coded string literal, never a caught error or any value that
  // could contain a secret or raw response detail.
  console.error(JSON.stringify({ error: message }));
  process.exit(1);
}

async function main(): Promise<void> {
  const code = process.argv[2]?.trim();
  if (!code) {
    fail('Usage: iomad-sync-company.ts <company-code> (e.g. MYGURU-SHIKSHA-001)');
    return;
  }

  let supabase: ReturnType<typeof getServerSupabaseClient>;
  try {
    supabase = getServerSupabaseClient();
  } catch {
    fail('Supabase is not configured (SUPABASE_URL / SUPABASE_SECRET_KEY) — see .env.example.');
    return;
  }

  // Always safe to construct — reports not_configured/invalid_config on
  // first use if IOMAD_BASE_URL/IOMAD_SERVICE_TOKEN are missing or the
  // base URL fails validation (see iomadConfig.ts).
  const gateway = createIomadGateway();
  const repository = new SupabaseOrganisationSyncRepository(supabase);
  const service = new IomadCompanySyncService(gateway, repository);

  const result = await service.syncByCompanyCode(code);

  // Sanitised, minimal output only — see file header. Deliberately
  // reconstructs a fresh object rather than spreading `result` as-is, so
  // adding a field to SingleCompanySyncResult later can't silently widen
  // what this script prints without a deliberate change here too.
  console.log(
    JSON.stringify(
      {
        companyCode: result.companyCode,
        iomadCompanyId: result.iomadCompanyId,
        outcome: result.outcome,
        timestamp: result.timestamp,
        ...(result.errorCode ? { errorCode: result.errorCode } : {}),
      },
      null,
      2,
    ),
  );

  if (result.outcome === 'failed') {
    process.exitCode = 1;
  }
}

main().catch((_err: unknown) => {
  // Never print the caught error directly — it could be a library
  // exception carrying request/response detail. Only ever a fixed,
  // generic message.
  console.error(JSON.stringify({ error: 'unexpected_failure' }));
  process.exitCode = 1;
});
