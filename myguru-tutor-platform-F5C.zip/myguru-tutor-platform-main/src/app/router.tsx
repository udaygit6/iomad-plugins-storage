import { createBrowserRouter, Navigate, Outlet } from 'react-router-dom';
import { Shell } from '../components/layout/Shell';
import { HomePage } from '../pages/HomePage';
import { TutorsPage } from '../pages/TutorsPage';
import { TutorProfilePage } from '../pages/TutorProfilePage';
import { SubjectsPage } from '../pages/SubjectsPage';
import { SubjectDetailPage } from '../pages/SubjectDetailPage';
import { LevelPage } from '../pages/LevelPage';
import { FindTutorPage } from '../pages/FindTutorPage';
import { BecomeATutorPage } from '../pages/BecomeATutorPage';
import { ApplyPage } from '../pages/ApplyPage';
import { AboutPage } from '../pages/AboutPage';
import { HowItWorksPage } from '../pages/HowItWorksPage';
import { FaqPage } from '../pages/FaqPage';
import { ContactPage } from '../pages/ContactPage';
import { SafeguardingPage } from '../pages/SafeguardingPage';
import { LegalDraftPage } from '../pages/LegalDraftPage';
import { AdminAuthProvider } from '../features/admin-auth/AdminAuthContext';
import { RequireAdmin } from '../features/admin-auth/RequireAdmin';
import { AdminLoginPage } from '../pages/admin/AdminLoginPage';
import { AdminLayout } from '../pages/admin/AdminLayout';
import { AdminApplicationsPage } from '../pages/admin/AdminApplicationsPage';
import { AdminTutorProfilesPage } from '../pages/admin/AdminTutorProfilesPage';
import { AdminMatchingRequestsPage } from '../pages/admin/AdminMatchingRequestsPage';
import { AdminEnquiriesPage } from '../pages/admin/AdminEnquiriesPage';
import { AdminSubjectsPage } from '../pages/admin/AdminSubjectsPage';
import { AdminOrganisationsPage } from '../pages/admin/AdminOrganisationsPage';
import { NotFoundPage } from '../pages/NotFoundPage';

export const router = createBrowserRouter([
  {
    path: '/',
    element: <Shell />,
    errorElement: <NotFoundPage />,
    children: [
      { index: true, element: <HomePage /> },
      { path: 'tutors', element: <TutorsPage /> },
      { path: 'tutors/:slug', element: <TutorProfilePage /> },
      { path: 'find-a-tutor', element: <FindTutorPage /> },
      { path: 'subjects', element: <SubjectsPage /> },
      { path: 'subjects/:slug', element: <SubjectDetailPage /> },
      { path: 'levels/:level', element: <LevelPage /> },
      { path: 'how-it-works', element: <HowItWorksPage /> },
      { path: 'about', element: <AboutPage /> },
      { path: 'become-a-tutor', element: <BecomeATutorPage /> },
      { path: 'apply', element: <ApplyPage /> },
      { path: 'contact', element: <ContactPage /> },
      { path: 'faq', element: <FaqPage /> },
      { path: 'safeguarding', element: <SafeguardingPage /> },
      {
        path: 'privacy',
        element: <LegalDraftPage title="Privacy Policy" intro="How personal data is collected, used, and protected on this platform." />,
      },
      {
        path: 'cookies',
        element: <LegalDraftPage title="Cookie Policy" intro="What cookies are used on this site and why." />,
      },
      {
        path: 'terms',
        element: <LegalDraftPage title="Terms & Conditions" intro="The terms governing use of this platform." />,
      },
      {
        path: 'admin',
        element: (
          <AdminAuthProvider>
            <Outlet />
          </AdminAuthProvider>
        ),
        children: [
          { path: 'login', element: <AdminLoginPage /> },
          {
            element: <RequireAdmin />,
            children: [
              {
                element: <AdminLayout />,
                children: [
                  { index: true, element: <Navigate to="applications" replace /> },
                  { path: 'applications', element: <AdminApplicationsPage /> },
                  { path: 'tutor-profiles', element: <AdminTutorProfilesPage /> },
                  { path: 'matching-requests', element: <AdminMatchingRequestsPage /> },
                  { path: 'enquiries', element: <AdminEnquiriesPage /> },
                  { path: 'subjects', element: <AdminSubjectsPage /> },
                  { path: 'organisations', element: <AdminOrganisationsPage /> },
                ],
              },
            ],
          },
        ],
      },
      { path: '*', element: <NotFoundPage /> },
    ],
  },
]);
