import type { Subject, EducationLevel } from '../../domain/models/types';

// DEVELOPMENT FIXTURE — not production reference data.
export const mockSubjects: Subject[] = [
  { id: 'sub-maths', slug: 'maths', name: 'Maths', description: 'From times tables to A-Level calculus.' },
  { id: 'sub-english', slug: 'english', name: 'English', description: 'Reading, writing and analysis skills.' },
  { id: 'sub-combined-science', slug: 'combined-science', name: 'Combined Science' },
  { id: 'sub-biology', slug: 'biology', name: 'Biology' },
  { id: 'sub-chemistry', slug: 'chemistry', name: 'Chemistry' },
  { id: 'sub-physics', slug: 'physics', name: 'Physics' },
  { id: 'sub-computer-science', slug: 'computer-science', name: 'Computer Science' },
  { id: 'sub-geography', slug: 'geography', name: 'Geography' },
  { id: 'sub-history', slug: 'history', name: 'History' },
  { id: 'sub-french', slug: 'french', name: 'French' },
  { id: 'sub-spanish', slug: 'spanish', name: 'Spanish' },
  { id: 'sub-business', slug: 'business', name: 'Business' },
  { id: 'sub-economics', slug: 'economics', name: 'Economics' },
];

// DEVELOPMENT FIXTURE — not production reference data.
export const mockEducationLevels: EducationLevel[] = [
  {
    id: 'lvl-ks1',
    slug: 'ks1',
    name: 'KS1',
    stageHeadline: 'Build strong foundations',
    stageDescription: 'Early reading, writing and number skills, at their own pace.',
  },
  {
    id: 'lvl-ks2',
    slug: 'ks2',
    name: 'KS2',
    stageHeadline: 'Strengthen the basics',
    stageDescription: 'Solidifying core skills ahead of the move to secondary school.',
  },
  {
    id: 'lvl-ks3',
    slug: 'ks3',
    name: 'KS3',
    stageHeadline: 'Strengthen understanding',
    stageDescription: 'Closing gaps before subjects narrow and pace picks up at GCSE.',
  },
  {
    id: 'lvl-gcse',
    slug: 'gcse',
    name: 'GCSE',
    stageHeadline: 'Prepare with confidence',
    stageDescription: 'Focused, exam-aware support in the subjects that need it most.',
  },
  {
    id: 'lvl-a-level',
    slug: 'a-level',
    name: 'A-Level',
    stageHeadline: 'Master advanced subjects',
    stageDescription: 'Depth and independence for the step up to further study.',
  },
];
