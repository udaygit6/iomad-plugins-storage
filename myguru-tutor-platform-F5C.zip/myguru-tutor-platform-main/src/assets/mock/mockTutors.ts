import type { TutorProfile } from '../../domain/models/types';
import { mockSubjects, mockEducationLevels } from './mockSubjects';

const bySlug = (slug: string) => mockSubjects.find((s) => s.slug === slug)!;
const levelBySlug = (slug: string) => mockEducationLevels.find((l) => l.slug === slug)!;

/**
 * DEVELOPMENT FIXTURE — clearly fictional. Not real tutors, not production
 * data. Must be replaced/removed before any production build. See
 * docs/domain-model.md for the fixture-replacement strategy.
 */
export const mockTutors: TutorProfile[] = [
  {
    id: 'tutor-1',
    slug: 'sarah-m-maths',
    publicDisplayName: 'Sarah M.',
    headline: 'GCSE & A-Level Maths',
    positioningStatement: 'Making algebra click, one step at a time.',
    bio: 'Sample development bio — not a real tutor. Replace before production.',
    teachingApproach: 'Sample development content describing a patient, example-led teaching approach.',
    subjects: [bySlug('maths')],
    educationLevels: [levelBySlug('gcse'), levelBySlug('a-level')],
    qualificationsSummary: ['BSc Mathematics (sample data)'],
    experienceSummary: 'Sample development content — years of experience placeholder.',
    languages: ['English'],
    acceptingStudents: true,
    publicVerificationBadges: ['qualification_checked'],
    status: 'published',
  },
  {
    id: 'tutor-2',
    slug: 'james-o-english',
    publicDisplayName: 'James O.',
    headline: 'Primary (KS1–KS2) & KS3 English',
    positioningStatement: 'Reading should feel like a door opening, not a chore.',
    bio: 'Sample development bio — not a real tutor. Replace before production.',
    teachingApproach: 'Sample development content describing an encouraging, confidence-first approach.',
    subjects: [bySlug('english')],
    educationLevels: [levelBySlug('ks1'), levelBySlug('ks2'), levelBySlug('ks3')],
    qualificationsSummary: ['PGCE English (sample data)'],
    experienceSummary: 'Sample development content — years of experience placeholder.',
    languages: ['English'],
    acceptingStudents: true,
    publicVerificationBadges: ['qualification_checked'],
    status: 'published',
  },
  {
    id: 'tutor-3',
    slug: 'priya-k-science',
    publicDisplayName: 'Priya K.',
    headline: 'GCSE Combined Science',
    positioningStatement: 'Science makes sense once you see the pattern.',
    bio: 'Sample development bio — not a real tutor. Replace before production.',
    teachingApproach: 'Sample development content describing a structured, visual teaching style.',
    subjects: [bySlug('combined-science')],
    educationLevels: [levelBySlug('gcse')],
    qualificationsSummary: ['MSci Natural Sciences (sample data)'],
    experienceSummary: 'Sample development content — years of experience placeholder.',
    languages: ['English', 'Hindi'],
    acceptingStudents: false,
    publicVerificationBadges: ['qualification_checked', 'identity_checked'],
    status: 'published',
  },
  {
    id: 'tutor-4',
    slug: 'daniel-r-physics',
    publicDisplayName: 'Daniel R.',
    headline: 'A-Level Physics',
    positioningStatement: 'Breaking problems down until they stop feeling impossible.',
    bio: 'Sample development bio — not a real tutor. Replace before production.',
    teachingApproach: 'Sample development content describing a problem-first teaching approach.',
    subjects: [bySlug('physics')],
    educationLevels: [levelBySlug('a-level')],
    qualificationsSummary: ['MPhys Physics (sample data)'],
    experienceSummary: 'Sample development content — years of experience placeholder.',
    languages: ['English'],
    acceptingStudents: true,
    publicVerificationBadges: ['qualification_checked'],
    status: 'published',
  },
];
