import { describe, it, expect, afterEach } from 'vitest';
import { render, cleanup } from '@testing-library/react';
import { PageMeta } from './PageMeta';

function getRobotsContent(): string | null {
  return document.querySelector('meta[name="robots"]')?.getAttribute('content') ?? null;
}

describe('PageMeta robots directive (SPA noindex leak regression)', () => {
  afterEach(() => {
    cleanup();
    document.querySelectorAll('meta[name="robots"]').forEach((el) => el.remove());
  });

  it('defaults to index, follow when no robots prop is given', () => {
    render(<PageMeta title="Public page" description="A public page." />);
    expect(getRobotsContent()).toBe('index, follow');
  });

  it('applies noindex, nofollow when explicitly requested (admin routes)', () => {
    render(<PageMeta title="Admin" description="Internal admin workflow." robots="noindex, nofollow" />);
    expect(getRobotsContent()).toBe('noindex, nofollow');
  });

  it('does not leak noindex onto a subsequent public route: public -> admin -> public', () => {
    const { unmount } = render(<PageMeta title="Home" description="Public home." />);
    expect(getRobotsContent()).toBe('index, follow');

    // Simulate navigating to an admin route (a different PageMeta instance,
    // exactly as happens when React Router swaps route components).
    unmount();
    const admin = render(<PageMeta title="Admin" description="Internal admin workflow." robots="noindex, nofollow" />);
    expect(getRobotsContent()).toBe('noindex, nofollow');

    // Simulate navigating back to a public route.
    admin.unmount();
    render(<PageMeta title="Browse Tutors" description="Public tutors page." />);
    expect(getRobotsContent()).toBe('index, follow');
  });

  it('reuses a single meta[name="robots"] tag rather than accumulating duplicates across route changes', () => {
    const first = render(<PageMeta title="Home" description="Public home." />);
    first.unmount();
    render(<PageMeta title="Admin" description="Internal admin workflow." robots="noindex, nofollow" />);

    expect(document.querySelectorAll('meta[name="robots"]').length).toBe(1);
  });
});
