import { useEffect } from 'react';
import { siteConfig } from '../config/siteConfig';

interface PageMetaProps {
  title: string;
  description: string;
  /**
   * Search-engine indexing directive for this route. Defaults to normal
   * indexing ('index, follow') so that navigating away from a route that
   * opts into 'noindex, nofollow' (e.g. /admin/*) always restores default
   * behaviour on the next route — nothing "leaks" between routes because
   * every PageMeta call sets an explicit value, never leaving the previous
   * route's value in place.
   */
  robots?: string;
}

/**
 * Minimal per-route <title>/meta-description/robots management. Deliberately
 * not pulling in a routing-meta library for this — Phase D §39 asks for
 * minimal dependency usage, and this is a small, well-understood side effect.
 */
export function PageMeta({ title, description, robots = 'index, follow' }: PageMetaProps) {
  useEffect(() => {
    document.title = title;

    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement('meta');
      meta.setAttribute('name', 'description');
      document.head.appendChild(meta);
    }
    meta.setAttribute('content', description);

    let robotsMeta = document.querySelector('meta[name="robots"]');
    if (!robotsMeta) {
      robotsMeta = document.createElement('meta');
      robotsMeta.setAttribute('name', 'robots');
      document.head.appendChild(robotsMeta);
    }
    robotsMeta.setAttribute('content', robots);

    let ogTitle = document.querySelector('meta[property="og:title"]');
    if (!ogTitle) {
      ogTitle = document.createElement('meta');
      ogTitle.setAttribute('property', 'og:title');
      document.head.appendChild(ogTitle);
    }
    ogTitle.setAttribute('content', `${title} — ${siteConfig.brandName}`);
  }, [title, description, robots]);

  return null;
}
