export interface Review {
  authorInitial: string;
  quote: string;
  context: string; // e.g. "Parent, GCSE Maths"
}

/**
 * Renders nothing when `reviews` is empty or undefined — per Phase D §11,
 * an empty placeholder must never ship to end users. This component is not
 * currently mounted anywhere in the app (see pages/HomePage.tsx) because no
 * genuine reviews exist yet. It stays here, ready to be wired in once real,
 * consented reviews are available — nothing needs to be built from scratch
 * at that point, just data and a mount point.
 */
export function ReviewsSection({ reviews }: { reviews?: Review[] }) {
  if (!reviews || reviews.length === 0) return null;

  return (
    <section className="band" aria-labelledby="reviews-heading">
      <div className="container">
        <h2 id="reviews-heading">What families say</h2>
        <ul className="reviews-grid">
          {reviews.map((r, i) => (
            <li key={i} className="review-card">
              <p>&ldquo;{r.quote}&rdquo;</p>
              <span>
                {r.authorInitial} — {r.context}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
