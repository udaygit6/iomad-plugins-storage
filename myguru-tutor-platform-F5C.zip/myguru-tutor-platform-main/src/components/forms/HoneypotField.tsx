/**
 * A honeypot field: visible to bots that fill in every input, invisible
 * and unreachable to real users. Uses off-screen positioning rather than
 * display:none/visibility:hidden (some bots skip those specifically) and
 * is excluded from tab order and screen readers.
 */
export function HoneypotField({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  return (
    <div style={{ position: 'absolute', left: '-9999px', top: 'auto', width: 1, height: 1, overflow: 'hidden' }} aria-hidden="true">
      <label htmlFor="website">Website</label>
      <input
        id="website"
        name="website"
        type="text"
        tabIndex={-1}
        autoComplete="off"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  );
}
