import type { ReactNode } from 'react';
import './WizardShell.css';

interface WizardShellProps {
  title: string;
  stepLabel: string;
  stepNumber: number;
  totalSteps: number;
  progressPercent: number;
  children: ReactNode;
  footer: ReactNode;
}

export function WizardShell({ title, stepLabel, stepNumber, totalSteps, progressPercent, children, footer }: WizardShellProps) {
  return (
    <div className="wizard-shell">
      <div className="wizard-head">
        <div>
          <span className="eyebrow">{title}</span>
          <h2 className="wizard-step-title">{stepLabel}</h2>
        </div>
        <span className="wizard-step-count">
          Step {stepNumber} of {totalSteps}
        </span>
      </div>
      <div className="wizard-progress-track" role="progressbar" aria-valuenow={progressPercent} aria-valuemin={0} aria-valuemax={100}>
        <div className="wizard-progress-fill" style={{ width: `${progressPercent}%` }} />
      </div>
      <div className="wizard-body">{children}</div>
      <div className="wizard-footer">{footer}</div>
    </div>
  );
}
