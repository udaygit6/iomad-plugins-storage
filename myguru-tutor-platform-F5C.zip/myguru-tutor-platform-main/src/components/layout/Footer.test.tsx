import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { Footer } from './Footer';

describe('Footer — Staff sign in link (E7 §15)', () => {
  it('renders a "Staff sign in" link pointing to /admin/login', () => {
    render(
      <MemoryRouter>
        <Footer />
      </MemoryRouter>,
    );
    const link = screen.getByRole('link', { name: 'Staff sign in' });
    expect(link).toHaveAttribute('href', '/admin/login');
  });

  it('does not add Admin/Staff to the main footer navigation columns (only the subtle bottom link)', () => {
    render(
      <MemoryRouter>
        <Footer />
      </MemoryRouter>,
    );
    // "Find a tutor", "Tutors", "Trust", "Legal" columns should not contain an admin link.
    const allLinks = screen.getAllByRole('link');
    const adminLinks = allLinks.filter((el) => el.getAttribute('href')?.startsWith('/admin'));
    expect(adminLinks).toHaveLength(1); // exactly the one "Staff sign in" link
  });
});
