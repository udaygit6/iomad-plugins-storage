import { Link } from 'react-router-dom';
import { siteConfig } from '../../config/siteConfig';
import { Logo } from './Header';
import './Footer.css';

export function Footer() {
  return (
    <footer>
      <div className="container">
        <div className="footer-grid">
          <div className="footer-brand">
            <Logo onInk />
            <p>Online tutoring, Primary through A-Level. Carefully reviewed tutors, matched to what your child actually needs.</p>
          </div>
          <div className="footer-col">
            <h5>Find a tutor</h5>
            <ul>
              <li><Link to="/find-a-tutor">Find My Tutor</Link></li>
              <li><Link to="/tutors">Browse tutors</Link></li>
              <li><Link to="/subjects">Subjects</Link></li>
              <li><Link to="/how-it-works">How it works</Link></li>
            </ul>
          </div>
          <div className="footer-col">
            <h5>Tutors</h5>
            <ul>
              <li><Link to="/become-a-tutor">Become a tutor</Link></li>
              <li><Link to="/apply">Apply now</Link></li>
            </ul>
          </div>
          <div className="footer-col">
            <h5>Trust</h5>
            <ul>
              <li><Link to="/safeguarding">Safeguarding</Link></li>
              <li><Link to="/faq">FAQ</Link></li>
              <li><Link to="/contact">Contact</Link></li>
            </ul>
          </div>
          <div className="footer-col">
            <h5>Legal</h5>
            <ul>
              <li><Link to="/privacy">Privacy policy</Link></li>
              <li><Link to="/cookies">Cookie policy</Link></li>
              <li><Link to="/terms">Terms &amp; conditions</Link></li>
            </ul>
          </div>
        </div>
        <div className="footer-bottom">
          {/* No "Registered in England & Wales" claim — siteConfig.legal is unpopulated (Phase D §31/§57). */}
          <span>© {new Date().getFullYear()} {siteConfig.brandName} (working name). All rights reserved.</span>
          <Link to="/admin/login" style={{ fontSize: 13 }}>
            Staff sign in
          </Link>
        </div>
      </div>
    </footer>
  );
}
