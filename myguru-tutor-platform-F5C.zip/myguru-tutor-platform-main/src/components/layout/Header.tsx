import { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { siteConfig } from '../../config/siteConfig';
import { Drawer } from '../ui/Drawer';
import './Header.css';
import '../ui/Button.css';

const NAV_LINKS = [
  { to: '/tutors', label: 'Find a Tutor' },
  { to: '/subjects', label: 'Subjects' },
  { to: '/how-it-works', label: 'How It Works' },
  { to: '/become-a-tutor', label: 'For Tutors' },
  { to: '/about', label: 'About' },
];

export function Logo({ onInk = false }: { onInk?: boolean }) {
  const stroke = onInk ? 'var(--color-text-on-ink)' : 'var(--color-ink-900)';
  return (
    <Link to="/" className="logo" aria-label={`${siteConfig.brandName} — home`}>
      <svg className="logo-mark" viewBox="0 0 28 28" fill="none" aria-hidden="true">
        <circle cx="14" cy="14" r="12.5" stroke={stroke} strokeWidth="1.4" />
        <circle cx="14" cy="14" r="3.4" fill="var(--color-gold-600)" />
        <path d="M14 3.5v4M14 20.5v4M3.5 14h4M20.5 14h4" stroke={stroke} strokeWidth="1.2" strokeLinecap="round" />
      </svg>
      {siteConfig.brandNameParts.light}
      <b>{siteConfig.brandNameParts.accent}</b>
    </Link>
  );
}

export function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  const navContent = (
    <>
      {NAV_LINKS.map((link) => (
        <NavLink key={link.to} to={link.to} onClick={() => setMenuOpen(false)}>
          {link.label}
        </NavLink>
      ))}
    </>
  );

  return (
    <header>
      <div className="container nav-row">
        <Logo />
        <nav className="nav-links nav-links-desktop" aria-label="Primary">
          {navContent}
        </nav>
        <div className="nav-cta">
          <Link to="/tutors" className="btn-text">
            Browse Tutors
          </Link>
          <Link to="/find-a-tutor" className="btn btn-primary btn-sm">
            Find My Tutor
          </Link>
        </div>
        <button
          className="nav-toggle"
          aria-label="Open menu"
          aria-expanded={menuOpen}
          aria-controls="mobile-nav-drawer"
          onClick={() => setMenuOpen(true)}
        >
          <span />
          <span />
          <span />
        </button>
      </div>

      <Drawer open={menuOpen} onClose={() => setMenuOpen(false)} labelledBy="mobile-nav-heading">
        <div id="mobile-nav-drawer">
          <div className="drawer-header">
            <span id="mobile-nav-heading" className="sr-only">
              Navigation menu
            </span>
            <button className="drawer-close" onClick={() => setMenuOpen(false)} aria-label="Close menu">
              ×
            </button>
          </div>
          <nav className="nav-links nav-links-mobile" aria-label="Mobile primary">
            {navContent}
          </nav>
          <div className="mobile-cta">
            <Link to="/tutors" className="btn btn-outline" onClick={() => setMenuOpen(false)}>
              Browse Tutors
            </Link>
            <Link to="/find-a-tutor" className="btn btn-primary" onClick={() => setMenuOpen(false)}>
              Find My Tutor
            </Link>
          </div>
        </div>
      </Drawer>
    </header>
  );
}
