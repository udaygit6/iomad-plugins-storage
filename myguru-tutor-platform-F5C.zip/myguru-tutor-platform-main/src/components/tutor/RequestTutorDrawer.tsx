import { useState } from 'react';
import { Drawer } from '../ui/Drawer';
import { enquiryService, validateEnquiry, type EnquiryFormData } from '../../services/enquiries/EnquiryService';
import { useAntiAbuseFields } from '../../hooks/useAntiAbuseFields';
import { HoneypotField } from '../forms/HoneypotField';
import type { FieldErrors } from '../../domain/validation/formValidation';
import '../forms/WizardShell.css';

const EMPTY: EnquiryFormData = { name: '', email: '', message: '' };

export function RequestTutorDrawer({
  open,
  onClose,
  tutorName,
  tutorSlug,
}: {
  open: boolean;
  onClose: () => void;
  tutorName: string;
  tutorSlug: string;
}) {
  const [data, setData] = useState<EnquiryFormData>(EMPTY);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [status, setStatus] = useState<'idle' | 'submitting' | 'submitted' | 'error'>('idle');
  const { meta, honeypotValue, setHoneypotValue } = useAntiAbuseFields();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const validationErrors = validateEnquiry(data);
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;

    setStatus('submitting');
    try {
      await enquiryService.submit(data, tutorSlug, meta);
      setStatus('submitted');
    } catch {
      setStatus('error');
    }
  }

  function handleClose() {
    onClose();
    // Reset after the close transition so the drawer doesn't visibly flash empty.
    setTimeout(() => {
      setData(EMPTY);
      setErrors({});
      setStatus('idle');
    }, 250);
  }

  return (
    <Drawer open={open} onClose={handleClose} labelledBy="request-tutor-heading">
      <HoneypotField value={honeypotValue} onChange={setHoneypotValue} />
      <div className="drawer-header">
        <span id="request-tutor-heading" style={{ fontWeight: 700, fontSize: 18 }}>
          Request {tutorName}
        </span>
        <button className="drawer-close" onClick={handleClose} aria-label="Close">
          ×
        </button>
      </div>

      {status === 'submitted' ? (
        <div className="confirmation-state">
          <div className="confirmation-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <path d="M4 12l6 6L20 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <h3>Request sent</h3>
          <p style={{ color: 'var(--color-text-muted)', marginTop: 'var(--space-2)' }}>
            We&rsquo;ve received your request about {tutorName}. We&rsquo;ll be in touch by email.
          </p>
          <button className="btn btn-primary" style={{ marginTop: 'var(--space-6)' }} onClick={handleClose}>
            Done
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} noValidate>
          <p className="lede" style={{ fontSize: 14.5, marginBottom: 'var(--space-5)' }}>
            Tell us a little about what you&rsquo;re looking for and we&rsquo;ll pass it on.
          </p>
          <div className="form-field">
            <label htmlFor="req-name">Your name</label>
            <input
              id="req-name"
              className="form-input"
              autoComplete="name"
              value={data.name}
              aria-invalid={!!errors.name}
              onChange={(e) => setData({ ...data, name: e.target.value })}
            />
            {errors.name && <p className="form-error">{errors.name}</p>}
          </div>
          <div className="form-field">
            <label htmlFor="req-email">Email</label>
            <input
              id="req-email"
              type="email"
              className="form-input"
              autoComplete="email"
              value={data.email}
              aria-invalid={!!errors.email}
              onChange={(e) => setData({ ...data, email: e.target.value })}
            />
            {errors.email && <p className="form-error">{errors.email}</p>}
          </div>
          <div className="form-field">
            <label htmlFor="req-message">Message</label>
            <textarea
              id="req-message"
              className="form-textarea"
              value={data.message}
              aria-invalid={!!errors.message}
              onChange={(e) => setData({ ...data, message: e.target.value })}
            />
            {errors.message && <p className="form-error">{errors.message}</p>}
          </div>
          {status === 'error' && <p className="form-error">Something went wrong — please try again.</p>}
          <button
            type="submit"
            className="btn btn-primary"
            style={{ width: '100%' }}
            data-loading={status === 'submitting' ? 'true' : undefined}
            disabled={status === 'submitting'}
          >
            {status === 'submitting' ? 'Sending…' : 'Send request'}
          </button>
        </form>
      )}
    </Drawer>
  );
}
