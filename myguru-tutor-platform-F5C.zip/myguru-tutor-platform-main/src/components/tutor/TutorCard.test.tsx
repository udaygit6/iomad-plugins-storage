import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { TutorCard } from './TutorCard';
import type { TutorProfile } from '../../domain/models/types';

function makeTutor(overrides: Partial<TutorProfile> = {}): TutorProfile {
  return {
    id: 'tutor-1',
    slug: 'sarah-m',
    publicDisplayName: 'Sarah M.',
    headline: 'GCSE Maths',
    positioningStatement: 'Making algebra click.',
    bio: 'Bio',
    teachingApproach: 'Approach',
    subjects: [{ id: 's1', slug: 'maths', name: 'Maths' }],
    educationLevels: [{ id: 'l1', slug: 'gcse', name: 'GCSE', stageHeadline: '', stageDescription: '' }],
    qualificationsSummary: [],
    experienceSummary: '',
    languages: [],
    acceptingStudents: true,
    publicVerificationBadges: ['qualification_checked'],
    status: 'published',
    ...overrides,
  };
}

function renderCard(tutor: TutorProfile, isExample = false) {
  return render(
    <MemoryRouter>
      <TutorCard tutor={tutor} isExample={isExample} />
    </MemoryRouter>,
  );
}

describe('TutorCard', () => {
  it('renders the public display name, subject tags, and positioning statement', () => {
    renderCard(makeTutor());
    expect(screen.getByText('Sarah M.')).toBeInTheDocument();
    expect(screen.getByText('Maths')).toBeInTheDocument();
    expect(screen.getByText(/Making algebra click/)).toBeInTheDocument();
  });

  it('shows the "Taking students" label when accepting students', () => {
    renderCard(makeTutor({ acceptingStudents: true }));
    expect(screen.getByText('Taking students')).toBeInTheDocument();
  });

  it('shows a neutral label when not accepting students', () => {
    renderCard(makeTutor({ acceptingStudents: false }));
    expect(screen.getByText('Not currently available')).toBeInTheDocument();
  });

  it('renders a verification badge only when one is genuinely present', () => {
    renderCard(makeTutor({ publicVerificationBadges: ['qualification_checked'] }));
    expect(screen.getByText('Qualification checked')).toBeInTheDocument();
  });

  it('renders no verification badge when none are present, rather than a generic "Verified" claim', () => {
    renderCard(makeTutor({ publicVerificationBadges: [] }));
    expect(screen.queryByText(/checked/i)).not.toBeInTheDocument();
    expect(screen.queryByText(/verified/i)).not.toBeInTheDocument();
  });

  it('never renders private/internal fields such as a DBS-pending state', () => {
    renderCard(makeTutor());
    expect(screen.queryByText(/pending/i)).not.toBeInTheDocument();
    expect(screen.queryByText(/failed/i)).not.toBeInTheDocument();
  });

  it('shows an "Example profile" tag only when isExample is true', () => {
    const { rerender } = renderCard(makeTutor(), true);
    expect(screen.getByText('Example profile')).toBeInTheDocument();

    rerender(
      <MemoryRouter>
        <TutorCard tutor={makeTutor()} isExample={false} />
      </MemoryRouter>,
    );
    expect(screen.queryByText('Example profile')).not.toBeInTheDocument();
  });
});
