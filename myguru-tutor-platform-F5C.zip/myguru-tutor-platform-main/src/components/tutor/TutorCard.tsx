import { Link } from 'react-router-dom';
import type { TutorProfile } from '../../domain/models/types';
import { VerificationBadge, Tag } from '../ui/Badge';
import { useAvailabilityLabel } from '../../hooks/useAvailabilityLabel';
import './TutorCard.css';

/** Deterministic placeholder illustration gradient — no real photography in Phase D (§10, §38). */
function TutorPhotoPlaceholder({ seed }: { seed: string }) {
  // Semantic palette variation, not literal brand hex — each pair is drawn
  // from the token system so a rebrand/re-palette changes these too.
  const gradients = [
    ['var(--color-gold-300)', 'var(--color-ink-700)'],
    ['var(--color-gold-600)', 'var(--color-ink-900)'],
    ['var(--color-gold-300)', 'var(--color-ink-500)'],
  ];
  const idx = seed.charCodeAt(0) % gradients.length;
  const [from, to] = gradients[idx];
  const gradId = `tutor-photo-${seed}`;
  return (
    <svg
      className="tutor-photo-svg"
      viewBox="0 0 200 200"
      preserveAspectRatio="xMidYMax slice"
      role="img"
      aria-label="Illustrated tutor placeholder — not a real photograph"
    >
      <rect width="200" height="200" fill="var(--color-paper-50)" />
      <path
        d="M100 40c-24 0-38 18-38 40 0 16 7 27 15 33-28 9-52 27-58 60h162c-6-33-30-51-58-60 8-6 15-17 15-33 0-22-13-40-38-40z"
        fill={`url(#${gradId})`}
      />
      <defs>
        <linearGradient id={gradId} x1="40" y1="40" x2="160" y2="200">
          <stop stopColor={from} />
          <stop offset="1" stopColor={to} />
        </linearGradient>
      </defs>
    </svg>
  );
}

export function TutorCard({ tutor, isExample = false }: { tutor: TutorProfile; isExample?: boolean }) {
  const availabilityLabel = useAvailabilityLabel(tutor.acceptingStudents);

  return (
    <article className="tutor-card">
      <div className="tutor-photo">
        {isExample && <span className="example-tag">Example profile</span>}
        <div className="avail-dot">
          <i data-available={tutor.acceptingStudents} />
          <span>{availabilityLabel}</span>
        </div>
        <TutorPhotoPlaceholder seed={tutor.id} />
      </div>
      <div className="tutor-body">
        <div>
          <div className="tutor-name">{tutor.publicDisplayName}</div>
          {tutor.positioningStatement && <p className="tutor-statement">&ldquo;{tutor.positioningStatement}&rdquo;</p>}
        </div>
        <div className="tutor-tags">
          {tutor.subjects.map((s) => (
            <Tag key={s.id}>{s.name}</Tag>
          ))}
          <Tag>{tutor.educationLevels.map((l) => l.name).join(' · ')}</Tag>
        </div>
        {tutor.publicVerificationBadges.length > 0 && (
          <div className="verify-row">
            {/* Only ever the first badge is shown inline on the card to keep it uncluttered; full list on the profile page. */}
            <VerificationBadge type={tutor.publicVerificationBadges[0]} />
          </div>
        )}
        <div className="tutor-footer">
          <Link to={`/tutors/${tutor.slug}`} className="btn-text">
            View profile <span aria-hidden="true">→</span>
          </Link>
        </div>
      </div>
    </article>
  );
}
