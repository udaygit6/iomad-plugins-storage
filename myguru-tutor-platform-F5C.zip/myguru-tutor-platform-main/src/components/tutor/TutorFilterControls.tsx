import type { Subject, EducationLevel, TutorFilters, EducationLevelSlug } from '../../domain/models/types';
import './TutorFilterControls.css';

interface TutorFilterControlsProps {
  subjects: Subject[];
  levels: EducationLevel[];
  filters: TutorFilters;
  onChange: (filters: TutorFilters) => void;
  idPrefix: string;
}

export function TutorFilterControls({ subjects, levels, filters, onChange, idPrefix }: TutorFilterControlsProps) {
  const activeCount = [filters.subjectSlug, filters.educationLevelSlug, filters.acceptingStudentsOnly].filter(Boolean).length;

  return (
    <div className="filter-controls">
      <div className="form-field">
        <label htmlFor={`${idPrefix}-subject`}>Subject</label>
        <select
          id={`${idPrefix}-subject`}
          className="form-select"
          value={filters.subjectSlug ?? ''}
          onChange={(e) => onChange({ ...filters, subjectSlug: e.target.value || undefined })}
        >
          <option value="">All subjects</option>
          {subjects.map((s) => (
            <option key={s.id} value={s.slug}>
              {s.name}
            </option>
          ))}
        </select>
      </div>

      <div className="form-field">
        <label htmlFor={`${idPrefix}-level`}>Education level</label>
        <select
          id={`${idPrefix}-level`}
          className="form-select"
          value={filters.educationLevelSlug ?? ''}
          onChange={(e) => onChange({ ...filters, educationLevelSlug: (e.target.value || undefined) as EducationLevelSlug | undefined })}
        >
          <option value="">All levels</option>
          {levels.map((l) => (
            <option key={l.id} value={l.slug}>
              {l.name}
            </option>
          ))}
        </select>
      </div>

      <div className="form-field">
        <label className="checkbox-field">
          <input
            type="checkbox"
            checked={filters.acceptingStudentsOnly ?? false}
            onChange={(e) => onChange({ ...filters, acceptingStudentsOnly: e.target.checked || undefined })}
          />
          Only show tutors currently taking students
        </label>
      </div>

      {activeCount > 0 && (
        <button type="button" className="btn-text" onClick={() => onChange({})}>
          Clear filters
        </button>
      )}
    </div>
  );
}
