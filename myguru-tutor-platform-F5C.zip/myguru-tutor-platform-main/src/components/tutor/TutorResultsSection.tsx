import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { TutorCard } from './TutorCard';
import { TutorCardSkeleton } from './TutorCardSkeleton';
import { EmptyState } from '../ui/EmptyState';
import { ErrorState } from '../ui/ErrorState';
import { tutorDiscoveryService } from '../../services/tutors/TutorDiscoveryService';
import type { TutorFilters, TutorProfile } from '../../domain/models/types';
import './TutorResultsSection.css';

type LoadState = { status: 'loading' } | { status: 'error' } | { status: 'ready'; tutors: TutorProfile[] };

export function TutorResultsSection({ filters }: { filters: TutorFilters }) {
  const [state, setState] = useState<LoadState>({ status: 'loading' });
  const [reloadToken, setReloadToken] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setState({ status: 'loading' });
    tutorDiscoveryService
      .list(filters)
      .then((tutors) => {
        if (!cancelled) setState({ status: 'ready', tutors });
      })
      .catch(() => {
        if (!cancelled) setState({ status: 'error' });
      });
    return () => {
      cancelled = true;
    };
    // filters is a plain object rebuilt per render by callers from URL
    // params — stringify so the effect only re-runs on genuine changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [JSON.stringify(filters), reloadToken]);

  if (state.status === 'loading') {
    return (
      <div className="tutor-grid" aria-busy="true" aria-live="polite">
        {Array.from({ length: 6 }).map((_, i) => (
          <TutorCardSkeleton key={i} />
        ))}
      </div>
    );
  }

  if (state.status === 'error') {
    return <ErrorState message="We couldn't load tutors just now." onRetry={() => setReloadToken((t) => t + 1)} />;
  }

  if (state.tutors.length === 0) {
    return (
      <EmptyState
        title="No tutors match those filters"
        message="Try widening the filters, or get matched instead and we'll do the searching."
        action={
          <Link to="/find-a-tutor" className="btn btn-primary btn-sm">
            Get matched instead
          </Link>
        }
      />
    );
  }

  return (
    <>
      <p className="results-count" aria-live="polite">
        {state.tutors.length} {state.tutors.length === 1 ? 'tutor' : 'tutors'} found
      </p>
      <div className="tutor-grid">
        {state.tutors.map((t) => (
          <TutorCard key={t.id} tutor={t} isExample />
        ))}
      </div>
    </>
  );
}
