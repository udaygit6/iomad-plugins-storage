import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Accordion } from './Accordion';

const items = [
  { id: 'a', question: 'Question A', answer: 'Answer A' },
  { id: 'b', question: 'Question B', answer: 'Answer B' },
];

describe('Accordion', () => {
  it('opens the item specified by defaultOpenId and marks it aria-expanded', () => {
    render(<Accordion items={items} defaultOpenId="a" />);
    expect(screen.getByRole('button', { name: /Question A/ })).toHaveAttribute('aria-expanded', 'true');
    expect(screen.getByRole('button', { name: /Question B/ })).toHaveAttribute('aria-expanded', 'false');
  });

  it('toggles a panel open/closed on click, and closes the previously open one', async () => {
    const user = userEvent.setup();
    render(<Accordion items={items} defaultOpenId="a" />);

    await user.click(screen.getByRole('button', { name: /Question B/ }));

    expect(screen.getByRole('button', { name: /Question B/ })).toHaveAttribute('aria-expanded', 'true');
    expect(screen.getByRole('button', { name: /Question A/ })).toHaveAttribute('aria-expanded', 'false');
  });

  it('each trigger has aria-controls pointing at a real panel element', () => {
    render(<Accordion items={items} defaultOpenId="a" />);
    const trigger = screen.getByRole('button', { name: /Question A/ });
    const panelId = trigger.getAttribute('aria-controls');
    expect(panelId).toBeTruthy();
    expect(document.getElementById(panelId!)).toBeInTheDocument();
  });
});
