import type { ReactNode } from 'react';
import type { PublicVerificationBadge } from '../../domain/models/types';
import './Badge.css';

export function Tag({ children }: { children: ReactNode }) {
  return <span className="tag">{children}</span>;
}

const VERIFICATION_LABELS: Record<PublicVerificationBadge, string> = {
  qualification_checked: 'Qualification checked',
  identity_checked: 'Identity checked',
  dbs_checked: 'DBS checked',
};

/**
 * Renders ONLY genuinely-approved public verification badges. There is no
 * "pending" or "failed" variant here by design (Phase D §15) — those states
 * belong exclusively to the private admin/application view.
 */
export function VerificationBadge({ type }: { type: PublicVerificationBadge }) {
  return (
    <span className="verify-badge">
      <svg width="11" height="11" viewBox="0 0 11 11" fill="none" aria-hidden="true">
        <path d="M2 5.5l2.2 2.2L9 3" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      {VERIFICATION_LABELS[type]}
    </span>
  );
}
