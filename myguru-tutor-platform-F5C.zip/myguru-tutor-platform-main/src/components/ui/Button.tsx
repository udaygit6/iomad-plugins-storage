import { forwardRef } from 'react';
import type { ButtonHTMLAttributes, AnchorHTMLAttributes, ReactNode, Ref } from 'react';
import './Button.css';

type Variant = 'primary' | 'outline' | 'text';
type Size = 'md' | 'sm';

interface CommonProps {
  variant?: Variant;
  size?: Size;
  children: ReactNode;
  className?: string;
}

type ButtonAsButton = CommonProps &
  Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'className'> & { as?: 'button'; loading?: boolean };
type ButtonAsAnchor = CommonProps & Omit<AnchorHTMLAttributes<HTMLAnchorElement>, 'className'> & { as: 'a' };

type ButtonProps = ButtonAsButton | ButtonAsAnchor;

function classes(variant: Variant, size: Size, className?: string) {
  return ['btn', `btn-${variant}`, size === 'sm' ? 'btn-sm' : '', className].filter(Boolean).join(' ');
}

/** Polymorphic Button: renders a <button> by default, or an <a> when `as="a"`. */
export const Button = forwardRef<HTMLButtonElement | HTMLAnchorElement, ButtonProps>((props, ref) => {
  const { variant = 'primary', size = 'md', children, className } = props;

  if (props.as === 'a') {
    const { as: _as, variant: _v, size: _s, children: _c, className: _cn, ...anchorProps } = props;
    return (
      <a ref={ref as Ref<HTMLAnchorElement>} className={classes(variant, size, className)} {...anchorProps}>
        {children}
      </a>
    );
  }

  const { as: _as, variant: _v, size: _s, children: _c, className: _cn, loading, ...buttonProps } = props;
  return (
    <button
      ref={ref as Ref<HTMLButtonElement>}
      className={classes(variant, size, className)}
      data-loading={loading ? 'true' : undefined}
      aria-busy={loading || undefined}
      {...buttonProps}
    >
      {children}
    </button>
  );
});
Button.displayName = 'Button';
