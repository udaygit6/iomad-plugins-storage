import type { ReactNode } from 'react';
import './States.css';

export function EmptyState({ title, message, action }: { title: string; message: string; action?: ReactNode }) {
  return (
    <div className="empty-state">
      <svg width="36" height="36" viewBox="0 0 36 36" fill="none" aria-hidden="true">
        <circle cx="15" cy="15" r="10" stroke="currentColor" strokeWidth="1.6" />
        <path d="M22 22l8 8" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
      </svg>
      <h3>{title}</h3>
      <p>{message}</p>
      {action}
    </div>
  );
}
