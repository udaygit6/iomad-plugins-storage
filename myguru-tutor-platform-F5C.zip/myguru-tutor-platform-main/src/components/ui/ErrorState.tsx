import './States.css';

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="error-state" role="alert">
      <svg width="28" height="28" viewBox="0 0 28 28" fill="none" aria-hidden="true">
        <circle cx="14" cy="14" r="11" stroke="currentColor" strokeWidth="1.6" />
        <path d="M14 8v7M14 19h.01" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
      </svg>
      <p>{message}</p>
      {onRetry && (
        <button className="btn-text" onClick={onRetry}>
          Try again
        </button>
      )}
    </div>
  );
}
