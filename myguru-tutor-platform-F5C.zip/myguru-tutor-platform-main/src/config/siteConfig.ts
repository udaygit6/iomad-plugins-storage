/**
 * Central brand/site configuration.
 *
 * MyGuru is a temporary working brand (approved Phase C Rev 2 / Phase C.5).
 * Nothing outside this file should hard-code the brand name, tagline, or
 * contact details — components read from `siteConfig` so a rebrand is a
 * change in exactly one place.
 */
export interface SiteConfig {
  brandName: string;
  brandNameParts: { light: string; accent: string }; // for the two-tone wordmark, e.g. "My" + "Guru"
  tagline: string;
  isBrandFinal: boolean;
  favicon: string;
  contact: {
    email?: string;
    phone?: string;
  };
  social: {
    // Populated when real accounts are supplied. Left empty deliberately —
    // do not fabricate social presence.
    facebook?: string;
    instagram?: string;
    linkedin?: string;
  };
  legal: {
    // Populated once real company information is confirmed. Do not display
    // "Registered in England & Wales" or similar until this is filled in.
    companyName?: string;
    companyNumber?: string;
    registeredAddress?: string;
  };
}

export const siteConfig: SiteConfig = {
  brandName: 'MyGuru',
  brandNameParts: { light: 'My', accent: 'Guru' },
  tagline: 'The right tutor. The right fit.',
  isBrandFinal: false,
  favicon: '/favicon.svg',
  contact: {
    // email: undefined until a real inbox is confirmed
  },
  social: {},
  legal: {},
};
