/**
 * Domain models — the frontend contract for tutors, subjects, matching, and
 * applications. These types are provider-agnostic: nothing here references
 * Supabase, Iomad, or Netlify. Repository implementations map onto these
 * shapes, not the other way round.
 */

// ---------------------------------------------------------------------------
// Reference / taxonomy data (fixture-backed for Phase D, DB-backed later)
// ---------------------------------------------------------------------------

export interface Subject {
  id: string;
  slug: string;
  name: string;
  /** Short description for subject hub/detail pages. */
  description?: string;
}

export type EducationLevelSlug = 'ks1' | 'ks2' | 'ks3' | 'gcse' | 'a-level';

export interface EducationLevel {
  id: string;
  slug: EducationLevelSlug;
  name: string;
  stageHeadline: string; // e.g. "Build strong foundations"
  stageDescription: string;
}

// ---------------------------------------------------------------------------
// Public tutor discovery contract
// ---------------------------------------------------------------------------

/**
 * A verification badge is only ever present in this array if the
 * corresponding check has genuinely been completed and approved for public
 * display. There is no "pending" or "failed" state in this public-facing
 * type — those states exist only in the private admin/application model.
 */
export type PublicVerificationBadge =
  | 'qualification_checked'
  | 'identity_checked'
  | 'dbs_checked';

export interface TutorPricing {
  // Intentionally minimal and optional. Pricing is unresolved (Phase B/D) —
  // this type exists so the UI can render pricing later without a redesign,
  // not because pricing is enabled today.
  hourlyRateGBP?: number;
  note?: string;
}

export type TutorProfileStatus = 'draft' | 'approved' | 'published' | 'unpublished';

/**
 * The PUBLIC tutor contract. Anything that must never be shown publicly
 * (application notes, internal verification detail, documents, home
 * address, personal email/phone, DBS-pending or failed-check state, admin
 * notes) deliberately has no field here — see TutorApplication for the
 * private counterpart.
 */
export interface TutorProfile {
  id: string;
  slug: string;
  /** MVP display format: "First name + last initial", e.g. "Sarah M." */
  publicDisplayName: string;
  headline: string;
  positioningStatement?: string; // short italic line used on cards
  bio: string;
  teachingApproach: string;
  photoUrl?: string;
  subjects: Subject[];
  educationLevels: EducationLevel[];
  qualificationsSummary: string[];
  experienceSummary: string;
  languages: string[];
  /** Derived label, never hard-coded in components (see hooks/useAvailabilityLabel). */
  acceptingStudents: boolean;
  publicVerificationBadges: PublicVerificationBadge[];
  pricing?: TutorPricing;
  status: TutorProfileStatus;
}

export interface TutorFilters {
  subjectSlug?: string;
  educationLevelSlug?: EducationLevelSlug;
  acceptingStudentsOnly?: boolean;
}

// ---------------------------------------------------------------------------
// Tutor application (private) — distinct from the public TutorProfile
// ---------------------------------------------------------------------------

export type TutorApplicationStatus =
  | 'draft'
  | 'submitted'
  | 'under_review'
  | 'more_information_required'
  | 'approved'
  | 'rejected';

export interface TutorApplication {
  id: string;
  status: TutorApplicationStatus;
  fullName: string; // private — never shown publicly
  email: string; // private
  phone?: string; // private
  aboutYou: string;
  teachingExperience: string;
  education: string;
  qualifications: string[];
  subjectSlugs: string[];
  educationLevelSlugs: EducationLevelSlug[];
  teachingApproach: string;
  availabilityNotes: string;
  supportingDocumentsNote?: string; // placeholder — no real upload in Phase D
  submittedAt?: string;
  reviewedAt?: string;
  adminNotes?: string; // private, admin-only, never synced anywhere
}

// ---------------------------------------------------------------------------
// Parent / Student — kept as separate entities (Phase C.5 Correction 1)
// ---------------------------------------------------------------------------

export interface Parent {
  id: string;
  name: string;
  email: string;
  phone?: string;
}

export interface Student {
  id: string;
  parentId: string;
  firstName: string;
  yearGroupLabel: string; // e.g. "Year 9" — free-form label, not a strict enum
  // Deliberately no dateOfBirth, schoolName, or address field — Phase B §12 /
  // Phase D §29 data-minimisation instruction.
}

// ---------------------------------------------------------------------------
// Matching request
// ---------------------------------------------------------------------------

export type MatchingRequestStatus =
  | 'submitted'
  | 'reviewing'
  | 'matched'
  | 'contacted'
  | 'closed';

export type HelpNeededReason =
  | 'catching_up'
  | 'exam_preparation'
  | 'confidence'
  | 'homework_support'
  | 'specific_topic'
  | 'other';

export interface MatchingRequest {
  id: string;
  status: MatchingRequestStatus;
  parent: Pick<Parent, 'name' | 'email' | 'phone'>;
  student: Pick<Student, 'firstName' | 'yearGroupLabel'>;
  subjectSlug: string;
  helpNeeded: HelpNeededReason;
  goalsNote?: string;
  availabilityNote: string;
  submittedAt: string;
}

// ---------------------------------------------------------------------------
// General enquiry
// ---------------------------------------------------------------------------

export type EnquiryStatus = 'new' | 'in_progress' | 'resolved';

export interface Enquiry {
  id: string;
  status: EnquiryStatus;
  name: string;
  email: string;
  message: string;
  relatedTutorSlug?: string; // set when raised from a tutor profile ("Request this tutor")
  submittedAt: string;
}
