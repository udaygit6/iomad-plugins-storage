import { describe, it, expect } from 'vitest';
import { deriveDisplayName, slugifyBase, makeUniqueSlug } from './tutorProfileNaming';

describe('deriveDisplayName', () => {
  it('produces "First name + last initial" for a two-part name', () => {
    expect(deriveDisplayName('Sarah Example')).toBe('Sarah E.');
  });
  it('uses the last word\'s initial for a multi-part name', () => {
    expect(deriveDisplayName('Sarah Jane Example')).toBe('Sarah E.');
  });
  it('never exposes the applicant\'s full legal surname', () => {
    const result = deriveDisplayName('Priya Patel');
    expect(result).not.toContain('Patel');
    expect(result).toBe('Priya P.');
  });
  it('handles a single-word name gracefully', () => {
    expect(deriveDisplayName('Madonna')).toBe('Madonna');
  });
  it('trims surrounding whitespace and collapses internal spaces', () => {
    expect(deriveDisplayName('  Sarah   Example  ')).toBe('Sarah E.');
  });
});

describe('slugifyBase', () => {
  it('lowercases and hyphenates', () => {
    expect(slugifyBase('Sarah E.')).toBe('sarah-e');
  });
  it('trims leading/trailing hyphens', () => {
    expect(slugifyBase('--Sarah--')).toBe('sarah');
  });
});

describe('makeUniqueSlug', () => {
  it('appends a suffix to the base', () => {
    const slug = makeUniqueSlug('sarah-e');
    expect(slug.startsWith('sarah-e-')).toBe(true);
  });
  it('produces different slugs on repeated calls (collision avoidance)', () => {
    const a = makeUniqueSlug('sarah-e');
    const b = makeUniqueSlug('sarah-e');
    expect(a).not.toBe(b);
  });
});
