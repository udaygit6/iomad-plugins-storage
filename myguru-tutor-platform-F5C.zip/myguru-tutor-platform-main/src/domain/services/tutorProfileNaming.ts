/**
 * Derives the "First name + last initial" public display name convention
 * (e.g. "Sarah M.") from an applicant's full name. Mirrors the logic inside
 * the create_tutor_profile_from_application Postgres function
 * (supabase/migrations/0014) exactly — kept here too so the Mock
 * repository (and tests) don't need a live database to exercise the same
 * behaviour.
 */
export function deriveDisplayName(fullName: string): string {
  const parts = fullName.trim().split(/\s+/).filter(Boolean);
  if (parts.length <= 1) return parts[0] ?? 'Tutor';
  return `${parts[0]} ${parts[parts.length - 1][0]}.`;
}

/** A URL-safe slug base from a display name, e.g. "Sarah M." -> "sarah-m". */
export function slugifyBase(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-+|-+$)/g, '');
}

/** Appends a short random suffix so slugs don't collide across profiles sharing a display name. */
export function makeUniqueSlug(base: string): string {
  const suffix = Math.random().toString(36).slice(2, 8);
  return `${base}-${suffix}`;
}
