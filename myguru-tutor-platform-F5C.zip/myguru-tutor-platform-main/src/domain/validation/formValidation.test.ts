import { describe, it, expect } from 'vitest';
import { required, requiredArray, validEmail, runValidators } from './formValidation';

describe('required', () => {
  it('fails on empty/whitespace-only strings', () => {
    expect(required('')).not.toBeNull();
    expect(required('   ')).not.toBeNull();
    expect(required(undefined)).not.toBeNull();
  });
  it('passes on a non-empty string', () => {
    expect(required('Sarah')).toBeNull();
  });
});

describe('requiredArray', () => {
  it('fails on an empty array', () => {
    expect(requiredArray([])).not.toBeNull();
  });
  it('passes when at least one item is present', () => {
    expect(requiredArray(['maths'])).toBeNull();
  });
});

describe('validEmail', () => {
  it('rejects an obviously invalid email', () => {
    expect(validEmail('not-an-email')).not.toBeNull();
  });
  it('rejects an empty value', () => {
    expect(validEmail('')).not.toBeNull();
  });
  it('accepts a plausible email', () => {
    expect(validEmail('parent@example.com')).toBeNull();
  });
});

describe('runValidators', () => {
  it('only includes fields that actually failed', () => {
    const errors = runValidators({
      name: () => required(''),
      email: () => validEmail('parent@example.com'),
    });
    expect(Object.keys(errors)).toEqual(['name']);
  });

  it('returns an empty object when everything passes', () => {
    const errors = runValidators({ name: () => required('Sarah') });
    expect(errors).toEqual({});
  });
});
