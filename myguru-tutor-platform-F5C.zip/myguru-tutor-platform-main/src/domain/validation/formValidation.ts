export type FieldErrors = Record<string, string>;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function required(value: string | undefined | null, message = 'This field is required.'): string | null {
  return value && value.trim().length > 0 ? null : message;
}

export function requiredArray(value: unknown[] | undefined | null, message = 'Select at least one option.'): string | null {
  return value && value.length > 0 ? null : message;
}

export function validEmail(value: string | undefined | null, message = 'Enter a valid email address.'): string | null {
  if (!value) return message;
  return EMAIL_RE.test(value.trim()) ? null : message;
}

/** Runs a set of { field: validator } pairs and returns only the failures. */
export function runValidators(validators: Record<string, () => string | null>): FieldErrors {
  const errors: FieldErrors = {};
  for (const [field, validate] of Object.entries(validators)) {
    const message = validate();
    if (message) errors[field] = message;
  }
  return errors;
}
