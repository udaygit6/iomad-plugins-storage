import { useEffect, useState, useCallback } from 'react';
import type { ReactNode } from 'react';
import { adminAuthService } from '../../services/admin/AdminAuthService';
import { AdminAuthContext, type AdminAuthStatus } from './useAdminAuth';

/**
 * Resolves the full status in one place: not_configured (Supabase env vars
 * missing — a distinct safe state, not the same as "logged out") ->
 * unauthenticated (no session) -> unauthorized (session exists, no
 * admin_profiles row) -> authorized. Never flashes protected content while
 * this resolves - consumers gate rendering on status === 'loading'.
 */
async function resolveStatus(): Promise<{ status: AdminAuthStatus; email: string | null }> {
  if (!adminAuthService.isConfigured()) {
    return { status: 'not_configured', email: null };
  }
  const user = await adminAuthService.getCurrentUser();
  if (!user) {
    return { status: 'unauthenticated', email: null };
  }
  const isAdmin = await adminAuthService.isAdmin(user.id);
  return { status: isAdmin ? 'authorized' : 'unauthorized', email: user.email };
}

export function AdminAuthProvider({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<AdminAuthStatus>('loading');
  const [email, setEmail] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    const result = await resolveStatus();
    setStatus(result.status);
    setEmail(result.email);
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const result = await resolveStatus();
      if (!cancelled) {
        setStatus(result.status);
        setEmail(result.email);
      }
    })();

    // Re-resolve on any auth event (sign-in, sign-out, token refresh,
    // expiry) rather than relying on a one-time check at mount.
    const unsubscribe = adminAuthService.onAuthStateChange(() => {
      if (!cancelled) refresh();
    });

    return () => {
      cancelled = true;
      unsubscribe();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const signIn = useCallback(async (emailInput: string, password: string) => {
    const result = await adminAuthService.signInWithPassword(emailInput, password);
    if (result.ok) await refresh();
    return result;
  }, [refresh]);

  const signOut = useCallback(async () => {
    await adminAuthService.signOut();
    await refresh();
  }, [refresh]);

  return <AdminAuthContext.Provider value={{ status, email, signIn, signOut }}>{children}</AdminAuthContext.Provider>;
}
