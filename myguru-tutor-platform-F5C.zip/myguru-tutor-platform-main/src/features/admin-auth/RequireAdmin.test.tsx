import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import { createMemoryRouter, RouterProvider } from 'react-router-dom';
import { RequireAdmin } from './RequireAdmin';
import * as useAdminAuthModule from './useAdminAuth';
import type { AdminAuthState } from './useAdminAuth';

function mockAuthState(overrides: Partial<AdminAuthState>) {
  vi.spyOn(useAdminAuthModule, 'useAdminAuth').mockReturnValue({
    status: 'loading',
    email: null,
    signIn: vi.fn(),
    signOut: vi.fn(),
    ...overrides,
  });
}

function renderGuarded() {
  const router = createMemoryRouter(
    [
      { path: '/admin/login', element: <div>Login page</div> },
      {
        element: <RequireAdmin />,
        children: [{ path: '/admin', element: <div>Protected admin content</div> }],
      },
    ],
    { initialEntries: ['/admin'] },
  );
  return render(<RouterProvider router={router} />);
}

describe('RequireAdmin', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('shows a neutral loading state and never renders protected content while resolving', () => {
    mockAuthState({ status: 'loading' });
    renderGuarded();
    expect(screen.getByText('Checking access…')).toBeInTheDocument();
    expect(screen.queryByText('Protected admin content')).not.toBeInTheDocument();
  });

  it('redirects to /admin/login when unauthenticated', () => {
    mockAuthState({ status: 'unauthenticated' });
    renderGuarded();
    expect(screen.getByText('Login page')).toBeInTheDocument();
    expect(screen.queryByText('Protected admin content')).not.toBeInTheDocument();
  });

  it('denies access with a safe message when authenticated but not an admin', () => {
    mockAuthState({ status: 'unauthorized', email: 'notadmin@example.com' });
    renderGuarded();
    expect(screen.getByText('Not authorized')).toBeInTheDocument();
    expect(screen.getByText(/does not have admin access/)).toBeInTheDocument();
    expect(screen.queryByText('Protected admin content')).not.toBeInTheDocument();
  });

  it('shows a distinct safe state when Supabase is not configured', () => {
    mockAuthState({ status: 'not_configured' });
    renderGuarded();
    expect(screen.getByText('Admin is not available')).toBeInTheDocument();
    expect(screen.queryByText('Protected admin content')).not.toBeInTheDocument();
  });

  it('renders protected content only when authorized', () => {
    mockAuthState({ status: 'authorized', email: 'admin@example.com' });
    renderGuarded();
    expect(screen.getByText('Protected admin content')).toBeInTheDocument();
  });

  it('offers a logout action on the unauthorized screen', async () => {
    const signOut = vi.fn();
    mockAuthState({ status: 'unauthorized', signOut });
    renderGuarded();
    screen.getByRole('button', { name: /log out/i }).click();
    expect(signOut).toHaveBeenCalled();
  });
});
