import { Navigate, Outlet } from 'react-router-dom';
import { useAdminAuth } from './useAdminAuth';
import './RequireAdmin.css';

export function RequireAdmin() {
  const { status, email, signOut } = useAdminAuth();

  if (status === 'loading') {
    // Deliberately blank/neutral rather than any admin content — Phase E3
    // §12: never flash protected content before auth state resolves.
    return (
      <div className="admin-auth-state container" aria-busy="true" aria-live="polite">
        <p>Checking access…</p>
      </div>
    );
  }

  if (status === 'not_configured') {
    return (
      <div className="admin-auth-state container">
        <h1>Admin is not available</h1>
        <p>Supabase is not configured in this environment. Try again once staging configuration is set.</p>
      </div>
    );
  }

  if (status === 'unauthenticated') {
    return <Navigate to="/admin/login" replace />;
  }

  if (status === 'unauthorized') {
    return (
      <div className="admin-auth-state container">
        <h1>Not authorized</h1>
        <p>
          {email ? `${email} is` : 'This account is'} signed in but does not have admin access on this platform.
        </p>
        <button className="btn btn-outline" onClick={() => signOut()}>
          Log out
        </button>
      </div>
    );
  }

  return <Outlet />;
}
