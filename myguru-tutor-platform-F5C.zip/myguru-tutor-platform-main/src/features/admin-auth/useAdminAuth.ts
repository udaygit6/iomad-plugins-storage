import { createContext, useContext } from 'react';

export type AdminAuthStatus = 'loading' | 'not_configured' | 'unauthenticated' | 'unauthorized' | 'authorized';

export interface AdminAuthState {
  status: AdminAuthStatus;
  email: string | null;
  signIn: (email: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  signOut: () => Promise<void>;
}

export const AdminAuthContext = createContext<AdminAuthState | null>(null);

export function useAdminAuth(): AdminAuthState {
  const ctx = useContext(AdminAuthContext);
  if (!ctx) throw new Error('useAdminAuth must be used within an AdminAuthProvider');
  return ctx;
}
