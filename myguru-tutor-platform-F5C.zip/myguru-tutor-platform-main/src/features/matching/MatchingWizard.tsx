import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useWizard, type WizardStep } from '../../hooks/useWizard';
import { useAntiAbuseFields } from '../../hooks/useAntiAbuseFields';
import { WizardShell } from '../../components/forms/WizardShell';
import { HoneypotField } from '../../components/forms/HoneypotField';
import { subjectService } from '../../services/subjects/SubjectService';
import { matchingService, EMPTY_MATCHING_FORM, type MatchingFormData } from '../../services/matching/MatchingService';
import type { Subject } from '../../domain/models/types';
import type { FieldErrors } from '../../domain/validation/formValidation';
import { YEAR_GROUP_OPTIONS, HELP_OPTIONS, HELP_LABELS } from './matchingOptions';
import './MatchingWizard.css';

const STEPS: WizardStep[] = [
  { id: 'student', label: "Tell us about the student" },
  { id: 'subject', label: 'Which subject?' },
  { id: 'help', label: 'What kind of help is needed?' },
  { id: 'goals', label: 'Anything else that would help us match well?' },
  { id: 'availability', label: 'When generally works?' },
  { id: 'contact', label: 'How should we reach you?' },
  { id: 'review', label: 'Review and submit' },
];

export function MatchingWizard() {
  const wizard = useWizard(STEPS);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [data, setData] = useState<MatchingFormData>(EMPTY_MATCHING_FORM);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'submitting' | 'submitted' | 'error'>('idle');
  const { meta, honeypotValue, setHoneypotValue } = useAntiAbuseFields();

  useEffect(() => {
    subjectService.listSubjects().then(setSubjects);
  }, []);

  function update<K extends keyof MatchingFormData>(key: K, value: MatchingFormData[K]) {
    setData((d) => ({ ...d, [key]: value }));
    if (errors[key as string]) setErrors((e) => ({ ...e, [key]: '' }));
  }

  function handleNext() {
    const stepErrors = matchingService.validateStep(wizard.currentStep.id, data);
    setErrors(stepErrors);
    if (Object.keys(stepErrors).length === 0) wizard.goNext();
  }

  async function handleSubmit() {
    setSubmitStatus('submitting');
    try {
      await matchingService.submit(data, meta);
      setSubmitStatus('submitted');
    } catch {
      setSubmitStatus('error');
    }
  }

  const subjectName = subjects.find((s) => s.slug === data.subjectSlug)?.name ?? data.subjectSlug;

  if (submitStatus === 'submitted') {
    return (
      <div className="container matching-page">
        <div className="wizard-shell">
          <div className="confirmation-state">
            <div className="confirmation-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path d="M4 12l6 6L20 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <h2>Request received</h2>
            <p style={{ color: 'var(--color-text-muted)', marginTop: 'var(--space-3)', maxWidth: '44ch', marginLeft: 'auto', marginRight: 'auto' }}>
              We&rsquo;ll review what you&rsquo;ve told us and be in touch by email about a suitable tutor. In the meantime you
              can also browse tutors yourself.
            </p>
            <div style={{ display: 'flex', gap: 'var(--space-4)', justifyContent: 'center', marginTop: 'var(--space-6)' }}>
              <Link to="/tutors" className="btn btn-outline">
                Browse tutors
              </Link>
              <Link to="/" className="btn btn-primary">
                Back to homepage
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container matching-page">
      <HoneypotField value={honeypotValue} onChange={setHoneypotValue} />
      <WizardShell
        title="Find My Tutor"
        stepLabel={wizard.currentStep.label}
        stepNumber={wizard.currentIndex + 1}
        totalSteps={STEPS.length}
        progressPercent={wizard.progressPercent}
        footer={
          <>
            <button type="button" className="btn-text" onClick={wizard.goBack} disabled={wizard.isFirst} style={{ visibility: wizard.isFirst ? 'hidden' : 'visible' }}>
              ← Back
            </button>
            {wizard.isLast ? (
              <button type="button" className="btn btn-primary" onClick={handleSubmit} disabled={submitStatus === 'submitting'} data-loading={submitStatus === 'submitting' ? 'true' : undefined}>
                {submitStatus === 'submitting' ? 'Submitting…' : 'Submit request'}
              </button>
            ) : (
              <button type="button" className="btn btn-primary" onClick={handleNext}>
                Continue
              </button>
            )}
          </>
        }
      >
        {wizard.currentStep.id === 'student' && (
          <>
            <div className="form-field">
              <label htmlFor="m-student-name">Student&rsquo;s first name</label>
              <input
                id="m-student-name"
                className="form-input"
                value={data.studentFirstName}
                aria-invalid={!!errors.studentFirstName}
                onChange={(e) => update('studentFirstName', e.target.value)}
              />
              {errors.studentFirstName && <p className="form-error">{errors.studentFirstName}</p>}
            </div>
            <div className="form-field">
              <label htmlFor="m-year-group">Year group / stage</label>
              <select
                id="m-year-group"
                className="form-select"
                value={data.yearGroupLabel}
                aria-invalid={!!errors.yearGroupLabel}
                onChange={(e) => update('yearGroupLabel', e.target.value)}
              >
                <option value="">Select a year group</option>
                {YEAR_GROUP_OPTIONS.map((y) => (
                  <option key={y} value={y}>
                    {y}
                  </option>
                ))}
              </select>
              {errors.yearGroupLabel && <p className="form-error">{errors.yearGroupLabel}</p>}
            </div>
          </>
        )}

        {wizard.currentStep.id === 'subject' && (
          <fieldset className="form-field" style={{ border: 'none', padding: 0, margin: 0 }}>
            <legend>Subject</legend>
            <div className="option-grid">
              {subjects.map((s) => (
                <label key={s.id} className="option-card">
                  <input
                    type="radio"
                    name="subject"
                    value={s.slug}
                    checked={data.subjectSlug === s.slug}
                    onChange={() => update('subjectSlug', s.slug)}
                  />
                  <span className="option-card-label">{s.name}</span>
                </label>
              ))}
            </div>
            {errors.subjectSlug && <p className="form-error">{errors.subjectSlug}</p>}
          </fieldset>
        )}

        {wizard.currentStep.id === 'help' && (
          <fieldset className="form-field" style={{ border: 'none', padding: 0, margin: 0 }}>
            <legend>What kind of help is needed?</legend>
            <div className="option-grid">
              {HELP_OPTIONS.map((opt) => (
                <label key={opt.value} className="option-card">
                  <input
                    type="radio"
                    name="help"
                    value={opt.value}
                    checked={data.helpNeeded === opt.value}
                    onChange={() => update('helpNeeded', opt.value)}
                  />
                  <span className="option-card-label">{opt.label}</span>
                </label>
              ))}
            </div>
            {errors.helpNeeded && <p className="form-error">{errors.helpNeeded}</p>}
          </fieldset>
        )}

        {wizard.currentStep.id === 'goals' && (
          <div className="form-field">
            <label htmlFor="m-goals">
              Goals or preferences <span className="optional-tag">(optional)</span>
            </label>
            <textarea
              id="m-goals"
              className="form-textarea"
              placeholder="e.g. building confidence with algebra before the next assessment"
              value={data.goalsNote}
              onChange={(e) => update('goalsNote', e.target.value)}
            />
            <p className="form-hint">This is entirely optional — skip it if you&rsquo;d rather keep things brief.</p>
          </div>
        )}

        {wizard.currentStep.id === 'availability' && (
          <div className="form-field">
            <label htmlFor="m-availability">Roughly when works for sessions?</label>
            <textarea
              id="m-availability"
              className="form-textarea"
              placeholder="e.g. weekday evenings, or weekend mornings"
              value={data.availabilityNote}
              aria-invalid={!!errors.availabilityNote}
              onChange={(e) => update('availabilityNote', e.target.value)}
            />
            {errors.availabilityNote && <p className="form-error">{errors.availabilityNote}</p>}
          </div>
        )}

        {wizard.currentStep.id === 'contact' && (
          <>
            <div className="form-field">
              <label htmlFor="m-parent-name">Your name</label>
              <input
                id="m-parent-name"
                className="form-input"
                autoComplete="name"
                value={data.parentName}
                aria-invalid={!!errors.parentName}
                onChange={(e) => update('parentName', e.target.value)}
              />
              {errors.parentName && <p className="form-error">{errors.parentName}</p>}
            </div>
            <div className="form-field">
              <label htmlFor="m-parent-email">Email</label>
              <input
                id="m-parent-email"
                type="email"
                className="form-input"
                autoComplete="email"
                value={data.parentEmail}
                aria-invalid={!!errors.parentEmail}
                onChange={(e) => update('parentEmail', e.target.value)}
              />
              {errors.parentEmail && <p className="form-error">{errors.parentEmail}</p>}
            </div>
            <div className="form-field">
              <label htmlFor="m-parent-phone">
                Phone <span className="optional-tag">(optional)</span>
              </label>
              <input
                id="m-parent-phone"
                type="tel"
                className="form-input"
                autoComplete="tel"
                value={data.parentPhone}
                onChange={(e) => update('parentPhone', e.target.value)}
              />
            </div>
          </>
        )}

        {wizard.currentStep.id === 'review' && (
          <dl className="review-block">
            <dt>Student</dt>
            <dd>
              {data.studentFirstName || '—'}, {data.yearGroupLabel || '—'}
            </dd>
            <dt>Subject</dt>
            <dd>{subjectName || '—'}</dd>
            <dt>Help needed</dt>
            <dd>{data.helpNeeded ? HELP_LABELS[data.helpNeeded] : '—'}</dd>
            {data.goalsNote && (
              <>
                <dt>Goals</dt>
                <dd>{data.goalsNote}</dd>
              </>
            )}
            <dt>Availability</dt>
            <dd>{data.availabilityNote || '—'}</dd>
            <dt>Contact</dt>
            <dd>
              {data.parentName || '—'} — {data.parentEmail || '—'}
              {data.parentPhone && ` — ${data.parentPhone}`}
            </dd>
          </dl>
        )}

        {submitStatus === 'error' && <p className="form-error" style={{ marginTop: 'var(--space-4)' }}>Something went wrong submitting your request — please try again.</p>}
      </WizardShell>
    </div>
  );
}
