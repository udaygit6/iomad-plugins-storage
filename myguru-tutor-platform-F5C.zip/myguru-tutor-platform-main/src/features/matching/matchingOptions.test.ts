import { describe, it, expect } from 'vitest';
import { YEAR_GROUP_OPTIONS } from './matchingOptions';

describe('MatchingWizard year group options (correction 2)', () => {
  it('does not offer Reception/EYFS — that scope has not been approved', () => {
    expect(YEAR_GROUP_OPTIONS).not.toContain('Reception');
  });

  it('starts from Year 1', () => {
    expect(YEAR_GROUP_OPTIONS[0]).toBe('Year 1');
  });
});
