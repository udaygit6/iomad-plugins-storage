import type { HelpNeededReason } from '../../domain/models/types';

export const YEAR_GROUP_OPTIONS = [
  'Year 1', 'Year 2', 'Year 3', 'Year 4', 'Year 5', 'Year 6',
  'Year 7', 'Year 8', 'Year 9', 'Year 10', 'Year 11', 'Year 12', 'Year 13', 'Not sure yet',
];

export const HELP_OPTIONS: { value: HelpNeededReason; label: string }[] = [
  { value: 'catching_up', label: 'Catching up on missed learning' },
  { value: 'exam_preparation', label: 'Preparing for an exam' },
  { value: 'confidence', label: 'Building confidence' },
  { value: 'homework_support', label: 'Ongoing homework support' },
  { value: 'specific_topic', label: 'One specific topic' },
  { value: 'other', label: 'Something else' },
];

export const HELP_LABELS: Record<HelpNeededReason, string> = Object.fromEntries(HELP_OPTIONS.map((o) => [o.value, o.label])) as Record<
  HelpNeededReason,
  string
>;
