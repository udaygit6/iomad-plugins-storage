import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useWizard, type WizardStep } from '../../hooks/useWizard';
import { useAntiAbuseFields } from '../../hooks/useAntiAbuseFields';
import { WizardShell } from '../../components/forms/WizardShell';
import { HoneypotField } from '../../components/forms/HoneypotField';
import { subjectService } from '../../services/subjects/SubjectService';
import { tutorApplicationService, EMPTY_APPLICATION_FORM, type ApplicationFormData } from '../../services/applications/TutorApplicationService';
import type { Subject, EducationLevel, EducationLevelSlug } from '../../domain/models/types';
import type { FieldErrors } from '../../domain/validation/formValidation';
import '../matching/MatchingWizard.css';

const STEPS: WizardStep[] = [
  { id: 'about', label: 'About you' },
  { id: 'experience', label: 'Teaching experience' },
  { id: 'education', label: 'Your education' },
  { id: 'subjects', label: 'Subjects you teach' },
  { id: 'levels', label: 'Education levels' },
  { id: 'approach', label: 'Your teaching approach' },
  { id: 'availability', label: 'Availability' },
  { id: 'documents', label: 'Supporting information' },
  { id: 'review', label: 'Review and submit' },
];

function toggleInArray<T>(arr: T[], value: T): T[] {
  return arr.includes(value) ? arr.filter((v) => v !== value) : [...arr, value];
}

export function ApplicationWizard() {
  const wizard = useWizard(STEPS);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [levels, setLevels] = useState<EducationLevel[]>([]);
  const [data, setData] = useState<ApplicationFormData>(EMPTY_APPLICATION_FORM);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'submitting' | 'submitted' | 'error'>('idle');
  const { meta, honeypotValue, setHoneypotValue } = useAntiAbuseFields();

  useEffect(() => {
    subjectService.listSubjects().then(setSubjects);
    subjectService.listEducationLevels().then(setLevels);
  }, []);

  function update<K extends keyof ApplicationFormData>(key: K, value: ApplicationFormData[K]) {
    setData((d) => ({ ...d, [key]: value }));
    if (errors[key as string]) setErrors((e) => ({ ...e, [key]: '' }));
  }

  function handleNext() {
    const stepErrors = tutorApplicationService.validateStep(wizard.currentStep.id, data);
    setErrors(stepErrors);
    if (Object.keys(stepErrors).length === 0) wizard.goNext();
  }

  async function handleSubmit() {
    setSubmitStatus('submitting');
    try {
      await tutorApplicationService.submit(data, meta);
      setSubmitStatus('submitted');
    } catch {
      setSubmitStatus('error');
    }
  }

  if (submitStatus === 'submitted') {
    return (
      <div className="container matching-page">
        <div className="wizard-shell">
          <div className="confirmation-state">
            <div className="confirmation-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path d="M4 12l6 6L20 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <h2>Application submitted</h2>
            <p style={{ color: 'var(--color-text-muted)', marginTop: 'var(--space-3)', maxWidth: '48ch', marginLeft: 'auto', marginRight: 'auto' }}>
              Thank you — your application will be reviewed by our team. Your profile will only be published once it&rsquo;s
              been approved; nothing goes live automatically.
            </p>
            <Link to="/" className="btn btn-primary" style={{ marginTop: 'var(--space-6)', display: 'inline-flex' }}>
              Back to homepage
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container matching-page">
      <HoneypotField value={honeypotValue} onChange={setHoneypotValue} />
      <WizardShell
        title="Become a Tutor"
        stepLabel={wizard.currentStep.label}
        stepNumber={wizard.currentIndex + 1}
        totalSteps={STEPS.length}
        progressPercent={wizard.progressPercent}
        footer={
          <>
            <button type="button" className="btn-text" onClick={wizard.goBack} disabled={wizard.isFirst} style={{ visibility: wizard.isFirst ? 'hidden' : 'visible' }}>
              ← Back
            </button>
            {wizard.isLast ? (
              <button type="button" className="btn btn-primary" onClick={handleSubmit} disabled={submitStatus === 'submitting'} data-loading={submitStatus === 'submitting' ? 'true' : undefined}>
                {submitStatus === 'submitting' ? 'Submitting…' : 'Submit application'}
              </button>
            ) : (
              <button type="button" className="btn btn-primary" onClick={handleNext}>
                Continue
              </button>
            )}
          </>
        }
      >
        {wizard.currentStep.id === 'about' && (
          <>
            <div className="form-field">
              <label htmlFor="a-name">Full name</label>
              <input id="a-name" className="form-input" autoComplete="name" value={data.fullName} aria-invalid={!!errors.fullName} onChange={(e) => update('fullName', e.target.value)} />
              {errors.fullName && <p className="form-error">{errors.fullName}</p>}
            </div>
            <div className="form-field">
              <label htmlFor="a-email">Email</label>
              <input id="a-email" type="email" className="form-input" autoComplete="email" value={data.email} aria-invalid={!!errors.email} onChange={(e) => update('email', e.target.value)} />
              {errors.email && <p className="form-error">{errors.email}</p>}
            </div>
            <div className="form-field">
              <label htmlFor="a-phone">
                Phone <span className="optional-tag">(optional)</span>
              </label>
              <input id="a-phone" type="tel" className="form-input" autoComplete="tel" value={data.phone} onChange={(e) => update('phone', e.target.value)} />
            </div>
            <div className="form-field">
              <label htmlFor="a-about">A little about you</label>
              <textarea id="a-about" className="form-textarea" value={data.aboutYou} aria-invalid={!!errors.aboutYou} onChange={(e) => update('aboutYou', e.target.value)} />
              {errors.aboutYou && <p className="form-error">{errors.aboutYou}</p>}
            </div>
          </>
        )}

        {wizard.currentStep.id === 'experience' && (
          <div className="form-field">
            <label htmlFor="a-experience">Teaching / tutoring experience</label>
            <textarea id="a-experience" className="form-textarea" value={data.teachingExperience} aria-invalid={!!errors.teachingExperience} onChange={(e) => update('teachingExperience', e.target.value)} />
            {errors.teachingExperience && <p className="form-error">{errors.teachingExperience}</p>}
          </div>
        )}

        {wizard.currentStep.id === 'education' && (
          <>
            <div className="form-field">
              <label htmlFor="a-education">Your education background</label>
              <textarea id="a-education" className="form-textarea" value={data.education} aria-invalid={!!errors.education} onChange={(e) => update('education', e.target.value)} />
              {errors.education && <p className="form-error">{errors.education}</p>}
            </div>
            <div className="form-field">
              <label htmlFor="a-quals">
                Qualifications <span className="optional-tag">(one per line)</span>
              </label>
              <textarea
                id="a-quals"
                className="form-textarea"
                placeholder={'BSc Mathematics\nPGCE Secondary Education'}
                value={data.qualificationsText}
                onChange={(e) => update('qualificationsText', e.target.value)}
              />
              <p className="form-hint">You may be asked to provide supporting evidence during the application review process.</p>
            </div>
          </>
        )}

        {wizard.currentStep.id === 'subjects' && (
          <fieldset className="form-field" style={{ border: 'none', padding: 0, margin: 0 }}>
            <legend>Which subjects do you teach?</legend>
            <div className="option-grid">
              {subjects.map((s) => (
                <label key={s.id} className="option-card">
                  <input type="checkbox" checked={data.subjectSlugs.includes(s.slug)} onChange={() => update('subjectSlugs', toggleInArray(data.subjectSlugs, s.slug))} />
                  <span className="option-card-label">{s.name}</span>
                </label>
              ))}
            </div>
            {errors.subjectSlugs && <p className="form-error">{errors.subjectSlugs}</p>}
          </fieldset>
        )}

        {wizard.currentStep.id === 'levels' && (
          <fieldset className="form-field" style={{ border: 'none', padding: 0, margin: 0 }}>
            <legend>Which education levels?</legend>
            <div className="option-grid">
              {levels.map((l) => (
                <label key={l.id} className="option-card">
                  <input
                    type="checkbox"
                    checked={data.educationLevelSlugs.includes(l.slug)}
                    onChange={() => update('educationLevelSlugs', toggleInArray(data.educationLevelSlugs, l.slug) as EducationLevelSlug[])}
                  />
                  <span className="option-card-label">{l.name}</span>
                </label>
              ))}
            </div>
            {errors.educationLevelSlugs && <p className="form-error">{errors.educationLevelSlugs}</p>}
          </fieldset>
        )}

        {wizard.currentStep.id === 'approach' && (
          <div className="form-field">
            <label htmlFor="a-approach">How would you describe your teaching approach?</label>
            <textarea id="a-approach" className="form-textarea" value={data.teachingApproach} aria-invalid={!!errors.teachingApproach} onChange={(e) => update('teachingApproach', e.target.value)} />
            {errors.teachingApproach && <p className="form-error">{errors.teachingApproach}</p>}
          </div>
        )}

        {wizard.currentStep.id === 'availability' && (
          <div className="form-field">
            <label htmlFor="a-availability">General availability</label>
            <textarea id="a-availability" className="form-textarea" placeholder="e.g. weekday evenings and weekend mornings" value={data.availabilityNotes} aria-invalid={!!errors.availabilityNotes} onChange={(e) => update('availabilityNotes', e.target.value)} />
            {errors.availabilityNotes && <p className="form-error">{errors.availabilityNotes}</p>}
          </div>
        )}

        {wizard.currentStep.id === 'documents' && (
          <div className="form-field">
            <label htmlFor="a-documents">
              Supporting information <span className="optional-tag">(optional)</span>
            </label>
            <textarea
              id="a-documents"
              className="form-textarea"
              placeholder="Document upload isn't available yet — for now, feel free to describe any relevant certificates or references."
              value={data.supportingDocumentsNote}
              onChange={(e) => update('supportingDocumentsNote', e.target.value)}
            />
            <p className="form-hint">A proper document upload will be added in a later phase — this is a placeholder for now.</p>
          </div>
        )}

        {wizard.currentStep.id === 'review' && (
          <dl className="review-block">
            <dt>Name</dt>
            <dd>{data.fullName || '—'}</dd>
            <dt>Contact</dt>
            <dd>
              {data.email || '—'}
              {data.phone && ` — ${data.phone}`}
            </dd>
            <dt>Subjects</dt>
            <dd>{subjects.filter((s) => data.subjectSlugs.includes(s.slug)).map((s) => s.name).join(', ') || '—'}</dd>
            <dt>Education levels</dt>
            <dd>{levels.filter((l) => data.educationLevelSlugs.includes(l.slug)).map((l) => l.name).join(', ') || '—'}</dd>
            <dt>Availability</dt>
            <dd>{data.availabilityNotes || '—'}</dd>
          </dl>
        )}

        {submitStatus === 'error' && <p className="form-error" style={{ marginTop: 'var(--space-4)' }}>Something went wrong submitting your application — please try again.</p>}
      </WizardShell>
    </div>
  );
}
