import { useState } from 'react';
import type { SubmitMeta } from '../repositories/interfaces';

/**
 * Captures the two client-side anti-abuse signals every public submission
 * form sends alongside its real data (Phase E4): a form-load timestamp
 * (rejects implausibly fast bot submissions) and a honeypot field value
 * (real users never see or fill it in). Used by MatchingWizard,
 * ApplicationWizard, RequestTutorDrawer, and ContactPage.
 */
export function useAntiAbuseFields() {
  const [formLoadedAt] = useState(() => Date.now());
  const [honeypotValue, setHoneypotValue] = useState('');

  const meta: SubmitMeta = { formLoadedAt, honeypotValue };

  return { meta, honeypotValue, setHoneypotValue };
}
