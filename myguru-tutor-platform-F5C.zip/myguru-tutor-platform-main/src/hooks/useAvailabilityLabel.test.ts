import { describe, it, expect } from 'vitest';
import { useAvailabilityLabel } from './useAvailabilityLabel';

describe('useAvailabilityLabel', () => {
  it('returns a positive label when accepting students', () => {
    expect(useAvailabilityLabel(true)).toBe('Taking students');
  });

  it('returns a neutral, non-alarming label when not accepting students', () => {
    expect(useAvailabilityLabel(false)).toBe('Not currently available');
  });
});
