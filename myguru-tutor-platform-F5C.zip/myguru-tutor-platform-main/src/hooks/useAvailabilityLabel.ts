export function useAvailabilityLabel(acceptingStudents: boolean): string {
  return acceptingStudents ? 'Taking students' : 'Not currently available';
}
