import { describe, it, expect } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useWizard } from './useWizard';

const STEPS = [
  { id: 'a', label: 'Step A' },
  { id: 'b', label: 'Step B' },
  { id: 'c', label: 'Step C' },
];

describe('useWizard', () => {
  it('starts on the first step', () => {
    const { result } = renderHook(() => useWizard(STEPS));
    expect(result.current.currentStep.id).toBe('a');
    expect(result.current.isFirst).toBe(true);
    expect(result.current.isLast).toBe(false);
  });

  it('goNext advances to the next step', () => {
    const { result } = renderHook(() => useWizard(STEPS));
    act(() => result.current.goNext());
    expect(result.current.currentStep.id).toBe('b');
  });

  it('goNext does not advance past the last step', () => {
    const { result } = renderHook(() => useWizard(STEPS));
    act(() => result.current.goNext());
    act(() => result.current.goNext());
    act(() => result.current.goNext()); // one extra call past the end
    expect(result.current.currentStep.id).toBe('c');
    expect(result.current.isLast).toBe(true);
  });

  it('goBack does not go before the first step', () => {
    const { result } = renderHook(() => useWizard(STEPS));
    act(() => result.current.goBack());
    expect(result.current.currentStep.id).toBe('a');
    expect(result.current.isFirst).toBe(true);
  });

  it('goToStep jumps directly to a named step', () => {
    const { result } = renderHook(() => useWizard(STEPS));
    act(() => result.current.goToStep('c'));
    expect(result.current.currentStep.id).toBe('c');
  });

  it('progressPercent reflects the current position', () => {
    const { result } = renderHook(() => useWizard(STEPS));
    expect(result.current.progressPercent).toBe(33); // 1 of 3, rounded
    act(() => result.current.goNext());
    expect(result.current.progressPercent).toBe(67); // 2 of 3, rounded
    act(() => result.current.goNext());
    expect(result.current.progressPercent).toBe(100);
  });
});
