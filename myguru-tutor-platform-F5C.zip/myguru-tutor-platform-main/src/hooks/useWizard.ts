import { useState, useCallback, useMemo } from 'react';

export interface WizardStep {
  id: string;
  label: string;
}

/**
 * Generic step-navigation state for a multi-step form. Deliberately holds
 * no form data itself — the matching questionnaire and tutor application
 * each own their own data shape and validation; this hook only tracks
 * "which step am I on" and "can I move forward", so it's reusable by both
 * without coupling their data models together.
 */
export function useWizard(steps: WizardStep[]) {
  const [currentIndex, setCurrentIndex] = useState(0);

  const currentStep = steps[currentIndex];
  const isFirst = currentIndex === 0;
  const isLast = currentIndex === steps.length - 1;
  const progressPercent = useMemo(() => Math.round(((currentIndex + 1) / steps.length) * 100), [currentIndex, steps.length]);

  const goNext = useCallback(() => {
    setCurrentIndex((i) => Math.min(i + 1, steps.length - 1));
  }, [steps.length]);

  const goBack = useCallback(() => {
    setCurrentIndex((i) => Math.max(i - 1, 0));
  }, []);

  const goToStep = useCallback(
    (id: string) => {
      const idx = steps.findIndex((s) => s.id === id);
      if (idx >= 0) setCurrentIndex(idx);
    },
    [steps],
  );

  return { steps, currentStep, currentIndex, isFirst, isLast, progressPercent, goNext, goBack, goToStep };
}
