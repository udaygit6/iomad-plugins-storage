/**
 * IomadGateway — F3 read-only contract.
 *
 * TYPES/INTERFACE ONLY. No network implementation, no tokens, no secrets
 * live here. The real server-side implementation is
 * `netlify/functions/_lib/iomad/IomadRestGateway.ts` — it satisfies this
 * shape by duck-typing, not by importing this file, because
 * `netlify/functions/` has zero import path back into `src/` (the same
 * boundary already established for `netlify/functions/_lib/validation.ts`
 * — see that file's header comment). This file therefore stays the
 * provider-agnostic contract both sides agree on, kept in sync by hand.
 *
 * Relationship to the existing LMS boundary: `src/services/lms/LmsService.ts`
 * is the application-facing contract MyGuru's services call — deliberately
 * Iomad-agnostic in its naming (`LmsUser`, `LmsCourse`, ...). `IomadGateway`
 * below is narrower and Iomad-specific: the shape a future
 * `IomadLmsAdapter` would use *underneath* `LmsService`. It does not
 * replace `LmsService`, and does not itself implement `LmsService`.
 *
 * Scope (F3, read-only): list companies, list a company's courses, get a
 * single course. Deliberately excludes every write operation (create/
 * edit/disable company, assign/unassign users or courses, enrol users,
 * licences, etc.) — those are confirmed-available Iomad functions per
 * `docs/IOMAD_INTEGRATION_CONTRACT.md` but explicitly out of F3 scope.
 *
 * Confirmed/documented Iomad function mapping (server-side only — see
 * `IomadRestGateway.ts`; nothing here references a wsfunction name):
 *   listCompanies      → block_iomad_company_admin_get_companies (no
 *                        criteria — UNVERIFIED call form)
 *   getCompanyByCode   → block_iomad_company_admin_get_companies,
 *                        filtered by company `code` — CONFIRMED,
 *                        live-tested against the real Iomad instance
 *   listCompanyCourses → block_iomad_company_admin_get_company_courses,
 *                        filtered by `criteria[0][companyid]`/
 *                        `criteria[0][shared]` — F5A: DOCUMENTED, NOT YET
 *                        execution-verified
 *   getCourse          → block_iomad_company_admin_get_course_info,
 *                        singular `courseid` — F3-era guess, UNVERIFIED
 *   getCourseSettings  → block_iomad_company_admin_get_course_info,
 *                        `courrseids[0]`/`courrseids[1]`/... (exact
 *                        documented spelling) — F5A: DOCUMENTED, NOT YET
 *                        execution-verified
 *   getCompany         → NOT a confirmed single-company-by-id function;
 *                        derived by filtering the result of
 *                        listCompanies(). The one confirmed lookup
 *                        (getCompanyByCode) filters by CODE, not by this
 *                        numeric id. If a dedicated get-single-company-
 *                        by-id function is later confirmed, this can
 *                        switch to calling it directly without changing
 *                        the interface.
 *
 * Response field names (`externalId`, `displayName`) are a minimal,
 * defensively-normalized shape. As of a live-verified `get_companies`
 * call (filtered by code — see docs/IOMAD_INTEGRATION_CONTRACT.md's
 * "Live-verified: get_companies by code"), companies are now CONFIRMED to
 * also carry a distinct `code` field and a NUMERIC `suspended` field
 * (0 = active, non-zero = suspended, never a JSON boolean) — both
 * captured optionally below as `code`/`isSuspended`, though neither is
 * consumed by any sync/business logic yet. Course fields remain entirely
 * UNVERIFIED. See `docs/IOMAD_INTEGRATION_CONTRACT.md` for the remaining
 * live-test checklist items.
 */

/** Normalized Iomad company/tenant. `externalId`/`displayName` are
 * live-verified for the criteria-filtered lookup path (see
 * `IomadGateway.getCompanyByCode`); `code`/`isSuspended` are also
 * live-verified fields, captured defensively but not yet consumed by any
 * business logic. */
export interface IomadCompanySummary {
  /** Iomad's own company ID — the external ID persisted per Ground rule 2
   * in `docs/SYSTEM_OF_RECORD.md`. */
  externalId: string;
  displayName: string;
  /** CONFIRMED present and distinct from `shortname` (live example:
   * `code: "MYGURU-SHIKSHA-001"`, `shortname: "SHIKSHA"`). Optional —
   * defensive, not guaranteed present on every code path. */
  code?: string;
  /** CONFIRMED numeric on the wire (0 = active, non-zero = suspended) —
   * never a JSON boolean. Undefined if absent/non-numeric, never
   * assumed. NOT wired into any organisation/sync status decision. */
  isSuspended?: boolean;
}

/** Normalized Iomad course — response adapter pending live schema verification. */
export interface IomadCourseSummary {
  /** Iomad's own course ID — the external ID persisted per Ground rule 2
   * in `docs/SYSTEM_OF_RECORD.md`. */
  externalId: string;
  displayName: string;
}

/**
 * F5A — one course allocated to a company, as returned nested inside
 * `block_iomad_company_admin_get_company_courses`'s response. DOCUMENTED
 * from the live Iomad admin UI, NOT YET execution-verified — see
 * `docs/IOMAD_INTEGRATION_CONTRACT.md`'s F5A section.
 */
export interface CompanyCourseAllocation {
  externalCourseId: string;
  fullName: string;
  /** Present only if Iomad returned at least one well-formed custom
   * field for this course. Malformed individual entries are dropped, not
   * fatal. */
  customFields?: Array<{ externalFieldId: string; name: string; value: string }>;
}

/**
 * F5A — one course's licensing/settings row, as returned by
 * `block_iomad_company_admin_get_course_info`. DOCUMENTED, NOT YET
 * execution-verified. `licensed`/`shared` are derived strictly from a
 * numeric wire value (`!== 0`) — never assumed boolean.
 */
export interface IomadCourseSettings {
  externalCourseId: string;
  licensed: boolean;
  shared: boolean;
  validLengthDays: number;
  warnExpireDays: number;
  warnCompletionDays: number;
  notifyPeriodDays: number;
}

export interface ListCompaniesOptions {
  /** Opaque pagination cursor/offset — shape UNVERIFIED, not sent by the
   * F3 implementation until confirmed. */
  page?: number;
}

/**
 * Read-only gateway contract. No method here performs a write. F3 ships
 * exactly one concrete implementation
 * (`netlify/functions/_lib/iomad/IomadRestGateway.ts`), reachable only
 * from server-side code — never from a component or a browser-bundled
 * module.
 */
export interface IomadGateway {
  listCompanies(options?: ListCompaniesOptions): Promise<IomadCompanySummary[]>;

  /** Derived by filtering `listCompanies()` — see file header. Not a
   * separate confirmed Iomad function as of F3/F4. */
  getCompany(externalCompanyId: string): Promise<IomadCompanySummary | null>;

  /** CONFIRMED — live-tested lookup by Iomad company `code` (not the
   * numeric id). See "Live-verified: get_companies by code" in
   * docs/IOMAD_INTEGRATION_CONTRACT.md. */
  getCompanyByCode(code: string): Promise<IomadCompanySummary | null>;

  /**
   * F5A — courses allocated to a company. `shared` defaults to `false`
   * (`criteria[0][shared]=0`, a "normal company-specific lookup" per the
   * documented contract). DOCUMENTED, NOT YET execution-verified — see
   * docs/IOMAD_INTEGRATION_CONTRACT.md's F5A section.
   */
  listCompanyCourses(companyId: string, shared?: boolean): Promise<CompanyCourseAllocation[]>;

  getCourse(externalCourseId: string): Promise<IomadCourseSummary | null>;

  /**
   * F5A — course settings/licensing info for one or more courses in a
   * single call. May return fewer entries than `courseIds` — match on
   * `externalCourseId`, not position. DOCUMENTED, NOT YET
   * execution-verified. Empty input returns an empty array without a
   * network call.
   */
  getCourseSettings(courseIds: string[]): Promise<IomadCourseSettings[]>;
}

/**
 * Deferred to F4+, not part of the F3 interface (per the brief: "do not
 * implement unnecessary operations in F3"). Listed here only so a future
 * phase doesn't have to rediscover that these functions are already
 * confirmed available:
 *   - listDepartments(companyId)        → block_iomad_company_admin_get_departments
 *   - listDepartmentUsers(departmentId) → block_iomad_company_admin_get_department_users
 *   - getUserCompanies(userId)          → block_iomad_company_admin_get_user_companies
 *   - getLicenseInfo(...) / getLicenseFromId(...)
 */
