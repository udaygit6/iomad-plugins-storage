import { createClient, type SupabaseClient } from '@supabase/supabase-js';

/**
 * The ONLY place a raw Supabase client is constructed. Repository
 * implementations under src/repositories/supabase/ and the admin auth
 * service are the only permitted importers — per ARCHITECTURE.md's
 * provider-independence rule, no component or feature service may import
 * this module or call `supabase.from(...)`/`supabase.auth` directly.
 *
 * Uses the current (non-legacy) Supabase key model, per Phase E3 §2:
 *   VITE_SUPABASE_URL
 *   VITE_SUPABASE_PUBLISHABLE_KEY
 * Both are client-safe (anything prefixed VITE_ ships to the browser) and
 * are subject to RLS — this client can never do more than the `anon`/
 * `authenticated` policies in supabase/migrations/0009 allow.
 *
 * The server-only privileged Supabase key (used only by netlify/functions/)
 * is never referenced here or anywhere in client-side code.
 */

let client: SupabaseClient | null = null;
let configError: string | null = null;

function readConfig(): { url: string; publishableKey: string } | null {
  const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
  const publishableKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string | undefined;

  if (!url || !publishableKey) {
    configError =
      'Supabase is not configured (VITE_SUPABASE_URL / VITE_SUPABASE_PUBLISHABLE_KEY missing). ' +
      'Set VITE_DATA_PROVIDER=mock to use the mock repositories instead, or configure these ' +
      'variables to use the Supabase-backed repositories.';
    return null;
  }
  return { url, publishableKey };
}

/**
 * Lazily constructs (and caches) the Supabase client. Deliberately lazy —
 * and deliberately NOT called anywhere unless VITE_DATA_PROVIDER=supabase
 * actually selects a Supabase repository — so a mock-mode dev/test run
 * never needs these environment variables set at all (Phase E3 §17: a
 * missing-config state must not crash the whole app).
 *
 * Throws a single, non-sensitive error (never a raw Supabase/network
 * error) if config is missing. Callers (repositories) catch this and
 * surface a safe empty/error state — see SupabaseSubjectRepository /
 * SupabaseTutorRepository.
 */
export function getSupabaseClient(): SupabaseClient {
  if (client) return client;

  const config = readConfig();
  if (!config) {
    throw new Error(configError ?? 'Supabase client is not configured.');
  }

  client = createClient(config.url, config.publishableKey, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: false,
    },
  });
  return client;
}

/** True if the client-safe Supabase env vars are present, without constructing the client. */
export function isSupabaseConfigured(): boolean {
  return readConfig() !== null;
}
