/**
 * Hand-maintained row types matching supabase/migrations/0001-0010.
 *
 * NOT generated via `supabase gen types` — this sandbox has no network
 * access to the linked staging project, so type generation could not be
 * run. These are typed by hand directly against the migration SQL and
 * should be replaced with `supabase gen types typescript --linked` output
 * the first time someone runs this with real project access; the shapes
 * below were written to match exactly, so that regeneration should be a
 * near no-op diff.
 *
 * Per ARCHITECTURE.md's provider-independence rule: these types are used
 * ONLY inside src/repositories/supabase/ mappers. Domain models
 * (src/domain/models/types.ts) never import from this file.
 */

export interface SubjectRow {
  id: string;
  slug: string;
  name: string;
  description: string | null;
  enabled: boolean;
  display_order: number;
  created_at: string;
  updated_at: string;
}

export interface EducationLevelRow {
  id: string;
  slug: 'ks1' | 'ks2' | 'ks3' | 'gcse' | 'a-level';
  name: string;
  stage_headline: string;
  stage_description: string;
  display_order: number;
  created_at: string;
  updated_at: string;
}

export interface TutorProfileRow {
  id: string;
  slug: string;
  public_display_name: string;
  headline: string;
  positioning_statement: string | null;
  bio: string;
  teaching_approach: string;
  photo_url: string | null;
  qualifications_summary: string[];
  experience_summary: string;
  languages: string[];
  accepting_students: boolean;
  status: 'draft' | 'approved' | 'published' | 'unpublished';
}

/** Row shape when nested-selecting subjects through tutor_profile_subjects. */
export interface TutorProfileSubjectJoinRow {
  subjects: SubjectRow;
}

/** Row shape when nested-selecting levels through tutor_profile_levels. */
export interface TutorProfileLevelJoinRow {
  education_levels: EducationLevelRow;
}

export interface PublicVerificationBadgeRow {
  tutor_profile_id: string;
  verification_type: 'identity' | 'qualification' | 'dbs';
}

export interface AdminProfileRow {
  user_id: string;
  role: 'admin';
  created_at: string;
}

/**
 * F4D — admin-only visibility into F4/F4C's already-synchronised company
 * data. Matches `supabase/migrations/0015_organisation_iomad_company_sync.sql`
 * exactly (unchanged by F4D — no migration added). These types are, like
 * every other row type in this file, used ONLY inside
 * `src/repositories/supabase/` mappers.
 */
export interface OrganisationRow {
  id: string;
  name: string;
  type: 'unclassified' | 'myguru_franchise' | 'corporate' | 'school_future' | 'internal';
  status: 'active' | 'suspended' | 'inactive';
  source: 'iomad_sync' | 'manual';
  created_at: string;
  updated_at: string;
}

export interface IomadCompanyMappingRow {
  id: string;
  organisation_id: string;
  iomad_company_id: string;
  sync_status: 'pending' | 'synced' | 'failed' | 'stale';
  last_synced_at: string | null;
  last_error_code: string | null;
  created_at: string;
  updated_at: string;
}

/**
 * Row shape when nested-selecting `iomad_company_mappings` through
 * `organisations` (`.select('*, iomad_company_mappings(*)')` — the same
 * "child embeds via its FK" direction PostgREST always supports,
 * regardless of the child's `organisation_id` also being unique).
 * PostgREST's embedded-resource shape for a to-many relationship is
 * normally an array; some client/schema-cache configurations can instead
 * return a single object for a uniquely-constrained child. The mapper in
 * `SupabaseOrganisationRepository.ts` handles both defensively, plus the
 * case where no mapping row exists at all (an organisation not created by
 * F4 sync, or one whose mapping was somehow removed) — never assumes
 * exactly one mapping is present.
 */
export type OrganisationWithMappingRow = OrganisationRow & {
  iomad_company_mappings: IomadCompanyMappingRow[] | IomadCompanyMappingRow | null;
};

/**
 * F5C — admin-only visibility into F5B's already-synchronised course
 * persistence data. Matches
 * `supabase/migrations/0016_course_persistence_and_organisation_allocations.sql`
 * exactly (unchanged by F5C — no migration added). Used only inside
 * `src/repositories/supabase/SupabaseOrganisationRepository.ts`'s
 * `listOrganisationCourses()`.
 */
export interface OrganisationCourseAllocationRow {
  id: string;
  licensed: boolean;
  shared: boolean;
  valid_length_days: number;
  warn_expire_days: number;
  warn_completion_days: number;
  notify_period_days: number;
  sync_status: 'pending' | 'synced' | 'failed' | 'stale';
  last_synced_at: string | null;
}

export interface IomadCourseMappingIdOnlyRow {
  iomad_course_id: string;
}

/**
 * Row shape for the nested select
 * `organisation_course_allocations.select('..., courses(name, iomad_course_mappings(iomad_course_id))')`.
 * `courses` is a to-one embed (the allocation's own `course_id` FK), so
 * PostgREST always returns it as a single object or null — never an
 * array. `iomad_course_mappings`, nested one level further, is the same
 * "child embeds via its FK" shape already seen in
 * `OrganisationWithMappingRow` — normally an array, but handled
 * defensively for either shape (or entirely absent) by the mapper, the
 * same posture that file already established.
 */
export type OrganisationCourseAllocationWithCourseRow = OrganisationCourseAllocationRow & {
  courses: {
    name: string;
    iomad_course_mappings: IomadCourseMappingIdOnlyRow[] | IomadCourseMappingIdOnlyRow | null;
  } | null;
};
