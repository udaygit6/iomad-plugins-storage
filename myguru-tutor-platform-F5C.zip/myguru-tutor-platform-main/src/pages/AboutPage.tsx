import { PageMeta } from '../components/PageMeta';
import { siteConfig } from '../config/siteConfig';
import './ContentPage.css';

export function AboutPage() {
  return (
    <>
      <PageMeta title={`About — ${siteConfig.brandName}`} description={`About ${siteConfig.brandName}, an online tutoring platform for Primary through A-Level.`} />
      <div className="container content-page">
        <span className="eyebrow">About us</span>
        <h1>Built around finding the right fit, not just a long list of names</h1>
        <p className="lede">
          {siteConfig.brandName} exists because choosing a tutor shouldn&rsquo;t mean scrolling through dozens of
          near-identical profiles hoping one stands out. We review every tutor before they&rsquo;re listed, and we help
          match families to a tutor whose subject and level experience fits what they&rsquo;re looking for.
        </p>
        <section>
          <h2>What we do</h2>
          <p>
            We connect students across Primary through A-Level with reviewed online tutors, either through a guided
            matching process or by browsing and choosing directly.
          </p>
        </section>
        <section>
          <h2>Where we are</h2>
          <p>
            {siteConfig.brandName} is a working name for a platform currently in development. Company registration
            details, final branding, and full policy information will be published here before launch.
          </p>
        </section>
      </div>
    </>
  );
}
