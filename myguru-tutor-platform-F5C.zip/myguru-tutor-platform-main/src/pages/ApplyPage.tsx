import { PageMeta } from '../components/PageMeta';
import { ApplicationWizard } from '../features/tutor-application/ApplicationWizard';
import { siteConfig } from '../config/siteConfig';

export function ApplyPage() {
  return (
    <>
      <PageMeta title={`Tutor Application — ${siteConfig.brandName}`} description="Apply to become a tutor." />
      <h1 className="sr-only">Tutor Application</h1>
      <ApplicationWizard />
    </>
  );
}
