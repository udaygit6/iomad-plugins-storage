import { Link } from 'react-router-dom';
import { PageMeta } from '../components/PageMeta';
import { siteConfig } from '../config/siteConfig';
import './BecomeATutorPage.css';

export function BecomeATutorPage() {
  return (
    <>
      <PageMeta
        title={`Become a Tutor — ${siteConfig.brandName}`}
        description="Apply to tutor online, Primary through A-Level."
      />
      <div className="container become-tutor-page">
        <span className="eyebrow">For tutors</span>
        <h1 style={{ marginTop: 'var(--space-3)' }}>Tutor online, on your own schedule</h1>
        <p className="lede" style={{ marginTop: 'var(--space-4)' }}>
          We review every application before a profile can be published — so families can trust who they&rsquo;re booking,
          and tutors join a platform that takes vetting seriously.
        </p>

        <div className="become-tutor-steps">
          <div className="become-tutor-step">
            <div className="step-num">1</div>
            <h3>Apply</h3>
            <p>Tell us about your background, subjects, and experience.</p>
          </div>
          <div className="become-tutor-step">
            <div className="step-num">2</div>
            <h3>Application reviewed</h3>
            <p>Our team reviews your application before any profile is created.</p>
          </div>
          <div className="become-tutor-step">
            <div className="step-num">3</div>
            <h3>Profile published</h3>
            <p>Once approved, your profile becomes visible to families searching for a tutor.</p>
          </div>
        </div>

        <Link to="/apply" className="btn btn-primary" style={{ marginTop: 'var(--space-7)' }}>
          Start your application
        </Link>
      </div>
    </>
  );
}
