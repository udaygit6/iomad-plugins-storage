import { useState } from 'react';
import { PageMeta } from '../components/PageMeta';
import { enquiryService, validateEnquiry, type EnquiryFormData } from '../services/enquiries/EnquiryService';
import { useAntiAbuseFields } from '../hooks/useAntiAbuseFields';
import { HoneypotField } from '../components/forms/HoneypotField';
import type { FieldErrors } from '../domain/validation/formValidation';
import { siteConfig } from '../config/siteConfig';
import '../components/forms/WizardShell.css';
import './ContentPage.css';

const EMPTY: EnquiryFormData = { name: '', email: '', message: '' };

export function ContactPage() {
  const [data, setData] = useState<EnquiryFormData>(EMPTY);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [status, setStatus] = useState<'idle' | 'submitting' | 'submitted' | 'error'>('idle');
  const { meta, honeypotValue, setHoneypotValue } = useAntiAbuseFields();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const validationErrors = validateEnquiry(data);
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;

    setStatus('submitting');
    try {
      await enquiryService.submit(data, undefined, meta);
      setStatus('submitted');
    } catch {
      setStatus('error');
    }
  }

  return (
    <>
      <PageMeta title={`Contact — ${siteConfig.brandName}`} description="Get in touch with a general question." />
      <div className="container content-page">
        <span className="eyebrow">Contact</span>
        <h1>Get in touch</h1>
        <p className="lede">For anything not covered by the FAQ, send us a message and we&rsquo;ll get back to you by email.</p>

        <HoneypotField value={honeypotValue} onChange={setHoneypotValue} />
        <div className="wizard-shell" style={{ marginTop: 'var(--space-7)', maxWidth: 560 }}>
          <div className="wizard-body" style={{ minHeight: 'auto' }}>
            {status === 'submitted' ? (
              <div className="confirmation-state">
                <div className="confirmation-icon">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M4 12l6 6L20 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
                <h2>Message sent</h2>
                <p style={{ color: 'var(--color-text-muted)', marginTop: 'var(--space-2)' }}>We&rsquo;ll be in touch by email.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate>
                <div className="form-field">
                  <label htmlFor="c-name">Your name</label>
                  <input id="c-name" className="form-input" autoComplete="name" value={data.name} aria-invalid={!!errors.name} onChange={(e) => setData({ ...data, name: e.target.value })} />
                  {errors.name && <p className="form-error">{errors.name}</p>}
                </div>
                <div className="form-field">
                  <label htmlFor="c-email">Email</label>
                  <input id="c-email" type="email" className="form-input" autoComplete="email" value={data.email} aria-invalid={!!errors.email} onChange={(e) => setData({ ...data, email: e.target.value })} />
                  {errors.email && <p className="form-error">{errors.email}</p>}
                </div>
                <div className="form-field">
                  <label htmlFor="c-message">Message</label>
                  <textarea id="c-message" className="form-textarea" value={data.message} aria-invalid={!!errors.message} onChange={(e) => setData({ ...data, message: e.target.value })} />
                  {errors.message && <p className="form-error">{errors.message}</p>}
                </div>
                {status === 'error' && <p className="form-error">Something went wrong — please try again.</p>}
                <button type="submit" className="btn btn-primary" style={{ width: '100%' }} disabled={status === 'submitting'} data-loading={status === 'submitting' ? 'true' : undefined}>
                  {status === 'submitting' ? 'Sending…' : 'Send message'}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
