import { PageMeta } from '../components/PageMeta';
import { Accordion } from '../components/ui/Accordion';
import { siteConfig } from '../config/siteConfig';
import './ContentPage.css';

const FAQ_ITEMS = [
  {
    id: 'choose',
    question: 'How do you choose tutors?',
    answer: 'Every tutor applies, and their application is reviewed before a profile can be published — nothing goes live automatically.',
  },
  { id: 'format', question: 'Is tutoring online or in person?', answer: `All tutoring on ${siteConfig.brandName} is online.` },
  {
    id: 'match-or-browse',
    question: 'Do I have to use tutor matching, or can I choose myself?',
    answer: 'Either — matching is there to help narrow things down, but you can browse and choose a tutor directly at any time.',
  },
  {
    id: 'change',
    question: 'Can I change tutors if it\u2019s not the right fit?',
    answer: 'This is one of the things we\u2019re still finalising, and it will be published clearly before launch.',
  },
  {
    id: 'price',
    question: 'How much does tutoring cost?',
    answer: 'Pricing is still being decided. This section will be updated with clear, published information before launch.',
  },
  {
    id: 'ages',
    question: 'What ages/stages do you support?',
    answer: 'Primary (KS1 and KS2) through A-Level.',
  },
  {
    id: 'verification',
    question: 'How are tutors verified?',
    answer:
      'Tutor applications are reviewed before a profile can be published. Verification badges on a profile are only ever shown for checks that have actually been completed.',
  },
  {
    id: 'start',
    question: 'How quickly can lessons start?',
    answer: 'This depends on tutor availability and is still being finalised — clear timelines will be published before launch.',
  },
];

export function FaqPage() {
  return (
    <>
      <PageMeta title={`FAQ — ${siteConfig.brandName}`} description="Frequently asked questions about tutoring, matching, and verification." />
      <div className="container content-page">
        <span className="eyebrow">Frequently asked questions</span>
        <h1>Before you get started</h1>
        <div style={{ marginTop: 'var(--space-7)' }}>
          <Accordion items={FAQ_ITEMS} defaultOpenId="choose" />
        </div>
      </div>
    </>
  );
}
