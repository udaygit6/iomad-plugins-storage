import { PageMeta } from '../components/PageMeta';
import { MatchingWizard } from '../features/matching/MatchingWizard';
import { siteConfig } from '../config/siteConfig';

export function FindTutorPage() {
  return (
    <>
      <PageMeta
        title={`Find My Tutor — ${siteConfig.brandName}`}
        description="Tell us what your child needs and we'll help identify a suitable tutor."
      />
      <h1 className="sr-only">Find My Tutor</h1>
      <MatchingWizard />
    </>
  );
}
