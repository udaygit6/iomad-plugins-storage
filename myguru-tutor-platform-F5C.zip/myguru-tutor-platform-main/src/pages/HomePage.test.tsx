import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { HomePage } from './HomePage';

vi.mock('../services/tutors/TutorDiscoveryService', () => ({
  tutorDiscoveryService: {
    listFeatured: vi.fn().mockResolvedValue([]),
  },
}));

vi.mock('../services/subjects/SubjectService', () => ({
  subjectService: {
    listSubjects: vi.fn().mockResolvedValue([]),
    listEducationLevels: vi.fn().mockResolvedValue([]),
  },
}));

function renderHome() {
  return render(
    <MemoryRouter>
      <HomePage />
    </MemoryRouter>,
  );
}

describe('HomePage', () => {
  it('renders the primary and secondary CTAs', () => {
    renderHome();
    expect(screen.getAllByRole('link', { name: /Find My Tutor/i }).length).toBeGreaterThan(0);
    expect(screen.getAllByRole('link', { name: /Browse tutors/i }).length).toBeGreaterThan(0);
  });

  it('renders the brand name from siteConfig, not a second hard-coded literal', () => {
    renderHome();
    // Appears in the dev notice and the FAQ answer — both sourced from siteConfig.
    expect(screen.getAllByText(/MyGuru/).length).toBeGreaterThan(0);
  });

  it('does not assert the introductory-session model as an established policy', () => {
    renderHome();
    expect(screen.queryByText(/introductory session/i)).not.toBeInTheDocument();
  });

  it('does not claim scheduling flexibility as a guarantee', () => {
    renderHome();
    expect(screen.queryByText(/arranged around your schedule/i)).not.toBeInTheDocument();
  });

  it('does not claim qualification checks are operational, only that applications are reviewed', () => {
    renderHome();
    expect(screen.queryByText(/qualifications checked against supporting documents/i)).not.toBeInTheDocument();
    expect(screen.getAllByText(/reviewed/i).length).toBeGreaterThan(0);
  });

  it('resolves the featured tutors section without throwing once the (mocked) service responds', async () => {
    renderHome();
    await waitFor(() => {
      expect(screen.getByText(/A preview of how tutor profiles will look/)).toBeInTheDocument();
    });
  });
});
