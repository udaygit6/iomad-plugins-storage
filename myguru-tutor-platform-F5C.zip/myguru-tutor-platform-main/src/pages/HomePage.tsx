import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Accordion } from '../components/ui/Accordion';
import { TutorCard } from '../components/tutor/TutorCard';
import { TutorCardSkeleton } from '../components/tutor/TutorCardSkeleton';
import { tutorDiscoveryService } from '../services/tutors/TutorDiscoveryService';
import { subjectService } from '../services/subjects/SubjectService';
import type { TutorProfile, Subject, EducationLevel } from '../domain/models/types';
import { PageMeta } from '../components/PageMeta';
import { siteConfig } from '../config/siteConfig';
import './HomePage.css';

const FAQ_ITEMS = [
  {
    id: 'q1',
    question: 'How do you choose tutors?',
    answer:
      'Every tutor applies, and their application is reviewed before a profile can be published — nothing goes live automatically.',
  },
  { id: 'q2', question: 'Is tutoring online or in person?', answer: `All tutoring on ${siteConfig.brandName} is online.` },
  {
    id: 'q3',
    question: 'Can I change tutors if it\u2019s not the right fit?',
    answer: 'This is one of the things we\u2019re still finalising, and it will be published clearly before launch.',
  },
  {
    id: 'q4',
    question: 'How much does tutoring cost?',
    answer: 'Pricing is still being decided. This section will be updated with clear, published information before launch.',
  },
];

export function HomePage() {
  const [featuredTutors, setFeaturedTutors] = useState<TutorProfile[] | null>(null);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [levels, setLevels] = useState<EducationLevel[]>([]);

  useEffect(() => {
    let cancelled = false;
    tutorDiscoveryService.listFeatured(3).then((tutors) => {
      if (!cancelled) setFeaturedTutors(tutors);
    });
    subjectService.listSubjects().then((s) => !cancelled && setSubjects(s));
    subjectService.listEducationLevels().then((l) => !cancelled && setLevels(l));
    return () => {
      cancelled = true;
    };
  }, []);

  const featuredSubject = subjects[0];
  const otherSubjects = subjects.slice(1, 7);

  return (
    <>
      <PageMeta
        title={`${siteConfig.brandName} — Online tutoring, Primary to A-Level`}
        description="Personalised tutor matching and a browsable directory of reviewed online tutors, covering Primary through A-Level."
      />

      <div className="notice container">
        Development build — Phase D. &ldquo;{siteConfig.brandName}&rdquo; is a working brand name. Tutor photography is
        represented with illustrated placeholders; the tutors shown are development fixtures, not real people.
      </div>

      {/* ---------- Hero ---------- */}
      <section className="hero">
        <div className="container hero-grid">
          <div className="hero-copy">
            <span className="eyebrow">Online tutoring · Primary to A-Level</span>
            <h1>The right tutor. The right fit.</h1>
            <p className="lede">
              Tell us what your child needs and we&rsquo;ll identify a tutor who fits — subject, level, and the way they
              learn. Prefer to choose yourself? Every approved tutor is also open to browse.
            </p>
            <div className="hero-ctas">
              <Link to="/find-a-tutor" className="btn btn-primary">
                Find My Tutor
              </Link>
              <Link to="/tutors" className="btn-text">
                Browse tutors <span aria-hidden="true">→</span>
              </Link>
            </div>
            <div className="hero-proof">
              <div className="hero-proof-item">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
                  <path
                    d="M9 1.5l2.4 4.8 5.3.8-3.85 3.75.9 5.3L9 13.7l-4.75 2.4.9-5.3L1.3 7.1l5.3-.8L9 1.5z"
                    stroke="currentColor"
                    strokeWidth="1.3"
                    strokeLinejoin="round"
                  />
                </svg>
                <span>
                  <strong>Reviewed, not self-listed</strong>Tutor applications are reviewed before a profile can be published.
                </span>
              </div>
              <div className="hero-proof-item">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
                  <path
                    d="M9 2L2.5 5.2v3.6c0 4 2.8 6.9 6.5 8 3.7-1.1 6.5-4 6.5-8V5.2L9 2z"
                    stroke="currentColor"
                    strokeWidth="1.3"
                    strokeLinejoin="round"
                  />
                </svg>
                <span>
                  <strong>Safeguarding-first</strong>A vetting process designed around student safety.
                </span>
              </div>
            </div>
          </div>

          <div className="hero-visual">
            <div className="device-frame">
              <div className="device-screen">
                <div className="screen-main">
                  <div className="screen-grid-lines" />
                  <div className="screen-topbar">
                    <span className="rec-dot" />
                    <span className="rec-label">LIVE SESSION</span>
                  </div>
                  <svg className="silhouette" viewBox="0 0 200 180" fill="none" aria-hidden="true">
                    <path
                      d="M100 20c-26 0-40 20-40 44 0 18 8 30 16 36-30 10-56 30-64 66h176c-8-36-34-56-64-66 8-6 16-18 16-36 0-24-14-44-40-44z"
                      fill="url(#hero-g1)"
                    />
                    <defs>
                      <linearGradient id="hero-g1" x1="40" y1="20" x2="160" y2="180">
                        <stop stopColor="var(--color-gold-300)" />
                        <stop offset="1" stopColor="var(--color-ink-900)" />
                      </linearGradient>
                    </defs>
                  </svg>
                </div>
                <div className="screen-pip">
                  <svg className="silhouette-sm" viewBox="0 0 200 180" fill="none" aria-hidden="true">
                    <path
                      d="M100 20c-26 0-40 20-40 44 0 18 8 30 16 36-30 10-56 30-64 66h176c-8-36-34-56-64-66 8-6 16-18 16-36 0-24-14-44-40-44z"
                      fill="currentColor"
                      opacity="0.75"
                    />
                  </svg>
                </div>
              </div>
            </div>
            <div className="float-card">
              <div className="float-avatar">S</div>
              <div className="float-card-body">
                <strong>Matched: Sarah M.</strong>
                <span>GCSE Maths</span>
              </div>
              <div className="float-check">
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true">
                  <path d="M2 6l2.5 2.5L10 3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>
            </div>
            <div className="float-chip">
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
                <path d="M2 7l3.5 3.5L12 3" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              Matched to your goals
            </div>
            <p className="hero-visual-caption">Illustrative composition — not a real student, tutor, or session.</p>
          </div>
        </div>
      </section>

      {/* ---------- Trust strip ---------- */}
      <div className="trust-strip">
        <div className="container trust-list">
          <div className="trust-item">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
              <path d="M3 10l5 5 9-10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <div>
              <strong>Reviewed tutors</strong>
              <span>Applications reviewed before a profile can be published.</span>
            </div>
          </div>
          <div className="trust-item">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
              <rect x="2.5" y="4.5" width="15" height="12" rx="2" stroke="currentColor" strokeWidth="1.5" />
              <path d="M2.5 8h15" stroke="currentColor" strokeWidth="1.5" />
            </svg>
            <div>
              <strong>Online sessions</strong>
              <span>Delivered by video call.</span>
            </div>
          </div>
          <div className="trust-item">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
              <rect x="2.5" y="2.5" width="15" height="15" rx="3" stroke="currentColor" strokeWidth="1.5" />
              <path d="M6.5 10h7M10 6.5v7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
            </svg>
            <div>
              <strong>Primary to A-Level</strong>
              <span>One platform across every school stage.</span>
            </div>
          </div>
          <div className="trust-item">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
              <path
                d="M10 2.5l6 3v4c0 4.5-2.7 7.6-6 8.5-3.3-.9-6-4-6-8.5v-4l6-3z"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinejoin="round"
              />
            </svg>
            <div>
              <strong>Safeguarding-first</strong>
              <span>Designed with student safety as a starting point.</span>
            </div>
          </div>
        </div>
      </div>

      {/* ---------- How it works ---------- */}
      <section className="band" id="how-it-works">
        <div className="container how-grid">
          <div>
            <span className="eyebrow">How matching works</span>
            <h2 style={{ marginTop: 'var(--space-3)' }}>Four short steps, not a long application</h2>
            <div className="step-list">
              {[
                { n: 1, t: "Tell us what's needed", d: "Year group, subject, and what your child is finding difficult." },
                { n: 2, t: 'We identify a fit', d: "Matched against subject, level and availability — not just who's free." },
                { n: 3, t: 'Review your match', d: "We'll help identify tutors whose subject and level experience fit what you're looking for." },
                { n: 4, t: 'Start making progress', d: 'Regular sessions built around what your child actually needs.' },
              ].map((step) => (
                <div className="step" key={step.n}>
                  <div className="step-num">{step.n}</div>
                  <div className="step-copy">
                    <h3>{step.t}</h3>
                    <p>{step.d}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mock-card" aria-hidden="true">
            <div className="mock-card-head">
              <span>Find My Tutor</span>
              <div className="mock-progress">
                <i className="done" />
                <i className="done" />
                <i />
                <i />
              </div>
            </div>
            <div className="mock-card-body">
              <div className="mock-field">
                <label>Year group</label>
                <div className="mock-select active">
                  <span>Year 9</span>
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                    <path d="M3 5l4 4 4-4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
              </div>
              <div className="mock-field">
                <label>Subject</label>
                <div className="mock-chip-row">
                  <span className="mock-chip selected">Maths</span>
                  <span className="mock-chip">English</span>
                  <span className="mock-chip">Science</span>
                  <span className="mock-chip">+ more</span>
                </div>
              </div>
              <div className="mock-field" style={{ marginBottom: 0 }}>
                <label>What&rsquo;s the main goal?</label>
                <div className="mock-select">
                  <span style={{ color: 'var(--color-text-muted)', fontWeight: 400 }}>e.g. building confidence with algebra</span>
                </div>
              </div>
            </div>
            <div className="mock-card-foot">
              <Link to="/find-a-tutor" className="btn btn-primary btn-sm">
                Continue
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ---------- Subjects ---------- */}
      <section className="band" id="subjects">
        <div className="container">
          <div className="section-head left" style={{ marginBottom: 'var(--space-7)' }}>
            <span className="eyebrow">Popular subjects</span>
            <h2 style={{ marginTop: 'var(--space-3)' }}>Find support in the subject that matters right now</h2>
          </div>
          {subjects.length > 0 && (
            <div className="subject-layout">
              <Link to={`/subjects/${featuredSubject.slug}`} className="subject-feature">
                <div>
                  <h3>{featuredSubject.name}</h3>
                  <p>{featuredSubject.description ?? `Explore ${featuredSubject.name} tutors on ${siteConfig.brandName}.`}</p>
                </div>
                <span className="btn-text on-ink">
                  Explore {featuredSubject.name} tutors <span aria-hidden="true">→</span>
                </span>
              </Link>
              <div>
                <div className="subject-strip">
                  {otherSubjects.map((s) => (
                    <Link key={s.id} to={`/subjects/${s.slug}`} className="subject-tile">
                      <span className="subject-icon" aria-hidden="true">
                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                          <circle cx="9" cy="9" r="6.5" stroke="currentColor" strokeWidth="1.5" />
                        </svg>
                      </span>
                      <span>{s.name}</span>
                    </Link>
                  ))}
                </div>
                <div className="subjects-foot">
                  <Link to="/subjects" className="btn-text">
                    View all subjects <span aria-hidden="true">→</span>
                  </Link>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* ---------- Education journey ---------- */}
      <section className="band band-paper">
        <div className="container">
          <div className="section-head">
            <span className="eyebrow center">Wherever they&rsquo;re starting from</span>
            <h2>Support across the whole school journey</h2>
          </div>
          <div className="journey-row">
            {levels.map((level) => (
              <div className="journey-card" key={level.id}>
                <div className="journey-stage">{level.name}</div>
                <h3>{level.stageHeadline}</h3>
                <p>{level.stageDescription}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ---------- Approved tutors ---------- */}
      <section className="band" id="tutors">
        <div className="container">
          <div className="tutors-head">
            <div className="section-head left">
              <span className="eyebrow">Approved tutors</span>
              <h2 style={{ marginTop: 'var(--space-3)' }}>A preview of how tutor profiles will look</h2>
              <p>Development fixtures for review only — real, approved tutors will replace these.</p>
            </div>
            <Link to="/tutors" className="btn-text">
              Browse all tutors <span aria-hidden="true">→</span>
            </Link>
          </div>
          <div className="tutor-grid">
            {featuredTutors === null
              ? Array.from({ length: 3 }).map((_, i) => <TutorCardSkeleton key={i} />)
              : featuredTutors.map((t) => <TutorCard key={t.id} tutor={t} isExample />)}
          </div>
        </div>
      </section>

      {/* ---------- Why matching / vetting ---------- */}
      <section className="band band-paper">
        <div className="container split">
          <div>
            <span className="eyebrow">Why matching, not just a list</span>
            <h2 style={{ margin: 'var(--space-3) 0 var(--space-6)' }}>Scrolling through tutor profiles isn&rsquo;t a strategy</h2>
            <div className="point">
              <div className="point-icon" aria-hidden="true">
                <svg width="19" height="19" viewBox="0 0 19 19" fill="none">
                  <path
                    d="M9.5 2l2.2 4.8 5.3.7-3.85 3.75.9 5.3-4.55-2.4-4.55 2.4.9-5.3L2 7.5l5.3-.7L9.5 2z"
                    stroke="currentColor"
                    strokeWidth="1.4"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>
              <div>
                <h4>We start with the problem, not the profile</h4>
                <p>What&rsquo;s actually difficult right now matters more than a long list of bios.</p>
              </div>
            </div>
            <div className="point">
              <div className="point-icon" aria-hidden="true">
                <svg width="19" height="19" viewBox="0 0 19 19" fill="none">
                  <path d="M3.5 9.5a6 6 0 1112 0 6 6 0 01-12 0z" stroke="currentColor" strokeWidth="1.4" />
                  <path d="M9.5 6.5v3l2 2" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
                </svg>
              </div>
              <div>
                <h4>Faster than browsing alone</h4>
                <p>We narrow things down before you have to make a decision.</p>
              </div>
            </div>
            <div className="point">
              <div className="point-icon" aria-hidden="true">
                <svg width="19" height="19" viewBox="0 0 19 19" fill="none">
                  <path d="M9.5 2.5l7 3v4c0 4.4-3 7-7 7s-7-2.6-7-7v-4l7-3z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
                </svg>
              </div>
              <div>
                <h4>Still your choice</h4>
                <p>Browse and pick directly whenever you&rsquo;d rather — matching is a shortcut, not the only door.</p>
              </div>
            </div>
          </div>
          <div className="panel">
            <h3>How tutors are approved</h3>
            <p>The same review applies before every profile is published.</p>
            <ul className="panel-checklist">
              {[
                'Applications reviewed by our team, not automatically listed',
                'Tutor applications are reviewed before a profile can be published',
                'A profile only goes live after approval — never automatically',
                'Verification badges shown only for checks actually completed',
              ].map((item) => (
                <li key={item}>
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                    <path d="M2 8l4 4 8-8" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  {item}
                </li>
              ))}
            </ul>
            <Link to="/safeguarding" className="btn btn-outline">
              Read our safeguarding approach
            </Link>
          </div>
        </div>
      </section>

      {/*
        Reviews section intentionally NOT mounted — no genuine reviews exist
        yet (Phase D §11). See src/components/ReviewsSection.tsx.
      */}

      {/* ---------- FAQ ---------- */}
      <section className="band band-paper" id="faq">
        <div className="container">
          <div className="section-head">
            <span className="eyebrow center">Questions</span>
            <h2>Before you get started</h2>
          </div>
          <Accordion items={FAQ_ITEMS} defaultOpenId="q1" />
        </div>
      </section>

      {/* ---------- Final CTA ---------- */}
      <section className="band">
        <div className="container">
          <div className="final-cta">
            <h2>Ready to find the right tutor?</h2>
            <p>Tell us what&rsquo;s needed and we&rsquo;ll take it from there — or browse tutors yourself if you&rsquo;d rather choose directly.</p>
            <div className="final-cta-ctas">
              <Link to="/find-a-tutor" className="btn btn-primary">
                Find My Tutor
              </Link>
              <Link to="/tutors" className="btn btn-outline">
                Browse Tutors
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
