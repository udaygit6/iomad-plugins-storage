import { Link } from 'react-router-dom';
import { PageMeta } from '../components/PageMeta';
import { siteConfig } from '../config/siteConfig';
import './ContentPage.css';

export function HowItWorksPage() {
  return (
    <>
      <PageMeta
        title={`How It Works — ${siteConfig.brandName}`}
        description="How tutor matching and tutor review works on the platform."
      />
      <div className="container content-page">
        <span className="eyebrow">How it works</span>
        <h1>From telling us what&rsquo;s needed to starting sessions</h1>
        <section>
          <h2>1. Tell us what&rsquo;s needed</h2>
          <p>Year group, subject, and what your child is finding difficult right now.</p>
        </section>
        <section>
          <h2>2. We identify a fit</h2>
          <p>We look for tutors whose subject and level experience matches what you&rsquo;ve told us, not just who&rsquo;s available first.</p>
        </section>
        <section>
          <h2>3. Review your match</h2>
          <p>We&rsquo;ll share tutors whose experience fits, so you can decide who to go with.</p>
        </section>
        <section>
          <h2>4. Start making progress</h2>
          <p>Sessions are held online, arranged directly between you and your tutor.</p>
        </section>
        <section>
          <h2>Prefer to choose yourself?</h2>
          <p>
            You don&rsquo;t have to go through matching at all — every approved tutor is also open to{' '}
            <Link to="/tutors" className="btn-text" style={{ padding: 0 }}>
              browse directly
            </Link>
            .
          </p>
        </section>
      </div>
    </>
  );
}
