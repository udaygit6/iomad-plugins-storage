import { PageMeta } from '../components/PageMeta';
import { siteConfig } from '../config/siteConfig';
import './ContentPage.css';

export function LegalDraftPage({ title, intro }: { title: string; intro: string }) {
  return (
    <>
      <PageMeta title={`${title} — ${siteConfig.brandName}`} description={`${title} (draft) for ${siteConfig.brandName}.`} />
      <div className="container content-page">
        <span className="eyebrow">Legal</span>
        <h1>{title}</h1>
        <p className="lede">{intro}</p>
        <div className="legal-draft-notice">
          <strong>Draft — requires legal review before production.</strong> This page is a placeholder structure, not
          finalised legal text. It will be reviewed by a solicitor and updated with confirmed company and policy
          details before launch.
        </div>
      </div>
    </>
  );
}
