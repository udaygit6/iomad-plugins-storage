import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { PageMeta } from '../components/PageMeta';
import { TutorResultsSection } from '../components/tutor/TutorResultsSection';
import { subjectService } from '../services/subjects/SubjectService';
import type { EducationLevel } from '../domain/models/types';
import { siteConfig } from '../config/siteConfig';
import './LandingWithResults.css';

type LoadState = { status: 'loading' } | { status: 'not-found' } | { status: 'ready'; level: EducationLevel };

export function LevelPage() {
  const { level: levelSlug } = useParams<{ level: string }>();
  const [state, setState] = useState<LoadState>({ status: 'loading' });

  useEffect(() => {
    if (!levelSlug) return;
    let cancelled = false;
    subjectService.listEducationLevels().then((levels) => {
      if (cancelled) return;
      const level = levels.find((l) => l.slug === levelSlug);
      setState(level ? { status: 'ready', level } : { status: 'not-found' });
    });
    return () => {
      cancelled = true;
    };
  }, [levelSlug]);

  if (state.status === 'loading') return <div className="container" style={{ padding: 'var(--space-9) 0' }} />;

  if (state.status === 'not-found') {
    return (
      <div className="container" style={{ padding: 'var(--space-9) 0', textAlign: 'center' }}>
        <PageMeta title={`Stage not found — ${siteConfig.brandName}`} description="This education stage could not be found." />
        <h1>We couldn&rsquo;t find that stage</h1>
        <Link to="/tutors" className="btn btn-primary" style={{ marginTop: 'var(--space-6)', display: 'inline-flex' }}>
          Browse all tutors
        </Link>
      </div>
    );
  }

  const { level } = state;

  return (
    <>
      <PageMeta
        title={`${level.name} tutors — ${siteConfig.brandName}`}
        description={`Find a reviewed ${level.name} tutor. ${level.stageDescription}`}
      />
      <div className="container landing-with-results">
        <span className="eyebrow">Education stage</span>
        <h1 style={{ marginTop: 'var(--space-3)' }}>{level.name} tutors</h1>
        <p className="lede" style={{ marginTop: 'var(--space-3)' }}>
          <strong style={{ color: 'var(--color-ink-900)' }}>{level.stageHeadline}.</strong> {level.stageDescription}
        </p>
        <div style={{ marginTop: 'var(--space-7)' }}>
          <TutorResultsSection filters={{ educationLevelSlug: level.slug }} />
        </div>
      </div>
    </>
  );
}
