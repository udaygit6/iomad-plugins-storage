import { Link } from 'react-router-dom';
import { Header } from '../components/layout/Header';
import { Footer } from '../components/layout/Footer';
import { PageMeta } from '../components/PageMeta';
import { siteConfig } from '../config/siteConfig';

export function NotFoundPage() {
  return (
    <>
      <PageMeta title={`Page not found — ${siteConfig.brandName}`} description="This page could not be found." />
      <Header />
      <main id="main-content">
        <div className="container" style={{ padding: 'var(--space-9) 0', textAlign: 'center', minHeight: '40vh' }}>
          <span className="eyebrow center">404</span>
          <h1 style={{ marginTop: 'var(--space-3)' }}>We couldn&rsquo;t find that page</h1>
          <p className="lede" style={{ margin: '0 auto', marginTop: 'var(--space-4)' }}>
            The tutor, subject, or page you&rsquo;re looking for may have moved.
          </p>
          <Link to="/" className="btn btn-primary" style={{ marginTop: 'var(--space-6)', display: 'inline-flex' }}>
            Back to homepage
          </Link>
        </div>
      </main>
      <Footer />
    </>
  );
}
