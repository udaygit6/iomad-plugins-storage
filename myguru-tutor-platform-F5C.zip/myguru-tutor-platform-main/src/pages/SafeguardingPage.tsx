import { Link } from 'react-router-dom';
import { PageMeta } from '../components/PageMeta';
import { siteConfig } from '../config/siteConfig';
import './ContentPage.css';

export function SafeguardingPage() {
  return (
    <>
      <PageMeta title={`Safeguarding — ${siteConfig.brandName}`} description="How tutor applications are reviewed and our safeguarding-first approach." />
      <div className="container content-page">
        <span className="eyebrow">Safeguarding</span>
        <h1>A safeguarding-first approach to tutor review</h1>
        <p className="lede">
          This platform is designed with student safety as a starting point, not an afterthought. Here&rsquo;s what that
          means in practice today, and what&rsquo;s still being finalised.
        </p>
        <section>
          <h2>What happens before a tutor is listed</h2>
          <ul>
            <li>Every tutor submits an application — nobody can list themselves directly.</li>
            <li>Applications are reviewed by our team before a profile can be published.</li>
            <li>A profile only goes live after that review — never automatically.</li>
          </ul>
        </section>
        <section>
          <h2>Verification badges</h2>
          <p>
            Where a profile shows a verification badge (for example, &ldquo;Qualification checked&rdquo;), that badge is
            only ever shown once the corresponding check has genuinely been completed. We don&rsquo;t use a generic
            &ldquo;Verified&rdquo; label that could imply more checking happened than actually did.
          </p>
        </section>
        <section>
          <h2>Still being finalised</h2>
          <p>
            Our full vetting policy — including background-check requirements — is still being established, and we won&rsquo;t
            publish specific claims about it (such as DBS status) until that process is confirmed and genuinely in place.
            This page will be updated once that policy is finalised.
          </p>
        </section>
        <section>
          <h2>Reporting a concern</h2>
          <p>
            If you have a safeguarding concern about a tutor or the platform, please get in touch through our{' '}
            <Link to="/contact" style={{ textDecoration: 'underline' }}>
              contact page
            </Link>
            .
          </p>
        </section>
      </div>
    </>
  );
}
