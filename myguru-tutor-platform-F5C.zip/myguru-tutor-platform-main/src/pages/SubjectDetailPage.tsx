import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { PageMeta } from '../components/PageMeta';
import { TutorResultsSection } from '../components/tutor/TutorResultsSection';
import { subjectService } from '../services/subjects/SubjectService';
import type { Subject } from '../domain/models/types';
import { siteConfig } from '../config/siteConfig';
import './LandingWithResults.css';

type LoadState = { status: 'loading' } | { status: 'not-found' } | { status: 'ready'; subject: Subject };

export function SubjectDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const [state, setState] = useState<LoadState>({ status: 'loading' });

  useEffect(() => {
    if (!slug) return;
    let cancelled = false;
    subjectService.listSubjects().then((subjects) => {
      if (cancelled) return;
      const subject = subjects.find((s) => s.slug === slug);
      setState(subject ? { status: 'ready', subject } : { status: 'not-found' });
    });
    return () => {
      cancelled = true;
    };
  }, [slug]);

  if (state.status === 'loading') return <div className="container" style={{ padding: 'var(--space-9) 0' }} />;

  if (state.status === 'not-found') {
    return (
      <div className="container" style={{ padding: 'var(--space-9) 0', textAlign: 'center' }}>
        <PageMeta title={`Subject not found — ${siteConfig.brandName}`} description="This subject could not be found." />
        <h1>We couldn&rsquo;t find that subject</h1>
        <Link to="/subjects" className="btn btn-primary" style={{ marginTop: 'var(--space-6)', display: 'inline-flex' }}>
          View all subjects
        </Link>
      </div>
    );
  }

  const { subject } = state;

  return (
    <>
      <PageMeta
        title={`${subject.name} tutors — ${siteConfig.brandName}`}
        description={`Find a reviewed ${subject.name} tutor, Primary through A-Level.`}
      />
      <div className="container landing-with-results">
        <span className="eyebrow">Subject</span>
        <h1 style={{ marginTop: 'var(--space-3)' }}>{subject.name} tutors</h1>
        {subject.description && (
          <p className="lede" style={{ marginTop: 'var(--space-3)' }}>
            {subject.description}
          </p>
        )}
        <div style={{ marginTop: 'var(--space-7)' }}>
          <TutorResultsSection filters={{ subjectSlug: subject.slug }} />
        </div>
      </div>
    </>
  );
}
