import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { PageMeta } from '../components/PageMeta';
import { subjectService } from '../services/subjects/SubjectService';
import type { Subject } from '../domain/models/types';
import { siteConfig } from '../config/siteConfig';
import './SubjectsPage.css';

export function SubjectsPage() {
  const [subjects, setSubjects] = useState<Subject[] | null>(null);

  useEffect(() => {
    subjectService.listSubjects().then(setSubjects);
  }, []);

  return (
    <>
      <PageMeta
        title={`Subjects — ${siteConfig.brandName}`}
        description="Browse tutoring by subject, Primary through A-Level."
      />
      <div className="container subjects-page">
        <span className="eyebrow">All subjects</span>
        <h1 style={{ marginTop: 'var(--space-3)' }}>Find a tutor by subject</h1>
        <div className="subjects-hub-grid">
          {subjects === null
            ? Array.from({ length: 8 }).map((_, i) => <div key={i} className="subject-hub-skeleton" />)
            : subjects.map((s) => (
                <Link key={s.id} to={`/subjects/${s.slug}`} className="subject-hub-card">
                  <span>{s.name}</span>
                  {s.description && <p>{s.description}</p>}
                </Link>
              ))}
        </div>
      </div>
    </>
  );
}
