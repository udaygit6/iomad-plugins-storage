import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { PageMeta } from '../components/PageMeta';
import { Tag, VerificationBadge } from '../components/ui/Badge';
import { RequestTutorDrawer } from '../components/tutor/RequestTutorDrawer';
import { useAvailabilityLabel } from '../hooks/useAvailabilityLabel';
import { tutorDiscoveryService } from '../services/tutors/TutorDiscoveryService';
import type { TutorProfile } from '../domain/models/types';
import { siteConfig } from '../config/siteConfig';
import './TutorProfilePage.css';

type LoadState = { status: 'loading' } | { status: 'not-found' } | { status: 'ready'; tutor: TutorProfile };

export function TutorProfilePage() {
  const { slug } = useParams<{ slug: string }>();
  const [state, setState] = useState<LoadState>({ status: 'loading' });
  const [drawerOpen, setDrawerOpen] = useState(false);

  useEffect(() => {
    if (!slug) return;
    let cancelled = false;
    setState({ status: 'loading' });
    tutorDiscoveryService.getBySlug(slug).then((tutor) => {
      if (cancelled) return;
      setState(tutor ? { status: 'ready', tutor } : { status: 'not-found' });
    });
    return () => {
      cancelled = true;
    };
  }, [slug]);

  const availabilityLabel = useAvailabilityLabel(state.status === 'ready' ? state.tutor.acceptingStudents : false);

  if (state.status === 'loading') {
    return (
      <div className="container" style={{ padding: 'var(--space-9) 0' }}>
        <div className="profile-skeleton" aria-busy="true" aria-live="polite" />
      </div>
    );
  }

  if (state.status === 'not-found') {
    return (
      <div className="container" style={{ padding: 'var(--space-9) 0', textAlign: 'center' }}>
        <PageMeta title={`Tutor not found — ${siteConfig.brandName}`} description="This tutor profile could not be found." />
        <h1>We couldn&rsquo;t find that tutor</h1>
        <p className="lede" style={{ margin: '0 auto', marginTop: 'var(--space-3)' }}>
          This profile may have been unpublished, or the link may be out of date.
        </p>
        <Link to="/tutors" className="btn btn-primary" style={{ marginTop: 'var(--space-6)', display: 'inline-flex' }}>
          Browse all tutors
        </Link>
      </div>
    );
  }

  const { tutor } = state;

  return (
    <>
      <PageMeta
        title={`${tutor.publicDisplayName} — ${tutor.headline} — ${siteConfig.brandName}`}
        description={`${tutor.publicDisplayName}: ${tutor.headline}. ${tutor.experienceSummary}`}
      />
      <div className="container profile-page">
        <div className="profile-hero">
          <div className="profile-photo">
            <svg viewBox="0 0 200 200" preserveAspectRatio="xMidYMax slice" role="img" aria-label="Illustrated tutor placeholder — not a real photograph">
              <rect width="200" height="200" fill="var(--color-paper-50)" />
              <path
                d="M100 40c-24 0-38 18-38 40 0 16 7 27 15 33-28 9-52 27-58 60h162c-6-33-30-51-58-60 8-6 15-17 15-33 0-22-13-40-38-40z"
                fill="url(#profile-g)"
              />
              <defs>
                <linearGradient id="profile-g" x1="40" y1="40" x2="160" y2="200">
                  <stop stopColor="var(--color-gold-300)" />
                  <stop offset="1" stopColor="var(--color-ink-900)" />
                </linearGradient>
              </defs>
            </svg>
          </div>
          <div className="profile-summary">
            <span className="example-tag" style={{ position: 'static', display: 'inline-block', marginBottom: 'var(--space-3)' }}>
              Example profile
            </span>
            <h1>{tutor.publicDisplayName}</h1>
            <p className="profile-headline">{tutor.headline}</p>
            <div className="tutor-tags" style={{ margin: 'var(--space-3) 0' }}>
              {tutor.subjects.map((s) => (
                <Tag key={s.id}>{s.name}</Tag>
              ))}
              <Tag>{tutor.educationLevels.map((l) => l.name).join(' · ')}</Tag>
            </div>
            {tutor.publicVerificationBadges.length > 0 && (
              <div className="verify-row">
                {tutor.publicVerificationBadges.map((badge) => (
                  <VerificationBadge key={badge} type={badge} />
                ))}
              </div>
            )}
            <p className="profile-availability">
              <i className="avail-indicator" data-available={tutor.acceptingStudents} />
              {availabilityLabel}
            </p>
            <button className="btn btn-primary profile-cta-desktop" onClick={() => setDrawerOpen(true)}>
              Request this tutor
            </button>
          </div>
        </div>

        <div className="profile-content">
          <section>
            <h2>About</h2>
            <p>{tutor.bio}</p>
          </section>
          <section>
            <h2>Teaching approach</h2>
            <p>{tutor.teachingApproach}</p>
          </section>
          <section>
            <h2>Experience</h2>
            <p>{tutor.experienceSummary}</p>
          </section>
          {tutor.qualificationsSummary.length > 0 && (
            <section>
              <h2>Qualifications</h2>
              <ul className="plain-list">
                {tutor.qualificationsSummary.map((q) => (
                  <li key={q}>{q}</li>
                ))}
              </ul>
            </section>
          )}
          {tutor.languages.length > 0 && (
            <section>
              <h2>Languages</h2>
              <p>{tutor.languages.join(', ')}</p>
            </section>
          )}
        </div>
      </div>

      {/* Sticky mobile CTA — doesn't block content, only appears on small screens (see CSS) */}
      <div className="profile-sticky-cta">
        <button className="btn btn-primary" style={{ width: '100%' }} onClick={() => setDrawerOpen(true)}>
          Request this tutor
        </button>
      </div>

      <RequestTutorDrawer open={drawerOpen} onClose={() => setDrawerOpen(false)} tutorName={tutor.publicDisplayName} tutorSlug={tutor.slug} />
    </>
  );
}
