import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { PageMeta } from '../components/PageMeta';
import { Drawer } from '../components/ui/Drawer';
import { TutorFilterControls } from '../components/tutor/TutorFilterControls';
import { TutorResultsSection } from '../components/tutor/TutorResultsSection';
import { subjectService } from '../services/subjects/SubjectService';
import { filtersFromSearchParams, searchParamsFromFilters } from '../services/tutors/TutorDiscoveryService';
import type { Subject, EducationLevel, TutorFilters } from '../domain/models/types';
import { siteConfig } from '../config/siteConfig';
import './TutorsPage.css';

export function TutorsPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [levels, setLevels] = useState<EducationLevel[]>([]);
  const [drawerOpen, setDrawerOpen] = useState(false);

  const filters = filtersFromSearchParams(searchParams);

  useEffect(() => {
    subjectService.listSubjects().then(setSubjects);
    subjectService.listEducationLevels().then(setLevels);
  }, []);

  function applyFilters(next: TutorFilters) {
    setSearchParams(searchParamsFromFilters(next));
  }

  const subjectName = subjects.find((s) => s.slug === filters.subjectSlug)?.name;
  const levelName = levels.find((l) => l.slug === filters.educationLevelSlug)?.name;
  const activeChips: { key: keyof TutorFilters; label: string }[] = [
    ...(subjectName ? [{ key: 'subjectSlug' as const, label: subjectName }] : []),
    ...(levelName ? [{ key: 'educationLevelSlug' as const, label: levelName }] : []),
    ...(filters.acceptingStudentsOnly ? [{ key: 'acceptingStudentsOnly' as const, label: 'Taking students' }] : []),
  ];

  function removeChip(key: keyof TutorFilters) {
    applyFilters({ ...filters, [key]: undefined });
  }

  return (
    <>
      <PageMeta
        title={`Browse Tutors — ${siteConfig.brandName}`}
        description="Browse reviewed online tutors by subject and education level, Primary through A-Level."
      />
      <div className="container tutors-page">
        <div className="tutors-page-head">
          <div>
            <span className="eyebrow">Browse tutors</span>
            <h1 style={{ marginTop: 'var(--space-3)' }}>Find and choose a tutor yourself</h1>
            <p className="lede" style={{ marginTop: 'var(--space-3)' }}>
              Prefer a guided match instead?{' '}
              <Link to="/find-a-tutor" className="btn-text" style={{ padding: 0 }}>
                Get matched
              </Link>
              .
            </p>
          </div>
          <button className="btn btn-outline filter-toggle-btn" onClick={() => setDrawerOpen(true)}>
            Filters {activeChips.length > 0 && `(${activeChips.length})`}
          </button>
        </div>

        {activeChips.length > 0 && (
          <div className="filter-chips">
            {activeChips.map((chip) => (
              <span className="filter-chip" key={chip.key}>
                {chip.label}
                <button aria-label={`Remove ${chip.label} filter`} onClick={() => removeChip(chip.key)}>
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                    <path d="M2 2l8 8M10 2l-8 8" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
                  </svg>
                </button>
              </span>
            ))}
          </div>
        )}

        <div className="tutors-layout">
          <aside className="filter-sidebar" aria-label="Filter tutors">
            <h3>Filters</h3>
            <TutorFilterControls subjects={subjects} levels={levels} filters={filters} onChange={applyFilters} idPrefix="desktop" />
          </aside>

          <div>
            <TutorResultsSection filters={filters} />
          </div>
        </div>
      </div>

      <Drawer open={drawerOpen} onClose={() => setDrawerOpen(false)} labelledBy="filter-drawer-heading">
        <div className="drawer-header">
          <span id="filter-drawer-heading" style={{ fontWeight: 700, fontSize: 18 }}>
            Filters
          </span>
          <button className="drawer-close" onClick={() => setDrawerOpen(false)} aria-label="Close filters">
            ×
          </button>
        </div>
        <TutorFilterControls subjects={subjects} levels={levels} filters={filters} onChange={applyFilters} idPrefix="mobile" />
        <button className="btn btn-primary" style={{ width: '100%', marginTop: 'var(--space-5)' }} onClick={() => setDrawerOpen(false)}>
          Show results
        </button>
      </Drawer>
    </>
  );
}
