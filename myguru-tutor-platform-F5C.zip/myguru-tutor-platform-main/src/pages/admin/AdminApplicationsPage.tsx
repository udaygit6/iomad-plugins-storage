import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { adminApplicationsService } from '../../services/admin/AdminApplicationsService';
import { adminTutorProfilesService } from '../../services/admin/AdminTutorProfilesService';
import type { TutorApplication, TutorApplicationStatus } from '../../domain/models/types';

const STATUS_TONE: Record<TutorApplicationStatus, 'default' | 'positive' | 'warning' | 'negative'> = {
  draft: 'default',
  submitted: 'default',
  under_review: 'warning',
  more_information_required: 'warning',
  approved: 'positive',
  rejected: 'negative',
};

const STATUS_LABEL: Record<TutorApplicationStatus, string> = {
  draft: 'Draft',
  submitted: 'Submitted',
  under_review: 'Under review',
  more_information_required: 'More info requested',
  approved: 'Approved',
  rejected: 'Rejected',
};

export function AdminApplicationsPage() {
  const navigate = useNavigate();
  const [applications, setApplications] = useState<TutorApplication[] | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [notes, setNotes] = useState('');
  const [actionPending, setActionPending] = useState(false);
  const [profileActionPending, setProfileActionPending] = useState(false);
  const [profileActionError, setProfileActionError] = useState<string | null>(null);

  function reload() {
    adminApplicationsService.list().then(setApplications);
  }

  useEffect(reload, []);

  const selected = applications?.find((a) => a.id === selectedId) ?? null;

  async function handleApprove() {
    if (!selected) return;
    setActionPending(true);
    await adminApplicationsService.approve(selected.id);
    setActionPending(false);
    reload();
  }

  async function handleReject() {
    if (!selected) return;
    setActionPending(true);
    await adminApplicationsService.reject(selected.id, notes || undefined);
    setActionPending(false);
    setNotes('');
    reload();
  }

  async function handleRequestInfo() {
    if (!selected || !notes.trim()) return;
    setActionPending(true);
    await adminApplicationsService.requestMoreInfo(selected.id, notes);
    setActionPending(false);
    setNotes('');
    reload();
  }

  async function handleCreateOrOpenProfile() {
    if (!selected) return;
    setProfileActionPending(true);
    setProfileActionError(null);
    try {
      const profile = await adminTutorProfilesService.createFromApplication(selected.id);
      navigate(`/admin/tutor-profiles?open=${profile.id}`);
    } catch (err) {
      setProfileActionError(err instanceof Error ? err.message : 'Unable to create a tutor profile right now.');
    } finally {
      setProfileActionPending(false);
    }
  }

  if (applications === null) return <p>Loading…</p>;

  return (
    <div>
      <table className="admin-table">
        <thead>
          <tr>
            <th>Applicant</th>
            <th>Subjects</th>
            <th>Status</th>
            <th>Submitted</th>
          </tr>
        </thead>
        <tbody>
          {applications.length === 0 ? (
            <tr className="empty-admin-row">
              <td colSpan={4}>No tutor applications yet. Submit one via /apply to see it appear here.</td>
            </tr>
          ) : (
            applications.map((app) => (
              <tr key={app.id} onClick={() => setSelectedId(app.id)} style={{ cursor: 'pointer', background: app.id === selectedId ? 'var(--color-paper-50)' : undefined }}>
                <td>{app.fullName}</td>
                <td>{app.subjectSlugs.join(', ') || '—'}</td>
                <td>
                  <span className="status-pill" data-tone={STATUS_TONE[app.status]}>
                    {STATUS_LABEL[app.status]}
                  </span>
                </td>
                <td>{app.submittedAt ? new Date(app.submittedAt).toLocaleDateString() : '—'}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>

      {selected && (
        <div className="admin-detail-panel">
          <dl>
            <dt>Email</dt>
            <dd>{selected.email}</dd>
            <dt>About</dt>
            <dd>{selected.aboutYou}</dd>
            <dt>Teaching experience</dt>
            <dd>{selected.teachingExperience}</dd>
            <dt>Education</dt>
            <dd>{selected.education}</dd>
            <dt>Qualifications (self-reported — not yet verified)</dt>
            <dd>{selected.qualifications.join(', ') || '—'}</dd>
            <dt>Education levels</dt>
            <dd>{selected.educationLevelSlugs.join(', ') || '—'}</dd>
            <dt>Teaching approach</dt>
            <dd>{selected.teachingApproach}</dd>
            <dt>Availability</dt>
            <dd>{selected.availabilityNotes}</dd>
            {selected.adminNotes && (
              <>
                <dt>Admin notes</dt>
                <dd>{selected.adminNotes}</dd>
              </>
            )}
          </dl>

          <div className="form-field" style={{ marginTop: 'var(--space-5)' }}>
            <label htmlFor="admin-notes">
              Notes <span className="optional-tag">(used for reject / request more info)</span>
            </label>
            <textarea id="admin-notes" className="form-textarea" value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>

          <div className="admin-actions">
            <button className="btn btn-primary btn-sm" onClick={handleApprove} disabled={actionPending}>
              Approve
            </button>
            <button className="btn btn-outline btn-sm" onClick={handleRequestInfo} disabled={actionPending || !notes.trim()}>
              Request more information
            </button>
            <button className="btn-text" onClick={handleReject} disabled={actionPending}>
              Reject
            </button>
          </div>

          {selected.status === 'approved' && (
            <div className="admin-actions" style={{ marginTop: 'var(--space-3)' }}>
              <button className="btn btn-outline btn-sm" onClick={handleCreateOrOpenProfile} disabled={profileActionPending}>
                {profileActionPending ? 'Working…' : 'Create / open tutor profile'}
              </button>
              {profileActionError && <span style={{ color: 'var(--color-error-600)', fontSize: 13 }}>{profileActionError}</span>}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
