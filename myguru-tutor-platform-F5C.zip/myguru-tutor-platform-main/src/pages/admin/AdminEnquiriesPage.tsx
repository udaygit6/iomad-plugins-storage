import { useEffect, useState } from 'react';
import { adminEnquiriesService } from '../../services/admin/AdminWorkflowServices';
import type { Enquiry, EnquiryStatus } from '../../domain/models/types';

const STATUS_OPTIONS: EnquiryStatus[] = ['new', 'in_progress', 'resolved'];

export function AdminEnquiriesPage() {
  const [enquiries, setEnquiries] = useState<Enquiry[] | null>(null);

  function reload() {
    adminEnquiriesService.list().then(setEnquiries);
  }
  useEffect(reload, []);

  async function handleStatusChange(id: string, status: EnquiryStatus) {
    await adminEnquiriesService.updateStatus(id, status);
    reload();
  }

  if (enquiries === null) return <p>Loading…</p>;

  return (
    <table className="admin-table">
      <thead>
        <tr>
          <th>From</th>
          <th>Message</th>
          <th>Related tutor</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        {enquiries.length === 0 ? (
          <tr className="empty-admin-row">
            <td colSpan={4}>No enquiries yet. Submit one via the Contact page or a tutor profile to see it appear here.</td>
          </tr>
        ) : (
          enquiries.map((enq) => (
            <tr key={enq.id}>
              <td>
                {enq.name}
                <br />
                <span style={{ color: 'var(--color-text-muted)', fontSize: 12.5 }}>{enq.email}</span>
              </td>
              <td style={{ maxWidth: 320 }}>{enq.message}</td>
              <td>{enq.relatedTutorSlug ?? '—'}</td>
              <td>
                <select
                  className="form-select"
                  style={{ padding: '6px 10px', fontSize: 13 }}
                  value={enq.status}
                  onChange={(e) => handleStatusChange(enq.id, e.target.value as EnquiryStatus)}
                >
                  {STATUS_OPTIONS.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </td>
            </tr>
          ))
        )}
      </tbody>
    </table>
  );
}
