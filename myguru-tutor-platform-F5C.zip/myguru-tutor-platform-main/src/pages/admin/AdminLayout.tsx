import { NavLink, Outlet } from 'react-router-dom';
import { PageMeta } from '../../components/PageMeta';
import { siteConfig } from '../../config/siteConfig';
import { useAdminAuth } from '../../features/admin-auth/useAdminAuth';
import './AdminLayout.css';

const ADMIN_LINKS = [
  { to: '/admin/applications', label: 'Tutor applications' },
  { to: '/admin/tutor-profiles', label: 'Tutor profiles' },
  { to: '/admin/matching-requests', label: 'Matching requests' },
  { to: '/admin/enquiries', label: 'Enquiries' },
  { to: '/admin/subjects', label: 'Subjects' },
  { to: '/admin/organisations', label: 'Organisations' },
];

export function AdminLayout() {
  const { email, signOut } = useAdminAuth();

  return (
    <>
      <PageMeta
        title={`Admin — ${siteConfig.brandName}`}
        description="Internal admin workflow."
        robots="noindex, nofollow"
      />
      <div className="container admin-shell">
        <div className="admin-warning" role="note">
          <strong>Staging environment.</strong> Data here is persisted in the staging Supabase database. Publishing a
          tutor profile here will make it publicly visible on this staging site — treat it as real, not a sandbox.
        </div>
        <div className="admin-head">
          <div>
            <span className="eyebrow">Admin</span>
            <h1 style={{ marginTop: 'var(--space-3)' }}>Review and manage platform activity</h1>
          </div>
          <div className="admin-identity">
            {email && <span className="admin-identity-email">{email}</span>}
            <button className="btn-text" onClick={() => signOut()}>
              Log out
            </button>
          </div>
        </div>
        <nav className="admin-nav" aria-label="Admin sections">
          {ADMIN_LINKS.map((link) => (
            <NavLink key={link.to} to={link.to} className="admin-nav-link">
              {link.label}
            </NavLink>
          ))}
        </nav>
        <div className="admin-content">
          <Outlet />
        </div>
      </div>
    </>
  );
}
