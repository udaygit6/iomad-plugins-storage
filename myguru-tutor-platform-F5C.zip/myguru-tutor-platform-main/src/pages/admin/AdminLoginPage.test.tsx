import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import { createMemoryRouter, RouterProvider } from 'react-router-dom';
import { AdminLoginPage } from './AdminLoginPage';
import * as useAdminAuthModule from '../../features/admin-auth/useAdminAuth';
import type { AdminAuthState } from '../../features/admin-auth/useAdminAuth';

function mockAuthState(overrides: Partial<AdminAuthState>) {
  vi.spyOn(useAdminAuthModule, 'useAdminAuth').mockReturnValue({
    status: 'unauthenticated',
    email: null,
    signIn: vi.fn(),
    signOut: vi.fn(),
    ...overrides,
  });
}

function renderLoginPage() {
  const router = createMemoryRouter(
    [
      { path: '/admin/login', element: <AdminLoginPage /> },
      { path: '/admin/applications', element: <div>Applications screen</div> },
    ],
    { initialEntries: ['/admin/login'] },
  );
  return render(<RouterProvider router={router} />);
}

describe('AdminLoginPage — authorized-admin redirect (E7 §15)', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('redirects an already-authorized admin straight to /admin/applications instead of showing the login form', () => {
    mockAuthState({ status: 'authorized', email: 'admin@example.com' });
    renderLoginPage();
    expect(screen.getByText('Applications screen')).toBeInTheDocument();
    expect(screen.queryByRole('heading', { name: /admin sign in/i })).not.toBeInTheDocument();
  });

  it('shows the login form for an unauthenticated visitor', () => {
    mockAuthState({ status: 'unauthenticated' });
    renderLoginPage();
    expect(screen.getByRole('heading', { name: /admin sign in/i })).toBeInTheDocument();
  });
});
