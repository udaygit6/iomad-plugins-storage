import { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { PageMeta } from '../../components/PageMeta';
import { useAdminAuth } from '../../features/admin-auth/useAdminAuth';
import { siteConfig } from '../../config/siteConfig';
import '../../components/forms/WizardShell.css';
import './AdminLoginPage.css';

export function AdminLoginPage() {
  const { status, signIn } = useAdminAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Already signed in and authorized — no reason to show the login form.
  if (status === 'authorized') {
    return <Navigate to="/admin/applications" replace />;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    const result = await signIn(email, password);
    setSubmitting(false);
    if (!result.ok) setError(result.error ?? 'Something went wrong. Please try again.');
  }

  return (
    <>
      <PageMeta title={`Admin sign in — ${siteConfig.brandName}`} description="Admin sign in." robots="noindex, nofollow" />
      <div className="container admin-login-page">
        <div className="wizard-shell admin-login-card">
          <div className="wizard-body" style={{ minHeight: 'auto' }}>
            <h1 className="admin-login-title">Admin sign in</h1>
            <p className="admin-login-note">Staging admin access. Accounts are provisioned manually — there is no self-service sign-up.</p>

            <form onSubmit={handleSubmit} noValidate>
              <div className="form-field">
                <label htmlFor="admin-email">Email</label>
                <input
                  id="admin-email"
                  type="email"
                  className="form-input"
                  autoComplete="username"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="form-field">
                <label htmlFor="admin-password">Password</label>
                <input
                  id="admin-password"
                  type="password"
                  className="form-input"
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              {error && <p className="form-error" role="alert">{error}</p>}
              <button
                type="submit"
                className="btn btn-primary"
                style={{ width: '100%' }}
                disabled={submitting}
                data-loading={submitting ? 'true' : undefined}
              >
                {submitting ? 'Signing in…' : 'Sign in'}
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
}
