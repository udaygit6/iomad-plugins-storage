import { useEffect, useState } from 'react';
import { adminMatchingRequestsService } from '../../services/admin/AdminWorkflowServices';
import type { MatchingRequest, MatchingRequestStatus } from '../../domain/models/types';

const STATUS_OPTIONS: MatchingRequestStatus[] = ['submitted', 'reviewing', 'matched', 'contacted', 'closed'];

const STATUS_TONE: Record<MatchingRequestStatus, 'default' | 'positive' | 'warning' | 'negative'> = {
  submitted: 'default',
  reviewing: 'warning',
  matched: 'positive',
  contacted: 'positive',
  closed: 'default',
};

export function AdminMatchingRequestsPage() {
  const [requests, setRequests] = useState<MatchingRequest[] | null>(null);

  function reload() {
    adminMatchingRequestsService.list().then(setRequests);
  }
  useEffect(reload, []);

  async function handleStatusChange(id: string, status: MatchingRequestStatus) {
    await adminMatchingRequestsService.updateStatus(id, status);
    reload();
  }

  if (requests === null) return <p>Loading…</p>;

  return (
    <table className="admin-table">
      <thead>
        <tr>
          <th>Student</th>
          <th>Subject</th>
          <th>Parent</th>
          <th>Status</th>
          <th>Suggested tutor</th>
        </tr>
      </thead>
      <tbody>
        {requests.length === 0 ? (
          <tr className="empty-admin-row">
            <td colSpan={5}>No matching requests yet. Submit one via /find-a-tutor to see it appear here.</td>
          </tr>
        ) : (
          requests.map((req) => (
            <tr key={req.id}>
              <td>
                {req.student.firstName} — {req.student.yearGroupLabel}
              </td>
              <td>{req.subjectSlug}</td>
              <td>
                {req.parent.name}
                <br />
                <span style={{ color: 'var(--color-text-muted)', fontSize: 12.5 }}>{req.parent.email}</span>
              </td>
              <td>
                <select
                  className="form-select"
                  style={{ padding: '6px 10px', fontSize: 13 }}
                  value={req.status}
                  onChange={(e) => handleStatusChange(req.id, e.target.value as MatchingRequestStatus)}
                >
                  {STATUS_OPTIONS.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
                <div style={{ marginTop: 4 }}>
                  <span className="status-pill" data-tone={STATUS_TONE[req.status]}>
                    {req.status}
                  </span>
                </div>
              </td>
              <td style={{ color: 'var(--color-text-muted)', fontSize: 12.5 }}>
                Recommendation tooling placeholder — not yet wired up.
              </td>
            </tr>
          ))
        )}
      </tbody>
    </table>
  );
}
