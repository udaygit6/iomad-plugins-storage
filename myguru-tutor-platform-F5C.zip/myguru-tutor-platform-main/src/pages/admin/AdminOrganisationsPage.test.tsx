import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { AdminOrganisationsPage } from './AdminOrganisationsPage';
import { adminOrganisationsService } from '../../services/admin/AdminOrganisationsService';
import type { Organisation, OrganisationCourse } from '../../repositories/interfaces';

const SHIKSHA: Organisation = {
  id: 'org-1',
  name: 'Shiksha Academy',
  type: 'unclassified',
  status: 'active',
  iomadCompanyId: '3',
  syncStatus: 'synced',
  lastSyncedAt: '2026-01-15T09:30:00Z',
  hasSyncIssue: false,
};

const WITH_ISSUE: Organisation = {
  id: 'org-2',
  name: 'Example Learning Co',
  type: 'unclassified',
  status: 'active',
  iomadCompanyId: '7',
  syncStatus: 'failed',
  lastSyncedAt: '2026-01-10T14:00:00Z',
  hasSyncIssue: true,
};

const JUPITER_MATHS: OrganisationCourse = {
  id: 'alloc-1',
  courseName: 'Jupiter Test Mathematics',
  iomadCourseId: '4',
  licensed: false,
  shared: false,
  validLengthDays: 0,
  warnExpireDays: 0,
  warnCompletionDays: 0,
  notifyPeriodDays: 0,
  syncStatus: 'synced',
  lastSyncedAt: '2026-01-15T09:30:00Z',
};

describe('AdminOrganisationsPage', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('shows a loading state before data resolves', () => {
    vi.spyOn(adminOrganisationsService, 'listAll').mockReturnValue(new Promise(() => {})); // never resolves
    render(<AdminOrganisationsPage />);
    expect(screen.getByText('Loading…')).toBeInTheDocument();
  });

  it('renders the exact required columns and Shiksha Academy\'s data once loaded', async () => {
    vi.spyOn(adminOrganisationsService, 'listAll').mockResolvedValue([SHIKSHA]);
    render(<AdminOrganisationsPage />);

    await waitFor(() => expect(screen.getByText('Shiksha Academy')).toBeInTheDocument());
    expect(screen.getByText('Organisation')).toBeInTheDocument();
    expect(screen.getByText('Type')).toBeInTheDocument();
    expect(screen.getByText('Iomad Company ID')).toBeInTheDocument();
    expect(screen.getByText('Sync Status')).toBeInTheDocument();
    expect(screen.getByText('Last Synced')).toBeInTheDocument();
    expect(screen.getByText('unclassified')).toBeInTheDocument();
    expect(screen.getByText('active')).toBeInTheDocument();
    expect(screen.getByText('3')).toBeInTheDocument();
    expect(screen.getByText('Synced')).toBeInTheDocument();
  });

  it('shows the empty state message when no organisations exist', async () => {
    vi.spyOn(adminOrganisationsService, 'listAll').mockResolvedValue([]);
    render(<AdminOrganisationsPage />);

    await waitFor(() =>
      expect(screen.getByText('No organisations have been synchronised yet.')).toBeInTheDocument(),
    );
  });

  it('shows a safe generic error state on failure — never a raw Supabase error message', async () => {
    vi.spyOn(adminOrganisationsService, 'listAll').mockRejectedValue(new Error('permission denied for table organisations'));
    render(<AdminOrganisationsPage />);

    await waitFor(() => expect(screen.getByRole('alert')).toBeInTheDocument());
    expect(screen.getByText(/something went wrong loading organisations/i)).toBeInTheDocument();
    expect(screen.queryByText(/permission denied/i)).not.toBeInTheDocument();
  });

  it('offers a retry action from the error state', async () => {
    const spy = vi
      .spyOn(adminOrganisationsService, 'listAll')
      .mockRejectedValueOnce(new Error('boom'))
      .mockResolvedValueOnce([SHIKSHA]);
    render(<AdminOrganisationsPage />);

    await waitFor(() => expect(screen.getByRole('alert')).toBeInTheDocument());
    await userEvent.click(screen.getByRole('button', { name: /retry/i }));

    await waitFor(() => expect(screen.getByText('Shiksha Academy')).toBeInTheDocument());
    expect(spy).toHaveBeenCalledTimes(2);
  });

  it('shows a safe "Sync issue" indicator when hasSyncIssue is true, without any raw error code/message', async () => {
    vi.spyOn(adminOrganisationsService, 'listAll').mockResolvedValue([WITH_ISSUE]);
    render(<AdminOrganisationsPage />);

    await waitFor(() => expect(screen.getByText('Example Learning Co')).toBeInTheDocument());
    expect(screen.getByText('Sync issue')).toBeInTheDocument();
    expect(screen.queryByText(/network_error|unknown_response_schema|error_code/i)).not.toBeInTheDocument();
  });

  it('never renders address, custom fields, or any raw upstream payload text', async () => {
    vi.spyOn(adminOrganisationsService, 'listAll').mockResolvedValue([SHIKSHA]);
    const { container } = render(<AdminOrganisationsPage />);
    await waitFor(() => expect(screen.getByText('Shiksha Academy')).toBeInTheDocument());

    const text = container.textContent ?? '';
    expect(text).not.toContain('custom1');
    expect(text).not.toContain('Staines Upon Thames');
    expect(text).not.toContain('Test data');
  });

  it('opens a detail panel with only the safe fields when a row is clicked, and closes it', async () => {
    vi.spyOn(adminOrganisationsService, 'listAll').mockResolvedValue([SHIKSHA]);
    vi.spyOn(adminOrganisationsService, 'listOrganisationCourses').mockResolvedValue([]);
    render(<AdminOrganisationsPage />);
    await waitFor(() => expect(screen.getByText('Shiksha Academy')).toBeInTheDocument());

    await userEvent.click(screen.getByText('Shiksha Academy'));

    expect(screen.getByText('Organisation type')).toBeInTheDocument();
    expect(screen.getByText('Sync status')).toBeInTheDocument();
    expect(screen.getByText('Last synced')).toBeInTheDocument();

    await userEvent.click(screen.getByRole('button', { name: /close/i }));
    expect(screen.queryByText('Organisation type')).not.toBeInTheDocument();
  });

  it('shows a dash for organisations with no Iomad mapping (iomadCompanyId/syncStatus null) rather than throwing', async () => {
    vi.spyOn(adminOrganisationsService, 'listAll').mockResolvedValue([
      { ...SHIKSHA, id: 'org-3', name: 'No Mapping Org', iomadCompanyId: null, syncStatus: null, lastSyncedAt: null },
    ]);
    render(<AdminOrganisationsPage />);

    await waitFor(() => expect(screen.getByText('No Mapping Org')).toBeInTheDocument());
    // Multiple dashes are expected (Iomad ID, sync status, last synced) — just confirm no crash and text present.
    expect(screen.getAllByText('—').length).toBeGreaterThan(0);
  });
});

describe('AdminOrganisationsPage — F5C course visibility', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  async function selectShiksha(): Promise<void> {
    render(<AdminOrganisationsPage />);
    await waitFor(() => expect(screen.getByText('Shiksha Academy')).toBeInTheDocument());
    await userEvent.click(screen.getByText('Shiksha Academy'));
  }

  it('shows a loading state for courses before the course list resolves', async () => {
    vi.spyOn(adminOrganisationsService, 'listAll').mockResolvedValue([SHIKSHA]);
    vi.spyOn(adminOrganisationsService, 'listOrganisationCourses').mockReturnValue(new Promise(() => {}));
    await selectShiksha();

    expect(screen.getByText('Loading courses…')).toBeInTheDocument();
  });

  it('shows exactly one course with all documented fields (the real Jupiter Test Mathematics fixture)', async () => {
    vi.spyOn(adminOrganisationsService, 'listAll').mockResolvedValue([SHIKSHA]);
    vi.spyOn(adminOrganisationsService, 'listOrganisationCourses').mockResolvedValue([JUPITER_MATHS]);
    await selectShiksha();

    await waitFor(() => expect(screen.getByText('Courses (1)')).toBeInTheDocument());
    expect(screen.getByText('Jupiter Test Mathematics')).toBeInTheDocument();
    expect(screen.getByText('Iomad Course ID')).toBeInTheDocument();
    expect(screen.getByText('4')).toBeInTheDocument();
    expect(screen.getByText('Allocation Status')).toBeInTheDocument();
    expect(screen.getAllByText('Synced').length).toBeGreaterThan(0);
    expect(screen.getByText('Licensed')).toBeInTheDocument();
    expect(screen.getByText('Shared')).toBeInTheDocument();
    expect(screen.getByText('Valid Length')).toBeInTheDocument();
    expect(screen.getByText('Expiry Warning')).toBeInTheDocument();
    expect(screen.getByText('Completion Warning')).toBeInTheDocument();
    expect(screen.getByText('Notify Period')).toBeInTheDocument();
  });

  it('shows multiple courses correctly, without hard-coding any single course name', async () => {
    vi.spyOn(adminOrganisationsService, 'listAll').mockResolvedValue([SHIKSHA]);
    vi.spyOn(adminOrganisationsService, 'listOrganisationCourses').mockResolvedValue([
      JUPITER_MATHS,
      { ...JUPITER_MATHS, id: 'alloc-2', courseName: 'Jupiter Test Science', iomadCourseId: '5' },
    ]);
    await selectShiksha();

    await waitFor(() => expect(screen.getByText('Courses (2)')).toBeInTheDocument());
    expect(screen.getByText('Jupiter Test Mathematics')).toBeInTheDocument();
    expect(screen.getByText('Jupiter Test Science')).toBeInTheDocument();
  });

  it('shows the "no courses synchronised yet" empty state for a zero-course organisation, without hard-coding a course name', async () => {
    vi.spyOn(adminOrganisationsService, 'listAll').mockResolvedValue([SHIKSHA]);
    vi.spyOn(adminOrganisationsService, 'listOrganisationCourses').mockResolvedValue([]);
    await selectShiksha();

    await waitFor(() =>
      expect(screen.getByText('No courses have been synchronised for this organisation yet.')).toBeInTheDocument(),
    );
  });

  it('shows a dash for a course with no Iomad mapping, rather than throwing', async () => {
    vi.spyOn(adminOrganisationsService, 'listAll').mockResolvedValue([SHIKSHA]);
    vi.spyOn(adminOrganisationsService, 'listOrganisationCourses').mockResolvedValue([
      { ...JUPITER_MATHS, iomadCourseId: null },
    ]);
    await selectShiksha();

    await waitFor(() => expect(screen.getByText('Jupiter Test Mathematics')).toBeInTheDocument());
    expect(screen.getAllByText('—').length).toBeGreaterThan(0);
  });

  it('shows "Stale" for a stale allocation', async () => {
    vi.spyOn(adminOrganisationsService, 'listAll').mockResolvedValue([SHIKSHA]);
    vi.spyOn(adminOrganisationsService, 'listOrganisationCourses').mockResolvedValue([
      { ...JUPITER_MATHS, syncStatus: 'stale' },
    ]);
    await selectShiksha();

    await waitFor(() => expect(screen.getByText('Stale')).toBeInTheDocument());
  });

  it('shows the safe label "Sync issue" (not "Failed") for a failed allocation', async () => {
    vi.spyOn(adminOrganisationsService, 'listAll').mockResolvedValue([SHIKSHA]);
    vi.spyOn(adminOrganisationsService, 'listOrganisationCourses').mockResolvedValue([
      { ...JUPITER_MATHS, syncStatus: 'failed' },
    ]);
    await selectShiksha();

    await waitFor(() => expect(screen.getByText('Sync issue')).toBeInTheDocument());
    expect(screen.queryByText('Failed')).not.toBeInTheDocument();
  });

  it('shows Yes/No for licensed and shared booleans, not raw true/false', async () => {
    vi.spyOn(adminOrganisationsService, 'listAll').mockResolvedValue([SHIKSHA]);
    vi.spyOn(adminOrganisationsService, 'listOrganisationCourses').mockResolvedValue([
      { ...JUPITER_MATHS, licensed: true, shared: false },
    ]);
    await selectShiksha();

    await waitFor(() => expect(screen.getByText('Jupiter Test Mathematics')).toBeInTheDocument());
    const yesEls = screen.getAllByText('Yes');
    const noEls = screen.getAllByText('No');
    expect(yesEls.length).toBeGreaterThan(0);
    expect(noEls.length).toBeGreaterThan(0);
    expect(screen.queryByText('true')).not.toBeInTheDocument();
    expect(screen.queryByText('false')).not.toBeInTheDocument();
  });

  it('displays "Not configured" rather than "0" when valid_length_days is 0', async () => {
    vi.spyOn(adminOrganisationsService, 'listAll').mockResolvedValue([SHIKSHA]);
    vi.spyOn(adminOrganisationsService, 'listOrganisationCourses').mockResolvedValue([
      { ...JUPITER_MATHS, validLengthDays: 0 },
    ]);
    await selectShiksha();

    await waitFor(() => expect(screen.getByText('Not configured')).toBeInTheDocument());
  });

  it('displays a real day count (not "Not configured") when valid_length_days is nonzero', async () => {
    vi.spyOn(adminOrganisationsService, 'listAll').mockResolvedValue([SHIKSHA]);
    vi.spyOn(adminOrganisationsService, 'listOrganisationCourses').mockResolvedValue([
      { ...JUPITER_MATHS, validLengthDays: 365 },
    ]);
    await selectShiksha();

    await waitFor(() => expect(screen.getByText('365 days')).toBeInTheDocument());
    expect(screen.queryByText('Not configured')).not.toBeInTheDocument();
  });

  it('shows a safe generic error state when the course list fails to load — never a raw Supabase error message', async () => {
    vi.spyOn(adminOrganisationsService, 'listAll').mockResolvedValue([SHIKSHA]);
    vi.spyOn(adminOrganisationsService, 'listOrganisationCourses').mockRejectedValue(
      new Error('permission denied for table organisation_course_allocations'),
    );
    await selectShiksha();

    await waitFor(() => expect(screen.getByText(/something went wrong loading courses/i)).toBeInTheDocument());
    expect(screen.queryByText(/permission denied/i)).not.toBeInTheDocument();
  });

  it('offers a retry action for the course-list error state', async () => {
    vi.spyOn(adminOrganisationsService, 'listAll').mockResolvedValue([SHIKSHA]);
    const spy = vi
      .spyOn(adminOrganisationsService, 'listOrganisationCourses')
      .mockRejectedValueOnce(new Error('boom'))
      .mockResolvedValueOnce([JUPITER_MATHS]);
    await selectShiksha();

    await waitFor(() => expect(screen.getByText(/something went wrong loading courses/i)).toBeInTheDocument());
    await userEvent.click(screen.getByRole('button', { name: /retry/i }));

    await waitFor(() => expect(screen.getByText('Jupiter Test Mathematics')).toBeInTheDocument());
    expect(spy).toHaveBeenCalledTimes(2);
  });

  it('switching from one organisation to another refreshes the course list (not stale data from the previous selection)', async () => {
    const OTHER_ORG: Organisation = { ...SHIKSHA, id: 'org-9', name: 'Jupiter Test Academy', iomadCompanyId: '4' };
    vi.spyOn(adminOrganisationsService, 'listAll').mockResolvedValue([SHIKSHA, OTHER_ORG]);
    const coursesSpy = vi.spyOn(adminOrganisationsService, 'listOrganisationCourses').mockImplementation(
      async (organisationId: string) => (organisationId === 'org-9' ? [JUPITER_MATHS] : []),
    );

    render(<AdminOrganisationsPage />);
    await waitFor(() => expect(screen.getByText('Shiksha Academy')).toBeInTheDocument());

    await userEvent.click(screen.getByText('Shiksha Academy'));
    await waitFor(() =>
      expect(screen.getByText('No courses have been synchronised for this organisation yet.')).toBeInTheDocument(),
    );

    await userEvent.click(screen.getByText('Jupiter Test Academy'));
    await waitFor(() => expect(screen.getByText('Courses (1)')).toBeInTheDocument());
    expect(screen.getByText('Jupiter Test Mathematics')).toBeInTheDocument();
    expect(coursesSpy).toHaveBeenCalledWith('org-1');
    expect(coursesSpy).toHaveBeenCalledWith('org-9');
  });

  it('never renders raw upstream fields (organisation_id, course_id, created_at) anywhere in the course detail', async () => {
    vi.spyOn(adminOrganisationsService, 'listAll').mockResolvedValue([SHIKSHA]);
    vi.spyOn(adminOrganisationsService, 'listOrganisationCourses').mockResolvedValue([JUPITER_MATHS]);
    const { container } = await (async () => {
      const result = render(<AdminOrganisationsPage />);
      await waitFor(() => expect(screen.getByText('Shiksha Academy')).toBeInTheDocument());
      await userEvent.click(screen.getByText('Shiksha Academy'));
      await waitFor(() => expect(screen.getByText('Jupiter Test Mathematics')).toBeInTheDocument());
      return result;
    })();

    const text = container.textContent ?? '';
    expect(text).not.toContain('organisation_id');
    expect(text).not.toContain('course_id');
    expect(text).not.toContain('created_at');
  });
});
