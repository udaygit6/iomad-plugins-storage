import { useEffect, useState } from 'react';
import { adminOrganisationsService } from '../../services/admin/AdminOrganisationsService';
import type {
  Organisation,
  OrganisationStatus,
  OrganisationSyncStatus,
  OrganisationCourse,
} from '../../repositories/interfaces';

/**
 * F4D/F5C — visibility only. Reads F4/F4C's already-synchronised
 * organisation + Iomad company mapping data, and F5B's already-persisted
 * organisation-course allocation data, via AdminOrganisationsService →
 * OrganisationRepository → SupabaseOrganisationRepository →
 * authenticated Supabase browser client → RLS admin-read policy (0015,
 * 0016). No Iomad call, no write, no create/edit/delete control, no sync
 * trigger. Route protection is inherited from the existing `/admin`
 * RequireAdmin + AdminLayout subtree in src/app/router.tsx — this
 * component adds no auth logic of its own.
 */

const STATUS_TONE: Record<OrganisationStatus, 'default' | 'positive' | 'warning' | 'negative'> = {
  active: 'positive',
  suspended: 'negative',
  inactive: 'default',
};

const SYNC_STATUS_TONE: Record<OrganisationSyncStatus, 'default' | 'positive' | 'warning' | 'negative'> = {
  synced: 'positive',
  pending: 'default',
  stale: 'warning',
  failed: 'negative',
};

const SYNC_STATUS_LABEL: Record<OrganisationSyncStatus, string> = {
  synced: 'Synced',
  pending: 'Pending',
  stale: 'Stale',
  failed: 'Failed',
};

/** F5C — course allocation status labels, per the brief: a failed
 * allocation reads "Sync issue" here (not "Failed") — a distinct,
 * intentionally different label set from the organisation-level one
 * above, which keeps "Failed" for that context. */
const COURSE_SYNC_STATUS_TONE: Record<OrganisationSyncStatus, 'default' | 'positive' | 'warning' | 'negative'> = {
  synced: 'positive',
  pending: 'default',
  stale: 'warning',
  failed: 'negative',
};

const COURSE_SYNC_STATUS_LABEL: Record<OrganisationSyncStatus, string> = {
  synced: 'Synced',
  pending: 'Pending',
  stale: 'Stale',
  failed: 'Sync issue',
};

function formatLastSynced(value: string | null): string {
  if (!value) return '—';
  return new Date(value).toLocaleString();
}

/** F5C: 0 valid_length_days means "no expiry configured", not "expires
 * immediately" — must never be displayed as a bare "0". */
function formatValidLength(days: number): string {
  return days === 0 ? 'Not configured' : `${days} day${days === 1 ? '' : 's'}`;
}

function formatDayCount(days: number): string {
  return `${days} day${days === 1 ? '' : 's'}`;
}

type LoadState = { kind: 'loading' } | { kind: 'error' } | { kind: 'loaded'; organisations: Organisation[] };

type CoursesLoadState =
  | { kind: 'loading' }
  | { kind: 'error' }
  | { kind: 'loaded'; courses: OrganisationCourse[] };

export function AdminOrganisationsPage() {
  const [state, setState] = useState<LoadState>({ kind: 'loading' });
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [coursesState, setCoursesState] = useState<CoursesLoadState | null>(null);

  function reload() {
    setState({ kind: 'loading' });
    adminOrganisationsService
      .listAll()
      .then((organisations) => setState({ kind: 'loaded', organisations }))
      .catch(() => setState({ kind: 'error' }));
  }

  useEffect(reload, []);

  function loadCourses(organisationId: string) {
    setCoursesState({ kind: 'loading' });
    adminOrganisationsService
      .listOrganisationCourses(organisationId)
      .then((courses) => setCoursesState({ kind: 'loaded', courses }))
      .catch(() => setCoursesState({ kind: 'error' }));
  }

  // Loads (or reloads) the selected organisation's courses whenever the
  // selection changes — switching from one organisation to another
  // refreshes the course list rather than showing stale data.
  useEffect(() => {
    if (!selectedId) {
      setCoursesState(null);
      return;
    }
    loadCourses(selectedId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedId]);

  if (state.kind === 'loading') return <p>Loading…</p>;

  if (state.kind === 'error') {
    return (
      <div className="admin-auth-state" role="alert">
        <p>Something went wrong loading organisations. Please try again.</p>
        <button className="btn-text" onClick={reload}>
          Retry
        </button>
      </div>
    );
  }

  const { organisations } = state;
  const selected = organisations.find((o) => o.id === selectedId) ?? null;

  return (
    <div>
      <p style={{ fontSize: 13.5, color: 'var(--color-text-muted)', marginBottom: 'var(--space-4)' }}>
        Read-only view of organisations synchronised from Iomad company records. This page does not create, edit, or
        trigger a new sync — see the F4C manual sync tooling for that.
      </p>
      <table className="admin-table">
        <thead>
          <tr>
            <th>Organisation</th>
            <th>Type</th>
            <th>Status</th>
            <th>Iomad Company ID</th>
            <th>Sync Status</th>
            <th>Last Synced</th>
          </tr>
        </thead>
        <tbody>
          {organisations.length === 0 ? (
            <tr className="empty-admin-row">
              <td colSpan={6}>No organisations have been synchronised yet.</td>
            </tr>
          ) : (
            organisations.map((org) => (
              <tr
                key={org.id}
                onClick={() => setSelectedId(org.id)}
                style={{ cursor: 'pointer' }}
                aria-selected={selectedId === org.id}
              >
                <td>
                  {org.name}
                  {org.hasSyncIssue && (
                    <span className="status-pill" data-tone="warning" style={{ marginLeft: 'var(--space-2)' }}>
                      Sync issue
                    </span>
                  )}
                </td>
                <td>{org.type}</td>
                <td>
                  <span className="status-pill" data-tone={STATUS_TONE[org.status]}>
                    {org.status}
                  </span>
                </td>
                <td>{org.iomadCompanyId ?? '—'}</td>
                <td>
                  {org.syncStatus ? (
                    <span className="status-pill" data-tone={SYNC_STATUS_TONE[org.syncStatus]}>
                      {SYNC_STATUS_LABEL[org.syncStatus]}
                    </span>
                  ) : (
                    '—'
                  )}
                </td>
                <td>{formatLastSynced(org.lastSyncedAt)}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>

      {selected && (
        <div className="admin-detail-panel" style={{ marginTop: 'var(--space-6)' }}>
          <h2 style={{ marginBottom: 'var(--space-3)' }}>{selected.name}</h2>

          <h3 style={{ marginBottom: 'var(--space-2)' }}>Overview</h3>
          <dl>
            <dt>Organisation type</dt>
            <dd>{selected.type}</dd>
            <dt>Organisation status</dt>
            <dd>{selected.status}</dd>
            <dt>Iomad company ID</dt>
            <dd>{selected.iomadCompanyId ?? '—'}</dd>
            <dt>Sync status</dt>
            <dd>{selected.syncStatus ? SYNC_STATUS_LABEL[selected.syncStatus] : '—'}</dd>
            <dt>Last synced</dt>
            <dd>{formatLastSynced(selected.lastSyncedAt)}</dd>
          </dl>

          <h3 style={{ marginTop: 'var(--space-5)', marginBottom: 'var(--space-2)' }}>
            Courses{coursesState?.kind === 'loaded' ? ` (${coursesState.courses.length})` : ''}
          </h3>

          {coursesState?.kind === 'loading' && <p>Loading courses…</p>}

          {coursesState?.kind === 'error' && (
            <div className="admin-auth-state" role="alert">
              <p>Something went wrong loading courses. Please try again.</p>
              <button className="btn-text" onClick={() => loadCourses(selected.id)}>
                Retry
              </button>
            </div>
          )}

          {coursesState?.kind === 'loaded' && coursesState.courses.length === 0 && (
            <p>No courses have been synchronised for this organisation yet.</p>
          )}

          {coursesState?.kind === 'loaded' && coursesState.courses.length > 0 && (
            <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
              {coursesState.courses.map((course) => (
                <li key={course.id} style={{ marginBottom: 'var(--space-4)' }}>
                  <h4 style={{ marginBottom: 'var(--space-2)' }}>{course.courseName}</h4>
                  <dl>
                    <dt>Iomad Course ID</dt>
                    <dd>{course.iomadCourseId ?? '—'}</dd>
                    <dt>Allocation Status</dt>
                    <dd>
                      <span className="status-pill" data-tone={COURSE_SYNC_STATUS_TONE[course.syncStatus]}>
                        {COURSE_SYNC_STATUS_LABEL[course.syncStatus]}
                      </span>
                    </dd>
                    <dt>Licensed</dt>
                    <dd>{course.licensed ? 'Yes' : 'No'}</dd>
                    <dt>Shared</dt>
                    <dd>{course.shared ? 'Yes' : 'No'}</dd>
                    <dt>Valid Length</dt>
                    <dd>{formatValidLength(course.validLengthDays)}</dd>
                    <dt>Expiry Warning</dt>
                    <dd>{formatDayCount(course.warnExpireDays)}</dd>
                    <dt>Completion Warning</dt>
                    <dd>{formatDayCount(course.warnCompletionDays)}</dd>
                    <dt>Notify Period</dt>
                    <dd>{formatDayCount(course.notifyPeriodDays)}</dd>
                  </dl>
                </li>
              ))}
            </ul>
          )}

          <button
            className="btn-text"
            onClick={() => {
              setSelectedId(null);
            }}
          >
            Close
          </button>
        </div>
      )}
    </div>
  );
}
