import { describe, it, expect, vi, beforeEach } from 'vitest';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { render, screen } from '@testing-library/react';
import { createMemoryRouter, RouterProvider } from 'react-router-dom';
import { RequireAdmin } from '../../features/admin-auth/RequireAdmin';
import { AdminOrganisationsPage } from './AdminOrganisationsPage';
import { AdminLayout } from './AdminLayout';
import { adminOrganisationsService } from '../../services/admin/AdminOrganisationsService';
import * as useAdminAuthModule from '../../features/admin-auth/useAdminAuth';
import type { AdminAuthState } from '../../features/admin-auth/useAdminAuth';

function mockAuthState(overrides: Partial<AdminAuthState>) {
  vi.spyOn(useAdminAuthModule, 'useAdminAuth').mockReturnValue({
    status: 'loading',
    email: null,
    signIn: vi.fn(),
    signOut: vi.fn(),
    ...overrides,
  });
}

function renderGuardedOrganisationsPage() {
  const router = createMemoryRouter(
    [
      { path: '/admin/login', element: <div>Login page</div> },
      {
        element: <RequireAdmin />,
        children: [
          {
            element: <AdminLayout />,
            children: [{ path: '/admin/organisations', element: <AdminOrganisationsPage /> }],
          },
        ],
      },
    ],
    { initialEntries: ['/admin/organisations'] },
  );
  return render(<RouterProvider router={router} />);
}

describe('AdminOrganisationsPage — admin-only route protection (F4D)', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('does not render organisation data for an unauthenticated visitor — redirected to login instead', () => {
    mockAuthState({ status: 'unauthenticated' });
    renderGuardedOrganisationsPage();
    expect(screen.getByText('Login page')).toBeInTheDocument();
    expect(screen.queryByText('Organisations')).not.toBeInTheDocument();
  });

  it('does not render organisation data for an authenticated non-admin — shown the existing "Not authorized" screen instead', () => {
    mockAuthState({ status: 'unauthorized', email: 'notadmin@example.com' });
    renderGuardedOrganisationsPage();
    expect(screen.getByText('Not authorized')).toBeInTheDocument();
  });

  it('never calls the organisations service while access is loading or denied — no data fetch happens before authorization', () => {
    const listAllSpy = vi.spyOn(adminOrganisationsService, 'listAll').mockResolvedValue([]);
    const listCoursesSpy = vi.spyOn(adminOrganisationsService, 'listOrganisationCourses').mockResolvedValue([]);
    mockAuthState({ status: 'loading' });
    renderGuardedOrganisationsPage();
    expect(listAllSpy).not.toHaveBeenCalled();
    expect(listCoursesSpy).not.toHaveBeenCalled();
  });

  it('renders the Organisations admin content, including its nav link, once authorized', async () => {
    vi.spyOn(adminOrganisationsService, 'listAll').mockResolvedValue([]);
    mockAuthState({ status: 'authorized', email: 'admin@example.com' });
    renderGuardedOrganisationsPage();

    // The nav link comes from AdminLayout, which wraps this route exactly
    // as every other /admin/* page does.
    expect(await screen.findByRole('link', { name: 'Organisations' })).toBeInTheDocument();
  });
});

describe('Admin nav — Organisations link (F4D)', () => {
  it('AdminLayout includes an Organisations nav link pointing at /admin/organisations', () => {
    const source = readFileSync(join(__dirname, 'AdminLayout.tsx'), 'utf-8');
    expect(source).toContain("{ to: '/admin/organisations', label: 'Organisations' }");
  });
});

describe('Router — no public route exposes organisation data (F4D)', () => {
  it('/admin/organisations is nested inside the RequireAdmin + AdminLayout admin subtree, not a top-level public route', () => {
    const source = readFileSync(join(__dirname, '..', '..', 'app', 'router.tsx'), 'utf-8');

    // Only look at the actual route tree, not the import statements above
    // it (an import line naturally contains the component name and would
    // otherwise produce a false failure here).
    const routeTreeStart = source.indexOf('createBrowserRouter([');
    expect(routeTreeStart).toBeGreaterThan(-1);
    const routeTree = source.slice(routeTreeStart);

    const adminBlockStart = routeTree.indexOf("path: 'admin'");
    expect(adminBlockStart).toBeGreaterThan(-1);
    const adminBlock = routeTree.slice(adminBlockStart);
    expect(adminBlock).toContain("path: 'organisations', element: <AdminOrganisationsPage />");

    const publicRouteTreeBlock = routeTree.slice(0, adminBlockStart);
    expect(publicRouteTreeBlock).not.toContain('AdminOrganisationsPage');
  });

  it('AdminOrganisationsPage is used as JSX exactly once in the router (single admin-only mount point)', () => {
    const source = readFileSync(join(__dirname, '..', '..', 'app', 'router.tsx'), 'utf-8');
    const jsxUsages = source.match(/<AdminOrganisationsPage\s*\/>/g) ?? [];
    expect(jsxUsages.length).toBe(1);
  });
});

describe('F5C — no Iomad call from this page/repository', () => {
  it('AdminOrganisationsPage.tsx never references an Iomad wsfunction, token, or gateway import (the "Iomad Course ID" UI label is expected and fine — this checks for actual API/token usage, not the word)', () => {
    const source = readFileSync(join(__dirname, 'AdminOrganisationsPage.tsx'), 'utf-8');
    expect(source).not.toMatch(/block_iomad_company_admin_/);
    expect(source).not.toMatch(/IOMAD_SERVICE_TOKEN/);
    expect(source).not.toMatch(/IomadRestGateway|IomadGateway|createIomadGateway/);
  });

  it('SupabaseOrganisationRepository.ts never references Iomad or a Moodle/Iomad wsfunction — only Supabase table/column names', () => {
    const source = readFileSync(
      join(__dirname, '..', '..', 'repositories', 'supabase', 'SupabaseOrganisationRepository.ts'),
      'utf-8',
    );
    expect(source).not.toMatch(/block_iomad_company_admin_/);
    expect(source).not.toMatch(/IOMAD_SERVICE_TOKEN/);
    expect(source).not.toMatch(/IomadRestGateway|IomadGateway/);
  });

  it('AdminOrganisationsService.ts never references Iomad or a Moodle/Iomad wsfunction', () => {
    const source = readFileSync(
      join(__dirname, '..', '..', 'services', 'admin', 'AdminOrganisationsService.ts'),
      'utf-8',
    );
    expect(source).not.toMatch(/block_iomad_company_admin_/);
    expect(source).not.toMatch(/IOMAD_SERVICE_TOKEN/);
    expect(source).not.toMatch(/IomadRestGateway|IomadGateway/);
  });
});
