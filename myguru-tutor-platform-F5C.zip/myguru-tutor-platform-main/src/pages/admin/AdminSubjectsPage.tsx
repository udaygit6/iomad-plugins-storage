import { useEffect, useState } from 'react';
import { adminSubjectsService } from '../../services/admin/AdminSubjectsService';
import type { AdminSubjectView } from '../../repositories/interfaces';

export function AdminSubjectsPage() {
  const [subjects, setSubjects] = useState<AdminSubjectView[] | null>(null);
  const [pendingId, setPendingId] = useState<string | null>(null);

  function reload() {
    adminSubjectsService.listAll().then(setSubjects);
  }

  useEffect(reload, []);

  async function toggle(subject: AdminSubjectView) {
    setPendingId(subject.id);
    try {
      await adminSubjectsService.setEnabled(subject.id, !subject.enabled);
      reload();
    } catch (err) {
      console.error('Failed to update subject visibility:', err instanceof Error ? err.message : err);
    } finally {
      setPendingId(null);
    }
  }

  if (subjects === null) return <p>Loading…</p>;

  return (
    <div>
      <p style={{ fontSize: 13.5, color: 'var(--color-text-muted)', marginBottom: 'var(--space-4)' }}>
        Enabling/disabling a subject here changes what appears on the public site immediately. Re-ordering is not
        yet supported from this screen.
      </p>
      <table className="admin-table">
        <thead>
          <tr>
            <th>Subject</th>
            <th>Visible</th>
          </tr>
        </thead>
        <tbody>
          {subjects.map((s) => (
            <tr key={s.id}>
              <td>{s.name}</td>
              <td>
                <label className="checkbox-field" style={{ marginBottom: 0 }}>
                  <input type="checkbox" checked={s.enabled} disabled={pendingId === s.id} onChange={() => toggle(s)} />
                  {s.enabled ? 'Visible' : 'Hidden'}
                </label>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
