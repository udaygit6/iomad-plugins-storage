import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { adminTutorProfilesService } from '../../services/admin/AdminTutorProfilesService';
import { subjectService } from '../../services/subjects/SubjectService';
import type { AdminTutorProfileView, TutorProfileUpdateInput } from '../../repositories/interfaces';
import type { Subject, EducationLevel, TutorProfileStatus } from '../../domain/models/types';

const STATUS_TONE: Record<TutorProfileStatus, 'default' | 'positive' | 'warning' | 'negative'> = {
  draft: 'default',
  approved: 'warning',
  published: 'positive',
  unpublished: 'negative',
};

function toEditForm(profile: AdminTutorProfileView) {
  return {
    publicDisplayName: profile.publicDisplayName,
    headline: profile.headline,
    bio: profile.bio,
    teachingApproach: profile.teachingApproach,
    experienceSummary: profile.experienceSummary,
    qualificationsSummary: profile.qualificationsSummary.join('\n'),
    languages: profile.languages.join(', '),
    acceptingStudents: profile.acceptingStudents,
    photoUrl: profile.photoUrl ?? '',
    subjectSlugs: profile.subjects.map((s) => s.slug),
    educationLevelSlugs: profile.educationLevels.map((l) => l.slug),
  };
}

export function AdminTutorProfilesPage() {
  const [searchParams] = useSearchParams();
  const [profiles, setProfiles] = useState<AdminTutorProfileView[] | null>(null);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [levels, setLevels] = useState<EducationLevel[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(searchParams.get('open'));
  const [form, setForm] = useState<ReturnType<typeof toEditForm> | null>(null);
  const [saving, setSaving] = useState(false);
  const [statusPending, setStatusPending] = useState(false);

  function reload() {
    adminTutorProfilesService.listAll().then(setProfiles);
  }

  useEffect(reload, []);
  useEffect(() => {
    subjectService.listSubjects().then(setSubjects);
    subjectService.listEducationLevels().then(setLevels);
  }, []);

  const selected = profiles?.find((p) => p.id === selectedId) ?? null;

  useEffect(() => {
    if (selected) setForm(toEditForm(selected));
  }, [selected?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  async function handleSave() {
    if (!selected || !form) return;
    setSaving(true);
    try {
      const updates: TutorProfileUpdateInput = {
        publicDisplayName: form.publicDisplayName,
        headline: form.headline,
        bio: form.bio,
        teachingApproach: form.teachingApproach,
        experienceSummary: form.experienceSummary,
        qualificationsSummary: form.qualificationsSummary.split('\n').map((s) => s.trim()).filter(Boolean),
        languages: form.languages.split(',').map((s) => s.trim()).filter(Boolean),
        acceptingStudents: form.acceptingStudents,
        photoUrl: form.photoUrl.trim() || undefined,
        subjectSlugs: form.subjectSlugs,
        educationLevelSlugs: form.educationLevelSlugs,
      };
      await adminTutorProfilesService.update(selected.id, updates);
      reload();
    } finally {
      setSaving(false);
    }
  }

  async function handlePublish() {
    if (!selected) return;
    setStatusPending(true);
    try {
      await adminTutorProfilesService.publish(selected.id);
      reload();
    } finally {
      setStatusPending(false);
    }
  }

  async function handleUnpublish() {
    if (!selected) return;
    setStatusPending(true);
    try {
      await adminTutorProfilesService.unpublish(selected.id);
      reload();
    } finally {
      setStatusPending(false);
    }
  }

  function toggleSlug<T extends string>(list: T[], slug: T): T[] {
    return list.includes(slug) ? list.filter((s) => s !== slug) : [...list, slug];
  }

  if (profiles === null) return <p>Loading…</p>;

  return (
    <div>
      <table className="admin-table">
        <thead>
          <tr>
            <th>Display name</th>
            <th>Slug</th>
            <th>Subjects</th>
            <th>Levels</th>
            <th>Status</th>
            <th>Application</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {profiles.length === 0 ? (
            <tr className="empty-admin-row">
              <td colSpan={7}>No tutor profiles yet. Create one from an approved application.</td>
            </tr>
          ) : (
            profiles.map((p) => (
              <tr key={p.id} style={{ background: p.id === selectedId ? 'var(--color-paper-50)' : undefined }}>
                <td style={{ cursor: 'pointer' }} onClick={() => setSelectedId(p.id)}>
                  {p.publicDisplayName}
                </td>
                <td style={{ fontSize: 12.5, color: 'var(--color-text-muted)' }}>
                  {p.status === 'published' ? <a href={`/tutors/${p.slug}`} target="_blank" rel="noreferrer">/tutors/{p.slug}</a> : `/tutors/${p.slug}`}
                </td>
                <td>{p.subjects.map((s) => s.name).join(', ') || '—'}</td>
                <td>{p.educationLevels.map((l) => l.name).join(', ') || '—'}</td>
                <td>
                  <span className="status-pill" data-tone={STATUS_TONE[p.status]}>
                    {p.status}
                  </span>
                </td>
                <td style={{ fontSize: 12.5, color: 'var(--color-text-muted)' }}>{p.tutorApplicationId ? p.tutorApplicationId.slice(0, 8) : '—'}</td>
                <td>
                  <button className="btn-text" onClick={() => setSelectedId(p.id)}>
                    Edit
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>

      {selected && form && (
        <div className="admin-detail-panel">
          <div className="form-field">
            <label htmlFor="tp-name">Display name</label>
            <input id="tp-name" className="form-input" value={form.publicDisplayName} onChange={(e) => setForm({ ...form, publicDisplayName: e.target.value })} />
          </div>
          <div className="form-field">
            <label htmlFor="tp-headline">Headline</label>
            <input id="tp-headline" className="form-input" value={form.headline} onChange={(e) => setForm({ ...form, headline: e.target.value })} />
          </div>
          <div className="form-field">
            <label htmlFor="tp-bio">About</label>
            <textarea id="tp-bio" className="form-textarea" value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} />
          </div>
          <div className="form-field">
            <label htmlFor="tp-approach">Teaching approach</label>
            <textarea id="tp-approach" className="form-textarea" value={form.teachingApproach} onChange={(e) => setForm({ ...form, teachingApproach: e.target.value })} />
          </div>
          <div className="form-field">
            <label htmlFor="tp-experience">Experience summary</label>
            <textarea id="tp-experience" className="form-textarea" value={form.experienceSummary} onChange={(e) => setForm({ ...form, experienceSummary: e.target.value })} />
          </div>
          <div className="form-field">
            <label htmlFor="tp-quals">
              Qualifications summary <span className="optional-tag">(one per line, public-safe text — not the self-reported application data)</span>
            </label>
            <textarea id="tp-quals" className="form-textarea" value={form.qualificationsSummary} onChange={(e) => setForm({ ...form, qualificationsSummary: e.target.value })} />
          </div>
          <div className="form-field">
            <label htmlFor="tp-languages">
              Languages <span className="optional-tag">(comma separated)</span>
            </label>
            <input id="tp-languages" className="form-input" value={form.languages} onChange={(e) => setForm({ ...form, languages: e.target.value })} />
          </div>
          <div className="form-field">
            <label htmlFor="tp-photo">
              Photo URL <span className="optional-tag">(optional — no upload workflow yet)</span>
            </label>
            <input id="tp-photo" className="form-input" value={form.photoUrl} onChange={(e) => setForm({ ...form, photoUrl: e.target.value })} />
          </div>
          <div className="form-field">
            <label className="checkbox-field">
              <input type="checkbox" checked={form.acceptingStudents} onChange={(e) => setForm({ ...form, acceptingStudents: e.target.checked })} />
              Currently accepting students
            </label>
          </div>

          <fieldset className="form-field" style={{ border: 'none', padding: 0 }}>
            <legend>Subjects</legend>
            <div className="option-grid">
              {subjects.map((s) => (
                <label key={s.id} className="option-card">
                  <input type="checkbox" checked={form.subjectSlugs.includes(s.slug)} onChange={() => setForm({ ...form, subjectSlugs: toggleSlug(form.subjectSlugs, s.slug) })} />
                  <span className="option-card-label">{s.name}</span>
                </label>
              ))}
            </div>
          </fieldset>

          <fieldset className="form-field" style={{ border: 'none', padding: 0 }}>
            <legend>Education levels</legend>
            <div className="option-grid">
              {levels.map((l) => (
                <label key={l.id} className="option-card">
                  <input type="checkbox" checked={form.educationLevelSlugs.includes(l.slug)} onChange={() => setForm({ ...form, educationLevelSlugs: toggleSlug(form.educationLevelSlugs, l.slug) })} />
                  <span className="option-card-label">{l.name}</span>
                </label>
              ))}
            </div>
          </fieldset>

          <div className="admin-actions">
            <button className="btn btn-primary btn-sm" onClick={handleSave} disabled={saving}>
              {saving ? 'Saving…' : 'Save draft'}
            </button>
            {selected.status !== 'published' ? (
              <button className="btn btn-outline btn-sm" onClick={handlePublish} disabled={statusPending}>
                Publish
              </button>
            ) : (
              <button className="btn-text" onClick={handleUnpublish} disabled={statusPending}>
                Unpublish
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
