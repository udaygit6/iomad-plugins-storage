/**
 * Composition root. This is the ONLY file that should know which concrete
 * repository implementation is in use. Components and services import the
 * interfaces (or these pre-wired instances), never a concrete class
 * directly, so swapping Mock* for Supabase* later touches only this file.
 *
 * Provider selection (Phase E3 §5, extended in E4): VITE_DATA_PROVIDER
 * selects between 'mock' (default) and 'supabase'. In 'supabase' mode:
 *   - reads (tutors, subjects) go straight to Supabase via RLS-safe queries
 *   - anonymous WRITES (matching request, tutor application, enquiry
 *     submit()) go through the public Netlify Functions — never a direct
 *     client insert — see src/repositories/supabase/httpSubmit.ts
 *   - admin reads/writes (list/updateStatus/setEnabled) go directly to
 *     Supabase using the admin's authenticated session, enforced by RLS
 *     (0009's *_admin_all policies)
 */
import { MockTutorRepository } from './mock/MockTutorRepository';
import { MockSubjectRepository } from './mock/MockSubjectRepository';
import {
  MockMatchingRequestRepository,
  MockTutorApplicationRepository,
  MockEnquiryRepository,
} from './mock/MockWorkflowRepositories';
import { SupabaseTutorRepository } from './supabase/SupabaseTutorRepository';
import { SupabaseSubjectRepository } from './supabase/SupabaseSubjectRepository';
import { SupabaseMatchingRequestRepository } from './supabase/SupabaseMatchingRequestRepository';
import { SupabaseTutorApplicationRepository } from './supabase/SupabaseTutorApplicationRepository';
import { SupabaseEnquiryRepository } from './supabase/SupabaseEnquiryRepository';
import { SupabaseTutorProfileRepository } from './supabase/SupabaseTutorProfileRepository';
import { MockTutorProfileRepository } from './mock/MockTutorProfileRepository';
import { SupabaseOrganisationRepository } from './supabase/SupabaseOrganisationRepository';
import { MockOrganisationRepository } from './mock/MockOrganisationRepository';

export type DataProvider = 'mock' | 'supabase';

export function getDataProvider(): DataProvider {
  const raw = (import.meta.env.VITE_DATA_PROVIDER as string | undefined)?.trim().toLowerCase();
  return raw === 'supabase' ? 'supabase' : 'mock';
}

const provider = getDataProvider();

export const tutorRepository = provider === 'supabase' ? new SupabaseTutorRepository() : new MockTutorRepository();
export const subjectRepository = provider === 'supabase' ? new SupabaseSubjectRepository() : new MockSubjectRepository();
export const matchingRequestRepository =
  provider === 'supabase' ? new SupabaseMatchingRequestRepository() : new MockMatchingRequestRepository();
export const tutorApplicationRepository =
  provider === 'supabase' ? new SupabaseTutorApplicationRepository() : new MockTutorApplicationRepository();
export const enquiryRepository = provider === 'supabase' ? new SupabaseEnquiryRepository() : new MockEnquiryRepository();
export const tutorProfileRepository = provider === 'supabase' ? new SupabaseTutorProfileRepository() : new MockTutorProfileRepository();
export const organisationRepository =
  provider === 'supabase' ? new SupabaseOrganisationRepository() : new MockOrganisationRepository();
