import type {
  TutorProfile,
  TutorFilters,
  Subject,
  EducationLevel,
  EducationLevelSlug,
  TutorApplication,
  MatchingRequest,
  Enquiry,
} from '../../domain/models/types';

/**
 * Repository interfaces. React components and application services depend
 * only on these — never on a concrete Supabase/mock implementation.
 *
 * Phase D wires in mock/in-memory implementations (src/repositories/mock).
 * A later persistence phase wires in Supabase implementations against the
 * same interfaces, with no change required to callers.
 */

/**
 * Anti-abuse signals captured by the submitting form (Phase E4). Optional
 * and separate from the domain model on purpose — a honeypot value and a
 * form-load timestamp are submission-channel concerns, not part of what a
 * MatchingRequest/TutorApplication/Enquiry *is*. Mock repositories ignore
 * this; Supabase-backed repositories forward it to the server endpoint.
 */
export interface SubmitMeta {
  honeypotValue?: string;
  formLoadedAt?: number;
}

export interface TutorRepository {
  list(filters?: TutorFilters): Promise<TutorProfile[]>;
  getBySlug(slug: string): Promise<TutorProfile | null>;
}

/** Admin-only view of a tutor profile, including the source application it
 * was created from (if any) — the public TutorProfile type deliberately has
 * no such field, since public consumers never need it. */
export interface AdminTutorProfileView extends TutorProfile {
  tutorApplicationId?: string;
}

/** Fields an admin may edit on a tutor profile. All optional — an update
 * call only touches the fields it's given. */
export interface TutorProfileUpdateInput {
  publicDisplayName?: string;
  headline?: string;
  positioningStatement?: string;
  bio?: string;
  teachingApproach?: string;
  experienceSummary?: string;
  qualificationsSummary?: string[];
  languages?: string[];
  acceptingStudents?: boolean;
  photoUrl?: string;
  subjectSlugs?: string[];
  educationLevelSlugs?: EducationLevelSlug[];
}

export interface TutorProfileRepository {
  /** Admin-only: every profile regardless of status. */
  listForAdmin(): Promise<AdminTutorProfileView[]>;
  /** Admin-only: fetch by id, any status (unlike the public TutorRepository, which only returns published profiles). */
  getById(id: string): Promise<AdminTutorProfileView | null>;
  /** Admin-only: find the profile already linked to this application, if any — used for idempotency before creating. */
  getByApplicationId(applicationId: string): Promise<AdminTutorProfileView | null>;
  /** Admin-only: create a draft profile from an approved application, copying only public-safe fields. */
  createFromApplication(application: TutorApplication): Promise<AdminTutorProfileView>;
  update(id: string, updates: TutorProfileUpdateInput): Promise<AdminTutorProfileView>;
  publish(id: string): Promise<AdminTutorProfileView>;
  unpublish(id: string): Promise<AdminTutorProfileView>;
}

/** Admin-only view of a subject, including its visibility state — the
 * public Subject domain type deliberately has no `enabled` field (nothing
 * public-facing needs it), so this is a distinct, narrower type rather than
 * an extension of the domain model. */
export interface AdminSubjectView extends Subject {
  enabled: boolean;
}

export interface SubjectRepository {
  list(): Promise<Subject[]>;
  getBySlug(slug: string): Promise<Subject | null>;
  listEducationLevels(): Promise<EducationLevel[]>;
  /** Admin-only: every subject regardless of enabled state (Phase E5). */
  listForAdmin(): Promise<AdminSubjectView[]>;
  /** Admin-only write (Phase E5). Mock implementation uses in-memory state; Supabase implementation persists. */
  setEnabled(id: string, enabled: boolean): Promise<Subject>;
}

export interface TutorApplicationRepository {
  submit(input: Omit<TutorApplication, 'id' | 'status' | 'submittedAt'>, meta?: SubmitMeta): Promise<TutorApplication>;
  list(): Promise<TutorApplication[]>;
  getById(id: string): Promise<TutorApplication | null>;
  updateStatus(id: string, status: TutorApplication['status'], adminNotes?: string): Promise<TutorApplication>;
}

export interface MatchingRequestRepository {
  submit(input: Omit<MatchingRequest, 'id' | 'status' | 'submittedAt'>, meta?: SubmitMeta): Promise<MatchingRequest>;
  list(): Promise<MatchingRequest[]>;
  updateStatus(id: string, status: MatchingRequest['status']): Promise<MatchingRequest>;
}

export interface EnquiryRepository {
  submit(input: Omit<Enquiry, 'id' | 'status' | 'submittedAt'>, meta?: SubmitMeta): Promise<Enquiry>;
  list(): Promise<Enquiry[]>;
  updateStatus(id: string, status: Enquiry['status']): Promise<Enquiry>;
}

/**
 * F4D — admin-only visibility view of a platform Organisation, joined
 * with its Iomad company sync mapping (F4/F4C — see
 * `supabase/migrations/0015_organisation_iomad_company_sync.sql` and
 * `docs/SYSTEM_OF_RECORD.md`). Read-only: F4D adds no create/edit/delete
 * capability. `type`/`status` mirror the check constraints on the
 * `organisations` table exactly — kept in sync by hand, since `src/` has
 * no import path to the server-only `netlify/functions/_lib/companySync/`
 * types that define the same shapes for the sync service.
 */
export type OrganisationType = 'unclassified' | 'myguru_franchise' | 'corporate' | 'school_future' | 'internal';
export type OrganisationStatus = 'active' | 'suspended' | 'inactive';
export type OrganisationSyncStatus = 'pending' | 'synced' | 'failed' | 'stale';

export interface Organisation {
  id: string;
  name: string;
  type: OrganisationType;
  status: OrganisationStatus;
  /** Null when this organisation has no Iomad company mapping at all —
   * defensive; every organisation F4 sync creates has one, but this view
   * must not assume that can never be otherwise (a manually-created
   * organisation, or one whose mapping was removed, would have none). */
  iomadCompanyId: string | null;
  syncStatus: OrganisationSyncStatus | null;
  lastSyncedAt: string | null;
  /** True only when the mapping's `last_error_code` is non-null. Never
   * exposes the error code or message itself to this view — a safe
   * boolean flag is all this admin page shows (see
   * AdminOrganisationsPage.tsx's "Sync issue" indicator). */
  hasSyncIssue: boolean;
}

export interface OrganisationRepository {
  /** Every organisation, regardless of status — admin-only, enforced by
   * RLS (0015's `organisations_admin_read`/`iomad_company_mappings_admin_read`
   * policies, gated by `is_admin()`), not by this method. */
  listForAdmin(): Promise<Organisation[]>;

  /**
   * F5C — courses currently or previously allocated to one organisation
   * (F5B — see `supabase/migrations/0016_course_persistence_and_organisation_allocations.sql`).
   * Read-only visibility only: no create/edit/delete, no Iomad call, no
   * sync trigger. Includes stale allocations (F5B's domain rule: a
   * course losing access is marked stale, never deleted) — this method
   * does not filter them out; the UI decides how to present sync status.
   */
  listOrganisationCourses(organisationId: string): Promise<OrganisationCourse[]>;
}

/**
 * F5C — admin-only visibility view of one organisation's course
 * allocation, joined across `organisation_course_allocations` →
 * `courses` → `iomad_course_mappings` (F5B). Read-only. `syncStatus`
 * mirrors `organisation_course_allocations.sync_status`'s check
 * constraint exactly — kept in sync by hand, same convention as
 * `Organisation` above.
 */
export interface OrganisationCourse {
  /** The allocation row's own id — not usually shown in the UI, but kept
   * for use as a stable React list key. */
  id: string;
  courseName: string;
  /** Null when this course has no Iomad mapping at all — defensive; every
   * course F5B sync creates has one, but this view must not assume that
   * can never be otherwise. */
  iomadCourseId: string | null;
  licensed: boolean;
  shared: boolean;
  validLengthDays: number;
  warnExpireDays: number;
  warnCompletionDays: number;
  notifyPeriodDays: number;
  syncStatus: OrganisationSyncStatus;
  lastSyncedAt: string | null;
}
