import type { OrganisationRepository, Organisation, OrganisationCourse } from '../interfaces';

const delay = (ms = 150) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Fixture data for local/mock-mode preview of the F4D admin Organisations
 * page. Mirrors the live-verified F4C example (Shiksha Academy, Iomad
 * company id 3) exactly, plus one additional row to show a "Sync issue"
 * and one with no mapping at all, so both defensive display paths are
 * visible without needing a real Supabase connection.
 */
const mockOrganisations: Organisation[] = [
  {
    id: 'org-shiksha-academy',
    name: 'Shiksha Academy',
    type: 'unclassified',
    status: 'active',
    iomadCompanyId: '3',
    syncStatus: 'synced',
    lastSyncedAt: '2026-01-15T09:30:00Z',
    hasSyncIssue: false,
  },
  {
    id: 'org-example-with-issue',
    name: 'Example Learning Co',
    type: 'unclassified',
    status: 'active',
    iomadCompanyId: '7',
    syncStatus: 'failed',
    lastSyncedAt: '2026-01-10T14:00:00Z',
    hasSyncIssue: true,
  },
];

/**
 * F5C — mirrors the real live-verified Jupiter Test Mathematics example
 * (Iomad course id 4, licensed/shared both false, all day-counts 0),
 * keyed by the mock organisation it belongs to. Shiksha Academy
 * deliberately has none, to exercise the "no courses synchronised yet"
 * empty state without needing a real Supabase connection.
 */
const mockOrganisationCourses: Record<string, OrganisationCourse[]> = {
  'org-shiksha-academy': [],
  'org-example-with-issue': [
    {
      id: 'alloc-jupiter-test-mathematics',
      courseName: 'Jupiter Test Mathematics',
      iomadCourseId: '4',
      licensed: false,
      shared: false,
      validLengthDays: 0,
      warnExpireDays: 0,
      warnCompletionDays: 0,
      notifyPeriodDays: 0,
      syncStatus: 'synced',
      lastSyncedAt: '2026-01-15T09:30:00Z',
    },
  ],
};

export class MockOrganisationRepository implements OrganisationRepository {
  async listForAdmin(): Promise<Organisation[]> {
    await delay(100);
    return mockOrganisations;
  }

  async listOrganisationCourses(organisationId: string): Promise<OrganisationCourse[]> {
    await delay(100);
    return mockOrganisationCourses[organisationId] ?? [];
  }
}
