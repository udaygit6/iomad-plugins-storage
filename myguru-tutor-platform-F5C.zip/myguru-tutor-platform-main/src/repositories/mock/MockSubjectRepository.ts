import type { SubjectRepository, AdminSubjectView } from '../interfaces';
import type { Subject } from '../../domain/models/types';
import { mockSubjects, mockEducationLevels } from '../../assets/mock/mockSubjects';

const delay = (ms = 150) => new Promise((resolve) => setTimeout(resolve, ms));

// Module-level so it behaves like the other Mock repositories: real
// in-memory state shared across the app (not per-component local state),
// resetting only on page reload. Replaces AdminSubjectsPage's previous
// component-local Set, which wasn't a repository concern at all.
const disabledSubjectIds = new Set<string>();

export class MockSubjectRepository implements SubjectRepository {
  async list() {
    await delay();
    return mockSubjects.filter((s) => !disabledSubjectIds.has(s.id));
  }

  async getBySlug(slug: string) {
    await delay();
    const subject = mockSubjects.find((s) => s.slug === slug);
    return subject && !disabledSubjectIds.has(subject.id) ? subject : null;
  }

  async listEducationLevels() {
    await delay();
    return mockEducationLevels;
  }

  async listForAdmin(): Promise<AdminSubjectView[]> {
    await delay(100);
    return mockSubjects.map((s) => ({ ...s, enabled: !disabledSubjectIds.has(s.id) }));
  }

  async setEnabled(id: string, enabled: boolean): Promise<Subject> {
    await delay(100);
    const subject = mockSubjects.find((s) => s.id === id);
    if (!subject) throw new Error(`Subject ${id} not found`);
    if (enabled) disabledSubjectIds.delete(id);
    else disabledSubjectIds.add(id);
    return subject;
  }
}
