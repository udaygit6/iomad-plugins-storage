import { describe, it, expect } from 'vitest';
import { MockTutorProfileRepository } from './MockTutorProfileRepository';
import { MockTutorRepository } from './MockTutorRepository';
import type { TutorApplication } from '../../domain/models/types';

function makeApprovedApplication(): TutorApplication {
  return {
    id: `app-${Math.random().toString(36).slice(2, 8)}`,
    status: 'approved',
    fullName: 'Jordan Example',
    email: 'jordan@example.com',
    aboutYou: 'About',
    teachingExperience: 'Experience',
    education: 'Education',
    qualifications: ['BSc Physics'],
    subjectSlugs: ['physics'],
    educationLevelSlugs: ['a-level'],
    teachingApproach: 'Approach',
    availabilityNotes: 'Weekends',
  };
}

describe('Tutor profile visibility workflow (mock-mode, end-to-end)', () => {
  it('a newly-created draft profile is NOT visible via the public tutor repository', async () => {
    const profiles = new MockTutorProfileRepository();
    const publicTutors = new MockTutorRepository();
    const application = makeApprovedApplication();

    const created = await profiles.createFromApplication(application);
    expect(created.status).toBe('draft');

    const publicResults = await publicTutors.list();
    expect(publicResults.some((t) => t.id === created.id)).toBe(false);

    const publicBySlug = await publicTutors.getBySlug(created.slug);
    expect(publicBySlug).toBeNull();
  });

  it('publishing makes the profile appear on the public tutor repository', async () => {
    const profiles = new MockTutorProfileRepository();
    const publicTutors = new MockTutorRepository();
    const application = makeApprovedApplication();

    const created = await profiles.createFromApplication(application);
    await profiles.publish(created.id);

    const publicResults = await publicTutors.list();
    expect(publicResults.some((t) => t.id === created.id)).toBe(true);

    const publicBySlug = await publicTutors.getBySlug(created.slug);
    expect(publicBySlug?.id).toBe(created.id);
  });

  it('unpublishing removes the profile from public visibility again', async () => {
    const profiles = new MockTutorProfileRepository();
    const publicTutors = new MockTutorRepository();
    const application = makeApprovedApplication();

    const created = await profiles.createFromApplication(application);
    await profiles.publish(created.id);
    await profiles.unpublish(created.id);

    const publicResults = await publicTutors.list();
    expect(publicResults.some((t) => t.id === created.id)).toBe(false);
  });

  it('creating a profile twice from the same application returns the same profile (idempotent at the repository level too)', async () => {
    const profiles = new MockTutorProfileRepository();
    const application = makeApprovedApplication();

    const first = await profiles.createFromApplication(application);
    const second = await profiles.createFromApplication(application);

    expect(second.id).toBe(first.id);
  });

  it('refuses to create a profile from a non-approved application', async () => {
    const profiles = new MockTutorProfileRepository();
    const application = { ...makeApprovedApplication(), status: 'submitted' as const };

    await expect(profiles.createFromApplication(application)).rejects.toThrow(/only approved/i);
  });

  it('copies subjects/levels from the application, preserving distinct education-level slugs', async () => {
    const profiles = new MockTutorProfileRepository();
    const application = { ...makeApprovedApplication(), educationLevelSlugs: ['ks1', 'ks2'] as const };

    const created = await profiles.createFromApplication({ ...application, educationLevelSlugs: ['ks1', 'ks2'] });
    const slugs = created.educationLevels.map((l) => l.slug);
    expect(slugs).toContain('ks1');
    expect(slugs).toContain('ks2');
  });

  it('editing subjects/levels via update() changes what is copied, without touching the application', async () => {
    const profiles = new MockTutorProfileRepository();
    const application = makeApprovedApplication();
    const created = await profiles.createFromApplication(application);

    const updated = await profiles.update(created.id, { subjectSlugs: ['maths', 'english'] });
    expect(updated.subjects.map((s) => s.slug).sort()).toEqual(['english', 'maths']);
  });
});
