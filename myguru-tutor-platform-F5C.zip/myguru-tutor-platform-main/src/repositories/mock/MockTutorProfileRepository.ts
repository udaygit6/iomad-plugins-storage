import type { TutorProfileRepository, TutorProfileUpdateInput, AdminTutorProfileView } from '../interfaces';
import type { TutorApplication, TutorProfile } from '../../domain/models/types';
import { mockTutors } from '../../assets/mock/mockTutors';
import { mockSubjects, mockEducationLevels } from '../../assets/mock/mockSubjects';
import { deriveDisplayName, slugifyBase, makeUniqueSlug } from '../../domain/services/tutorProfileNaming';

const delay = (ms = 150) => new Promise((resolve) => setTimeout(resolve, ms));

// Module-level, mutating the SAME array MockTutorRepository reads from —
// so publishing a profile here immediately makes it appear on the public
// Browse Tutors page in mock mode, exactly as it does against Supabase.
const applicationLinks = new Map<string, string>(); // applicationId -> tutorProfileId

function toAdminView(tutor: TutorProfile): AdminTutorProfileView {
  const tutorApplicationId = [...applicationLinks.entries()].find(([, profileId]) => profileId === tutor.id)?.[0];
  return { ...tutor, tutorApplicationId };
}

export class MockTutorProfileRepository implements TutorProfileRepository {
  async listForAdmin(): Promise<AdminTutorProfileView[]> {
    await delay();
    return mockTutors.map(toAdminView);
  }

  async getById(id: string): Promise<AdminTutorProfileView | null> {
    await delay();
    const tutor = mockTutors.find((t) => t.id === id);
    return tutor ? toAdminView(tutor) : null;
  }

  async getByApplicationId(applicationId: string): Promise<AdminTutorProfileView | null> {
    await delay();
    const profileId = applicationLinks.get(applicationId);
    if (!profileId) return null;
    return this.getById(profileId);
  }

  async createFromApplication(application: TutorApplication): Promise<AdminTutorProfileView> {
    await delay(200);

    const existingId = applicationLinks.get(application.id);
    if (existingId) {
      const existing = await this.getById(existingId);
      if (existing) return existing;
    }

    if (application.status !== 'approved') {
      throw new Error('Only approved applications can create a tutor profile.');
    }

    const displayName = deriveDisplayName(application.fullName);
    const subjects = mockSubjects.filter((s) => application.subjectSlugs.includes(s.slug));
    const educationLevels = mockEducationLevels.filter((l) => application.educationLevelSlugs.includes(l.slug));
    const headline = subjects.map((s) => s.name).join(' & ') || 'Tutor';
    const slug = makeUniqueSlug(slugifyBase(displayName));

    const profile: TutorProfile = {
      id: `profile-${Math.random().toString(36).slice(2, 10)}`,
      slug,
      publicDisplayName: displayName,
      headline,
      bio: application.aboutYou,
      teachingApproach: application.teachingApproach,
      experienceSummary: application.teachingExperience,
      subjects,
      educationLevels,
      qualificationsSummary: [], // deliberately not copied from self-reported application data — see 0014's comment
      languages: [],
      acceptingStudents: false,
      publicVerificationBadges: [], // never inherited from approval
      status: 'draft',
    };

    mockTutors.push(profile);
    applicationLinks.set(application.id, profile.id);
    return toAdminView(profile);
  }

  async update(id: string, updates: TutorProfileUpdateInput): Promise<AdminTutorProfileView> {
    await delay();
    const tutor = mockTutors.find((t) => t.id === id);
    if (!tutor) throw new Error(`Tutor profile ${id} not found`);

    if (updates.publicDisplayName !== undefined) tutor.publicDisplayName = updates.publicDisplayName;
    if (updates.headline !== undefined) tutor.headline = updates.headline;
    if (updates.positioningStatement !== undefined) tutor.positioningStatement = updates.positioningStatement;
    if (updates.bio !== undefined) tutor.bio = updates.bio;
    if (updates.teachingApproach !== undefined) tutor.teachingApproach = updates.teachingApproach;
    if (updates.experienceSummary !== undefined) tutor.experienceSummary = updates.experienceSummary;
    if (updates.qualificationsSummary !== undefined) tutor.qualificationsSummary = updates.qualificationsSummary;
    if (updates.languages !== undefined) tutor.languages = updates.languages;
    if (updates.acceptingStudents !== undefined) tutor.acceptingStudents = updates.acceptingStudents;
    if (updates.photoUrl !== undefined) tutor.photoUrl = updates.photoUrl;
    if (updates.subjectSlugs !== undefined) {
      tutor.subjects = mockSubjects.filter((s) => updates.subjectSlugs!.includes(s.slug));
    }
    if (updates.educationLevelSlugs !== undefined) {
      tutor.educationLevels = mockEducationLevels.filter((l) => updates.educationLevelSlugs!.includes(l.slug));
    }

    return toAdminView(tutor);
  }

  async publish(id: string): Promise<AdminTutorProfileView> {
    await delay();
    const tutor = mockTutors.find((t) => t.id === id);
    if (!tutor) throw new Error(`Tutor profile ${id} not found`);
    tutor.status = 'published';
    return toAdminView(tutor);
  }

  async unpublish(id: string): Promise<AdminTutorProfileView> {
    await delay();
    const tutor = mockTutors.find((t) => t.id === id);
    if (!tutor) throw new Error(`Tutor profile ${id} not found`);
    tutor.status = 'unpublished';
    return toAdminView(tutor);
  }
}
