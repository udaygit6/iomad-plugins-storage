import type { TutorRepository } from '../interfaces';
import type { TutorFilters, TutorProfile } from '../../domain/models/types';
import { mockTutors } from '../../assets/mock/mockTutors';

// Simulated network latency so loading states are genuinely exercised.
const delay = (ms = 350) => new Promise((resolve) => setTimeout(resolve, ms));

export class MockTutorRepository implements TutorRepository {
  async list(filters?: TutorFilters): Promise<TutorProfile[]> {
    await delay();
    let results = mockTutors.filter((t) => t.status === 'published');

    if (filters?.subjectSlug) {
      results = results.filter((t) => t.subjects.some((s) => s.slug === filters.subjectSlug));
    }
    if (filters?.educationLevelSlug) {
      results = results.filter((t) => t.educationLevels.some((l) => l.slug === filters.educationLevelSlug));
    }
    if (filters?.acceptingStudentsOnly) {
      results = results.filter((t) => t.acceptingStudents);
    }
    return results;
  }

  async getBySlug(slug: string): Promise<TutorProfile | null> {
    await delay();
    const tutor = mockTutors.find((t) => t.slug === slug && t.status === 'published');
    return tutor ?? null;
  }
}
