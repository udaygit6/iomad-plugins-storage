import type {
  MatchingRequestRepository,
  TutorApplicationRepository,
  EnquiryRepository,
  SubmitMeta,
} from '../interfaces';
import type { MatchingRequest, TutorApplication, Enquiry } from '../../domain/models/types';

const delay = (ms = 300) => new Promise((resolve) => setTimeout(resolve, ms));
const uid = (prefix: string) => `${prefix}-${Math.random().toString(36).slice(2, 9)}`;

/**
 * In-memory stores. Data resets on page reload — this is intentional for
 * Phase D (§24: mock repositories validate workflow, not persistence).
 * A later persistence phase swaps these for Supabase-backed implementations
 * against the same interfaces.
 */
let matchingRequests: MatchingRequest[] = [];
let tutorApplications: TutorApplication[] = [];
let enquiries: Enquiry[] = [];

export class MockMatchingRequestRepository implements MatchingRequestRepository {
  async submit(input: Omit<MatchingRequest, 'id' | 'status' | 'submittedAt'>, _meta?: SubmitMeta) {
    await delay();
    const record: MatchingRequest = {
      ...input,
      id: uid('match'),
      status: 'submitted',
      submittedAt: new Date().toISOString(),
    };
    matchingRequests = [record, ...matchingRequests];
    return record;
  }

  async list() {
    await delay(150);
    return matchingRequests;
  }

  async updateStatus(id: string, status: MatchingRequest['status']) {
    await delay(150);
    matchingRequests = matchingRequests.map((r) => (r.id === id ? { ...r, status } : r));
    const updated = matchingRequests.find((r) => r.id === id);
    if (!updated) throw new Error(`Matching request ${id} not found`);
    return updated;
  }
}

export class MockTutorApplicationRepository implements TutorApplicationRepository {
  async submit(input: Omit<TutorApplication, 'id' | 'status' | 'submittedAt'>, _meta?: SubmitMeta) {
    await delay();
    const record: TutorApplication = {
      ...input,
      id: uid('app'),
      status: 'submitted',
      submittedAt: new Date().toISOString(),
    };
    tutorApplications = [record, ...tutorApplications];
    return record;
  }

  async list() {
    await delay(150);
    return tutorApplications;
  }

  async getById(id: string) {
    await delay(150);
    return tutorApplications.find((a) => a.id === id) ?? null;
  }

  async updateStatus(id: string, status: TutorApplication['status'], adminNotes?: string) {
    await delay(150);
    tutorApplications = tutorApplications.map((a) =>
      a.id === id ? { ...a, status, adminNotes: adminNotes ?? a.adminNotes, reviewedAt: new Date().toISOString() } : a,
    );
    const updated = tutorApplications.find((a) => a.id === id);
    if (!updated) throw new Error(`Application ${id} not found`);
    return updated;
  }
}

export class MockEnquiryRepository implements EnquiryRepository {
  async submit(input: Omit<Enquiry, 'id' | 'status' | 'submittedAt'>, _meta?: SubmitMeta) {
    await delay();
    const record: Enquiry = {
      ...input,
      id: uid('enq'),
      status: 'new',
      submittedAt: new Date().toISOString(),
    };
    enquiries = [record, ...enquiries];
    return record;
  }

  async list() {
    await delay(150);
    return enquiries;
  }

  async updateStatus(id: string, status: Enquiry['status']) {
    await delay(150);
    enquiries = enquiries.map((e) => (e.id === id ? { ...e, status } : e));
    const updated = enquiries.find((e) => e.id === id);
    if (!updated) throw new Error(`Enquiry ${id} not found`);
    return updated;
  }
}
