import { describe, it, expect, afterEach, vi } from 'vitest';

describe('getDataProvider (composition root provider selection)', () => {
  afterEach(() => {
    vi.unstubAllEnvs();
    vi.resetModules();
  });

  it('defaults to "mock" when VITE_DATA_PROVIDER is unset', async () => {
    vi.stubEnv('VITE_DATA_PROVIDER', '');
    const { getDataProvider } = await import('./index');
    expect(getDataProvider()).toBe('mock');
  });

  it('selects "supabase" when explicitly set', async () => {
    vi.stubEnv('VITE_DATA_PROVIDER', 'supabase');
    const { getDataProvider } = await import('./index');
    expect(getDataProvider()).toBe('supabase');
  });

  it('falls back to "mock" for any unrecognised value rather than throwing', async () => {
    vi.stubEnv('VITE_DATA_PROVIDER', 'something-invalid');
    const { getDataProvider } = await import('./index');
    expect(getDataProvider()).toBe('mock');
  });

  it('is case-insensitive', async () => {
    vi.stubEnv('VITE_DATA_PROVIDER', 'SUPABASE');
    const { getDataProvider } = await import('./index');
    expect(getDataProvider()).toBe('supabase');
  });

  it('wires tutorRepository/subjectRepository to the Mock* classes by default', async () => {
    vi.stubEnv('VITE_DATA_PROVIDER', 'mock');
    vi.resetModules();
    const { tutorRepository, subjectRepository } = await import('./index');
    expect(tutorRepository.constructor.name).toBe('MockTutorRepository');
    expect(subjectRepository.constructor.name).toBe('MockSubjectRepository');
  });

  it('wires tutorRepository/subjectRepository to the Supabase* classes when selected', async () => {
    vi.stubEnv('VITE_DATA_PROVIDER', 'supabase');
    vi.resetModules();
    const { tutorRepository, subjectRepository } = await import('./index');
    expect(tutorRepository.constructor.name).toBe('SupabaseTutorRepository');
    expect(subjectRepository.constructor.name).toBe('SupabaseSubjectRepository');
  });

  it('matching/application/enquiry repositories switch to Supabase-backed implementations when selected (E4: public writes now supported)', async () => {
    vi.stubEnv('VITE_DATA_PROVIDER', 'supabase');
    vi.resetModules();
    const { matchingRequestRepository, tutorApplicationRepository, enquiryRepository } = await import('./index');
    expect(matchingRequestRepository.constructor.name).toBe('SupabaseMatchingRequestRepository');
    expect(tutorApplicationRepository.constructor.name).toBe('SupabaseTutorApplicationRepository');
    expect(enquiryRepository.constructor.name).toBe('SupabaseEnquiryRepository');
  });

  it('matching/application/enquiry repositories remain Mock-backed in mock mode', async () => {
    vi.stubEnv('VITE_DATA_PROVIDER', 'mock');
    vi.resetModules();
    const { matchingRequestRepository, tutorApplicationRepository, enquiryRepository } = await import('./index');
    expect(matchingRequestRepository.constructor.name).toBe('MockMatchingRequestRepository');
    expect(tutorApplicationRepository.constructor.name).toBe('MockTutorApplicationRepository');
    expect(enquiryRepository.constructor.name).toBe('MockEnquiryRepository');
  });
});
