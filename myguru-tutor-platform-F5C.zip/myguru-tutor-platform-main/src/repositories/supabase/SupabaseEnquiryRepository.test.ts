import { describe, it, expect } from 'vitest';
import { _mappers } from './SupabaseEnquiryRepository';

describe('SupabaseEnquiryRepository row mapping', () => {
  it('maps a general enquiry row (no related tutor) correctly', () => {
    const mapped = _mappers.mapRow({
      id: 'enq-1',
      status: 'new',
      name: 'Sarah',
      email: 'sarah@example.com',
      message: 'A question',
      submitted_at: '2026-01-01T00:00:00Z',
      tutor_profiles: null,
    });
    expect(mapped.relatedTutorSlug).toBeUndefined();
  });

  it('maps a "request this tutor" enquiry row, including the related tutor slug', () => {
    const mapped = _mappers.mapRow({
      id: 'enq-2',
      status: 'new',
      name: 'Sarah',
      email: 'sarah@example.com',
      message: 'Interested',
      submitted_at: '2026-01-01T00:00:00Z',
      tutor_profiles: { slug: 'sarah-m-maths' },
    });
    expect(mapped.relatedTutorSlug).toBe('sarah-m-maths');
  });
});
