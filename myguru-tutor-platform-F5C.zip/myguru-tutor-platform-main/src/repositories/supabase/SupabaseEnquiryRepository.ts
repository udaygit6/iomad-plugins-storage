import { getSupabaseClient } from '../../integrations/supabase/client';
import { postSubmission } from './httpSubmit';
import type { EnquiryRepository, SubmitMeta } from '../interfaces';
import type { Enquiry } from '../../domain/models/types';

interface EnquiryRow {
  id: string;
  status: Enquiry['status'];
  name: string;
  email: string;
  message: string;
  submitted_at: string;
  tutor_profiles: { slug: string } | null;
}

const SELECT_WITH_JOIN = `*, tutor_profiles ( slug )`;

function mapRow(row: EnquiryRow): Enquiry {
  return {
    id: row.id,
    status: row.status,
    name: row.name,
    email: row.email,
    message: row.message,
    relatedTutorSlug: row.tutor_profiles?.slug ?? undefined,
    submittedAt: row.submitted_at,
  };
}

// Exported for unit testing without a network call.
export const _mappers = { mapRow };

export class SupabaseEnquiryRepository implements EnquiryRepository {
  async submit(input: Omit<Enquiry, 'id' | 'status' | 'submittedAt'>, meta?: SubmitMeta): Promise<Enquiry> {
    const { id } = await postSubmission('submit-enquiry', {
      name: input.name,
      email: input.email,
      message: input.message,
      relatedTutorSlug: input.relatedTutorSlug,
      website: meta?.honeypotValue ?? '',
      formLoadedAt: meta?.formLoadedAt,
    });
    return { ...input, id, status: 'new', submittedAt: new Date().toISOString() };
  }

  async list(): Promise<Enquiry[]> {
    try {
      const supabase = getSupabaseClient();
      const { data, error } = await supabase.from('enquiries').select(SELECT_WITH_JOIN).order('created_at', { ascending: false });

      if (error) {
        console.error('SupabaseEnquiryRepository.list failed:', error.message);
        return [];
      }
      return ((data ?? []) as unknown as EnquiryRow[]).map(mapRow);
    } catch (err) {
      console.error('SupabaseEnquiryRepository.list failed:', err instanceof Error ? err.message : err);
      return [];
    }
  }

  async updateStatus(id: string, status: Enquiry['status']): Promise<Enquiry> {
    const supabase = getSupabaseClient();
    const { data, error } = await supabase.from('enquiries').update({ status }).eq('id', id).select(SELECT_WITH_JOIN).single();

    if (error) {
      console.error('SupabaseEnquiryRepository.updateStatus failed:', error.message);
      throw new Error('Unable to update this enquiry.');
    }
    return mapRow(data as unknown as EnquiryRow);
  }
}
