import { describe, it, expect } from 'vitest';
import { _mappers } from './SupabaseMatchingRequestRepository';

describe('SupabaseMatchingRequestRepository row mapping', () => {
  it('maps a full joined row into the domain MatchingRequest shape', () => {
    const row = {
      id: 'req-1',
      status: 'submitted' as const,
      goals_note: 'Build confidence',
      availability_note: 'Weekday evenings',
      help_needed: 'confidence' as const,
      submitted_at: '2026-01-01T00:00:00Z',
      parent_contacts: { name: 'Sarah', email: 'sarah@example.com', phone: '07000000000' },
      students: { first_name: 'Emily', year_group_label: 'Year 5' },
      subjects: { slug: 'maths' },
    };

    const mapped = _mappers.mapRow(row);

    expect(mapped).toEqual({
      id: 'req-1',
      status: 'submitted',
      parent: { name: 'Sarah', email: 'sarah@example.com', phone: '07000000000' },
      student: { firstName: 'Emily', yearGroupLabel: 'Year 5' },
      subjectSlug: 'maths',
      helpNeeded: 'confidence',
      goalsNote: 'Build confidence',
      availabilityNote: 'Weekday evenings',
      submittedAt: '2026-01-01T00:00:00Z',
    });
  });

  it('falls back to safe empty values when a join is unexpectedly null, rather than throwing', () => {
    const row = {
      id: 'req-2',
      status: 'submitted' as const,
      goals_note: null,
      availability_note: 'Weekends',
      help_needed: 'other' as const,
      submitted_at: '2026-01-01T00:00:00Z',
      parent_contacts: null,
      students: null,
      subjects: null,
    };

    const mapped = _mappers.mapRow(row);
    expect(mapped.parent).toEqual({ name: '', email: '', phone: undefined });
    expect(mapped.student).toEqual({ firstName: '', yearGroupLabel: '' });
    expect(mapped.subjectSlug).toBe('');
    expect(mapped.goalsNote).toBeUndefined();
  });
});
