import { getSupabaseClient } from '../../integrations/supabase/client';
import { postSubmission } from './httpSubmit';
import type { MatchingRequestRepository, SubmitMeta } from '../interfaces';
import type { MatchingRequest, HelpNeededReason } from '../../domain/models/types';

interface MatchingRequestRow {
  id: string;
  status: MatchingRequest['status'];
  goals_note: string | null;
  availability_note: string;
  help_needed: HelpNeededReason;
  submitted_at: string;
  parent_contacts: { name: string; email: string; phone: string | null } | null;
  students: { first_name: string; year_group_label: string } | null;
  subjects: { slug: string } | null;
}

const SELECT_WITH_JOINS = `*, parent_contacts ( name, email, phone ), students ( first_name, year_group_label ), subjects ( slug )`;

function mapRow(row: MatchingRequestRow): MatchingRequest {
  return {
    id: row.id,
    status: row.status,
    parent: {
      name: row.parent_contacts?.name ?? '',
      email: row.parent_contacts?.email ?? '',
      phone: row.parent_contacts?.phone ?? undefined,
    },
    student: {
      firstName: row.students?.first_name ?? '',
      yearGroupLabel: row.students?.year_group_label ?? '',
    },
    subjectSlug: row.subjects?.slug ?? '',
    helpNeeded: row.help_needed,
    goalsNote: row.goals_note ?? undefined,
    availabilityNote: row.availability_note,
    submittedAt: row.submitted_at,
  };
}

// Exported for unit testing without a network call.
export const _mappers = { mapRow };

export class SupabaseMatchingRequestRepository implements MatchingRequestRepository {
  async submit(input: Omit<MatchingRequest, 'id' | 'status' | 'submittedAt'>, meta?: SubmitMeta): Promise<MatchingRequest> {
    const { id } = await postSubmission('submit-matching-request', {
      parentName: input.parent.name,
      parentEmail: input.parent.email,
      parentPhone: input.parent.phone,
      studentFirstName: input.student.firstName,
      yearGroupLabel: input.student.yearGroupLabel,
      subjectSlug: input.subjectSlug,
      helpNeeded: input.helpNeeded,
      goalsNote: input.goalsNote,
      availabilityNote: input.availabilityNote,
      website: meta?.honeypotValue ?? '',
      formLoadedAt: meta?.formLoadedAt,
    });
    // The server doesn't echo the full row back (it returns only the new
    // id) — safe to reconstruct locally since no caller reads anything
    // beyond what was just submitted; admin views always re-fetch via list().
    return { ...input, id, status: 'submitted', submittedAt: new Date().toISOString() };
  }

  async list(): Promise<MatchingRequest[]> {
    try {
      const supabase = getSupabaseClient();
      const { data, error } = await supabase
        .from('matching_requests')
        .select(SELECT_WITH_JOINS)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('SupabaseMatchingRequestRepository.list failed:', error.message);
        return [];
      }
      return ((data ?? []) as unknown as MatchingRequestRow[]).map(mapRow);
    } catch (err) {
      console.error('SupabaseMatchingRequestRepository.list failed:', err instanceof Error ? err.message : err);
      return [];
    }
  }

  async updateStatus(id: string, status: MatchingRequest['status']): Promise<MatchingRequest> {
    const supabase = getSupabaseClient();

    const { data: current, error: readError } = await supabase.from('matching_requests').select('status').eq('id', id).single();
    if (readError) {
      console.error('SupabaseMatchingRequestRepository.updateStatus read failed:', readError.message);
      throw new Error('Unable to load this matching request.');
    }

    const { data, error } = await supabase
      .from('matching_requests')
      .update({ status })
      .eq('id', id)
      .select(SELECT_WITH_JOINS)
      .single();

    if (error) {
      console.error('SupabaseMatchingRequestRepository.updateStatus failed:', error.message);
      throw new Error('Unable to update this matching request.');
    }

    const { data: userData } = await supabase.auth.getUser();
    const { error: historyError } = await supabase.from('matching_request_status_history').insert({
      matching_request_id: id,
      previous_status: current.status,
      new_status: status,
      changed_by: userData.user?.id ?? null,
    });
    if (historyError) {
      console.error('SupabaseMatchingRequestRepository: status-history insert failed:', historyError.message);
    }

    return mapRow(data as unknown as MatchingRequestRow);
  }
}
