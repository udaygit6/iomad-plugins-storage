import { describe, it, expect } from 'vitest';
import { _mappers } from './SupabaseOrganisationRepository';
import type { OrganisationWithMappingRow, OrganisationCourseAllocationWithCourseRow } from '../../integrations/supabase/types';

function baseRow(overrides: Partial<OrganisationWithMappingRow> = {}): OrganisationWithMappingRow {
  return {
    id: 'org-1',
    name: 'Shiksha Academy',
    type: 'unclassified',
    status: 'active',
    source: 'iomad_sync',
    created_at: '2026-01-01T00:00:00Z',
    updated_at: '2026-01-15T09:30:00Z',
    iomad_company_mappings: [
      {
        id: 'map-1',
        organisation_id: 'org-1',
        iomad_company_id: '3',
        sync_status: 'synced',
        last_synced_at: '2026-01-15T09:30:00Z',
        last_error_code: null,
        created_at: '2026-01-01T00:00:00Z',
        updated_at: '2026-01-15T09:30:00Z',
      },
    ],
    ...overrides,
  };
}

describe('SupabaseOrganisationRepository mappers', () => {
  it('maps a well-formed row (array-embedded mapping) to the Organisation view shape', () => {
    expect(_mappers.mapOrganisationRow(baseRow())).toEqual({
      id: 'org-1',
      name: 'Shiksha Academy',
      type: 'unclassified',
      status: 'active',
      iomadCompanyId: '3',
      syncStatus: 'synced',
      lastSyncedAt: '2026-01-15T09:30:00Z',
      hasSyncIssue: false,
    });
  });

  it('accepts a single-object embedded mapping (defensive — some PostgREST/schema-cache configurations return this instead of an array)', () => {
    const row = baseRow({
      iomad_company_mappings: {
        id: 'map-1',
        organisation_id: 'org-1',
        iomad_company_id: '3',
        sync_status: 'synced',
        last_synced_at: '2026-01-15T09:30:00Z',
        last_error_code: null,
        created_at: '2026-01-01T00:00:00Z',
        updated_at: '2026-01-15T09:30:00Z',
      },
    });
    expect(_mappers.mapOrganisationRow(row).iomadCompanyId).toBe('3');
  });

  it('handles an empty embedded array safely (mapping absent) — no throw, safe nulls', () => {
    const row = baseRow({ iomad_company_mappings: [] });
    expect(_mappers.mapOrganisationRow(row)).toEqual({
      id: 'org-1',
      name: 'Shiksha Academy',
      type: 'unclassified',
      status: 'active',
      iomadCompanyId: null,
      syncStatus: null,
      lastSyncedAt: null,
      hasSyncIssue: false,
    });
  });

  it('handles a null embedded mapping safely (organisation exists with no mapping row at all)', () => {
    const row = baseRow({ iomad_company_mappings: null });
    const result = _mappers.mapOrganisationRow(row);
    expect(result.iomadCompanyId).toBeNull();
    expect(result.syncStatus).toBeNull();
    expect(result.lastSyncedAt).toBeNull();
    expect(result.hasSyncIssue).toBe(false);
  });

  it('sets hasSyncIssue true only when last_error_code is non-null, and never exposes the code itself', () => {
    const row = baseRow({
      iomad_company_mappings: [
        {
          id: 'map-2',
          organisation_id: 'org-1',
          iomad_company_id: '7',
          sync_status: 'failed',
          last_synced_at: '2026-01-10T14:00:00Z',
          last_error_code: 'network_error',
          created_at: '2026-01-01T00:00:00Z',
          updated_at: '2026-01-10T14:00:00Z',
        },
      ],
    });
    const result = _mappers.mapOrganisationRow(row);
    expect(result.hasSyncIssue).toBe(true);
    expect(result.syncStatus).toBe('failed');
    expect(Object.values(result)).not.toContain('network_error');
    expect(JSON.stringify(result)).not.toContain('network_error');
  });

  it('never includes address/custom fields/source/created_at/updated_at — only the documented safe fields', () => {
    const result = _mappers.mapOrganisationRow(baseRow());
    expect(Object.keys(result).sort()).toEqual(
      ['id', 'name', 'type', 'status', 'iomadCompanyId', 'syncStatus', 'lastSyncedAt', 'hasSyncIssue'].sort(),
    );
  });
});

describe('SupabaseOrganisationRepository._mappers.pickMapping', () => {
  it('returns the first element of a non-empty array', () => {
    const mapping = {
      id: 'map-1',
      organisation_id: 'org-1',
      iomad_company_id: '3',
      sync_status: 'synced' as const,
      last_synced_at: null,
      last_error_code: null,
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    };
    expect(_mappers.pickMapping([mapping])).toEqual(mapping);
  });

  it('returns null for an empty array', () => {
    expect(_mappers.pickMapping([])).toBeNull();
  });

  it('returns null for null/undefined', () => {
    expect(_mappers.pickMapping(null)).toBeNull();
    expect(_mappers.pickMapping(undefined)).toBeNull();
  });

  it('returns the object as-is when given a single object (not an array)', () => {
    const mapping = {
      id: 'map-1',
      organisation_id: 'org-1',
      iomad_company_id: '3',
      sync_status: 'pending' as const,
      last_synced_at: null,
      last_error_code: null,
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    };
    expect(_mappers.pickMapping(mapping)).toEqual(mapping);
  });
});

describe('SupabaseOrganisationRepository.mapOrganisationCourseRow (F5C)', () => {
  function baseCourseRow(overrides: Partial<OrganisationCourseAllocationWithCourseRow> = {}): OrganisationCourseAllocationWithCourseRow {
    return {
      id: 'alloc-1',
      licensed: false,
      shared: false,
      valid_length_days: 0,
      warn_expire_days: 0,
      warn_completion_days: 0,
      notify_period_days: 0,
      sync_status: 'synced',
      last_synced_at: '2026-01-15T09:30:00Z',
      courses: {
        name: 'Jupiter Test Mathematics',
        iomad_course_mappings: [{ iomad_course_id: '4' }],
      },
      ...overrides,
    };
  }

  it('maps the exact real Jupiter Test Mathematics fixture (array-embedded course mapping)', () => {
    expect(_mappers.mapOrganisationCourseRow(baseCourseRow())).toEqual({
      id: 'alloc-1',
      courseName: 'Jupiter Test Mathematics',
      iomadCourseId: '4',
      licensed: false,
      shared: false,
      validLengthDays: 0,
      warnExpireDays: 0,
      warnCompletionDays: 0,
      notifyPeriodDays: 0,
      syncStatus: 'synced',
      lastSyncedAt: '2026-01-15T09:30:00Z',
    });
  });

  it('accepts a single-object embedded course mapping (defensive)', () => {
    const row = baseCourseRow({
      courses: { name: 'Jupiter Test Mathematics', iomad_course_mappings: { iomad_course_id: '4' } },
    });
    expect(_mappers.mapOrganisationCourseRow(row).iomadCourseId).toBe('4');
  });

  it('handles a missing iomad course mapping safely — iomadCourseId is null, no throw', () => {
    const row = baseCourseRow({ courses: { name: 'Jupiter Test Mathematics', iomad_course_mappings: [] } });
    expect(_mappers.mapOrganisationCourseRow(row).iomadCourseId).toBeNull();

    const rowNull = baseCourseRow({ courses: { name: 'Jupiter Test Mathematics', iomad_course_mappings: null } });
    expect(_mappers.mapOrganisationCourseRow(rowNull).iomadCourseId).toBeNull();
  });

  it('handles a null courses embed defensively (falls back to "Unknown course", no throw)', () => {
    const row = baseCourseRow({ courses: null });
    const result = _mappers.mapOrganisationCourseRow(row);
    expect(result.courseName).toBe('Unknown course');
    expect(result.iomadCourseId).toBeNull();
  });

  it('maps a stale allocation correctly', () => {
    const row = baseCourseRow({ sync_status: 'stale' });
    expect(_mappers.mapOrganisationCourseRow(row).syncStatus).toBe('stale');
  });

  it('maps a failed allocation correctly (safe label mapping is the UI\'s job, not this mapper\'s)', () => {
    const row = baseCourseRow({ sync_status: 'failed' });
    expect(_mappers.mapOrganisationCourseRow(row).syncStatus).toBe('failed');
  });

  it('maps licensed/shared true correctly', () => {
    const row = baseCourseRow({ licensed: true, shared: true });
    const result = _mappers.mapOrganisationCourseRow(row);
    expect(result.licensed).toBe(true);
    expect(result.shared).toBe(true);
  });

  it('preserves a nonzero valid_length_days as-is (display formatting is the UI\'s job)', () => {
    const row = baseCourseRow({ valid_length_days: 365 });
    expect(_mappers.mapOrganisationCourseRow(row).validLengthDays).toBe(365);
  });

  it('never includes raw database fields (organisation_id, course_id, created_at, updated_at, last_error_code) — only the documented safe fields', () => {
    const result = _mappers.mapOrganisationCourseRow(baseCourseRow());
    expect(Object.keys(result).sort()).toEqual(
      [
        'id',
        'courseName',
        'iomadCourseId',
        'licensed',
        'shared',
        'validLengthDays',
        'warnExpireDays',
        'warnCompletionDays',
        'notifyPeriodDays',
        'syncStatus',
        'lastSyncedAt',
      ].sort(),
    );
  });
});

describe('SupabaseOrganisationRepository._mappers.pickCourseMapping', () => {
  it('returns the first element of a non-empty array', () => {
    expect(_mappers.pickCourseMapping([{ iomad_course_id: '4' }])).toEqual({ iomad_course_id: '4' });
  });

  it('returns null for an empty array, null, or undefined', () => {
    expect(_mappers.pickCourseMapping([])).toBeNull();
    expect(_mappers.pickCourseMapping(null)).toBeNull();
    expect(_mappers.pickCourseMapping(undefined)).toBeNull();
  });

  it('returns the object as-is when given a single object', () => {
    expect(_mappers.pickCourseMapping({ iomad_course_id: '4' })).toEqual({ iomad_course_id: '4' });
  });
});
