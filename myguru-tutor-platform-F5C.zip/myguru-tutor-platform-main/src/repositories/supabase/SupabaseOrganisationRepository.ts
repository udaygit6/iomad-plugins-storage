import { getSupabaseClient } from '../../integrations/supabase/client';
import type {
  OrganisationWithMappingRow,
  IomadCompanyMappingRow,
  OrganisationCourseAllocationWithCourseRow,
  IomadCourseMappingIdOnlyRow,
} from '../../integrations/supabase/types';
import type { OrganisationRepository, Organisation, OrganisationCourse } from '../interfaces';

/**
 * Admin-only, read-only view of F4/F4C's already-synchronised
 * organisation + Iomad company mapping data. Never calls Iomad, never
 * writes, never uses the service-role key — only the authenticated
 * browser Supabase client, relying on RLS (0015's admin-read-only
 * policies) for authorization, exactly like `SupabaseSubjectRepository`'s
 * `listForAdmin()`.
 */

function pickMapping(
  raw: IomadCompanyMappingRow[] | IomadCompanyMappingRow | null | undefined,
): IomadCompanyMappingRow | null {
  if (!raw) return null;
  if (Array.isArray(raw)) return raw[0] ?? null;
  return raw;
}

function mapOrganisationRow(row: OrganisationWithMappingRow): Organisation {
  const mapping = pickMapping(row.iomad_company_mappings);
  return {
    id: row.id,
    name: row.name,
    type: row.type,
    status: row.status,
    iomadCompanyId: mapping?.iomad_company_id ?? null,
    syncStatus: mapping?.sync_status ?? null,
    lastSyncedAt: mapping?.last_synced_at ?? null,
    hasSyncIssue: Boolean(mapping?.last_error_code),
  };
}

/** Same "accept array, single object, or absent" defensiveness as
 * `pickMapping` above, applied to the nested course→mapping embed. */
function pickCourseMapping(
  raw: IomadCourseMappingIdOnlyRow[] | IomadCourseMappingIdOnlyRow | null | undefined,
): IomadCourseMappingIdOnlyRow | null {
  if (!raw) return null;
  if (Array.isArray(raw)) return raw[0] ?? null;
  return raw;
}

function mapOrganisationCourseRow(row: OrganisationCourseAllocationWithCourseRow): OrganisationCourse {
  const mapping = pickCourseMapping(row.courses?.iomad_course_mappings);
  return {
    id: row.id,
    // Defensive: courses is only null if the allocation's course_id FK
    // somehow points at nothing (should not happen given the FK
    // constraint, but this view never assumes it can't).
    courseName: row.courses?.name ?? 'Unknown course',
    iomadCourseId: mapping?.iomad_course_id ?? null,
    licensed: row.licensed,
    shared: row.shared,
    validLengthDays: row.valid_length_days,
    warnExpireDays: row.warn_expire_days,
    warnCompletionDays: row.warn_completion_days,
    notifyPeriodDays: row.notify_period_days,
    syncStatus: row.sync_status,
    lastSyncedAt: row.last_synced_at,
  };
}

// Exported for unit testing the mapping in isolation, without a network call.
export const _mappers = { mapOrganisationRow, pickMapping, mapOrganisationCourseRow, pickCourseMapping };

export class SupabaseOrganisationRepository implements OrganisationRepository {
  async listForAdmin(): Promise<Organisation[]> {
    const supabase = getSupabaseClient();
    const { data, error } = await supabase
      .from('organisations')
      .select('*, iomad_company_mappings(*)')
      .order('name', { ascending: true });

    if (error) {
      // Logged server-console-equivalent (browser devtools) only — a
      // Postgres/PostgREST error code and description, never surfaced
      // to the admin UI itself. See AdminOrganisationsPage.tsx's safe
      // generic error state.
      console.error('SupabaseOrganisationRepository.listForAdmin failed:', error.message);
      throw new Error('Unable to load organisations right now.');
    }

    return (data ?? []).map((row) => mapOrganisationRow(row as OrganisationWithMappingRow));
  }

  async listOrganisationCourses(organisationId: string): Promise<OrganisationCourse[]> {
    const supabase = getSupabaseClient();
    // Minimum fields required by the UI only (F5C brief) — no address,
    // no custom fields, no raw upstream payload; those were never
    // persisted by F5B in the first place.
    const { data, error } = await supabase
      .from('organisation_course_allocations')
      .select(
        `id, licensed, shared, valid_length_days, warn_expire_days, warn_completion_days, notify_period_days, sync_status, last_synced_at, courses ( name, iomad_course_mappings ( iomad_course_id ) )`,
      )
      .eq('organisation_id', organisationId)
      .order('created_at', { ascending: true });

    if (error) {
      console.error('SupabaseOrganisationRepository.listOrganisationCourses failed:', error.message);
      throw new Error('Unable to load courses for this organisation right now.');
    }

    return (data ?? []).map((row) =>
      mapOrganisationCourseRow(row as unknown as OrganisationCourseAllocationWithCourseRow),
    );
  }
}
