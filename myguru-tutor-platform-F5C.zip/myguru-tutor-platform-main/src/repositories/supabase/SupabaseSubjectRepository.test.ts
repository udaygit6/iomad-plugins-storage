import { describe, it, expect } from 'vitest';
import { _mappers } from './SupabaseSubjectRepository';
import type { SubjectRow, EducationLevelRow } from '../../integrations/supabase/types';

describe('SupabaseSubjectRepository mappers', () => {
  it('maps a subject row to the domain Subject shape', () => {
    const row: SubjectRow = {
      id: 'id-1',
      slug: 'maths',
      name: 'Maths',
      description: 'From times tables to A-Level calculus.',
      enabled: true,
      display_order: 1,
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    };

    expect(_mappers.mapSubjectRow(row)).toEqual({
      id: 'id-1',
      slug: 'maths',
      name: 'Maths',
      description: 'From times tables to A-Level calculus.',
    });
  });

  it('maps a null description to undefined, not null', () => {
    const row: SubjectRow = {
      id: 'id-2',
      slug: 'geography',
      name: 'Geography',
      description: null,
      enabled: true,
      display_order: 2,
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    };

    expect(_mappers.mapSubjectRow(row).description).toBeUndefined();
  });

  it('maps an education level row, preserving ks1/ks2 as distinct slugs', () => {
    const row: EducationLevelRow = {
      id: 'lvl-1',
      slug: 'ks1',
      name: 'KS1',
      stage_headline: 'Build strong foundations',
      stage_description: 'Early reading, writing and number skills, at their own pace.',
      display_order: 1,
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    };

    const mapped = _mappers.mapEducationLevelRow(row);
    expect(mapped.slug).toBe('ks1');
    expect(mapped.stageHeadline).toBe('Build strong foundations');
    expect(mapped.stageDescription).toBe('Early reading, writing and number skills, at their own pace.');
  });
});
