import { getSupabaseClient } from '../../integrations/supabase/client';
import type { SubjectRow, EducationLevelRow } from '../../integrations/supabase/types';
import type { SubjectRepository, AdminSubjectView } from '../interfaces';
import type { Subject, EducationLevel } from '../../domain/models/types';

function mapSubjectRow(row: SubjectRow): Subject {
  return {
    id: row.id,
    slug: row.slug,
    name: row.name,
    description: row.description ?? undefined,
  };
}

function mapEducationLevelRow(row: EducationLevelRow): EducationLevel {
  return {
    id: row.id,
    slug: row.slug,
    name: row.name,
    stageHeadline: row.stage_headline,
    stageDescription: row.stage_description,
  };
}

// Exported for unit testing the mapping in isolation, without a network call.
export const _mappers = { mapSubjectRow, mapEducationLevelRow };

export class SupabaseSubjectRepository implements SubjectRepository {
  async list(): Promise<Subject[]> {
    try {
      const supabase = getSupabaseClient();
      // RLS already restricts anon/authenticated to enabled=true (0009), but
      // filtering explicitly here keeps the query's intent self-documenting
      // and correct even if this ever runs under a broader-privileged role.
      const { data, error } = await supabase
        .from('subjects')
        .select('*')
        .eq('enabled', true)
        .order('display_order', { ascending: true });

      if (error) {
        console.error('SupabaseSubjectRepository.list failed:', error.message);
        return [];
      }
      return (data ?? []).map(mapSubjectRow);
    } catch (err) {
      console.error('SupabaseSubjectRepository.list failed:', err instanceof Error ? err.message : err);
      return [];
    }
  }

  async getBySlug(slug: string): Promise<Subject | null> {
    try {
      const supabase = getSupabaseClient();
      const { data, error } = await supabase
        .from('subjects')
        .select('*')
        .eq('slug', slug)
        .eq('enabled', true)
        .maybeSingle();

      if (error) {
        console.error('SupabaseSubjectRepository.getBySlug failed:', error.message);
        return null;
      }
      return data ? mapSubjectRow(data) : null;
    } catch (err) {
      console.error('SupabaseSubjectRepository.getBySlug failed:', err instanceof Error ? err.message : err);
      return null;
    }
  }

  async listEducationLevels(): Promise<EducationLevel[]> {
    try {
      const supabase = getSupabaseClient();
      const { data, error } = await supabase
        .from('education_levels')
        .select('*')
        .order('display_order', { ascending: true });

      if (error) {
        console.error('SupabaseSubjectRepository.listEducationLevels failed:', error.message);
        return [];
      }
      return (data ?? []).map(mapEducationLevelRow);
    } catch (err) {
      console.error('SupabaseSubjectRepository.listEducationLevels failed:', err instanceof Error ? err.message : err);
      return [];
    }
  }

  /**
   * Admin-only: every subject regardless of enabled state. Deliberately
   * does NOT filter by enabled=true — relies on RLS (0009's
   * subjects_admin_all policy, gated by is_admin()) to return every row
   * for an actual admin session and only enabled rows (or none) for
   * anyone else. This method should only ever be called from an
   * admin-authenticated context (AdminSubjectsService).
   */
  async listForAdmin(): Promise<AdminSubjectView[]> {
    try {
      const supabase = getSupabaseClient();
      const { data, error } = await supabase.from('subjects').select('*').order('display_order', { ascending: true });

      if (error) {
        console.error('SupabaseSubjectRepository.listForAdmin failed:', error.message);
        return [];
      }
      return (data ?? []).map((row: SubjectRow) => ({ ...mapSubjectRow(row), enabled: row.enabled }));
    } catch (err) {
      console.error('SupabaseSubjectRepository.listForAdmin failed:', err instanceof Error ? err.message : err);
      return [];
    }
  }

  /** Admin-only write. RLS (subjects_admin_all) enforces authorization — this call fails safe (throws) for a non-admin session. */
  async setEnabled(id: string, enabled: boolean): Promise<Subject> {
    const supabase = getSupabaseClient();
    const { data, error } = await supabase.from('subjects').update({ enabled }).eq('id', id).select('*').single();

    if (error) {
      console.error('SupabaseSubjectRepository.setEnabled failed:', error.message);
      throw new Error('Unable to update subject visibility.');
    }
    return mapSubjectRow(data as SubjectRow);
  }
}
