import { describe, it, expect } from 'vitest';
import { _mappers } from './SupabaseTutorApplicationRepository';

function makeRow() {
  return {
    id: 'app-1',
    status: 'submitted' as const,
    full_name: 'Priya Patel',
    email: 'priya@example.com',
    phone: null,
    about_you: 'About text',
    teaching_experience: 'Experience text',
    education: 'Education text',
    teaching_approach: 'Approach text',
    availability_notes: 'Weekday evenings',
    supporting_documents_note: null,
    admin_notes: null,
    submitted_at: '2026-01-01T00:00:00Z',
    reviewed_at: null,
    tutor_application_qualifications: [
      { qualification_text: 'PGCE', display_order: 1 },
      { qualification_text: 'BSc Maths', display_order: 0 },
    ],
    tutor_application_subjects: [{ subjects: { slug: 'maths' } }],
    tutor_application_levels: [{ education_levels: { slug: 'gcse' as const } }],
  };
}

describe('SupabaseTutorApplicationRepository row mapping', () => {
  it('sorts qualifications by display_order regardless of row order', () => {
    const mapped = _mappers.mapRow(makeRow());
    expect(mapped.qualifications).toEqual(['BSc Maths', 'PGCE']);
  });

  it('maps joined subjects/levels to slug arrays', () => {
    const mapped = _mappers.mapRow(makeRow());
    expect(mapped.subjectSlugs).toEqual(['maths']);
    expect(mapped.educationLevelSlugs).toEqual(['gcse']);
  });

  it('never fabricates verification/publication state — only maps what the row actually has', () => {
    const mapped = _mappers.mapRow(makeRow());
    expect(mapped.status).toBe('submitted');
    expect(mapped).not.toHaveProperty('publicVerificationBadges');
  });

  it('maps admin-only fields (admin_notes, reviewed_at) when present', () => {
    const row = { ...makeRow(), admin_notes: 'Looks good', reviewed_at: '2026-01-02T00:00:00Z', status: 'approved' as const };
    const mapped = _mappers.mapRow(row);
    expect(mapped.adminNotes).toBe('Looks good');
    expect(mapped.reviewedAt).toBe('2026-01-02T00:00:00Z');
  });
});
