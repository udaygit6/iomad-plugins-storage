import { getSupabaseClient } from '../../integrations/supabase/client';
import { postSubmission } from './httpSubmit';
import type { TutorApplicationRepository, SubmitMeta } from '../interfaces';
import type { TutorApplication, EducationLevelSlug } from '../../domain/models/types';

interface TutorApplicationRow {
  id: string;
  status: TutorApplication['status'];
  full_name: string;
  email: string;
  phone: string | null;
  about_you: string;
  teaching_experience: string;
  education: string;
  teaching_approach: string;
  availability_notes: string;
  supporting_documents_note: string | null;
  admin_notes: string | null;
  submitted_at: string | null;
  reviewed_at: string | null;
  tutor_application_qualifications: { qualification_text: string; display_order: number }[];
  tutor_application_subjects: { subjects: { slug: string } }[];
  tutor_application_levels: { education_levels: { slug: EducationLevelSlug } }[];
}

const SELECT_WITH_JOINS = `
  *,
  tutor_application_qualifications ( qualification_text, display_order ),
  tutor_application_subjects ( subjects ( slug ) ),
  tutor_application_levels ( education_levels ( slug ) )
`;

function mapRow(row: TutorApplicationRow): TutorApplication {
  return {
    id: row.id,
    status: row.status,
    fullName: row.full_name,
    email: row.email,
    phone: row.phone ?? undefined,
    aboutYou: row.about_you,
    teachingExperience: row.teaching_experience,
    education: row.education,
    qualifications: [...row.tutor_application_qualifications]
      .sort((a, b) => a.display_order - b.display_order)
      .map((q) => q.qualification_text),
    subjectSlugs: row.tutor_application_subjects.map((j) => j.subjects.slug),
    educationLevelSlugs: row.tutor_application_levels.map((j) => j.education_levels.slug),
    teachingApproach: row.teaching_approach,
    availabilityNotes: row.availability_notes,
    supportingDocumentsNote: row.supporting_documents_note ?? undefined,
    submittedAt: row.submitted_at ?? undefined,
    reviewedAt: row.reviewed_at ?? undefined,
    adminNotes: row.admin_notes ?? undefined,
  };
}

// Exported for unit testing without a network call.
export const _mappers = { mapRow };

export class SupabaseTutorApplicationRepository implements TutorApplicationRepository {
  async submit(input: Omit<TutorApplication, 'id' | 'status' | 'submittedAt'>, meta?: SubmitMeta): Promise<TutorApplication> {
    const { id } = await postSubmission('submit-tutor-application', {
      fullName: input.fullName,
      email: input.email,
      phone: input.phone,
      aboutYou: input.aboutYou,
      teachingExperience: input.teachingExperience,
      education: input.education,
      qualifications: input.qualifications,
      subjectSlugs: input.subjectSlugs,
      educationLevelSlugs: input.educationLevelSlugs,
      teachingApproach: input.teachingApproach,
      availabilityNotes: input.availabilityNotes,
      supportingDocumentsNote: input.supportingDocumentsNote,
      website: meta?.honeypotValue ?? '',
      formLoadedAt: meta?.formLoadedAt,
    });
    return { ...input, id, status: 'submitted', submittedAt: new Date().toISOString() };
  }

  async list(): Promise<TutorApplication[]> {
    try {
      const supabase = getSupabaseClient();
      const { data, error } = await supabase
        .from('tutor_applications')
        .select(SELECT_WITH_JOINS)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('SupabaseTutorApplicationRepository.list failed:', error.message);
        return [];
      }
      return ((data ?? []) as unknown as TutorApplicationRow[]).map(mapRow);
    } catch (err) {
      console.error('SupabaseTutorApplicationRepository.list failed:', err instanceof Error ? err.message : err);
      return [];
    }
  }

  async getById(id: string): Promise<TutorApplication | null> {
    try {
      const supabase = getSupabaseClient();
      const { data, error } = await supabase.from('tutor_applications').select(SELECT_WITH_JOINS).eq('id', id).maybeSingle();

      if (error) {
        console.error('SupabaseTutorApplicationRepository.getById failed:', error.message);
        return null;
      }
      return data ? mapRow(data as unknown as TutorApplicationRow) : null;
    } catch (err) {
      console.error('SupabaseTutorApplicationRepository.getById failed:', err instanceof Error ? err.message : err);
      return null;
    }
  }

  async updateStatus(id: string, status: TutorApplication['status'], adminNotes?: string): Promise<TutorApplication> {
    const supabase = getSupabaseClient();

    const { data: current, error: readError } = await supabase.from('tutor_applications').select('status').eq('id', id).single();
    if (readError) {
      console.error('SupabaseTutorApplicationRepository.updateStatus read failed:', readError.message);
      throw new Error('Unable to load this application.');
    }

    const { data, error } = await supabase
      .from('tutor_applications')
      .update({ status, admin_notes: adminNotes, reviewed_at: new Date().toISOString() })
      .eq('id', id)
      .select(SELECT_WITH_JOINS)
      .single();

    if (error) {
      console.error('SupabaseTutorApplicationRepository.updateStatus failed:', error.message);
      throw new Error('Unable to update this application.');
    }

    const { data: userData } = await supabase.auth.getUser();
    const { error: historyError } = await supabase.from('tutor_application_status_history').insert({
      tutor_application_id: id,
      previous_status: current.status,
      new_status: status,
      changed_by: userData.user?.id ?? null,
      notes: adminNotes ?? null,
    });
    if (historyError) {
      console.error('SupabaseTutorApplicationRepository: status-history insert failed:', historyError.message);
    }

    return mapRow(data as unknown as TutorApplicationRow);
  }
}
