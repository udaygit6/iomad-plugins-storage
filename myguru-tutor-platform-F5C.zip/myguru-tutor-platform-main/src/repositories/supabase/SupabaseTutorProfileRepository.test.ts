import { describe, it, expect, vi, beforeEach } from 'vitest';
import { _mappers, SupabaseTutorProfileRepository } from './SupabaseTutorProfileRepository';
import * as clientModule from '../../integrations/supabase/client';
import type { TutorApplication } from '../../domain/models/types';

function makeRow() {
  return {
    id: 'profile-1',
    slug: 'sarah-e-abc123',
    public_display_name: 'Sarah E.',
    headline: 'Maths',
    positioning_statement: null,
    bio: 'About text',
    teaching_approach: 'Approach text',
    photo_url: null,
    qualifications_summary: [],
    experience_summary: 'Experience text',
    languages: [],
    accepting_students: false,
    status: 'draft' as const,
    tutor_application_id: 'app-1',
    tutor_profile_subjects: [{ subjects: { id: 's1', slug: 'maths', name: 'Maths', description: null, enabled: true, display_order: 1, created_at: '', updated_at: '' } }],
    tutor_profile_levels: [{ education_levels: { id: 'l1', slug: 'gcse' as const, name: 'GCSE', stage_headline: 'h', stage_description: 'd', display_order: 4, created_at: '', updated_at: '' } }],
  };
}

describe('SupabaseTutorProfileRepository row mapping', () => {
  it('includes the linked application id for the admin view', () => {
    const mapped = _mappers.mapRow(makeRow());
    expect(mapped.tutorApplicationId).toBe('app-1');
  });

  it('handles no linked application (null) by leaving the field undefined', () => {
    const mapped = _mappers.mapRow({ ...makeRow(), tutor_application_id: null });
    expect(mapped.tutorApplicationId).toBeUndefined();
  });

  it('always returns an empty verification-badge array — the admin editor never inherits or displays public badges here', () => {
    const mapped = _mappers.mapRow(makeRow());
    expect(mapped.publicVerificationBadges).toEqual([]);
  });

  it('never surfaces application-only private fields (email, phone, adminNotes) — the type itself has no such property', () => {
    const mapped = _mappers.mapRow(makeRow());
    expect(mapped).not.toHaveProperty('email');
    expect(mapped).not.toHaveProperty('phone');
    expect(mapped).not.toHaveProperty('adminNotes');
  });

  it('maps subject and level joins correctly, preserving distinct KS1/KS2/etc slugs', () => {
    const mapped = _mappers.mapRow(makeRow());
    expect(mapped.subjects).toEqual([{ id: 's1', slug: 'maths', name: 'Maths', description: undefined }]);
    expect(mapped.educationLevels[0].slug).toBe('gcse');
  });
});

// ---------------------------------------------------------------------------
// E7 review fixes: auth.uid()-derived identity, and the RPC-based update()
// replacing independent client-side junction-table calls.
// ---------------------------------------------------------------------------

function makeApplication(overrides: Partial<TutorApplication> = {}): TutorApplication {
  return {
    id: 'app-1',
    status: 'approved',
    fullName: 'Sarah Example',
    email: 'sarah@example.com',
    aboutYou: 'About',
    teachingExperience: 'Experience',
    education: 'Education',
    qualifications: [],
    subjectSlugs: ['maths'],
    educationLevelSlugs: ['gcse'],
    teachingApproach: 'Approach',
    availabilityNotes: 'Evenings',
    ...overrides,
  };
}

/** A minimal PostgREST-style chainable/awaitable fake — supports the
 * subset of the query builder this repository actually calls. */
class FakeQueryBuilder implements PromiseLike<{ data: unknown; error: unknown }> {
  private result: { data: unknown; error: unknown };
  constructor(result: { data: unknown; error: unknown }) {
    this.result = result;
  }
  select() { return this; }
  eq() { return this; }
  in() { return this; }
  order() { return this; }
  insert() { return this; }
  delete() { return this; }
  update() { return this; }
  maybeSingle() { return Promise.resolve(this.result); }
  single() { return Promise.resolve(this.result); }
  then<TResult1, TResult2>(
    onfulfilled?: ((value: { data: unknown; error: unknown }) => TResult1 | PromiseLike<TResult1>) | null,
    onrejected?: ((reason: unknown) => TResult2 | PromiseLike<TResult2>) | null,
  ) {
    return Promise.resolve(this.result).then(onfulfilled, onrejected);
  }
}

function makeFakeSupabase(profileRow: unknown, rpcResult: { data: unknown; error: unknown }) {
  const fromTableCalls: string[] = [];
  const from = vi.fn((table: string) => {
    fromTableCalls.push(table);
    return new FakeQueryBuilder({ data: profileRow, error: null });
  });
  const rpc = vi.fn().mockResolvedValue(rpcResult);
  const client = { from, rpc, auth: { getUser: vi.fn().mockResolvedValue({ data: { user: { id: 'admin-1' } } }) } };
  return { client, from, rpc, fromTableCalls };
}

describe('SupabaseTutorProfileRepository.createFromApplication (auth identity fix)', () => {
  beforeEach(() => vi.restoreAllMocks());

  it('calls the RPC with only p_application_id — never a caller-supplied changed-by identity', async () => {
    const { client, rpc } = makeFakeSupabase(makeRow(), { data: 'profile-1', error: null });
    vi.spyOn(clientModule, 'getSupabaseClient').mockReturnValue(client as never);

    const repo = new SupabaseTutorProfileRepository();
    await repo.createFromApplication(makeApplication());

    expect(rpc).toHaveBeenCalledWith('create_tutor_profile_from_application', { p_application_id: 'app-1' });
    const callArgs = rpc.mock.calls[0][1] as Record<string, unknown>;
    expect(callArgs).not.toHaveProperty('p_changed_by');
    expect(callArgs).not.toHaveProperty('changedBy');
  });
});

describe('SupabaseTutorProfileRepository.update (transactional RPC fix)', () => {
  beforeEach(() => vi.restoreAllMocks());

  it('calls update_tutor_profile exactly once with the merged field set, never touching junction tables directly', async () => {
    const { client, rpc, from } = makeFakeSupabase(makeRow(), { data: 'profile-1', error: null });
    vi.spyOn(clientModule, 'getSupabaseClient').mockReturnValue(client as never);

    const repo = new SupabaseTutorProfileRepository();
    await repo.update('profile-1', { headline: 'New headline', subjectSlugs: ['maths', 'physics'] });

    expect(rpc).toHaveBeenCalledTimes(1);
    expect(rpc).toHaveBeenCalledWith(
      'update_tutor_profile',
      expect.objectContaining({
        p_profile_id: 'profile-1',
        p_headline: 'New headline',
        p_subject_slugs: ['maths', 'physics'],
      }),
    );

    // The repository must never call .from('tutor_profile_subjects') or
    // .from('tutor_profile_levels') directly for the write path — only the
    // RPC touches those tables now. (getById still reads tutor_profiles,
    // which is expected.)
    expect(from.mock.calls.map((c) => c[0])).not.toContain('tutor_profile_subjects');
    expect(from.mock.calls.map((c) => c[0])).not.toContain('tutor_profile_levels');
  });

  it('merges unspecified fields from the current profile rather than clobbering them', async () => {
    const { client, rpc } = makeFakeSupabase(makeRow(), { data: 'profile-1', error: null });
    vi.spyOn(clientModule, 'getSupabaseClient').mockReturnValue(client as never);

    const repo = new SupabaseTutorProfileRepository();
    // Only headline is being changed — bio, teachingApproach, etc. should
    // be sent as their CURRENT values (from makeRow()), not blanked out.
    await repo.update('profile-1', { headline: 'New headline' });

    const callArgs = rpc.mock.calls[0][1] as Record<string, unknown>;
    expect(callArgs.p_bio).toBe('About text');
    expect(callArgs.p_teaching_approach).toBe('Approach text');
    expect(callArgs.p_subject_slugs).toEqual(['maths']);
  });

  it('surfaces a distinct error for an invalid subject slug', async () => {
    const { client } = makeFakeSupabase(makeRow(), { data: null, error: { message: 'invalid_subject_slug' } });
    vi.spyOn(clientModule, 'getSupabaseClient').mockReturnValue(client as never);

    const repo = new SupabaseTutorProfileRepository();
    await expect(repo.update('profile-1', { subjectSlugs: ['not-a-real-subject'] })).rejects.toThrow(/subjects are invalid/i);
  });

  it('surfaces a distinct error for an invalid education-level slug', async () => {
    const { client } = makeFakeSupabase(makeRow(), { data: null, error: { message: 'invalid_education_level_slug' } });
    vi.spyOn(clientModule, 'getSupabaseClient').mockReturnValue(client as never);

    const repo = new SupabaseTutorProfileRepository();
    await expect(repo.update('profile-1', { educationLevelSlugs: ['not-a-real-level'] as never })).rejects.toThrow(/education levels are invalid/i);
  });
});
