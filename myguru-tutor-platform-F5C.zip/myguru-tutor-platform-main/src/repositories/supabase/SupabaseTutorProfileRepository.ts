import { getSupabaseClient } from '../../integrations/supabase/client';
import type { TutorProfileRepository, TutorProfileUpdateInput, AdminTutorProfileView } from '../interfaces';
import type { TutorApplication, TutorProfileStatus } from '../../domain/models/types';
import type { TutorProfileRow, TutorProfileSubjectJoinRow, TutorProfileLevelJoinRow } from '../../integrations/supabase/types';

type TutorProfileQueryRow = TutorProfileRow & {
  tutor_application_id: string | null;
  tutor_profile_subjects: TutorProfileSubjectJoinRow[];
  tutor_profile_levels: TutorProfileLevelJoinRow[];
};

const SELECT_WITH_JOINS = `
  *,
  tutor_profile_subjects ( subjects ( * ) ),
  tutor_profile_levels ( education_levels ( * ) )
`;

function mapRow(row: TutorProfileQueryRow): AdminTutorProfileView {
  return {
    id: row.id,
    slug: row.slug,
    publicDisplayName: row.public_display_name,
    headline: row.headline,
    positioningStatement: row.positioning_statement ?? undefined,
    bio: row.bio,
    teachingApproach: row.teaching_approach,
    photoUrl: row.photo_url ?? undefined,
    subjects: row.tutor_profile_subjects.map((j) => ({
      id: j.subjects.id,
      slug: j.subjects.slug,
      name: j.subjects.name,
      description: j.subjects.description ?? undefined,
    })),
    educationLevels: row.tutor_profile_levels.map((j) => ({
      id: j.education_levels.id,
      slug: j.education_levels.slug,
      name: j.education_levels.name,
      stageHeadline: j.education_levels.stage_headline,
      stageDescription: j.education_levels.stage_description,
    })),
    qualificationsSummary: row.qualifications_summary,
    experienceSummary: row.experience_summary,
    languages: row.languages,
    acceptingStudents: row.accepting_students,
    // Admin editing view never needs public verification badges — that
    // remains the public-safe view's concern (SupabaseTutorRepository).
    publicVerificationBadges: [],
    status: row.status,
    tutorApplicationId: row.tutor_application_id ?? undefined,
  };
}

// Exported for unit testing without a network call.
export const _mappers = { mapRow };

async function recordStatusHistory(
  supabase: ReturnType<typeof getSupabaseClient>,
  profileId: string,
  previousStatus: TutorProfileStatus,
  newStatus: TutorProfileStatus,
) {
  const { data: userData } = await supabase.auth.getUser();
  const { error } = await supabase.from('tutor_profile_status_history').insert({
    tutor_profile_id: profileId,
    previous_status: previousStatus,
    new_status: newStatus,
    changed_by: userData.user?.id ?? null,
  });
  if (error) {
    console.error('SupabaseTutorProfileRepository: status-history insert failed:', error.message);
  }
}

export class SupabaseTutorProfileRepository implements TutorProfileRepository {
  async listForAdmin(): Promise<AdminTutorProfileView[]> {
    try {
      const supabase = getSupabaseClient();
      const { data, error } = await supabase.from('tutor_profiles').select(SELECT_WITH_JOINS).order('created_at', { ascending: false });
      if (error) {
        console.error('SupabaseTutorProfileRepository.listForAdmin failed:', error.message);
        return [];
      }
      return ((data ?? []) as unknown as TutorProfileQueryRow[]).map(mapRow);
    } catch (err) {
      console.error('SupabaseTutorProfileRepository.listForAdmin failed:', err instanceof Error ? err.message : err);
      return [];
    }
  }

  async getById(id: string): Promise<AdminTutorProfileView | null> {
    try {
      const supabase = getSupabaseClient();
      const { data, error } = await supabase.from('tutor_profiles').select(SELECT_WITH_JOINS).eq('id', id).maybeSingle();
      if (error) {
        console.error('SupabaseTutorProfileRepository.getById failed:', error.message);
        return null;
      }
      return data ? mapRow(data as unknown as TutorProfileQueryRow) : null;
    } catch (err) {
      console.error('SupabaseTutorProfileRepository.getById failed:', err instanceof Error ? err.message : err);
      return null;
    }
  }

  async getByApplicationId(applicationId: string): Promise<AdminTutorProfileView | null> {
    try {
      const supabase = getSupabaseClient();
      const { data, error } = await supabase
        .from('tutor_profiles')
        .select(SELECT_WITH_JOINS)
        .eq('tutor_application_id', applicationId)
        .maybeSingle();
      if (error) {
        console.error('SupabaseTutorProfileRepository.getByApplicationId failed:', error.message);
        return null;
      }
      return data ? mapRow(data as unknown as TutorProfileQueryRow) : null;
    } catch (err) {
      console.error('SupabaseTutorProfileRepository.getByApplicationId failed:', err instanceof Error ? err.message : err);
      return null;
    }
  }

  /**
   * Calls the atomic, concurrency-safe create_tutor_profile_from_application
   * RPC (supabase/migrations/0014) — the RPC re-validates approved status
   * and idempotency itself server-side (defense in depth beyond the
   * service layer's own check, and safe even against a genuine race
   * between two concurrent calls), then this method re-fetches the full
   * row via getById so the caller gets the complete joined shape.
   * changed_by is derived from auth.uid() inside the RPC — never passed by
   * this client.
   */
  async createFromApplication(application: TutorApplication): Promise<AdminTutorProfileView> {
    const supabase = getSupabaseClient();

    const { data: profileId, error } = await supabase.rpc('create_tutor_profile_from_application', {
      p_application_id: application.id,
    });

    if (error) {
      console.error('SupabaseTutorProfileRepository.createFromApplication failed:', error.message);
      if (error.message?.includes('application_not_approved')) {
        throw new Error('Only approved applications can create a tutor profile.');
      }
      throw new Error('Unable to create a tutor profile from this application.');
    }

    const profile = await this.getById(profileId as string);
    if (!profile) throw new Error('Tutor profile was created but could not be reloaded.');
    return profile;
  }

  /**
   * Calls the atomic update_tutor_profile RPC (supabase/migrations/0014).
   * This method preserves the repository interface's PARTIAL-update
   * contract (only fields present in `updates` should change) by first
   * reading the current profile and merging `updates` over it — the write
   * itself is then a single atomic RPC call, never independent
   * update/delete/insert calls that could leave a half-applied profile if
   * one step failed.
   */
  async update(id: string, updates: TutorProfileUpdateInput): Promise<AdminTutorProfileView> {
    const current = await this.getById(id);
    if (!current) throw new Error('Tutor profile not found.');

    const merged = {
      publicDisplayName: updates.publicDisplayName ?? current.publicDisplayName,
      headline: updates.headline ?? current.headline,
      positioningStatement: updates.positioningStatement ?? current.positioningStatement ?? null,
      bio: updates.bio ?? current.bio,
      teachingApproach: updates.teachingApproach ?? current.teachingApproach,
      experienceSummary: updates.experienceSummary ?? current.experienceSummary,
      qualificationsSummary: updates.qualificationsSummary ?? current.qualificationsSummary,
      languages: updates.languages ?? current.languages,
      acceptingStudents: updates.acceptingStudents ?? current.acceptingStudents,
      photoUrl: updates.photoUrl ?? current.photoUrl ?? null,
      subjectSlugs: updates.subjectSlugs ?? current.subjects.map((s) => s.slug),
      educationLevelSlugs: updates.educationLevelSlugs ?? current.educationLevels.map((l) => l.slug),
    };

    const supabase = getSupabaseClient();
    const { error } = await supabase.rpc('update_tutor_profile', {
      p_profile_id: id,
      p_public_display_name: merged.publicDisplayName,
      p_headline: merged.headline,
      p_positioning_statement: merged.positioningStatement,
      p_bio: merged.bio,
      p_teaching_approach: merged.teachingApproach,
      p_experience_summary: merged.experienceSummary,
      p_qualifications_summary: merged.qualificationsSummary,
      p_languages: merged.languages,
      p_accepting_students: merged.acceptingStudents,
      p_photo_url: merged.photoUrl,
      p_subject_slugs: merged.subjectSlugs,
      p_education_level_slugs: merged.educationLevelSlugs,
    });

    if (error) {
      console.error('SupabaseTutorProfileRepository.update failed:', error.message);
      if (error.message?.includes('invalid_subject_slug')) throw new Error('One or more selected subjects are invalid.');
      if (error.message?.includes('invalid_education_level_slug')) throw new Error('One or more selected education levels are invalid.');
      throw new Error('Unable to save this tutor profile.');
    }

    const profile = await this.getById(id);
    if (!profile) throw new Error('Tutor profile not found after update.');
    return profile;
  }

  async publish(id: string): Promise<AdminTutorProfileView> {
    return this.transitionStatus(id, 'published');
  }

  async unpublish(id: string): Promise<AdminTutorProfileView> {
    return this.transitionStatus(id, 'unpublished');
  }

  private async transitionStatus(id: string, newStatus: TutorProfileStatus): Promise<AdminTutorProfileView> {
    const supabase = getSupabaseClient();

    const { data: current, error: readError } = await supabase.from('tutor_profiles').select('status').eq('id', id).single();
    if (readError) {
      console.error('SupabaseTutorProfileRepository.transitionStatus read failed:', readError.message);
      throw new Error('Unable to load this tutor profile.');
    }

    const { error } = await supabase.from('tutor_profiles').update({ status: newStatus }).eq('id', id);
    if (error) {
      console.error('SupabaseTutorProfileRepository.transitionStatus failed:', error.message);
      throw new Error('Unable to update this tutor profile.');
    }

    await recordStatusHistory(supabase, id, current.status as TutorProfileStatus, newStatus);

    const profile = await this.getById(id);
    if (!profile) throw new Error('Tutor profile not found after status change.');
    return profile;
  }
}
