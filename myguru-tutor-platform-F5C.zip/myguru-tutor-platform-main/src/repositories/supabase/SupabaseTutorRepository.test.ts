import { describe, it, expect } from 'vitest';
import { _mappers } from './SupabaseTutorRepository';
import type { TutorProfileRow, TutorProfileSubjectJoinRow, TutorProfileLevelJoinRow } from '../../integrations/supabase/types';

function makeRow() {
  const subjectJoin: TutorProfileSubjectJoinRow = {
    subjects: { id: 's1', slug: 'maths', name: 'Maths', description: null, enabled: true, display_order: 1, created_at: '', updated_at: '' },
  };
  const levelJoin: TutorProfileLevelJoinRow = {
    education_levels: { id: 'l1', slug: 'gcse', name: 'GCSE', stage_headline: 'h', stage_description: 'd', display_order: 4, created_at: '', updated_at: '' },
  };
  const row: TutorProfileRow = {
    id: 'tp-1',
    slug: 'sarah-m-maths',
    public_display_name: 'Sarah M.',
    headline: 'GCSE Maths',
    positioning_statement: 'Making algebra click.',
    bio: 'Bio text',
    teaching_approach: 'Approach text',
    photo_url: null,
    qualifications_summary: ['BSc Mathematics'],
    experience_summary: 'Five years tutoring',
    languages: ['English'],
    accepting_students: true,
    status: 'published',
  };
  return { ...row, tutor_profile_subjects: [subjectJoin], tutor_profile_levels: [levelJoin] };
}

describe('SupabaseTutorRepository mappers', () => {
  it('maps a full row plus verification badges into the public TutorProfile shape', () => {
    const mapped = _mappers.mapTutorProfileRow(makeRow(), ['qualification_checked']);

    expect(mapped.id).toBe('tp-1');
    expect(mapped.publicDisplayName).toBe('Sarah M.');
    expect(mapped.subjects).toEqual([{ id: 's1', slug: 'maths', name: 'Maths', description: undefined }]);
    expect(mapped.educationLevels[0].slug).toBe('gcse');
    expect(mapped.publicVerificationBadges).toEqual(['qualification_checked']);
    expect(mapped.status).toBe('published');
  });

  it('never includes a pricing field when the DB has no pricing column (not fabricated)', () => {
    const mapped = _mappers.mapTutorProfileRow(makeRow(), []);
    expect(mapped.pricing).toBeUndefined();
  });

  it('has no property on the mapped object corresponding to private application fields', () => {
    const mapped = _mappers.mapTutorProfileRow(makeRow(), []);
    // Public TutorProfile type has no email/phone/fullName/adminNotes fields
    // at all — this just double-checks the mapper doesn't smuggle any in.
    expect(mapped).not.toHaveProperty('email');
    expect(mapped).not.toHaveProperty('phone');
    expect(mapped).not.toHaveProperty('adminNotes');
    expect(mapped).not.toHaveProperty('fullName');
  });

  it('passes through an empty verification badge array when none are verified', () => {
    const mapped = _mappers.mapTutorProfileRow(makeRow(), []);
    expect(mapped.publicVerificationBadges).toEqual([]);
  });
});
