import { getSupabaseClient } from '../../integrations/supabase/client';
import type {
  TutorProfileRow,
  TutorProfileSubjectJoinRow,
  TutorProfileLevelJoinRow,
  PublicVerificationBadgeRow,
} from '../../integrations/supabase/types';
import type { TutorRepository } from '../interfaces';
import type { TutorProfile, TutorFilters, PublicVerificationBadge } from '../../domain/models/types';

type TutorProfileQueryRow = TutorProfileRow & {
  tutor_profile_subjects: TutorProfileSubjectJoinRow[];
  tutor_profile_levels: TutorProfileLevelJoinRow[];
};

function mapTutorProfileRow(row: TutorProfileQueryRow, badges: PublicVerificationBadge[]): TutorProfile {
  return {
    id: row.id,
    slug: row.slug,
    publicDisplayName: row.public_display_name,
    headline: row.headline,
    positioningStatement: row.positioning_statement ?? undefined,
    bio: row.bio,
    teachingApproach: row.teaching_approach,
    photoUrl: row.photo_url ?? undefined,
    subjects: row.tutor_profile_subjects.map((j) => ({
      id: j.subjects.id,
      slug: j.subjects.slug,
      name: j.subjects.name,
      description: j.subjects.description ?? undefined,
    })),
    educationLevels: row.tutor_profile_levels.map((j) => ({
      id: j.education_levels.id,
      slug: j.education_levels.slug,
      name: j.education_levels.name,
      stageHeadline: j.education_levels.stage_headline,
      stageDescription: j.education_levels.stage_description,
    })),
    qualificationsSummary: row.qualifications_summary,
    experienceSummary: row.experience_summary,
    languages: row.languages,
    acceptingStudents: row.accepting_students,
    // Pricing has no column yet (unresolved, Phase B/D) — deliberately omitted, not fabricated.
    publicVerificationBadges: badges,
    status: row.status,
  };
}

// Exported for unit testing the mapping in isolation, without a network call.
export const _mappers = { mapTutorProfileRow };

const TUTOR_SELECT = `
  *,
  tutor_profile_subjects ( subjects ( * ) ),
  tutor_profile_levels ( education_levels ( * ) )
`;

export class SupabaseTutorRepository implements TutorRepository {
  private async fetchBadgesFor(tutorProfileIds: string[]): Promise<Map<string, PublicVerificationBadge[]>> {
    const map = new Map<string, PublicVerificationBadge[]>();
    if (tutorProfileIds.length === 0) return map;

    const supabase = getSupabaseClient();
    // Reads the public-safe derived view (0005), never tutor_verifications
    // directly — that table has no anon/authenticated policy at all.
    const { data, error } = await supabase
      .from('public_tutor_verification_badges')
      .select('*')
      .in('tutor_profile_id', tutorProfileIds);

    if (error) {
      console.error('SupabaseTutorRepository: verification badge lookup failed:', error.message);
      return map; // fail safe: profiles still render, just without badges
    }

    for (const row of (data ?? []) as PublicVerificationBadgeRow[]) {
      const badgeType = (row.verification_type + '_checked') as PublicVerificationBadge;
      const existing = map.get(row.tutor_profile_id) ?? [];
      existing.push(badgeType);
      map.set(row.tutor_profile_id, existing);
    }
    return map;
  }

  async list(filters?: TutorFilters): Promise<TutorProfile[]> {
    try {
      const supabase = getSupabaseClient();
      // RLS (0009) already restricts anon/authenticated to status='published'
      // — filtering explicitly here too keeps query intent self-documenting.
      let query = supabase.from('tutor_profiles').select(TUTOR_SELECT).eq('status', 'published');

      if (filters?.acceptingStudentsOnly) {
        query = query.eq('accepting_students', true);
      }
      // subjectSlug/educationLevelSlug filtering happens after the join
      // fetch below (Postgrest nested-filter-then-project on a many-to-many
      // join is awkward to express safely in one query); acceptable at
      // current catalogue size, revisit with a dedicated RPC/view if the
      // tutor count grows enough for this to matter.

      const { data, error } = await query;
      if (error) {
        console.error('SupabaseTutorRepository.list failed:', error.message);
        return [];
      }

      const rows = (data ?? []) as unknown as TutorProfileQueryRow[];
      const badgeMap = await this.fetchBadgesFor(rows.map((r) => r.id));
      let tutors = rows.map((row) => mapTutorProfileRow(row, badgeMap.get(row.id) ?? []));

      if (filters?.subjectSlug) {
        tutors = tutors.filter((t) => t.subjects.some((s) => s.slug === filters.subjectSlug));
      }
      if (filters?.educationLevelSlug) {
        tutors = tutors.filter((t) => t.educationLevels.some((l) => l.slug === filters.educationLevelSlug));
      }
      return tutors;
    } catch (err) {
      console.error('SupabaseTutorRepository.list failed:', err instanceof Error ? err.message : err);
      return [];
    }
  }

  async getBySlug(slug: string): Promise<TutorProfile | null> {
    try {
      const supabase = getSupabaseClient();
      const { data, error } = await supabase
        .from('tutor_profiles')
        .select(TUTOR_SELECT)
        .eq('slug', slug)
        .eq('status', 'published')
        .maybeSingle();

      if (error) {
        console.error('SupabaseTutorRepository.getBySlug failed:', error.message);
        return null;
      }
      if (!data) return null;

      const row = data as unknown as TutorProfileQueryRow;
      const badgeMap = await this.fetchBadgesFor([row.id]);
      return mapTutorProfileRow(row, badgeMap.get(row.id) ?? []);
    } catch (err) {
      console.error('SupabaseTutorRepository.getBySlug failed:', err instanceof Error ? err.message : err);
      return null;
    }
  }
}
