/**
 * Posts a public submission to a Netlify Function. This is the ONLY way
 * browser code writes matching requests / tutor applications / enquiries —
 * never a direct Supabase insert from the client (Phase E4). Used only by
 * the Supabase-backed repositories in this folder; never called directly
 * from a component or service.
 */
export async function postSubmission(endpoint: string, payload: Record<string, unknown>): Promise<{ id: string }> {
  let response: Response;
  try {
    response = await fetch(`/.netlify/functions/${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
  } catch {
    throw new Error('Unable to reach the server. Please check your connection and try again.');
  }

  if (!response.ok) {
    let message = 'Something went wrong. Please try again.';
    try {
      const body = await response.json();
      if (typeof body?.message === 'string') message = body.message;
    } catch {
      // Non-JSON error body — keep the generic message, never surface raw text.
    }
    throw new Error(message);
  }

  const body = await response.json();
  return { id: body.id as string };
}

/** Anti-abuse timing signal: capture once when a form mounts, send back on submit. */
export function captureFormLoadedAt(): number {
  return Date.now();
}
