import { describe, it, expect, vi } from 'vitest';
import { AdminApplicationsService } from './AdminApplicationsService';
import type { TutorApplicationRepository } from '../../repositories/interfaces';
import type { TutorApplication } from '../../domain/models/types';

function makeFakeRepository() {
  const updateStatus = vi.fn(async (id: string, status: TutorApplication['status'], adminNotes?: string) => ({
    id,
    status,
    adminNotes,
  })) as unknown as TutorApplicationRepository['updateStatus'];
  const repo: TutorApplicationRepository = { submit: vi.fn(), list: vi.fn(), getById: vi.fn(), updateStatus };
  return { repo, updateStatus: repo.updateStatus as ReturnType<typeof vi.fn> };
}

describe('AdminApplicationsService', () => {
  it('approve transitions status to "approved" with no notes required', async () => {
    const { repo, updateStatus } = makeFakeRepository();
    const service = new AdminApplicationsService(repo);

    await service.approve('app-1');

    expect(updateStatus).toHaveBeenCalledWith('app-1', 'approved');
  });

  it('reject transitions status to "rejected" and forwards optional notes', async () => {
    const { repo, updateStatus } = makeFakeRepository();
    const service = new AdminApplicationsService(repo);

    await service.reject('app-1', 'Not currently accepting this subject area');

    expect(updateStatus).toHaveBeenCalledWith('app-1', 'rejected', 'Not currently accepting this subject area');
  });

  it('requestMoreInfo transitions status to "more_information_required" with the given notes', async () => {
    const { repo, updateStatus } = makeFakeRepository();
    const service = new AdminApplicationsService(repo);

    await service.requestMoreInfo('app-1', 'Please provide a reference');

    expect(updateStatus).toHaveBeenCalledWith('app-1', 'more_information_required', 'Please provide a reference');
  });
});
