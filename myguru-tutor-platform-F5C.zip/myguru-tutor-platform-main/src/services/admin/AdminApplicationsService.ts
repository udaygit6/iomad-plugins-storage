import type { TutorApplicationRepository } from '../../repositories/interfaces';
import type { TutorApplication } from '../../domain/models/types';
import { tutorApplicationRepository } from '../../repositories';

/**
 * AdminApplicationsService — the workflow rules for reviewing tutor
 * applications live here, not in the admin page component. "Approve" /
 * "Reject" / "Request more info" are named actions mapping onto the
 * TutorApplicationStatus union, keeping impossible states (Phase D §25)
 * out of reach from the UI layer.
 */
export class AdminApplicationsService {
  private readonly repository: TutorApplicationRepository;

  constructor(repository: TutorApplicationRepository) {
    this.repository = repository;
  }

  async list(): Promise<TutorApplication[]> {
    return this.repository.list();
  }

  async approve(id: string): Promise<TutorApplication> {
    return this.repository.updateStatus(id, 'approved');
  }

  async reject(id: string, notes?: string): Promise<TutorApplication> {
    return this.repository.updateStatus(id, 'rejected', notes);
  }

  async requestMoreInfo(id: string, notes: string): Promise<TutorApplication> {
    return this.repository.updateStatus(id, 'more_information_required', notes);
  }
}

export const adminApplicationsService = new AdminApplicationsService(tutorApplicationRepository);
