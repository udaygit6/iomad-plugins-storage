import { describe, it, expect, vi, beforeEach } from 'vitest';
import { AdminAuthService } from './AdminAuthService';
import * as clientModule from '../../integrations/supabase/client';

describe('AdminAuthService — safe fallback when Supabase is not configured', () => {
  beforeEach(() => {
    vi.spyOn(clientModule, 'isSupabaseConfigured').mockReturnValue(false);
  });

  it('getCurrentUser returns null rather than throwing', async () => {
    const service = new AdminAuthService();
    await expect(service.getCurrentUser()).resolves.toBeNull();
  });

  it('isAdmin returns false rather than throwing', async () => {
    const service = new AdminAuthService();
    await expect(service.isAdmin('some-user-id')).resolves.toBe(false);
  });

  it('signInWithPassword returns a safe, non-Supabase-specific error message', async () => {
    const service = new AdminAuthService();
    const result = await service.signInWithPassword('a@example.com', 'password');
    expect(result.ok).toBe(false);
    expect(result.error).toBe('Sign-in is not available right now.');
  });

  it('signOut resolves without throwing', async () => {
    const service = new AdminAuthService();
    await expect(service.signOut()).resolves.toBeUndefined();
  });

  it('onAuthStateChange returns a no-op unsubscribe rather than throwing', () => {
    const service = new AdminAuthService();
    const unsubscribe = service.onAuthStateChange(() => {});
    expect(() => unsubscribe()).not.toThrow();
  });
});

describe('AdminAuthService — invalid credential handling', () => {
  it('returns a generic "Invalid email or password" message, never the raw Supabase error', async () => {
    vi.spyOn(clientModule, 'isSupabaseConfigured').mockReturnValue(true);
    vi.spyOn(clientModule, 'getSupabaseClient').mockReturnValue({
      auth: {
        signInWithPassword: vi.fn().mockResolvedValue({ error: { message: 'Some internal Supabase/Postgres detail' } }),
      },
      // biome-ignore lint: minimal mock shape for this test
    } as never);

    const service = new AdminAuthService();
    const result = await service.signInWithPassword('a@example.com', 'wrong-password');

    expect(result.ok).toBe(false);
    expect(result.error).toBe('Invalid email or password.');
    expect(result.error).not.toContain('Postgres');
  });
});
