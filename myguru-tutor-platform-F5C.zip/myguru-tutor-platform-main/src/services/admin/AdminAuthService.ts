import { getSupabaseClient, isSupabaseConfigured } from '../../integrations/supabase/client';
import type { AdminProfileRow } from '../../integrations/supabase/types';

export interface AdminSessionUser {
  id: string;
  email: string | null;
}

/**
 * AdminAuthService — the only place that calls supabase.auth.* or queries
 * admin_profiles. Per Phase E3 §9: auth identity (a Supabase Auth user) is
 * kept separate from domain authorization (a row in admin_profiles) —
 * being logged in is necessary but not sufficient for admin access.
 *
 * Every method fails safe: if Supabase isn't configured (mock/local dev
 * with no env vars set) or a network/API error occurs, methods return a
 * safe default (null/false) rather than throwing into a component or
 * leaking a raw Supabase error message.
 */
export class AdminAuthService {
  isConfigured(): boolean {
    return isSupabaseConfigured();
  }

  async getCurrentUser(): Promise<AdminSessionUser | null> {
    if (!this.isConfigured()) return null;
    try {
      const supabase = getSupabaseClient();
      const { data, error } = await supabase.auth.getSession();
      if (error || !data.session?.user) return null;
      return { id: data.session.user.id, email: data.session.user.email ?? null };
    } catch (err) {
      console.error('AdminAuthService.getCurrentUser failed:', err instanceof Error ? err.message : err);
      return null;
    }
  }

  /**
   * Checks admin_profiles for the given user — the trusted domain
   * authorization mapping (Phase E3 §13). Relies on RLS policy
   * admin_profiles_self_read (0009): an authenticated user may only ever
   * see their OWN row, so this can never be used to enumerate admins.
   */
  async isAdmin(userId: string): Promise<boolean> {
    if (!this.isConfigured()) return false;
    try {
      const supabase = getSupabaseClient();
      const { data, error } = await supabase
        .from('admin_profiles')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle();

      if (error) {
        console.error('AdminAuthService.isAdmin failed:', error.message);
        return false;
      }
      return (data as AdminProfileRow | null) !== null;
    } catch (err) {
      console.error('AdminAuthService.isAdmin failed:', err instanceof Error ? err.message : err);
      return false;
    }
  }

  /** Returns a safe, generic error message on failure — never the raw Supabase error. */
  async signInWithPassword(email: string, password: string): Promise<{ ok: boolean; error?: string }> {
    if (!this.isConfigured()) {
      return { ok: false, error: 'Sign-in is not available right now.' };
    }
    try {
      const supabase = getSupabaseClient();
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) return { ok: false, error: 'Invalid email or password.' };
      return { ok: true };
    } catch (err) {
      console.error('AdminAuthService.signInWithPassword failed:', err instanceof Error ? err.message : err);
      return { ok: false, error: 'Something went wrong. Please try again.' };
    }
  }

  async signOut(): Promise<void> {
    if (!this.isConfigured()) return;
    try {
      const supabase = getSupabaseClient();
      await supabase.auth.signOut();
    } catch (err) {
      console.error('AdminAuthService.signOut failed:', err instanceof Error ? err.message : err);
    }
  }

  /** Subscribes to auth state changes (login/logout/token refresh/expiry). Returns an unsubscribe function. */
  onAuthStateChange(callback: () => void): () => void {
    if (!this.isConfigured()) return () => {};
    try {
      const supabase = getSupabaseClient();
      const {
        data: { subscription },
      } = supabase.auth.onAuthStateChange(() => callback());
      return () => subscription.unsubscribe();
    } catch (err) {
      console.error('AdminAuthService.onAuthStateChange failed:', err instanceof Error ? err.message : err);
      return () => {};
    }
  }
}

export const adminAuthService = new AdminAuthService();
