import { describe, it, expect, vi } from 'vitest';
import { AdminOrganisationsService } from './AdminOrganisationsService';
import type { OrganisationRepository, Organisation, OrganisationCourse } from '../../repositories/interfaces';

function fakeRepository(overrides: Partial<OrganisationRepository> = {}): OrganisationRepository {
  return {
    listForAdmin: vi.fn().mockResolvedValue([]),
    listOrganisationCourses: vi.fn().mockResolvedValue([]),
    ...overrides,
  };
}

const SHIKSHA: Organisation = {
  id: 'org-1',
  name: 'Shiksha Academy',
  type: 'unclassified',
  status: 'active',
  iomadCompanyId: '3',
  syncStatus: 'synced',
  lastSyncedAt: '2026-01-15T09:30:00Z',
  hasSyncIssue: false,
};

describe('AdminOrganisationsService.listAll', () => {
  it('forwards to repository.listForAdmin() and returns its result', async () => {
    const repository = fakeRepository({ listForAdmin: vi.fn().mockResolvedValue([SHIKSHA]) });
    const service = new AdminOrganisationsService(repository);

    const result = await service.listAll();

    expect(result).toEqual([SHIKSHA]);
    expect(repository.listForAdmin).toHaveBeenCalledTimes(1);
  });

  it('returns an empty array when the repository returns none', async () => {
    const repository = fakeRepository({ listForAdmin: vi.fn().mockResolvedValue([]) });
    const service = new AdminOrganisationsService(repository);

    expect(await service.listAll()).toEqual([]);
  });

  it('propagates a repository failure rather than swallowing it (so the page can show a distinct error state)', async () => {
    const repository = fakeRepository({ listForAdmin: vi.fn().mockRejectedValue(new Error('Unable to load organisations right now.')) });
    const service = new AdminOrganisationsService(repository);

    await expect(service.listAll()).rejects.toThrow('Unable to load organisations right now.');
  });
});

const JUPITER_MATHS: OrganisationCourse = {
  id: 'alloc-1',
  courseName: 'Jupiter Test Mathematics',
  iomadCourseId: '4',
  licensed: false,
  shared: false,
  validLengthDays: 0,
  warnExpireDays: 0,
  warnCompletionDays: 0,
  notifyPeriodDays: 0,
  syncStatus: 'synced',
  lastSyncedAt: '2026-01-15T09:30:00Z',
};

describe('AdminOrganisationsService.listOrganisationCourses', () => {
  it('forwards to repository.listOrganisationCourses(organisationId) and returns its result', async () => {
    const repository = fakeRepository({ listOrganisationCourses: vi.fn().mockResolvedValue([JUPITER_MATHS]) });
    const service = new AdminOrganisationsService(repository);

    const result = await service.listOrganisationCourses('org-jupiter');

    expect(result).toEqual([JUPITER_MATHS]);
    expect(repository.listOrganisationCourses).toHaveBeenCalledWith('org-jupiter');
  });

  it('returns an empty array when the organisation has no synchronised courses', async () => {
    const repository = fakeRepository({ listOrganisationCourses: vi.fn().mockResolvedValue([]) });
    const service = new AdminOrganisationsService(repository);

    expect(await service.listOrganisationCourses('org-shiksha')).toEqual([]);
  });

  it('propagates a repository failure rather than swallowing it', async () => {
    const repository = fakeRepository({
      listOrganisationCourses: vi.fn().mockRejectedValue(new Error('Unable to load courses for this organisation right now.')),
    });
    const service = new AdminOrganisationsService(repository);

    await expect(service.listOrganisationCourses('org-1')).rejects.toThrow(
      'Unable to load courses for this organisation right now.',
    );
  });
});
