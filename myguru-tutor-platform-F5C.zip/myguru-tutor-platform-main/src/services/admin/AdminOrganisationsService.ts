import type { OrganisationRepository, Organisation, OrganisationCourse } from '../../repositories/interfaces';
import { organisationRepository } from '../../repositories';

/**
 * F4D/F5C — thin service over `OrganisationRepository`. Read-only: no
 * create/edit/delete, no Iomad sync trigger. This page only reads
 * already-synchronised Supabase data (F4/F4C/F5B).
 */
export class AdminOrganisationsService {
  private readonly repository: OrganisationRepository;

  constructor(repository: OrganisationRepository) {
    this.repository = repository;
  }

  async listAll(): Promise<Organisation[]> {
    return this.repository.listForAdmin();
  }

  /** F5C — courses currently or previously allocated to one organisation. */
  async listOrganisationCourses(organisationId: string): Promise<OrganisationCourse[]> {
    return this.repository.listOrganisationCourses(organisationId);
  }
}

export const adminOrganisationsService = new AdminOrganisationsService(organisationRepository);
