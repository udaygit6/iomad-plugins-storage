import { describe, it, expect, vi } from 'vitest';
import { AdminSubjectsService } from './AdminSubjectsService';
import type { SubjectRepository, AdminSubjectView } from '../../repositories/interfaces';

function makeFakeRepository(views: AdminSubjectView[]) {
  const setEnabled = vi.fn(async (id: string, _enabled: boolean) => {
    const subject = views.find((v) => v.id === id);
    if (!subject) throw new Error('not found');
    return { id: subject.id, slug: subject.slug, name: subject.name };
  });
  const repo = {
    list: vi.fn(),
    getBySlug: vi.fn(),
    listEducationLevels: vi.fn(),
    listForAdmin: vi.fn().mockResolvedValue(views),
    setEnabled,
  } as unknown as SubjectRepository;
  return { repo, setEnabled };
}

describe('AdminSubjectsService', () => {
  it('listAll delegates to the repository listForAdmin', async () => {
    const views: AdminSubjectView[] = [{ id: 's1', slug: 'maths', name: 'Maths', enabled: true }];
    const { repo } = makeFakeRepository(views);
    const service = new AdminSubjectsService(repo);
    await expect(service.listAll()).resolves.toEqual(views);
  });

  it('setEnabled forwards the id and desired state to the repository', async () => {
    const views: AdminSubjectView[] = [{ id: 's1', slug: 'maths', name: 'Maths', enabled: true }];
    const { repo, setEnabled } = makeFakeRepository(views);
    const service = new AdminSubjectsService(repo);
    await service.setEnabled('s1', false);
    expect(setEnabled).toHaveBeenCalledWith('s1', false);
  });
});
