import type { SubjectRepository, AdminSubjectView } from '../../repositories/interfaces';
import { subjectRepository } from '../../repositories';

export class AdminSubjectsService {
  private readonly repository: SubjectRepository;

  constructor(repository: SubjectRepository) {
    this.repository = repository;
  }

  async listAll(): Promise<AdminSubjectView[]> {
    return this.repository.listForAdmin();
  }

  async setEnabled(id: string, enabled: boolean) {
    return this.repository.setEnabled(id, enabled);
  }
}

export const adminSubjectsService = new AdminSubjectsService(subjectRepository);
