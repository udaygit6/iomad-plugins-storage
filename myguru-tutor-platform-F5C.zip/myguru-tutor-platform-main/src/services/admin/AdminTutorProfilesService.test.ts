import { describe, it, expect, vi } from 'vitest';
import { AdminTutorProfilesService } from './AdminTutorProfilesService';
import type { TutorProfileRepository, AdminTutorProfileView, TutorApplicationRepository } from '../../repositories/interfaces';
import type { TutorApplication } from '../../domain/models/types';

function makeApplication(overrides: Partial<TutorApplication> = {}): TutorApplication {
  return {
    id: 'app-1',
    status: 'approved',
    fullName: 'Sarah Example',
    email: 'sarah@example.com',
    aboutYou: 'About',
    teachingExperience: 'Experience',
    education: 'Education',
    qualifications: ['BSc Maths'],
    subjectSlugs: ['maths'],
    educationLevelSlugs: ['gcse'],
    teachingApproach: 'Approach',
    availabilityNotes: 'Evenings',
    ...overrides,
  };
}

function makeProfileView(overrides: Partial<AdminTutorProfileView> = {}): AdminTutorProfileView {
  return {
    id: 'profile-1',
    slug: 'sarah-e-abc123',
    publicDisplayName: 'Sarah E.',
    headline: 'Maths',
    bio: 'About',
    teachingApproach: 'Approach',
    experienceSummary: 'Experience',
    qualificationsSummary: [],
    languages: [],
    subjects: [],
    educationLevels: [],
    acceptingStudents: false,
    publicVerificationBadges: [],
    status: 'draft',
    tutorApplicationId: 'app-1',
    ...overrides,
  };
}

function makeFakes(application: TutorApplication | null, existingProfile: AdminTutorProfileView | null) {
  const createFromApplication = vi.fn().mockResolvedValue(makeProfileView());
  const profiles = {
    listForAdmin: vi.fn(),
    getById: vi.fn(),
    getByApplicationId: vi.fn().mockResolvedValue(existingProfile),
    createFromApplication,
    update: vi.fn(),
    publish: vi.fn(),
    unpublish: vi.fn(),
  } as unknown as TutorProfileRepository;

  const applications = {
    submit: vi.fn(),
    list: vi.fn(),
    getById: vi.fn().mockResolvedValue(application),
    updateStatus: vi.fn(),
  } as unknown as TutorApplicationRepository;

  return { profiles, applications, createFromApplication };
}

describe('AdminTutorProfilesService.createFromApplication', () => {
  it('creates a profile when the application is approved', async () => {
    const { profiles, applications, createFromApplication } = makeFakes(makeApplication({ status: 'approved' }), null);
    const service = new AdminTutorProfilesService(profiles, applications);

    await service.createFromApplication('app-1');

    expect(createFromApplication).toHaveBeenCalledWith(expect.objectContaining({ id: 'app-1', status: 'approved' }));
  });

  it('refuses to create a profile from a rejected application', async () => {
    const { profiles, applications, createFromApplication } = makeFakes(makeApplication({ status: 'rejected' }), null);
    const service = new AdminTutorProfilesService(profiles, applications);

    await expect(service.createFromApplication('app-1')).rejects.toThrow(/only approved/i);
    expect(createFromApplication).not.toHaveBeenCalled();
  });

  it('refuses to create a profile from a submitted (not yet reviewed) application', async () => {
    const { profiles, applications, createFromApplication } = makeFakes(makeApplication({ status: 'submitted' }), null);
    const service = new AdminTutorProfilesService(profiles, applications);

    await expect(service.createFromApplication('app-1')).rejects.toThrow(/only approved/i);
    expect(createFromApplication).not.toHaveBeenCalled();
  });

  it('is idempotent: returns the existing profile without creating a duplicate if one already exists', async () => {
    const existing = makeProfileView({ id: 'existing-profile' });
    const { profiles, applications, createFromApplication } = makeFakes(makeApplication({ status: 'approved' }), existing);
    const service = new AdminTutorProfilesService(profiles, applications);

    const result = await service.createFromApplication('app-1');

    expect(result).toBe(existing);
    expect(createFromApplication).not.toHaveBeenCalled();
  });

  it('is idempotent even when called twice in a row (double-click safe)', async () => {
    const { profiles, applications, createFromApplication } = makeFakes(makeApplication({ status: 'approved' }), null);
    const service = new AdminTutorProfilesService(profiles, applications);

    // First call: no existing profile, so it creates one. Simulate the
    // repository now reporting that profile as existing for the second call.
    await service.createFromApplication('app-1');
    vi.mocked(profiles.getByApplicationId).mockResolvedValue(makeProfileView({ id: 'newly-created' }));
    await service.createFromApplication('app-1');

    expect(createFromApplication).toHaveBeenCalledTimes(1);
  });

  it('throws if the application does not exist', async () => {
    const { profiles, applications } = makeFakes(null, null);
    const service = new AdminTutorProfilesService(profiles, applications);

    await expect(service.createFromApplication('missing')).rejects.toThrow(/not found/i);
  });
});

describe('AdminTutorProfilesService delegation', () => {
  it('publish/unpublish/update/listAll/getById all delegate to the repository unchanged', async () => {
    const { profiles, applications } = makeFakes(null, null);
    vi.mocked(profiles.listForAdmin).mockResolvedValue([makeProfileView()]);
    vi.mocked(profiles.getById).mockResolvedValue(makeProfileView());
    vi.mocked(profiles.publish).mockResolvedValue(makeProfileView({ status: 'published' }));
    vi.mocked(profiles.unpublish).mockResolvedValue(makeProfileView({ status: 'unpublished' }));
    vi.mocked(profiles.update).mockResolvedValue(makeProfileView({ headline: 'Updated' }));

    const service = new AdminTutorProfilesService(profiles, applications);

    await expect(service.listAll()).resolves.toHaveLength(1);
    await expect(service.getById('profile-1')).resolves.toMatchObject({ id: 'profile-1' });
    await expect(service.publish('profile-1')).resolves.toMatchObject({ status: 'published' });
    await expect(service.unpublish('profile-1')).resolves.toMatchObject({ status: 'unpublished' });
    await expect(service.update('profile-1', { headline: 'Updated' })).resolves.toMatchObject({ headline: 'Updated' });
  });
});
