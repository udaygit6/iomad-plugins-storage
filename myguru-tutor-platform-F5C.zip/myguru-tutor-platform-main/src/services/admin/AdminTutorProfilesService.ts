import type { TutorProfileRepository, TutorProfileUpdateInput, AdminTutorProfileView } from '../../repositories/interfaces';
import type { TutorApplicationRepository } from '../../repositories/interfaces';
import { tutorProfileRepository, tutorApplicationRepository } from '../../repositories';

/**
 * AdminTutorProfilesService — owns the workflow rules for turning an
 * approved tutor application into a public-safe draft profile, and the
 * subsequent draft -> published -> unpublished lifecycle. The repository
 * layer stays a plain data-access boundary (plus the DB-level idempotency
 * guarantee in 0014's RPC as defense-in-depth); the "only approved
 * applications may create a profile" and "never create a duplicate" rules
 * are enforced here, at the service layer, matching this codebase's
 * established pattern (see ARCHITECTURE.md).
 */
export class AdminTutorProfilesService {
  private readonly profiles: TutorProfileRepository;
  private readonly applications: TutorApplicationRepository;

  constructor(profiles: TutorProfileRepository, applications: TutorApplicationRepository) {
    this.profiles = profiles;
    this.applications = applications;
  }

  async listAll(): Promise<AdminTutorProfileView[]> {
    return this.profiles.listForAdmin();
  }

  async getById(id: string): Promise<AdminTutorProfileView | null> {
    return this.profiles.getById(id);
  }

  /**
   * Creates a draft profile from an approved application, or returns the
   * existing one if this application already has a linked profile — the
   * caller never needs to check first, and never gets a duplicate no
   * matter how many times this is called (double-click safe).
   */
  async createFromApplication(applicationId: string): Promise<AdminTutorProfileView> {
    const application = await this.applications.getById(applicationId);
    if (!application) {
      throw new Error('Application not found.');
    }

    const existing = await this.profiles.getByApplicationId(applicationId);
    if (existing) {
      return existing;
    }

    if (application.status !== 'approved') {
      throw new Error('Only approved applications can create a tutor profile.');
    }

    return this.profiles.createFromApplication(application);
  }

  async update(id: string, updates: TutorProfileUpdateInput): Promise<AdminTutorProfileView> {
    return this.profiles.update(id, updates);
  }

  async publish(id: string): Promise<AdminTutorProfileView> {
    return this.profiles.publish(id);
  }

  async unpublish(id: string): Promise<AdminTutorProfileView> {
    return this.profiles.unpublish(id);
  }
}

export const adminTutorProfilesService = new AdminTutorProfilesService(tutorProfileRepository, tutorApplicationRepository);
