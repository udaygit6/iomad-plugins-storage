import type { MatchingRequestRepository, EnquiryRepository } from '../../repositories/interfaces';
import type { MatchingRequest, Enquiry } from '../../domain/models/types';
import { matchingRequestRepository, enquiryRepository } from '../../repositories';

export class AdminMatchingRequestsService {
  private readonly repository: MatchingRequestRepository;
  constructor(repository: MatchingRequestRepository) {
    this.repository = repository;
  }
  async list(): Promise<MatchingRequest[]> {
    return this.repository.list();
  }
  async updateStatus(id: string, status: MatchingRequest['status']): Promise<MatchingRequest> {
    return this.repository.updateStatus(id, status);
  }
}

export class AdminEnquiriesService {
  private readonly repository: EnquiryRepository;
  constructor(repository: EnquiryRepository) {
    this.repository = repository;
  }
  async list(): Promise<Enquiry[]> {
    return this.repository.list();
  }
  async updateStatus(id: string, status: Enquiry['status']): Promise<Enquiry> {
    return this.repository.updateStatus(id, status);
  }
}

export const adminMatchingRequestsService = new AdminMatchingRequestsService(matchingRequestRepository);
export const adminEnquiriesService = new AdminEnquiriesService(enquiryRepository);
