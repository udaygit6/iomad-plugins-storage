import { describe, it, expect, vi } from 'vitest';
import { TutorApplicationService, EMPTY_APPLICATION_FORM } from './TutorApplicationService';
import type { TutorApplicationRepository } from '../../repositories/interfaces';
import type { TutorApplication } from '../../domain/models/types';

function makeFakeRepository() {
  const submit = vi.fn(async (input: Omit<TutorApplication, 'id' | 'status' | 'submittedAt'>) => ({
    ...input,
    id: 'app-1',
    status: 'submitted' as const,
    submittedAt: new Date().toISOString(),
  }));
  const repo: TutorApplicationRepository = { submit, list: vi.fn(), getById: vi.fn(), updateStatus: vi.fn() };
  return { repo, submit };
}

describe('TutorApplicationService.validateStep', () => {
  const { repo } = makeFakeRepository();
  const service = new TutorApplicationService(repo);

  it('requires name, valid email, and an about-you blurb on the about step', () => {
    const errors = service.validateStep('about', EMPTY_APPLICATION_FORM);
    expect(errors.fullName).toBeTruthy();
    expect(errors.email).toBeTruthy();
    expect(errors.aboutYou).toBeTruthy();
  });

  it('requires at least one subject on the subjects step', () => {
    const errors = service.validateStep('subjects', EMPTY_APPLICATION_FORM);
    expect(errors.subjectSlugs).toBeTruthy();
  });

  it('passes the subjects step once at least one subject is selected', () => {
    const errors = service.validateStep('subjects', { ...EMPTY_APPLICATION_FORM, subjectSlugs: ['maths'] });
    expect(errors).toEqual({});
  });

  it('requires at least one education level on the levels step', () => {
    const errors = service.validateStep('levels', EMPTY_APPLICATION_FORM);
    expect(errors.educationLevelSlugs).toBeTruthy();
  });

  it('does not require anything on the documents step (optional)', () => {
    const errors = service.validateStep('documents', EMPTY_APPLICATION_FORM);
    expect(errors).toEqual({});
  });
});

describe('TutorApplicationService.submit', () => {
  it('splits qualifications text into a clean array, dropping blank lines', async () => {
    const { repo, submit } = makeFakeRepository();
    const service = new TutorApplicationService(repo);

    await service.submit({
      ...EMPTY_APPLICATION_FORM,
      fullName: 'Sarah Example',
      email: 'sarah@example.com',
      subjectSlugs: ['maths'],
      educationLevelSlugs: ['gcse'],
      qualificationsText: 'BSc Mathematics\n\nPGCE Secondary Education\n  ',
    });

    const [[callArg]] = submit.mock.calls;
    expect(callArg.qualifications).toEqual(['BSc Mathematics', 'PGCE Secondary Education']);
  });

  it('never includes an "adminNotes" or status field — that is the repository/admin boundary, not the applicant form', async () => {
    const { repo, submit } = makeFakeRepository();
    const service = new TutorApplicationService(repo);

    await service.submit({ ...EMPTY_APPLICATION_FORM, fullName: 'Sarah', email: 'sarah@example.com' });

    const [[callArg]] = submit.mock.calls;
    expect(callArg).not.toHaveProperty('status');
    expect(callArg).not.toHaveProperty('adminNotes');
  });
});
