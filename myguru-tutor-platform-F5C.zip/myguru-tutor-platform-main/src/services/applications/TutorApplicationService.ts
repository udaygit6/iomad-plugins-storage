import type { TutorApplicationRepository, SubmitMeta } from '../../repositories/interfaces';
import type { TutorApplication, EducationLevelSlug } from '../../domain/models/types';
import { tutorApplicationRepository } from '../../repositories';
import { required, requiredArray, validEmail, runValidators, type FieldErrors } from '../../domain/validation/formValidation';

export interface ApplicationFormData {
  fullName: string;
  email: string;
  phone: string;
  aboutYou: string;
  teachingExperience: string;
  education: string;
  qualificationsText: string; // one per line in the UI, split on submit
  subjectSlugs: string[];
  educationLevelSlugs: EducationLevelSlug[];
  teachingApproach: string;
  availabilityNotes: string;
  supportingDocumentsNote: string;
}

export const EMPTY_APPLICATION_FORM: ApplicationFormData = {
  fullName: '',
  email: '',
  phone: '',
  aboutYou: '',
  teachingExperience: '',
  education: '',
  qualificationsText: '',
  subjectSlugs: [],
  educationLevelSlugs: [],
  teachingApproach: '',
  availabilityNotes: '',
  supportingDocumentsNote: '',
};

/**
 * TutorApplicationService — validation and submission logic for the tutor
 * application flow, and the boundary that keeps private application data
 * (this form) conceptually separate from the public TutorProfile type that
 * only exists once an admin approves the application (Phase D §21).
 */
export class TutorApplicationService {
  private readonly repository: TutorApplicationRepository;

  constructor(repository: TutorApplicationRepository) {
    this.repository = repository;
  }

  validateStep(stepId: string, data: ApplicationFormData): FieldErrors {
    switch (stepId) {
      case 'about':
        return runValidators({
          fullName: () => required(data.fullName, 'Enter your full name.'),
          email: () => validEmail(data.email),
          aboutYou: () => required(data.aboutYou, 'Tell us a little about yourself.'),
        });
      case 'experience':
        return runValidators({ teachingExperience: () => required(data.teachingExperience, 'Describe your teaching/tutoring experience.') });
      case 'education':
        return runValidators({ education: () => required(data.education, 'Tell us about your education background.') });
      case 'subjects':
        return runValidators({ subjectSlugs: () => requiredArray(data.subjectSlugs, 'Select at least one subject.') });
      case 'levels':
        return runValidators({ educationLevelSlugs: () => requiredArray(data.educationLevelSlugs, 'Select at least one education level.') });
      case 'approach':
        return runValidators({ teachingApproach: () => required(data.teachingApproach, 'Describe your teaching approach.') });
      case 'availability':
        return runValidators({ availabilityNotes: () => required(data.availabilityNotes, 'Let us know your general availability.') });
      default:
        return {};
    }
  }

  async submit(data: ApplicationFormData, meta?: SubmitMeta): Promise<TutorApplication> {
    return this.repository.submit(
      {
        fullName: data.fullName.trim(),
        email: data.email.trim(),
        phone: data.phone.trim() || undefined,
        aboutYou: data.aboutYou.trim(),
        teachingExperience: data.teachingExperience.trim(),
        education: data.education.trim(),
        qualifications: data.qualificationsText
          .split('\n')
          .map((q) => q.trim())
          .filter(Boolean),
        subjectSlugs: data.subjectSlugs,
        educationLevelSlugs: data.educationLevelSlugs,
        teachingApproach: data.teachingApproach.trim(),
        availabilityNotes: data.availabilityNotes.trim(),
        supportingDocumentsNote: data.supportingDocumentsNote.trim() || undefined,
      },
      meta,
    );
  }
}

export const tutorApplicationService = new TutorApplicationService(tutorApplicationRepository);
