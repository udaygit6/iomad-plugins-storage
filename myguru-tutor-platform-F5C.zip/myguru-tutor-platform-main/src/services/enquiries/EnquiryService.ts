import type { EnquiryRepository, SubmitMeta } from '../../repositories/interfaces';
import type { Enquiry } from '../../domain/models/types';
import { enquiryRepository } from '../../repositories';
import { required, validEmail, runValidators, type FieldErrors } from '../../domain/validation/formValidation';

export interface EnquiryFormData {
  name: string;
  email: string;
  message: string;
}

export function validateEnquiry(data: EnquiryFormData): FieldErrors {
  return runValidators({
    name: () => required(data.name, 'Enter your name.'),
    email: () => validEmail(data.email),
    message: () => required(data.message, 'Add a short message.'),
  });
}

export class EnquiryService {
  private readonly repository: EnquiryRepository;

  constructor(repository: EnquiryRepository) {
    this.repository = repository;
  }

  async submit(data: EnquiryFormData, relatedTutorSlug?: string, meta?: SubmitMeta): Promise<Enquiry> {
    return this.repository.submit(
      {
        name: data.name.trim(),
        email: data.email.trim(),
        message: data.message.trim(),
        relatedTutorSlug,
      },
      meta,
    );
  }
}

export const enquiryService = new EnquiryService(enquiryRepository);
