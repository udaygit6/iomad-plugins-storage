/**
 * LmsService — the boundary contract between MyGuru and the LMS (Iomad).
 *
 * Per Phase C.5 / Phase D §6: Phase D implements ONLY a mock/no-op adapter.
 * No live Iomad call, token, or endpoint is referenced anywhere in this
 * codebase yet. The real `IomadLmsAdapter` is a later persistence-phase
 * deliverable, built against this same interface once the read-only Iomad
 * Technical Discovery findings (docs/decisions.md) are finalised.
 *
 * Per Phase C.5 Correction 3: commands (creates/writes) are conceptually
 * queued/idempotent operations; queries (reads) are on-demand. This
 * interface reflects that split structurally — callers await both the same
 * way, but the *application service* layer (not built in Phase D) is
 * responsible for routing command calls through the outbox and treating
 * query calls as on-demand/cacheable. Nothing here executes a real network
 * call in Phase D.
 */

export interface LmsUser {
  externalId: string;
  email?: string;
  role: 'student' | 'teacher';
}

export interface LmsCourse {
  externalId: string;
  name: string;
}

export interface LmsEnrolment {
  studentExternalId: string;
  courseExternalId: string;
  status: 'active' | 'pending' | 'failed';
}

export interface LmsProgress {
  courseExternalId: string;
  percentComplete: number;
}

export interface CreateStudentInput {
  myguruStudentId: string;
  // Deliberately NOT `email: parentEmail`. Per Phase C.5 Correction 1, the
  // student LMS identity strategy is an unresolved business decision — this
  // input intentionally has no default email source until that's settled.
  identityHint?: string;
}

export interface CreateTeacherInput {
  myguruTutorId: string;
  email: string; // valid for tutors — a tutor owns their own email (Phase C.5 §1)
}

export interface EnrolStudentInput {
  studentExternalId: string;
  courseExternalId: string;
}

export interface AssignTeacherInput {
  teacherExternalId: string;
  courseExternalId: string;
}

export interface LmsService {
  // Commands (writes) — conceptually outbox-backed once a real adapter exists.
  createStudent(input: CreateStudentInput): Promise<LmsUser>;
  createTeacher(input: CreateTeacherInput): Promise<LmsUser>;
  enrolStudent(input: EnrolStudentInput): Promise<LmsEnrolment>;
  assignTeacher(input: AssignTeacherInput): Promise<void>;

  // Queries (reads) — conceptually on-demand/cached once a real adapter exists.
  findUserByEmail(email: string): Promise<LmsUser | null>;
  getCourses(): Promise<LmsCourse[]>;
  getEnrolments(studentExternalId: string): Promise<LmsEnrolment[]>;
  getCourseProgress(studentExternalId: string, courseExternalId: string): Promise<LmsProgress | null>;
}
