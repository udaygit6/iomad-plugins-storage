import type {
  LmsService,
  LmsUser,
  LmsCourse,
  LmsEnrolment,
  LmsProgress,
  CreateStudentInput,
  CreateTeacherInput,
  EnrolStudentInput,
  AssignTeacherInput,
} from './LmsService';

/**
 * MockLmsService — a safe no-op implementation used throughout Phase D.
 * Makes NO network calls, contacts NO external service, creates NO real
 * accounts. Exists purely so application code can be written against the
 * `LmsService` interface today without depending on the real Iomad
 * integration, which is explicitly out of scope for Phase D (§6, §59).
 */
export class MockLmsService implements LmsService {
  async createStudent(input: CreateStudentInput): Promise<LmsUser> {
    return { externalId: `mock-student-${input.myguruStudentId}`, role: 'student' };
  }

  async createTeacher(input: CreateTeacherInput): Promise<LmsUser> {
    return { externalId: `mock-teacher-${input.myguruTutorId}`, email: input.email, role: 'teacher' };
  }

  async enrolStudent(input: EnrolStudentInput): Promise<LmsEnrolment> {
    return { studentExternalId: input.studentExternalId, courseExternalId: input.courseExternalId, status: 'pending' };
  }

  async assignTeacher(_input: AssignTeacherInput): Promise<void> {
    return;
  }

  async findUserByEmail(_email: string): Promise<LmsUser | null> {
    return null;
  }

  async getCourses(): Promise<LmsCourse[]> {
    return [];
  }

  async getEnrolments(_studentExternalId: string): Promise<LmsEnrolment[]> {
    return [];
  }

  async getCourseProgress(_studentExternalId: string, _courseExternalId: string): Promise<LmsProgress | null> {
    return null;
  }
}

export const lmsService: LmsService = new MockLmsService();
