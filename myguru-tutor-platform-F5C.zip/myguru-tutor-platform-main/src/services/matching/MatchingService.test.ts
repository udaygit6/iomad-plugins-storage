import { describe, it, expect, vi } from 'vitest';
import { MatchingService, EMPTY_MATCHING_FORM } from './MatchingService';
import type { MatchingRequestRepository } from '../../repositories/interfaces';
import type { MatchingRequest } from '../../domain/models/types';

function makeFakeRepository() {
  const submit = vi.fn(async (input: Omit<MatchingRequest, 'id' | 'status' | 'submittedAt'>) => ({
    ...input,
    id: 'req-1',
    status: 'submitted' as const,
    submittedAt: new Date().toISOString(),
  }));
  const repo: MatchingRequestRepository = { submit, list: vi.fn(), updateStatus: vi.fn() };
  return { repo, submit };
}

describe('MatchingService.validateStep', () => {
  const { repo } = makeFakeRepository();
  const service = new MatchingService(repo);

  it('requires student name and year group on the student step', () => {
    const errors = service.validateStep('student', EMPTY_MATCHING_FORM);
    expect(errors.studentFirstName).toBeTruthy();
    expect(errors.yearGroupLabel).toBeTruthy();
  });

  it('passes the student step once both fields are filled', () => {
    const errors = service.validateStep('student', { ...EMPTY_MATCHING_FORM, studentFirstName: 'Emily', yearGroupLabel: 'Year 5' });
    expect(errors).toEqual({});
  });

  it('requires a valid email on the contact step', () => {
    const errors = service.validateStep('contact', { ...EMPTY_MATCHING_FORM, parentName: 'Sarah', parentEmail: 'not-an-email' });
    expect(errors.parentEmail).toBeTruthy();
  });

  it('does not require optional fields (goals) on the goals step', () => {
    const errors = service.validateStep('goals', EMPTY_MATCHING_FORM);
    expect(errors).toEqual({});
  });
});

describe('MatchingService.submit', () => {
  it('maps form data onto the MatchingRequest shape and trims strings', async () => {
    const { repo, submit } = makeFakeRepository();
    const service = new MatchingService(repo);

    await service.submit({
      ...EMPTY_MATCHING_FORM,
      studentFirstName: '  Emily  ',
      yearGroupLabel: 'Year 5',
      subjectSlug: 'maths',
      helpNeeded: 'confidence',
      availabilityNote: 'Weekday evenings',
      parentName: '  Sarah  ',
      parentEmail: '  sarah@example.com  ',
    });

    expect(submit).toHaveBeenCalledWith(
      expect.objectContaining({
        student: expect.objectContaining({ firstName: 'Emily' }),
        parent: expect.objectContaining({ name: 'Sarah', email: 'sarah@example.com' }),
        subjectSlug: 'maths',
        helpNeeded: 'confidence',
      }),
      undefined,
    );
  });

  it('omits an empty optional phone/goals rather than sending empty strings', async () => {
    const { repo, submit } = makeFakeRepository();
    const service = new MatchingService(repo);

    await service.submit({ ...EMPTY_MATCHING_FORM, parentPhone: '', goalsNote: '' });

    const [[callArg]] = submit.mock.calls;
    expect(callArg.parent.phone).toBeUndefined();
    expect(callArg.goalsNote).toBeUndefined();
  });
});
