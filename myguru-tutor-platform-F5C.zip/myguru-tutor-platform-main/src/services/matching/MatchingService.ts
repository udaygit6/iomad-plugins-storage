import type { MatchingRequestRepository, SubmitMeta } from '../../repositories/interfaces';
import type { MatchingRequest, HelpNeededReason } from '../../domain/models/types';
import { matchingRequestRepository } from '../../repositories';
import { required, validEmail, runValidators, type FieldErrors } from '../../domain/validation/formValidation';

export interface MatchingFormData {
  studentFirstName: string;
  yearGroupLabel: string;
  subjectSlug: string;
  helpNeeded: HelpNeededReason | '';
  goalsNote: string;
  availabilityNote: string;
  parentName: string;
  parentEmail: string;
  parentPhone: string;
}

export const EMPTY_MATCHING_FORM: MatchingFormData = {
  studentFirstName: '',
  yearGroupLabel: '',
  subjectSlug: '',
  helpNeeded: '',
  goalsNote: '',
  availabilityNote: '',
  parentName: '',
  parentEmail: '',
  parentPhone: '',
};

/**
 * MatchingService — validation and submission logic for the Find My Tutor
 * flow. The wizard component coordinates UI state (which step is active);
 * this service owns what counts as a valid, submittable request and how
 * that request maps onto the MatchingRequest domain model.
 */
export class MatchingService {
  private readonly repository: MatchingRequestRepository;

  constructor(repository: MatchingRequestRepository) {
    this.repository = repository;
  }

  validateStep(stepId: string, data: MatchingFormData): FieldErrors {
    switch (stepId) {
      case 'student':
        return runValidators({
          studentFirstName: () => required(data.studentFirstName, "Enter the student's first name."),
          yearGroupLabel: () => required(data.yearGroupLabel, 'Select a year group or stage.'),
        });
      case 'subject':
        return runValidators({ subjectSlug: () => required(data.subjectSlug, 'Select a subject.') });
      case 'help':
        return runValidators({ helpNeeded: () => required(data.helpNeeded, 'Choose the option that fits best.') });
      case 'availability':
        return runValidators({ availabilityNote: () => required(data.availabilityNote, 'Let us know roughly when works.') });
      case 'contact':
        return runValidators({
          parentName: () => required(data.parentName, 'Enter your name.'),
          parentEmail: () => validEmail(data.parentEmail),
        });
      default:
        return {};
    }
  }

  async submit(data: MatchingFormData, meta?: SubmitMeta): Promise<MatchingRequest> {
    return this.repository.submit(
      {
        parent: { name: data.parentName.trim(), email: data.parentEmail.trim(), phone: data.parentPhone.trim() || undefined },
        student: { firstName: data.studentFirstName.trim(), yearGroupLabel: data.yearGroupLabel },
        subjectSlug: data.subjectSlug,
        helpNeeded: data.helpNeeded as HelpNeededReason,
        goalsNote: data.goalsNote.trim() || undefined,
        availabilityNote: data.availabilityNote.trim(),
      },
      meta,
    );
  }
}

export const matchingService = new MatchingService(matchingRequestRepository);
