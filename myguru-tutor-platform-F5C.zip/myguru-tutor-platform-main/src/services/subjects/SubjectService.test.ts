import { describe, it, expect } from 'vitest';
import { SubjectService } from './SubjectService';
import type { SubjectRepository } from '../../repositories/interfaces';
import type { Subject, EducationLevel } from '../../domain/models/types';

const subjects: Subject[] = Array.from({ length: 9 }, (_, i) => ({
  id: `s${i}`,
  slug: `subject-${i}`,
  name: `Subject ${i}`,
}));

class FakeSubjectRepository implements SubjectRepository {
  async list() {
    return subjects;
  }
  async getBySlug(slug: string) {
    return subjects.find((s) => s.slug === slug) ?? null;
  }
  async listEducationLevels(): Promise<EducationLevel[]> {
    return [];
  }
  async listForAdmin() {
    return subjects.map((s) => ({ ...s, enabled: true }));
  }
  async setEnabled(id: string, enabled: boolean) {
    const subject = subjects.find((s) => s.id === id);
    if (!subject) throw new Error('not found');
    return { ...subject, enabled };
  }
}

describe('SubjectService', () => {
  it('getHomepageSubjects treats the first subject as featured and excludes it from "others"', async () => {
    const service = new SubjectService(new FakeSubjectRepository());

    const { featured, others } = await service.getHomepageSubjects(6);

    expect(featured?.id).toBe('s0');
    expect(others).toHaveLength(6);
    expect(others.some((s) => s.id === 's0')).toBe(false);
  });

  it('getHomepageSubjects respects a smaller otherCount', async () => {
    const service = new SubjectService(new FakeSubjectRepository());
    const { others } = await service.getHomepageSubjects(2);
    expect(others).toHaveLength(2);
  });
});

describe('Education level taxonomy (correction 1)', () => {
  it('keeps KS1 and KS2 as independently selectable levels, not collapsed into a single "primary" slug', async () => {
    const { mockEducationLevels } = await import('../../assets/mock/mockSubjects');
    const slugs = mockEducationLevels.map((l) => l.slug);

    expect(slugs).toContain('ks1');
    expect(slugs).toContain('ks2');
    expect(slugs).not.toContain('primary');
    // KS1 and KS2 must be distinct entries, not the same object/id.
    const ks1 = mockEducationLevels.find((l) => l.slug === 'ks1');
    const ks2 = mockEducationLevels.find((l) => l.slug === 'ks2');
    expect(ks1?.id).not.toBe(ks2?.id);
  });
});
