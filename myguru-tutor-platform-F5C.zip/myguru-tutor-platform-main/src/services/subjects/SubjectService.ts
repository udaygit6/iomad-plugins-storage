import type { SubjectRepository } from '../../repositories/interfaces';
import type { Subject, EducationLevel } from '../../domain/models/types';
import { subjectRepository } from '../../repositories';

export interface FeaturedSubjects {
  featured: Subject | undefined;
  others: Subject[];
}

/**
 * SubjectService — application-service boundary for subject/education-level
 * reference data. Currently thin (subjects are near-static reference data),
 * but composition logic that's genuinely feature-specific — e.g. which
 * subject is "featured" on the homepage — lives here rather than inline in
 * the page component, so the same rule can be reused (or changed) without
 * hunting through JSX.
 */
export class SubjectService {
  private readonly repository: SubjectRepository;

  constructor(repository: SubjectRepository) {
    this.repository = repository;
  }

  async listSubjects(): Promise<Subject[]> {
    return this.repository.list();
  }

  async listEducationLevels(): Promise<EducationLevel[]> {
    return this.repository.listEducationLevels();
  }

  /** First subject is "featured" (larger tile); the rest fill the strip. */
  async getHomepageSubjects(otherCount = 6): Promise<FeaturedSubjects> {
    const subjects = await this.repository.list();
    return { featured: subjects[0], others: subjects.slice(1, otherCount + 1) };
  }
}

export const subjectService = new SubjectService(subjectRepository);
