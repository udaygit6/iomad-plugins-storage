import { describe, it, expect } from 'vitest';
import { TutorDiscoveryService } from './TutorDiscoveryService';
import type { TutorRepository } from '../../repositories/interfaces';
import type { TutorProfile, TutorFilters } from '../../domain/models/types';

function makeTutor(overrides: Partial<TutorProfile> = {}): TutorProfile {
  return {
    id: 'id-1',
    slug: 'test-tutor',
    publicDisplayName: 'Test T.',
    headline: 'Headline',
    bio: 'Bio',
    teachingApproach: 'Approach',
    subjects: [],
    educationLevels: [],
    qualificationsSummary: [],
    experienceSummary: 'Experience',
    languages: [],
    acceptingStudents: true,
    publicVerificationBadges: [],
    status: 'published',
    ...overrides,
  };
}

/** A synchronous, dependency-free fake — deliberately not MockTutorRepository,
 * so these tests exercise the service's own logic, not the mock's latency
 * simulation or fixture data. */
class FakeTutorRepository implements TutorRepository {
  private tutors: TutorProfile[];
  constructor(tutors: TutorProfile[]) {
    this.tutors = tutors;
  }
  async list(filters?: TutorFilters) {
    if (!filters) return this.tutors;
    return this.tutors.filter((t) => !filters.subjectSlug || t.subjects.some((s) => s.slug === filters.subjectSlug));
  }
  async getBySlug(slug: string) {
    return this.tutors.find((t) => t.slug === slug) ?? null;
  }
}

describe('TutorDiscoveryService', () => {
  it('listFeatured limits results to the requested count', async () => {
    const tutors = [makeTutor({ id: '1' }), makeTutor({ id: '2' }), makeTutor({ id: '3' }), makeTutor({ id: '4' })];
    const service = new TutorDiscoveryService(new FakeTutorRepository(tutors));

    const featured = await service.listFeatured(3);

    expect(featured).toHaveLength(3);
    expect(featured.map((t) => t.id)).toEqual(['1', '2', '3']);
  });

  it('listFeatured defaults to 3 when no limit is given', async () => {
    const tutors = Array.from({ length: 5 }, (_, i) => makeTutor({ id: String(i) }));
    const service = new TutorDiscoveryService(new FakeTutorRepository(tutors));

    expect(await service.listFeatured()).toHaveLength(3);
  });

  it('getBySlug returns null for an unknown slug rather than throwing', async () => {
    const service = new TutorDiscoveryService(new FakeTutorRepository([makeTutor()]));
    await expect(service.getBySlug('does-not-exist')).resolves.toBeNull();
  });

  it('list delegates filtering to the repository', async () => {
    const maths = makeTutor({ id: 'm', subjects: [{ id: 's1', slug: 'maths', name: 'Maths' }] });
    const english = makeTutor({ id: 'e', subjects: [{ id: 's2', slug: 'english', name: 'English' }] });
    const service = new TutorDiscoveryService(new FakeTutorRepository([maths, english]));

    const results = await service.list({ subjectSlug: 'maths' });

    expect(results).toHaveLength(1);
    expect(results[0].id).toBe('m');
  });
});
