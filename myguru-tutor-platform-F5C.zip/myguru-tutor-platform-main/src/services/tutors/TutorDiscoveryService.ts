import type { TutorRepository } from '../../repositories/interfaces';
import type { TutorFilters, TutorProfile, EducationLevelSlug } from '../../domain/models/types';
import { tutorRepository } from '../../repositories';

/** Canonical URL query-param names for tutor discovery filters — defined
 * once here so pages don't scatter magic strings, and so the mapping
 * between "what's in the URL" and "what TutorFilters means" lives with the
 * feature logic rather than in a route component. */
export const TUTOR_FILTER_PARAMS = {
  subject: 'subject',
  level: 'level',
  acceptingOnly: 'accepting',
} as const;

export function filtersFromSearchParams(params: URLSearchParams): TutorFilters {
  const subjectSlug = params.get(TUTOR_FILTER_PARAMS.subject) ?? undefined;
  const educationLevelSlug = (params.get(TUTOR_FILTER_PARAMS.level) as EducationLevelSlug | null) ?? undefined;
  const acceptingStudentsOnly = params.get(TUTOR_FILTER_PARAMS.acceptingOnly) === '1';
  return { subjectSlug, educationLevelSlug, acceptingStudentsOnly };
}

export function searchParamsFromFilters(filters: TutorFilters): URLSearchParams {
  const params = new URLSearchParams();
  if (filters.subjectSlug) params.set(TUTOR_FILTER_PARAMS.subject, filters.subjectSlug);
  if (filters.educationLevelSlug) params.set(TUTOR_FILTER_PARAMS.level, filters.educationLevelSlug);
  if (filters.acceptingStudentsOnly) params.set(TUTOR_FILTER_PARAMS.acceptingOnly, '1');
  return params;
}

/**
 * TutorDiscoveryService — feature/application logic for tutor discovery.
 *
 * Pages/components call this, not `TutorRepository` directly. Today it's a
 * thin wrapper because the only logic is "fetch and slice" — that's
 * intentional, not an oversight (Phase D correction 4 explicitly warns
 * against layering for its own sake). D4's filtering/sorting rules and any
 * future matching-suggestion logic belong here, in this service, not in a
 * route component and not pushed down into the repository (which should
 * stay a plain data-access boundary, agnostic of product rules).
 */
export class TutorDiscoveryService {
  private readonly repository: TutorRepository;

  constructor(repository: TutorRepository) {
    this.repository = repository;
  }

  async list(filters?: TutorFilters): Promise<TutorProfile[]> {
    return this.repository.list(filters);
  }

  async listFeatured(limit = 3): Promise<TutorProfile[]> {
    const tutors = await this.repository.list();
    return tutors.slice(0, limit);
  }

  async getBySlug(slug: string): Promise<TutorProfile | null> {
    return this.repository.getBySlug(slug);
  }
}

export const tutorDiscoveryService = new TutorDiscoveryService(tutorRepository);
