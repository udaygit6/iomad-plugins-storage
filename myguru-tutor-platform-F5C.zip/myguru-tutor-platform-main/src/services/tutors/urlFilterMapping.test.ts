import { describe, it, expect } from 'vitest';
import { filtersFromSearchParams, searchParamsFromFilters } from './TutorDiscoveryService';

describe('filtersFromSearchParams', () => {
  it('parses an empty query string into an all-undefined filter', () => {
    const filters = filtersFromSearchParams(new URLSearchParams(''));
    expect(filters.subjectSlug).toBeUndefined();
    expect(filters.educationLevelSlug).toBeUndefined();
    expect(filters.acceptingStudentsOnly).toBe(false);
  });

  it('reads subject, level, and accepting=1 correctly', () => {
    const filters = filtersFromSearchParams(new URLSearchParams('subject=maths&level=gcse&accepting=1'));
    expect(filters.subjectSlug).toBe('maths');
    expect(filters.educationLevelSlug).toBe('gcse');
    expect(filters.acceptingStudentsOnly).toBe(true);
  });

  it('treats any accepting value other than "1" as false', () => {
    const filters = filtersFromSearchParams(new URLSearchParams('accepting=true'));
    expect(filters.acceptingStudentsOnly).toBe(false);
  });
});

describe('searchParamsFromFilters', () => {
  it('omits keys for undefined/false filter values', () => {
    const params = searchParamsFromFilters({});
    expect(params.toString()).toBe('');
  });

  it('round-trips through filtersFromSearchParams', () => {
    const original = { subjectSlug: 'english', educationLevelSlug: 'a-level' as const, acceptingStudentsOnly: true };
    const params = searchParamsFromFilters(original);
    const roundTripped = filtersFromSearchParams(params);
    expect(roundTripped).toEqual(original);
  });
});
