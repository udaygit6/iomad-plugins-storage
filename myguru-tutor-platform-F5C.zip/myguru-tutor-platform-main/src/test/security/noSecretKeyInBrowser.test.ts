import { describe, it, expect } from 'vitest';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';

const SRC_ROOT = join(__dirname, '..', '..'); // resolves to src/

function walk(dir: string): string[] {
  const entries = readdirSync(dir);
  let files: string[] = [];
  for (const entry of entries) {
    const fullPath = join(dir, entry);
    const stat = statSync(fullPath);
    if (stat.isDirectory()) {
      files = files.concat(walk(fullPath));
    } else if (/\.(ts|tsx)$/.test(entry) && !entry.endsWith('.test.ts') && !entry.endsWith('.test.tsx')) {
      files.push(fullPath);
    }
  }
  return files;
}

const sourceFiles = walk(SRC_ROOT);

describe('Security audit — no privileged Supabase key can reach browser code (src/)', () => {
  it('no source file references SUPABASE_SECRET_KEY', () => {
    const offenders = sourceFiles.filter((f) => readFileSync(f, 'utf-8').includes('SUPABASE_SECRET_KEY'));
    expect(offenders).toEqual([]);
  });

  it('no source file references a service_role key/credential', () => {
    const offenders = sourceFiles.filter((f) => readFileSync(f, 'utf-8').includes('service_role'));
    expect(offenders).toEqual([]);
  });

  it('no source file imports the server-only Supabase client module', () => {
    const offenders = sourceFiles.filter((f) => readFileSync(f, 'utf-8').includes('supabaseServerClient'));
    expect(offenders).toEqual([]);
  });

  it('no source file declares a VITE_-prefixed variable containing "SECRET" (the one prefix that ships to the browser)', () => {
    const offenders = sourceFiles.filter((f) => /VITE_[A-Z_]*SECRET/.test(readFileSync(f, 'utf-8')));
    expect(offenders).toEqual([]);
  });

  it('no source file references IOMAD_SERVICE_TOKEN (server-only — see netlify/functions/_lib/iomad/iomadConfig.ts)', () => {
    const offenders = sourceFiles.filter((f) => readFileSync(f, 'utf-8').includes('IOMAD_SERVICE_TOKEN'));
    expect(offenders).toEqual([]);
  });

  it('no source file declares a VITE_-prefixed Iomad token/credential variable', () => {
    const offenders = sourceFiles.filter((f) => /VITE_IOMAD/.test(readFileSync(f, 'utf-8')));
    expect(offenders).toEqual([]);
  });

  it('no React page/component under src/ imports @supabase/supabase-js directly (only src/integrations/supabase and src/repositories/supabase may)', () => {
    const allowedDirs = [join(SRC_ROOT, 'integrations', 'supabase'), join(SRC_ROOT, 'repositories', 'supabase')];
    const offenders = sourceFiles.filter((f) => {
      if (allowedDirs.some((dir) => f.startsWith(dir))) return false;
      return readFileSync(f, 'utf-8').includes('@supabase/supabase-js');
    });
    expect(offenders).toEqual([]);
  });

  it('no source file references iomad_company_mappings — that table stays server-only (F4/F4C), no browser read or write path exists to it', () => {
    // Unlike organisations (see the next test), F4D does not read
    // iomad_company_mappings directly from the browser — it reads the
    // embedded `iomad_company_mappings(*)` fields through the
    // organisations query in SupabaseOrganisationRepository, which
    // legitimately references the table NAME as part of that embed
    // syntax. That one file is the sole, reviewed exception.
    const allowedFiles = [
      join(SRC_ROOT, 'repositories', 'supabase', 'SupabaseOrganisationRepository.ts'),
      join(SRC_ROOT, 'integrations', 'supabase', 'types.ts'),
      join(SRC_ROOT, 'repositories', 'interfaces', 'index.ts'),
    ];
    const offenders = sourceFiles.filter((f) => {
      if (allowedFiles.includes(f)) return false;
      return readFileSync(f, 'utf-8').includes('iomad_company_mappings');
    });
    expect(offenders).toEqual([]);
  });

  it('no source file WRITES to organisations/iomad_company_mappings — only read-only, RLS-gated admin visibility exists in src/ (F4D)', () => {
    // F4D (admin Organisations visibility page) intentionally and
    // reviewedly adds a READ path from src/ to these tables — see
    // SupabaseOrganisationRepository.ts's listForAdmin(), gated by RLS's
    // admin-read-only policies (0015). This test's job is narrower than
    // its F4-era predecessor: prove no INSERT/UPDATE/DELETE/UPSERT call
    // against either table exists anywhere in src/, not that the table
    // names are never mentioned at all.
    const writeCallPattern =
      /\.from\((['"])(organisations|iomad_company_mappings)\1\)\s*\.\s*(insert|update|upsert|delete)\s*\(/;
    const offenders = sourceFiles.filter((f) => writeCallPattern.test(readFileSync(f, 'utf-8')));
    expect(offenders).toEqual([]);
  });

  it('only the reviewed SupabaseOrganisationRepository.ts reads from organisations — no other src/ file queries it directly', () => {
    const allowedFiles = [join(SRC_ROOT, 'repositories', 'supabase', 'SupabaseOrganisationRepository.ts')];
    const offenders = sourceFiles.filter((f) => {
      if (allowedFiles.includes(f)) return false;
      const content = readFileSync(f, 'utf-8');
      return content.includes("from('organisations')") || content.includes('from("organisations")');
    });
    expect(offenders).toEqual([]);
  });
});
