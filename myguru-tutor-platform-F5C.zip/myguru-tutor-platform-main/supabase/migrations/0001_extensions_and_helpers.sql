-- 0001_extensions_and_helpers.sql
-- Extensions and small reusable helpers used by every later migration.

create extension if not exists "pgcrypto"; -- gen_random_uuid()

-- Generic updated_at maintenance, reused by every table with an updated_at column.
create or replace function set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- Note: the is_admin() helper used throughout RLS policies is defined in
-- 0008_admin_profiles.sql, immediately after the admin_profiles table it
-- queries — not here, to avoid a forward reference (audit fix).
