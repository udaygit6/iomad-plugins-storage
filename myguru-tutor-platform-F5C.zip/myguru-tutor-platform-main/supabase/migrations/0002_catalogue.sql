-- 0002_catalogue.sql
-- Reference/catalogue data: subjects and education levels.
-- Matches src/domain/models/types.ts Subject / EducationLevel exactly.

create table education_levels (
  id uuid primary key default gen_random_uuid(),
  -- Matches EducationLevelSlug exactly. KS1/KS2 kept independently
  -- selectable per the frozen decision — never collapsed into 'primary'.
  slug text not null unique check (slug in ('ks1', 'ks2', 'ks3', 'gcse', 'a-level')),
  name text not null,
  stage_headline text not null,
  stage_description text not null,
  display_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create trigger education_levels_set_updated_at
  before update on education_levels
  for each row execute function set_updated_at();

alter table education_levels enable row level security;

create table subjects (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name text not null,
  description text,
  enabled boolean not null default true,
  display_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create trigger subjects_set_updated_at
  before update on subjects
  for each row execute function set_updated_at();

alter table subjects enable row level security;

create index idx_subjects_enabled_order on subjects (enabled, display_order) where enabled = true;

comment on table education_levels is 'Seeded, near-static reference data (KS1, KS2, KS3, GCSE, A-Level). Not user-editable in Phase D/E scope.';
comment on table subjects is 'MyGuru subject taxonomy. NOT the same concept as an Iomad course (Phase C.5) — see docs/PHASE_E_SCHEMA_RLS.md.';
