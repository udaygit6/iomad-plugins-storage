-- 0003_tutor_applications.sql
-- Private tutor application workflow. Fields match
-- src/domain/models/types.ts TutorApplication and
-- src/services/applications/TutorApplicationService.ts exactly —
-- no new collection requirements invented.

create table tutor_applications (
  id uuid primary key default gen_random_uuid(),
  status text not null default 'submitted'
    check (status in ('draft', 'submitted', 'under_review', 'more_information_required', 'approved', 'rejected')),

  -- Private applicant identity/contact — never copied into tutor_profiles.
  full_name text not null,
  email text not null,
  phone text,

  about_you text not null,
  teaching_experience text not null,
  education text not null,
  -- qualifications: stored relationally (see tutor_application_qualifications)
  -- rather than as an array/JSON column, since "one qualification per row,
  -- self-reported" is exactly the relational shape this data has.
  teaching_approach text not null,
  availability_notes text not null,
  supporting_documents_note text, -- placeholder free text; no real file upload in Phase D/E

  admin_notes text, -- private, admin-only, never exposed publicly or synced anywhere

  submitted_at timestamptz,
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create trigger tutor_applications_set_updated_at
  before update on tutor_applications
  for each row execute function set_updated_at();

alter table tutor_applications enable row level security;

create index idx_tutor_applications_status on tutor_applications (status);
create index idx_tutor_applications_created_at on tutor_applications (created_at desc);

comment on table tutor_applications is
  'Private workflow entity. Distinct from tutor_profiles — approval does NOT
   automatically create/publish a profile (frozen decision, Phase C.5 §9 /
   Phase D §21). Never publicly readable; see RLS policies in 0009.';
comment on column tutor_applications.admin_notes is
  'Admin-only. Never synced to any other system, never exposed via any public view.';

-- Self-reported qualifications, one row per line the applicant entered
-- (TutorApplicationService splits the wizard's textarea on submit).
create table tutor_application_qualifications (
  id uuid primary key default gen_random_uuid(),
  tutor_application_id uuid not null references tutor_applications(id) on delete cascade,
  qualification_text text not null,
  display_order integer not null default 0,
  created_at timestamptz not null default now()
);

create index idx_tutor_app_quals_application on tutor_application_qualifications (tutor_application_id);

alter table tutor_application_qualifications enable row level security;

comment on table tutor_application_qualifications is
  'Self-reported by the applicant, NOT independently verified by this table.
   A verified claim is a separate concept — see tutor_verifications (0005).';

-- subject_slugs / education_level_slugs → proper junction tables, not arrays.
create table tutor_application_subjects (
  tutor_application_id uuid not null references tutor_applications(id) on delete cascade,
  subject_id uuid not null references subjects(id) on delete restrict,
  primary key (tutor_application_id, subject_id)
);

create table tutor_application_levels (
  tutor_application_id uuid not null references tutor_applications(id) on delete cascade,
  education_level_id uuid not null references education_levels(id) on delete restrict,
  primary key (tutor_application_id, education_level_id)
);

create index idx_tutor_app_subjects_subject on tutor_application_subjects (subject_id);
create index idx_tutor_app_levels_level on tutor_application_levels (education_level_id);

alter table tutor_application_subjects enable row level security;
alter table tutor_application_levels enable row level security;

-- Status history — "what changed, who changed it, when" (Phase E1 §11).
-- changed_by references auth.users directly (not admin_profiles) because a
-- historical record should survive even if an admin_profiles row is later
-- removed; the FK to auth.users is enough to answer "who".
create table tutor_application_status_history (
  id uuid primary key default gen_random_uuid(),
  tutor_application_id uuid not null references tutor_applications(id) on delete cascade,
  previous_status text,
  new_status text not null,
  changed_by uuid references auth.users(id),
  notes text,
  created_at timestamptz not null default now()
);

create index idx_tutor_app_status_history_application on tutor_application_status_history (tutor_application_id, created_at desc);

alter table tutor_application_status_history enable row level security;

comment on table tutor_application_status_history is
  'Lightweight audit trail for AdminApplicationsService.approve/reject/
   requestMoreInfo. Not event-sourcing — just enough to answer what/who/when.';
