-- 0004_tutor_profiles.sql
-- Public-safe tutor profile entity. Fields match src/domain/models/types.ts
-- TutorProfile exactly. Deliberately does NOT include any field from
-- tutor_applications that isn't meant to be public (no email/phone/full
-- legal name/admin_notes/documents here — see Phase D §13, §26).

create table tutor_profiles (
  id uuid primary key default gen_random_uuid(),
  -- Nullable + ON DELETE SET NULL: an application can be deleted (e.g. a
  -- data-retention request) without being forced to also delete the public
  -- profile it produced, and a profile's existence must never depend on the
  -- application row still existing.
  tutor_application_id uuid references tutor_applications(id) on delete set null,

  slug text not null unique,
  public_display_name text not null, -- "First name + last initial" convention, enforced at the service layer, not the DB
  headline text not null,
  positioning_statement text,
  bio text not null,
  teaching_approach text not null,
  photo_url text,
  qualifications_summary text[] not null default '{}', -- public-safe summary strings only, not the private self-reported rows
  experience_summary text not null,
  languages text[] not null default '{}',
  accepting_students boolean not null default false,

  status text not null default 'draft'
    check (status in ('draft', 'approved', 'published', 'unpublished')),

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create trigger tutor_profiles_set_updated_at
  before update on tutor_profiles
  for each row execute function set_updated_at();

-- The one index that matters most for the public site: fast lookup of
-- published profiles, and fast slug lookup for the profile page.
create unique index idx_tutor_profiles_slug on tutor_profiles (slug);
create index idx_tutor_profiles_published on tutor_profiles (status) where status = 'published';

alter table tutor_profiles enable row level security;

comment on table tutor_profiles is
  'Public-safe profile. Approving a tutor_application does NOT automatically
   create or publish a row here — that is a deliberate separate admin action
   (frozen decision). Only status = ''published'' rows should ever be
   readable by anonymous/public clients — see RLS in 0009.';

create table tutor_profile_subjects (
  tutor_profile_id uuid not null references tutor_profiles(id) on delete cascade,
  subject_id uuid not null references subjects(id) on delete restrict,
  primary key (tutor_profile_id, subject_id)
);

create table tutor_profile_levels (
  tutor_profile_id uuid not null references tutor_profiles(id) on delete cascade,
  education_level_id uuid not null references education_levels(id) on delete restrict,
  primary key (tutor_profile_id, education_level_id)
);

create index idx_tutor_profile_subjects_subject on tutor_profile_subjects (subject_id);
create index idx_tutor_profile_levels_level on tutor_profile_levels (education_level_id);

alter table tutor_profile_subjects enable row level security;
alter table tutor_profile_levels enable row level security;

-- publish/unpublish history — mirrors tutor_application_status_history.
create table tutor_profile_status_history (
  id uuid primary key default gen_random_uuid(),
  tutor_profile_id uuid not null references tutor_profiles(id) on delete cascade,
  previous_status text,
  new_status text not null,
  changed_by uuid references auth.users(id),
  notes text,
  created_at timestamptz not null default now()
);

create index idx_tutor_profile_status_history_profile on tutor_profile_status_history (tutor_profile_id, created_at desc);

alter table tutor_profile_status_history enable row level security;
