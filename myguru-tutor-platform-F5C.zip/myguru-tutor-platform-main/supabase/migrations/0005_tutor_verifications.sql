-- 0005_tutor_verifications.sql
-- Verification tracking, kept structurally separate from tutor_profiles so
-- internal state (pending/failed/expired, evidence references, admin notes)
-- can never accidentally leak into what the public site reads.
--
-- Matches src/domain/models/types.ts PublicVerificationBadge exactly:
-- 'qualification_checked' | 'identity_checked' | 'dbs_checked'. Note that
-- type has NO pending/failed member by design (Phase D §15/§25) — this
-- table is where those internal states actually live; only 'verified' rows
-- are ever exposed, and only as a boolean-shaped public view.

create table tutor_verifications (
  id uuid primary key default gen_random_uuid(),
  tutor_profile_id uuid not null references tutor_profiles(id) on delete cascade,
  verification_type text not null check (verification_type in ('identity', 'qualification', 'dbs')),
  state text not null default 'not_started'
    check (state in ('not_started', 'pending', 'verified', 'expired', 'failed')),

  -- Private evidence/admin detail. Never selected by the public-safe view below.
  evidence_reference text, -- e.g. a Storage object path or document ID; no raw documents in this table
  admin_notes text,
  verified_at timestamptz,
  verified_by uuid references auth.users(id),

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  unique (tutor_profile_id, verification_type)
);

alter table tutor_verifications enable row level security;

create trigger tutor_verifications_set_updated_at
  before update on tutor_verifications
  for each row execute function set_updated_at();

comment on table tutor_verifications is
  'Internal verification state. NEVER selected directly by anonymous/public
   clients — see the public_tutor_verification_badges view below and the RLS
   policy in 0009, which blocks anonymous SELECT on this table entirely.';
comment on column tutor_verifications.evidence_reference is
  'Private. A pointer to evidence (future Storage integration), never a raw document.';
comment on column tutor_verifications.admin_notes is
  'Private, admin-only. Never exposed publicly, never synced elsewhere (Phase C.5 §17).';

-- ---------------------------------------------------------------------------
-- Public-safe derived view (Phase E1 §7's "how a public-safe verification
-- claim is derived/exposed without leaking internal state").
--
-- This view is the ONLY thing the public site is ever granted SELECT on for
-- verification data. It exposes exactly one row per genuinely verified
-- check on a published profile — no pending/failed/expired state, no
-- evidence reference, no admin notes, no verified_by identity.
-- ---------------------------------------------------------------------------
create view public_tutor_verification_badges as
select
  tv.tutor_profile_id,
  tv.verification_type
from tutor_verifications tv
join tutor_profiles tp on tp.id = tv.tutor_profile_id
where tv.state = 'verified'
  and tp.status = 'published';

comment on view public_tutor_verification_badges is
  'Public-safe verification badges. Deliberately exposes only
   (tutor_profile_id, verification_type) for state=''verified'' rows on
   published profiles — nothing else from tutor_verifications is reachable
   through this view.';
