-- 0006_parent_student_matching.sql
-- Parent ≠ Student (frozen decision). Fields match
-- src/services/matching/MatchingService.ts MatchingFormData /
-- src/domain/models/types.ts MatchingRequest exactly.
--
-- Recommendation on parent → multiple students (Phase E1 §8):
-- Normalise into parent_contacts + students, but do NOT require any
-- account/auth to do so. The server-side write path (see §18 in the design
-- doc) upserts parent_contacts by email (find-or-create) on every
-- submission, so a returning parent's contact record is naturally reused
-- across multiple matching requests without any login. A NEW students row
-- is created on every submission rather than attempting automatic
-- child-matching/dedup — silently merging two children based on a
-- first-name+year-group guess risks merging two different kids, and
-- Phase B already flagged this exact heuristic as "admin judgement, not
-- automated". This keeps anonymous MVP submission simple (one INSERT path,
-- no "is this an existing child?" UI) while still giving admins a real
-- parent_contact_id to correlate multiple requests from the same family by.

create table parent_contacts (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text not null,
  phone text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create trigger parent_contacts_set_updated_at
  before update on parent_contacts
  for each row execute function set_updated_at();

-- Case-insensitive uniqueness so the find-or-create-by-email upsert is reliable.
create unique index idx_parent_contacts_email on parent_contacts (lower(email));

alter table parent_contacts enable row level security;

comment on table parent_contacts is
  'A parent/guardian contact — NOT an auth.users row. No mandatory parent
   account at MVP (frozen decision); this table exists purely so multiple
   matching requests from the same email can be correlated by admins.';

create table students (
  id uuid primary key default gen_random_uuid(),
  parent_contact_id uuid not null references parent_contacts(id) on delete cascade,
  first_name text not null,
  year_group_label text not null, -- free-form label e.g. "Year 9", matches Student.yearGroupLabel exactly
  -- Deliberately NO date_of_birth, school_name, or address column —
  -- Phase B §12 / Phase D §29 data-minimisation instruction, carried
  -- through unchanged into the schema.
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create trigger students_set_updated_at
  before update on students
  for each row execute function set_updated_at();

create index idx_students_parent_contact on students (parent_contact_id);

alter table students enable row level security;

comment on table students is
  'A child a parent is seeking tutoring for. No email column — a student
   does not require an email at MVP (frozen decision), and no LMS identity
   is assigned here; that remains a separate, later integration concern
   (Phase C.5 Correction 1).';

create table matching_requests (
  id uuid primary key default gen_random_uuid(),
  status text not null default 'submitted'
    check (status in ('submitted', 'reviewing', 'matched', 'contacted', 'closed')),

  parent_contact_id uuid not null references parent_contacts(id) on delete restrict,
  student_id uuid not null references students(id) on delete restrict,
  subject_id uuid not null references subjects(id) on delete restrict,

  help_needed text not null
    check (help_needed in ('catching_up', 'exam_preparation', 'confidence', 'homework_support', 'specific_topic', 'other')),
  goals_note text,
  availability_note text not null,

  submitted_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create trigger matching_requests_set_updated_at
  before update on matching_requests
  for each row execute function set_updated_at();

create index idx_matching_requests_status on matching_requests (status);
create index idx_matching_requests_created_at on matching_requests (created_at desc);
create index idx_matching_requests_subject on matching_requests (subject_id);

alter table matching_requests enable row level security;

create table matching_request_status_history (
  id uuid primary key default gen_random_uuid(),
  matching_request_id uuid not null references matching_requests(id) on delete cascade,
  previous_status text,
  new_status text not null,
  changed_by uuid references auth.users(id),
  notes text,
  created_at timestamptz not null default now()
);

create index idx_matching_request_status_history_request on matching_request_status_history (matching_request_id, created_at desc);

alter table matching_request_status_history enable row level security;
