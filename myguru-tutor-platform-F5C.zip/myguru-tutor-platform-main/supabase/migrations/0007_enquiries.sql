-- 0007_enquiries.sql
-- General/tutor-specific enquiries. Matches
-- src/domain/models/types.ts Enquiry exactly.
--
-- Kept separate from matching_requests deliberately — an enquiry (general
-- contact, or "Request this tutor" from a specific profile) has a different
-- shape and workflow (new/in_progress/resolved) than a matching request
-- (submitted/reviewing/matched/contacted/closed), and merging them would
-- force one status vocabulary onto two different processes for no
-- relational benefit — there's no query that genuinely needs to join them
-- as one entity.

create table enquiries (
  id uuid primary key default gen_random_uuid(),
  status text not null default 'new' check (status in ('new', 'in_progress', 'resolved')),

  name text not null,
  email text not null,
  message text not null,

  -- Nullable: a general Contact-page enquiry has no tutor; a "Request this
  -- tutor" enquiry does. ON DELETE SET NULL so deleting/unpublishing a
  -- profile later never blocks deleting the profile itself.
  related_tutor_profile_id uuid references tutor_profiles(id) on delete set null,

  submitted_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create trigger enquiries_set_updated_at
  before update on enquiries
  for each row execute function set_updated_at();

create index idx_enquiries_status on enquiries (status);
create index idx_enquiries_created_at on enquiries (created_at desc);
create index idx_enquiries_related_tutor on enquiries (related_tutor_profile_id) where related_tutor_profile_id is not null;

alter table enquiries enable row level security;
