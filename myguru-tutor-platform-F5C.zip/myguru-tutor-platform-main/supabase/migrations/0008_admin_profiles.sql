-- 0008_admin_profiles.sql
-- Minimal admin-identity mapping, prepared now so E2's RLS policies have
-- something real to check, but populated only in E3 when Supabase Auth is
-- actually wired up. No auth.users rows are created by this migration.
--
-- Domain data is NOT stored inside auth.users (Phase E1 §10) — this table
-- is a thin link, not a domain table. If/when this ever migrates to
-- Cognito, only this table's population mechanism changes (how a user_id
-- gets marked as admin); every RLS policy and every application-layer
-- admin check continues to call is_admin(), unchanged.

create table admin_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'admin' check (role in ('admin')), -- single role at MVP, per Phase E1 §10 — do not over-engineer RBAC
  created_at timestamptz not null default now()
);

alter table admin_profiles enable row level security;

comment on table admin_profiles is
  'Links a Supabase Auth user to admin status. Populated only by a trusted
   server-side process (Phase E3+) — never by a public-facing mutation, and
   never by anything under anonymous or authenticated-non-admin RLS grants
   (see 0009). A single "admin" role is intentional; do not add granular
   RBAC here without a genuine product requirement.';

-- ---------------------------------------------------------------------------
-- Admin recognition (E2 §17)
--
-- Moved here (audit fix) so this function is defined AFTER the table it
-- queries actually exists, rather than forward-referencing admin_profiles
-- from an earlier migration — Postgres doesn't error on that (SQL-language
-- function bodies aren't validated against object existence until they're
-- executed), but reading the migrations top-to-bottom should not require
-- knowing that.
--
-- RLS must not rely on a client-provided role string. This function is what
-- every admin-only RLS policy calls — it checks the database's own record
-- of who is an admin, never anything supplied by the browser.
--
-- SECURITY DEFINER so the function can read admin_profiles even under a
-- caller's restrictive RLS context; it only ever returns a boolean, never
-- table contents, so this does not create a data-leak path. `set search_path
-- = public` is the standard hardening for SECURITY DEFINER functions —
-- without it, a malicious search_path set by the calling session could
-- redirect `admin_profiles` to an attacker-controlled object; `auth.uid()`
-- is explicitly schema-qualified for the same reason. The function takes no
-- parameters, so there is no injection surface via arguments either.
-- ---------------------------------------------------------------------------
create or replace function is_admin()
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1 from admin_profiles
    where user_id = auth.uid()
  );
$$;

comment on function is_admin() is
  'Returns true only if the currently authenticated user (auth.uid()) has a
   row in admin_profiles. Used by RLS policies instead of any client-supplied
   role claim. admin_profiles rows are created by trusted server-side
   processes only (Phase E3+), never by a public-facing mutation.';
