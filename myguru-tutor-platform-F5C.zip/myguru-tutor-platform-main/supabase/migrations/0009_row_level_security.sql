-- 0009_row_level_security.sql
--
-- E2 — RLS design. See docs/PHASE_E_SCHEMA_RLS.md for the full matrix and
-- rationale. This file adds POLICIES only — `enable row level security` now
-- happens inside each table's own creation migration (0002–0008, 0010),
-- immediately after `create table`, so there is no window where a table
-- exists without RLS enabled if migrations are ever applied one-by-one
-- rather than as a single atomic batch (audit fix — RLS-enable was
-- originally batched here, which left tables 0002–0008 briefly relying on
-- default grants between their own migration and this one).
--
-- Key structural decisions this migration implements:
--
-- 1. `service_role` (the Supabase service-role key) BYPASSES RLS entirely —
--    this is a Postgres/Supabase platform guarantee, not something this
--    migration configures. Every policy below is therefore written only for
--    `anon` and `authenticated`, plus an `is_admin()`-gated admin case for
--    `authenticated`. There is no separate "service role" policy anywhere
--    in this file because none is needed.
--
-- 2. Public-facing WRITES (tutor applications, matching requests, enquiries)
--    go through a trusted server-side endpoint using the service-role key
--    (Option B in the design doc — §18), NOT a direct anonymous INSERT
--    under RLS. Consequently `anon` gets ZERO policies on those tables —
--    not even INSERT. This is deliberate, not an oversight: it lets the
--    server endpoint perform validation, rate-limiting, and atomic
--    multi-table writes (e.g. an application plus its qualification/subject/
--    level rows) as one operation, which a raw anonymous multi-table INSERT
--    under RLS cannot safely guarantee.
--
-- 3. Internal verification state (tutor_verifications) is never selectable
--    by anon/authenticated at all — the public reads the derived
--    `public_tutor_verification_badges` VIEW instead (granted below).

-- ---------------------------------------------------------------------------
-- Catalogue: subjects, education_levels — public read, admin write
-- ---------------------------------------------------------------------------

create policy education_levels_public_read on education_levels
  for select to anon, authenticated
  using (true);

create policy education_levels_admin_all on education_levels
  for all to authenticated
  using (is_admin())
  with check (is_admin());

create policy subjects_public_read on subjects
  for select to anon, authenticated
  using (enabled = true);

create policy subjects_admin_all on subjects
  for all to authenticated
  using (is_admin())
  with check (is_admin());

-- ---------------------------------------------------------------------------
-- Tutor applications — fully private. No anon policy at all (writes go
-- through the server endpoint using the service-role key, per §18 Option B).
-- ---------------------------------------------------------------------------

create policy tutor_applications_admin_all on tutor_applications
  for all to authenticated
  using (is_admin())
  with check (is_admin());

create policy tutor_application_qualifications_admin_all on tutor_application_qualifications
  for all to authenticated
  using (is_admin())
  with check (is_admin());

create policy tutor_application_subjects_admin_all on tutor_application_subjects
  for all to authenticated
  using (is_admin())
  with check (is_admin());

create policy tutor_application_levels_admin_all on tutor_application_levels
  for all to authenticated
  using (is_admin())
  with check (is_admin());

create policy tutor_application_status_history_admin_all on tutor_application_status_history
  for all to authenticated
  using (is_admin())
  with check (is_admin());

-- ---------------------------------------------------------------------------
-- Tutor profiles — public read ONLY for published rows. Admin full access.
-- ---------------------------------------------------------------------------

create policy tutor_profiles_public_read_published on tutor_profiles
  for select to anon, authenticated
  using (status = 'published');

create policy tutor_profiles_admin_all on tutor_profiles
  for all to authenticated
  using (is_admin())
  with check (is_admin());

-- Junction tables have no status column of their own — a row is public
-- exactly when the tutor_profile it points to is published.
create policy tutor_profile_subjects_public_read on tutor_profile_subjects
  for select to anon, authenticated
  using (exists (
    select 1 from tutor_profiles tp
    where tp.id = tutor_profile_subjects.tutor_profile_id and tp.status = 'published'
  ));

create policy tutor_profile_subjects_admin_all on tutor_profile_subjects
  for all to authenticated
  using (is_admin())
  with check (is_admin());

create policy tutor_profile_levels_public_read on tutor_profile_levels
  for select to anon, authenticated
  using (exists (
    select 1 from tutor_profiles tp
    where tp.id = tutor_profile_levels.tutor_profile_id and tp.status = 'published'
  ));

create policy tutor_profile_levels_admin_all on tutor_profile_levels
  for all to authenticated
  using (is_admin())
  with check (is_admin());

create policy tutor_profile_status_history_admin_all on tutor_profile_status_history
  for all to authenticated
  using (is_admin())
  with check (is_admin());

-- ---------------------------------------------------------------------------
-- Tutor verifications — fully private table. Public reads the derived view
-- instead (granted below), never this table directly.
-- ---------------------------------------------------------------------------

create policy tutor_verifications_admin_all on tutor_verifications
  for all to authenticated
  using (is_admin())
  with check (is_admin());

-- No anon/authenticated policy on tutor_verifications at all — RLS
-- default-denies, so anon/authenticated get zero rows on a direct SELECT
-- against this table regardless of what they ask for.

-- Views execute with the privileges of their owner by default (not the
-- querying role) unless declared security_invoker, so this explicit GRANT
-- is what lets anon/authenticated read the view even though they cannot
-- read tutor_verifications or tutor_profiles.status='draft' rows it may
-- join against — the view's own WHERE clause (state='verified' AND
-- status='published') is the only filter that matters here.
grant select on public_tutor_verification_badges to anon, authenticated;

-- ---------------------------------------------------------------------------
-- Parent/student/matching — fully private. Writes via server endpoint only.
-- ---------------------------------------------------------------------------

create policy parent_contacts_admin_all on parent_contacts
  for all to authenticated
  using (is_admin())
  with check (is_admin());

create policy students_admin_all on students
  for all to authenticated
  using (is_admin())
  with check (is_admin());

create policy matching_requests_admin_all on matching_requests
  for all to authenticated
  using (is_admin())
  with check (is_admin());

create policy matching_request_status_history_admin_all on matching_request_status_history
  for all to authenticated
  using (is_admin())
  with check (is_admin());

-- ---------------------------------------------------------------------------
-- Enquiries — fully private. Writes via server endpoint only.
-- ---------------------------------------------------------------------------

create policy enquiries_admin_all on enquiries
  for all to authenticated
  using (is_admin())
  with check (is_admin());

-- ---------------------------------------------------------------------------
-- Admin profiles — a user may read their OWN row (so the frontend can ask
-- "am I an admin?"); nobody self-inserts admin status.
-- ---------------------------------------------------------------------------

create policy admin_profiles_self_read on admin_profiles
  for select to authenticated
  using (user_id = auth.uid());

-- No INSERT/UPDATE/DELETE policy for anon or authenticated at all — rows are
-- created only by a trusted server-side process using the service-role key
-- (which bypasses RLS), per Phase E1 §10.
