-- 0010_integration_jobs.sql
--
-- Schema-only preparation for future async LMS integration (Phase C.5
-- §12/§16). NOTHING in this migration calls Iomad, executes a job, or
-- creates a live integration — it is a durable outbox table for commands
-- only, matching the approved command/query split: LMS WRITES go through
-- this table; LMS READS are on-demand/cached and never forced through it.
--
-- Not yet wired to anything — no application code references this table.

create table integration_jobs (
  id uuid primary key default gen_random_uuid(),
  external_system text not null check (external_system in ('iomad')),
  operation_type text not null
    check (operation_type in (
      'create_student', 'create_teacher', 'enrol_student', 'assign_teacher',
      'create_link_company', 'sync_courses', 'sync_company',
      'refresh_enrolment', 'refresh_progress', 'refresh_completion'
    )),
  -- Polymorphic-by-convention, not a real FK: a job may reference a
  -- student, tutor_profile, matching_request, etc. A generic FK here would
  -- have to point at one specific table, defeating the purpose. Referential
  -- integrity for entity_id is enforced at the application layer that
  -- creates job rows, not the database — this is the one deliberate
  -- exception to "prefer FK-based integrity" in this schema, and it's
  -- scoped narrowly to this single outbox table.
  entity_type text not null,
  entity_id uuid not null,

  idempotency_key text not null,
  status text not null default 'pending'
    check (status in ('pending', 'processing', 'succeeded', 'retrying', 'failed', 'manual_review')),
  attempt_count integer not null default 0,
  last_attempt_at timestamptz,
  next_attempt_at timestamptz,
  last_error text, -- sanitised only; no secrets, no full request/response bodies (Phase C.5 §12)
  external_id text, -- populated once known (e.g. the resulting Iomad user/course ID)

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  unique (external_system, idempotency_key)
);

create trigger integration_jobs_set_updated_at
  before update on integration_jobs
  for each row execute function set_updated_at();

create index idx_integration_jobs_status on integration_jobs (status);
create index idx_integration_jobs_next_attempt on integration_jobs (next_attempt_at) where status in ('pending', 'retrying');
create index idx_integration_jobs_entity on integration_jobs (entity_type, entity_id);

alter table integration_jobs enable row level security;

-- Admin can view job status (Phase C.5 §21 admin visibility) — nothing
-- else. Job rows are created/processed only by a trusted server-side
-- worker using the service-role key, which bypasses RLS.
create policy integration_jobs_admin_read on integration_jobs
  for select to authenticated
  using (is_admin());

comment on table integration_jobs is
  'Outbox for future async Iomad commands. Not executed by anything yet —
   schema-only preparation per Phase E1 §13. Reads (grades/progress/
   completion) are explicitly NOT routed through this table — see
   docs/PHASE_E_SCHEMA_RLS.md.';
