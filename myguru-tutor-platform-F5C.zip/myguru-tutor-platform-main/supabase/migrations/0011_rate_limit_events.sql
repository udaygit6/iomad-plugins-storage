-- 0011_rate_limit_events.sql
--
-- E4 anti-abuse: a small database-backed rate-limit ledger for the public
-- submission Netlify Functions. Deliberately NOT relying on in-process
-- memory — Netlify Function instances are ephemeral/scale horizontally, so
-- an in-memory counter would silently reset or fail to share state across
-- concurrent/cold-started instances. This table is the "small database-
-- backed mechanism" the brief asked for, not a new paid service.
--
-- Written and read ONLY by the server-side Netlify Functions using the
-- service-role/secret key (which bypasses RLS). No anon/authenticated
-- policy is granted at all — RLS is enabled immediately at creation with
-- zero policies, which default-denies everyone except the
-- privilege-bypassing service role, consistent with the pattern established
-- in the 0001-0010 audit.
--
-- Idempotent creation guards (`if not exists`) are used here specifically
-- because this migration may be reviewed/re-run locally before the single
-- approved remote push — the earlier migrations didn't need this since
-- they were written and pushed once as a batch.

create table if not exists rate_limit_events (
  id uuid primary key default gen_random_uuid(),
  -- A hash of (endpoint + hashed caller IP), never the raw IP — this table
  -- exists purely to count recent attempts, not to identify who made them.
  bucket_key text not null,
  created_at timestamptz not null default now()
);

create index if not exists idx_rate_limit_events_bucket_created
  on rate_limit_events (bucket_key, created_at desc);

alter table rate_limit_events enable row level security;

comment on table rate_limit_events is
  'Server-only rate-limit ledger for public submission endpoints (Phase E4).
   No anon/authenticated policy exists — only the service role (used by
   Netlify Functions) can read/write, via RLS bypass. Rows are not
   personally identifying (bucket_key is a hash, not a raw IP/email).';
