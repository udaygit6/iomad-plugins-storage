-- 0012_public_submission_functions.sql
--
-- E4: two narrowly-scoped, transactional Postgres functions — NOT a
-- generic RPC executor. Each function performs exactly one business
-- operation across the tables that operation genuinely needs, as a single
-- atomic transaction (a plpgsql function body commits/rolls back as one
-- unit). Called only from the server-side Netlify Functions using the
-- service-role/secret key — see netlify/functions/_lib/supabaseServerClient.ts.
--
-- Deliberately SECURITY INVOKER (the Postgres default, not SECURITY
-- DEFINER): these functions carry no privilege of their own. Whoever calls
-- them executes the internal INSERTs under their own role's RLS — the
-- service role already has full access (RLS bypass, a platform property),
-- so no elevation is needed, and if anon/authenticated ever called this
-- directly, the internal INSERTs would still be blocked by the existing
-- RLS policies on those tables (0009) since there is no anon/authenticated
-- INSERT policy on any of them. The explicit REVOKE/GRANT below is
-- defense-in-depth on top of that, not the only thing preventing misuse.
--
-- NOTE on the execute grant: written against the current understanding
-- that Supabase's server-side "secret key" requests still execute as the
-- underlying Postgres `service_role` — the newer key naming
-- (publishable/secret) is an API-key format change, not a new Postgres
-- role model, per the E3/E4 briefs' own key-naming guidance. Verify this
-- against the actual linked project before relying on it in production;
-- flagged rather than assumed silently.

create or replace function create_matching_request(
  p_parent_name text,
  p_parent_email text,
  p_parent_phone text,
  p_student_first_name text,
  p_year_group_label text,
  p_subject_slug text,
  p_help_needed text,
  p_goals_note text,
  p_availability_note text
)
returns uuid
language plpgsql
set search_path = public
as $$
declare
  v_email text := lower(trim(p_parent_email));
  v_parent_id uuid;
  v_student_id uuid;
  v_subject_id uuid;
  v_request_id uuid;
begin
  select id into v_subject_id from subjects where slug = p_subject_slug and enabled = true;
  if v_subject_id is null then
    raise exception 'invalid_subject_slug';
  end if;

  -- Find-or-create the parent contact by normalized email, WITHOUT
  -- overwriting an existing row's stored name/phone (Phase E1/E2 audit
  -- recommendation) and without the caller being able to tell which
  -- branch happened (both leave v_parent_id set to the correct row).
  insert into parent_contacts (name, email, phone)
  values (p_parent_name, v_email, p_parent_phone)
  on conflict (lower(email)) do nothing
  returning id into v_parent_id;

  if v_parent_id is null then
    select id into v_parent_id from parent_contacts where lower(email) = v_email;
  end if;

  -- Students are never deduplicated — a new row every submission, per the
  -- approved recommendation.
  insert into students (parent_contact_id, first_name, year_group_label)
  values (v_parent_id, p_student_first_name, p_year_group_label)
  returning id into v_student_id;

  insert into matching_requests (parent_contact_id, student_id, subject_id, help_needed, goals_note, availability_note)
  values (v_parent_id, v_student_id, v_subject_id, p_help_needed, p_goals_note, p_availability_note)
  returning id into v_request_id;

  insert into matching_request_status_history (matching_request_id, previous_status, new_status, changed_by, notes)
  values (v_request_id, null, 'submitted', null, null);

  return v_request_id;
end;
$$;

revoke execute on function create_matching_request(text, text, text, text, text, text, text, text, text) from public;
grant execute on function create_matching_request(text, text, text, text, text, text, text, text, text) to service_role;

comment on function create_matching_request is
  'Atomic public matching-request submission (Phase E4). Called only from
   netlify/functions/submit-matching-request.ts using the service-role key.
   Parent find-or-create never overwrites existing contact data; students
   are never deduplicated.';


create or replace function create_tutor_application(
  p_full_name text,
  p_email text,
  p_phone text,
  p_about_you text,
  p_teaching_experience text,
  p_education text,
  p_qualifications text[],
  p_subject_slugs text[],
  p_education_level_slugs text[],
  p_teaching_approach text,
  p_availability_notes text,
  p_supporting_documents_note text
)
returns uuid
language plpgsql
set search_path = public
as $$
declare
  v_email text := lower(trim(p_email));
  v_app_id uuid;
  v_matched_subjects int;
  v_matched_levels int;
begin
  -- Validate every referenced subject/education-level slug actually exists
  -- before writing anything, rather than silently dropping unmatched ones.
  select count(*) into v_matched_subjects
  from unnest(p_subject_slugs) as slug join subjects s on s.slug = slug;
  if v_matched_subjects <> coalesce(array_length(p_subject_slugs, 1), 0) then
    raise exception 'invalid_subject_slug';
  end if;

  select count(*) into v_matched_levels
  from unnest(p_education_level_slugs) as slug join education_levels l on l.slug = slug;
  if v_matched_levels <> coalesce(array_length(p_education_level_slugs, 1), 0) then
    raise exception 'invalid_education_level_slug';
  end if;

  -- Status is server-controlled, never caller-supplied — table default 'submitted'.
  insert into tutor_applications (
    full_name, email, phone, about_you, teaching_experience, education,
    teaching_approach, availability_notes, supporting_documents_note, submitted_at
  )
  values (
    p_full_name, v_email, p_phone, p_about_you, p_teaching_experience, p_education,
    p_teaching_approach, p_availability_notes, p_supporting_documents_note, now()
  )
  returning id into v_app_id;

  insert into tutor_application_qualifications (tutor_application_id, qualification_text, display_order)
  select v_app_id, q, (ord - 1)::int
  from unnest(p_qualifications) with ordinality as t(q, ord);

  insert into tutor_application_subjects (tutor_application_id, subject_id)
  select v_app_id, s.id from unnest(p_subject_slugs) as slug join subjects s on s.slug = slug;

  insert into tutor_application_levels (tutor_application_id, education_level_id)
  select v_app_id, l.id from unnest(p_education_level_slugs) as slug join education_levels l on l.slug = slug;

  insert into tutor_application_status_history (tutor_application_id, previous_status, new_status, changed_by, notes)
  values (v_app_id, null, 'submitted', null, null);

  return v_app_id;
end;
$$;

revoke execute on function create_tutor_application(text, text, text, text, text, text, text[], text[], text[], text, text, text) from public;
grant execute on function create_tutor_application(text, text, text, text, text, text, text[], text[], text[], text, text, text) to service_role;

comment on function create_tutor_application is
  'Atomic public tutor-application submission (Phase E4). Called only from
   netlify/functions/submit-tutor-application.ts using the service-role key.
   Never creates a tutor_profiles row, never marks anything verified —
   TutorApplication remains fully separate from TutorProfile.';
