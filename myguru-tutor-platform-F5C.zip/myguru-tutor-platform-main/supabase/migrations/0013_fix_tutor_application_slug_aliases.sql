-- 0013_fix_tutor_application_slug_aliases.sql
--
-- Hotfix for create_tutor_application() deployed in migration 0012.
-- PostgreSQL raised:
--   column reference "slug" is ambiguous
--
-- Root cause:
--   unnest(...) result aliases used the generic name "slug", which became
--   ambiguous alongside joined tables that also expose a "slug" column.
--
-- This migration preserves the exact function signature, behaviour,
-- permissions, search_path, workflow semantics, and public/private
-- boundaries from 0012. Only the four ambiguous unnest aliases are changed.
--
-- Migration 0012 is intentionally left untouched because it is already
-- applied to the staging database.

create or replace function create_tutor_application(
  p_full_name text,
  p_email text,
  p_phone text,
  p_about_you text,
  p_teaching_experience text,
  p_education text,
  p_qualifications text[],
  p_subject_slugs text[],
  p_education_level_slugs text[],
  p_teaching_approach text,
  p_availability_notes text,
  p_supporting_documents_note text
)
returns uuid
language plpgsql
set search_path = public
as $$
declare
  v_email text := lower(trim(p_email));
  v_app_id uuid;
  v_matched_subjects int;
  v_matched_levels int;
begin
  -- Validate every referenced subject/education-level slug actually exists
  -- before writing anything, rather than silently dropping unmatched ones.
  select count(*) into v_matched_subjects
  from unnest(p_subject_slugs) as u(subject_slug)
  join subjects s on s.slug = u.subject_slug;

  if v_matched_subjects <> coalesce(array_length(p_subject_slugs, 1), 0) then
    raise exception 'invalid_subject_slug';
  end if;

  select count(*) into v_matched_levels
  from unnest(p_education_level_slugs) as u(level_slug)
  join education_levels l on l.slug = u.level_slug;

  if v_matched_levels <> coalesce(array_length(p_education_level_slugs, 1), 0) then
    raise exception 'invalid_education_level_slug';
  end if;

  -- Status is server-controlled, never caller-supplied — table default 'submitted'.
  insert into tutor_applications (
    full_name, email, phone, about_you, teaching_experience, education,
    teaching_approach, availability_notes, supporting_documents_note, submitted_at
  )
  values (
    p_full_name, v_email, p_phone, p_about_you, p_teaching_experience, p_education,
    p_teaching_approach, p_availability_notes, p_supporting_documents_note, now()
  )
  returning id into v_app_id;

  insert into tutor_application_qualifications (
    tutor_application_id,
    qualification_text,
    display_order
  )
  select v_app_id, q, (ord - 1)::int
  from unnest(p_qualifications) with ordinality as t(q, ord);

  insert into tutor_application_subjects (
    tutor_application_id,
    subject_id
  )
  select v_app_id, s.id
  from unnest(p_subject_slugs) as u(subject_slug)
  join subjects s on s.slug = u.subject_slug;

  insert into tutor_application_levels (
    tutor_application_id,
    education_level_id
  )
  select v_app_id, l.id
  from unnest(p_education_level_slugs) as u(level_slug)
  join education_levels l on l.slug = u.level_slug;

  insert into tutor_application_status_history (
    tutor_application_id,
    previous_status,
    new_status,
    changed_by,
    notes
  )
  values (
    v_app_id,
    null,
    'submitted',
    null,
    null
  );

  return v_app_id;
end;
$$;

revoke execute on function create_tutor_application(
  text,
  text,
  text,
  text,
  text,
  text,
  text[],
  text[],
  text[],
  text,
  text,
  text
) from public;

grant execute on function create_tutor_application(
  text,
  text,
  text,
  text,
  text,
  text,
  text[],
  text[],
  text[],
  text,
  text,
  text
) to service_role;

comment on function create_tutor_application is
  'Atomic public tutor-application submission (Phase E4). Called only from
   netlify/functions/submit-tutor-application.ts using the service-role key.
   Never creates a tutor_profiles row, never marks anything verified —
   TutorApplication remains fully separate from TutorProfile.';