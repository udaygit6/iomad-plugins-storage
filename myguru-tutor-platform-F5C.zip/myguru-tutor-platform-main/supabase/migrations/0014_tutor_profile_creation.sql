-- 0014_tutor_profile_creation.sql
--
-- E7: the missing admin workflow step between an approved tutor
-- application and a publishable tutor profile.
--
-- Revised after E7 review (still local-only, not yet deployed — edited in
-- place rather than superseded by a new migration, since nothing here has
-- ever been pushed to staging):
--
-- 1. AUDIT IDENTITY: create_tutor_profile_from_application() no longer
--    accepts a caller-supplied p_changed_by. changed_by is now derived
--    exclusively from auth.uid() inside the function — a caller can no
--    longer attribute a profile creation to an arbitrary user id.
--
-- 2. CONCURRENCY: the original "check existing, then insert" idempotency
--    check left a real (if narrow) race: two concurrent calls for the same
--    application could both pass the existence check before either
--    inserted, and the loser would receive a raw unique_violation instead
--    of the existing profile's id. The insert is now wrapped in its own
--    exception block that specifically catches a violation of
--    idx_tutor_profiles_application_id (checked by constraint name, not
--    assumed) and returns the winning transaction's profile id instead —
--    any other unique violation (e.g. an extraordinarily unlikely slug
--    collision) is re-raised unchanged, never silently swallowed.
--
-- 3. PROFILE UPDATE ATOMICITY: a new update_tutor_profile() RPC replaces
--    what was previously three independent client-side calls (a table
--    update, then a delete+insert on each junction table) with one
--    transactional operation. Validates subject/education-level slugs the
--    same way create_tutor_application() does (0013's fix), remains
--    SECURITY INVOKER, and exposes no private application fields — it only
--    ever touches tutor_profiles' public-safe columns and the two junction
--    tables.
--
-- Both functions are invoked by an authenticated ADMIN session, not the
-- service-role key — SECURITY INVOKER (unchanged) means their internal
-- INSERT/UPDATE/DELETE statements execute as the calling admin and are
-- authorized by the existing tutor_profiles_admin_all /
-- tutor_profile_subjects_admin_all / tutor_profile_levels_admin_all RLS
-- policies (0009, gated by is_admin()) — no privilege elevation needed or
-- granted. A non-admin calling either function would have every internal
-- write rejected by RLS, exactly as calling the underlying tables directly
-- would be.

create unique index if not exists idx_tutor_profiles_application_id
  on tutor_profiles (tutor_application_id)
  where tutor_application_id is not null;

comment on index idx_tutor_profiles_application_id is
  'Enforces at most one tutor_profiles row per tutor_applications row
   (Phase E7 §12 idempotency requirement). NULLs are unrestricted.';


create or replace function create_tutor_profile_from_application(
  p_application_id uuid
)
returns uuid
language plpgsql
set search_path = public
as $$
declare
  v_existing_profile_id uuid;
  v_app tutor_applications%rowtype;
  v_profile_id uuid;
  v_name_parts text[];
  v_display_name text;
  v_headline text;
  v_slug_base text;
  v_slug text;
  v_constraint_name text;
begin
  -- Fast path: an existing profile for this application is returned as-is.
  -- This is an optimization, not the only guarantee — see the exception
  -- handler below for the concurrency-safe guarantee.
  select id into v_existing_profile_id from tutor_profiles where tutor_application_id = p_application_id;
  if v_existing_profile_id is not null then
    return v_existing_profile_id;
  end if;

  select * into v_app from tutor_applications where id = p_application_id;
  if v_app.id is null then
    raise exception 'application_not_found';
  end if;
  if v_app.status <> 'approved' then
    raise exception 'application_not_approved';
  end if;

  -- Public display name: "First name + last initial" (the working
  -- convention, e.g. "Sarah M.") — never the applicant's full legal name.
  v_name_parts := regexp_split_to_array(trim(v_app.full_name), '\s+');
  if array_length(v_name_parts, 1) <= 1 then
    v_display_name := coalesce(v_name_parts[1], 'Tutor');
  else
    v_display_name := v_name_parts[1] || ' ' || left(v_name_parts[array_length(v_name_parts, 1)], 1) || '.';
  end if;

  -- A genuinely useful starting headline derived from the application's
  -- own approved subjects — admin reviews/edits before publishing.
  select string_agg(s.name, ' & ' order by s.name) into v_headline
  from tutor_application_subjects tas
  join subjects s on s.id = tas.subject_id
  where tas.tutor_application_id = p_application_id;
  v_headline := coalesce(v_headline, 'Tutor');

  v_slug_base := trim(both '-' from lower(regexp_replace(v_display_name, '[^a-zA-Z0-9]+', '-', 'g')));
  v_slug := v_slug_base || '-' || substr(md5(random()::text || clock_timestamp()::text), 1, 6);

  -- Deliberately copies only: display name (derived), headline (derived),
  -- bio (from about_you), teaching approach, experience summary (from
  -- teaching_experience), and subject/level selections. Deliberately does
  -- NOT copy: email, phone, admin_notes, supporting_documents_note,
  -- self-reported qualifications (left for admin to write public-safe
  -- text explicitly), or any verification state. accepting_students
  -- defaults false — admin must explicitly opt a new profile in.
  --
  -- The insert is isolated in its own exception-handling block: if a
  -- concurrent call for the SAME application committed first, this insert
  -- fails with unique_violation against idx_tutor_profiles_application_id.
  -- Rather than letting that error propagate, we look up and return the
  -- winning transaction's profile id — by the time Postgres reports the
  -- conflict, the other transaction has already committed (Postgres
  -- blocks a conflicting insert until the other transaction resolves), so
  -- its junction/status-history rows are guaranteed to exist too. Any
  -- OTHER unique violation (checked by constraint name, not assumed) is
  -- re-raised unchanged rather than silently swallowed.
  begin
    insert into tutor_profiles (
      tutor_application_id, slug, public_display_name, headline, bio,
      teaching_approach, experience_summary, qualifications_summary,
      languages, accepting_students, status
    ) values (
      p_application_id, v_slug, v_display_name, v_headline, v_app.about_you,
      v_app.teaching_approach, v_app.teaching_experience, '{}', '{}', false, 'draft'
    )
    returning id into v_profile_id;
  exception
    when unique_violation then
      get stacked diagnostics v_constraint_name = constraint_name;
      if v_constraint_name = 'idx_tutor_profiles_application_id' then
        select id into v_profile_id from tutor_profiles where tutor_application_id = p_application_id;
        return v_profile_id;
      else
        raise;
      end if;
  end;

  insert into tutor_profile_subjects (tutor_profile_id, subject_id)
  select v_profile_id, tas.subject_id
  from tutor_application_subjects tas
  where tas.tutor_application_id = p_application_id;

  insert into tutor_profile_levels (tutor_profile_id, education_level_id)
  select v_profile_id, tal.education_level_id
  from tutor_application_levels tal
  where tal.tutor_application_id = p_application_id;

  insert into tutor_profile_status_history (tutor_profile_id, previous_status, new_status, changed_by, notes)
  values (v_profile_id, null, 'draft', auth.uid(), 'Created from approved application');

  return v_profile_id;
end;
$$;

-- Called by an authenticated admin session, not the service-role key —
-- grant to `authenticated`, not `service_role`. RLS on the tables the
-- function writes to is what actually enforces admin-only access; a
-- non-admin authenticated user calling this function would have every
-- internal INSERT rejected.
revoke execute on function create_tutor_profile_from_application(uuid) from public;
grant execute on function create_tutor_profile_from_application(uuid) to authenticated;

comment on function create_tutor_profile_from_application is
  'Atomic, idempotent (including under concurrent calls) draft-profile
   creation from an approved tutor application (Phase E7, revised in
   review). Called from an authenticated admin session
   (AdminTutorProfilesService), never the service-role key. changed_by is
   derived from auth.uid(), never caller-supplied. Only status=''approved''
   applications may create a profile; calling it again for the same
   application — even concurrently — returns the existing profile rather
   than creating or erroring on a duplicate.';


create or replace function update_tutor_profile(
  p_profile_id uuid,
  p_public_display_name text,
  p_headline text,
  p_positioning_statement text,
  p_bio text,
  p_teaching_approach text,
  p_experience_summary text,
  p_qualifications_summary text[],
  p_languages text[],
  p_accepting_students boolean,
  p_photo_url text,
  p_subject_slugs text[],
  p_education_level_slugs text[]
)
returns uuid
language plpgsql
set search_path = public
as $$
declare
  v_matched_subjects int;
  v_matched_levels int;
begin
  -- Validate every referenced slug actually exists, exactly as
  -- create_tutor_application() does (0013's aliasing fix applied here from
  -- the start — no ambiguous unnest alias to fix later).
  select count(*) into v_matched_subjects
  from unnest(p_subject_slugs) as u(subject_slug)
  join subjects s on s.slug = u.subject_slug;
  if v_matched_subjects <> coalesce(array_length(p_subject_slugs, 1), 0) then
    raise exception 'invalid_subject_slug';
  end if;

  select count(*) into v_matched_levels
  from unnest(p_education_level_slugs) as u(level_slug)
  join education_levels l on l.slug = u.level_slug;
  if v_matched_levels <> coalesce(array_length(p_education_level_slugs, 1), 0) then
    raise exception 'invalid_education_level_slug';
  end if;

  -- Only the approved public-safe profile fields — never touches status,
  -- tutor_application_id, or anything from tutor_applications.
  update tutor_profiles set
    public_display_name = p_public_display_name,
    headline = p_headline,
    positioning_statement = p_positioning_statement,
    bio = p_bio,
    teaching_approach = p_teaching_approach,
    experience_summary = p_experience_summary,
    qualifications_summary = p_qualifications_summary,
    languages = p_languages,
    accepting_students = p_accepting_students,
    photo_url = p_photo_url
  where id = p_profile_id;

  if not found then
    raise exception 'profile_not_found';
  end if;

  delete from tutor_profile_subjects where tutor_profile_id = p_profile_id;
  insert into tutor_profile_subjects (tutor_profile_id, subject_id)
  select p_profile_id, s.id
  from unnest(p_subject_slugs) as u(subject_slug)
  join subjects s on s.slug = u.subject_slug;

  delete from tutor_profile_levels where tutor_profile_id = p_profile_id;
  insert into tutor_profile_levels (tutor_profile_id, education_level_id)
  select p_profile_id, l.id
  from unnest(p_education_level_slugs) as u(level_slug)
  join education_levels l on l.slug = u.level_slug;

  return p_profile_id;
end;
$$;

revoke execute on function update_tutor_profile(uuid, text, text, text, text, text, text, text[], text[], boolean, text, text[], text[]) from public;
grant execute on function update_tutor_profile(uuid, text, text, text, text, text, text, text[], text[], boolean, text, text[], text[]) to authenticated;

comment on function update_tutor_profile is
  'Atomic tutor-profile edit (Phase E7, added in review): replaces the
   previous three-independent-calls approach (table update + delete/insert
   on each junction table) with one transaction. Validates subject/
   education-level slugs before writing anything. Touches only
   tutor_profiles'' public-safe columns and its two junction tables — never
   status, never tutor_application_id, never anything from
   tutor_applications. SECURITY INVOKER; authorized by the same RLS admin
   policies as every other write in this migration.';
