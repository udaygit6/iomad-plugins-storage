-- 0015_organisation_iomad_company_sync.sql
--
-- F4 — platform-side company synchronisation foundation. Read-only sync
-- FROM Iomad only: nothing in this migration, and nothing in the
-- application code that uses it, ever writes back to Iomad. See
-- docs/IOMAD_INTEGRATION_CONTRACT.md and docs/SYSTEM_OF_RECORD.md for the
-- full contract this schema implements.
--
--   Iomad Company (authoritative for LMS tenant/company state)
--     → read-only sync
--     → organisations (VedasGuru platform — business/customer metadata)
--     → iomad_company_mappings (the seam between the two — external
--       identity link, never a merge)
--
-- Deliberately minimal per the F4 brief ("Do NOT over-model yet"): no
-- Corporate-specific tables, no franchise billing tables, no student
-- mappings. Those are explicitly out of scope here.
--
-- Does not modify 0001-0014. This is a new, additive migration only.
-- Revised in place after F4 review (not yet deployed to staging — same
-- "acceptable to edit before push" precedent as 0014's review fixes):
-- the create+link write path moved into sync_iomad_company() below so it
-- runs as one atomic transaction instead of two separate HTTP requests,
-- and new organisations are classified 'unclassified' rather than
-- guessed as 'myguru_franchise'.

create table organisations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  -- 'unclassified' is what generic Iomad sync always uses (see
  -- sync_iomad_company() below) — the single shared Iomad instance holds
  -- MyGuru franchise, Corporate, future school, and potentially internal
  -- tenants, and F4 has no verified signal to distinguish them from a
  -- company id/name alone. Business classification is a deliberate later
  -- step (an explicit provisioning or admin workflow), never inferred
  -- here from name/email/ID heuristics.
  type text not null default 'unclassified'
    check (type in ('unclassified', 'myguru_franchise', 'corporate', 'school_future', 'internal')),
  status text not null default 'active'
    check (status in ('active', 'suspended', 'inactive')),
  -- How this row came to exist. Every F4 row is 'iomad_sync' — 'manual' is
  -- reserved for a future admin-created-organisation flow that does not
  -- exist yet (no such write path is added by this migration or by F4's
  -- application code).
  source text not null
    check (source in ('iomad_sync', 'manual')),

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create trigger organisations_set_updated_at
  before update on organisations
  for each row execute function set_updated_at();

create index idx_organisations_status on organisations (status);
create index idx_organisations_type on organisations (type);

alter table organisations enable row level security;

comment on table organisations is
  'Platform-owned business/customer organisation metadata (F1/F4). Distinct
   from an Iomad company — see iomad_company_mappings for the link between
   them. Iomad company suspension is authoritative for LMS operational
   access (F4 business requirement); organisations.status is NOT yet wired
   to that — see docs/IOMAD_INTEGRATION_CONTRACT.md''s live schema gate.
   Written only by the server-side company sync service (via
   sync_iomad_company(), below) using the service-role key (see 0010''s
   identical pattern for integration_jobs) — no anon/authenticated write
   policy exists on this table. New rows from generic sync are always
   type = ''unclassified''; business classification is assigned later,
   not inferred during sync.';

create table iomad_company_mappings (
  id uuid primary key default gen_random_uuid(),
  -- One organisation maps to at most one Iomad company for F4. A
  -- franchise/paid tutor or Corporate customer mapping to a *different*
  -- Iomad company than another organisation is the normal case (separate
  -- rows) — this is not a statement that VedasGuru will only ever have
  -- one Iomad company overall.
  organisation_id uuid not null unique references organisations(id) on delete cascade,

  -- The external identity. NEVER email/name — see F1 Ground rule 2
  -- (docs/SYSTEM_OF_RECORD.md). Text, not integer: Iomad's id is
  -- normalised to a string by the F3 response adapter
  -- (../iomad/IomadResponseAdapters.ts) before it ever reaches this
  -- table, and the exact underlying Iomad type is unverified.
  iomad_company_id text not null unique check (iomad_company_id <> ''),

  sync_status text not null default 'pending'
    check (sync_status in ('pending', 'synced', 'failed', 'stale')),
  last_synced_at timestamptz,
  -- Safe error code only (e.g. an IomadErrorCode value) — never a raw
  -- message, never a stack trace, never response body content. See
  -- ../iomad/IomadErrors.ts and IomadCompanySyncService.ts's logSafe().
  last_error_code text,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create trigger iomad_company_mappings_set_updated_at
  before update on iomad_company_mappings
  for each row execute function set_updated_at();

create index idx_iomad_company_mappings_sync_status on iomad_company_mappings (sync_status);

alter table iomad_company_mappings enable row level security;

comment on table iomad_company_mappings is
  'External-identity link between a platform organisation and an Iomad
   company (F1/F4). iomad_company_id is unique and is the only identity
   key used for sync matching. Rows are created/updated ONLY by
   sync_iomad_company() (below), called with the service-role key, which
   bypasses RLS — see netlify/functions/_lib/companySync/. A company
   missing from a later sync is marked ''stale'', never deleted (F4 §7) —
   temporary API filtering, token scope changes, or source failures could
   make a company transiently disappear from a listCompanies() response.
   Suspension sync is NOT implemented — sync_status tracks THIS
   synchronisation''s health, not the Iomad company''s operational/
   suspended state, which remains PENDING LIVE SCHEMA VERIFICATION (see
   docs/IOMAD_INTEGRATION_CONTRACT.md).';

-- ---------------------------------------------------------------------------
-- RLS — internal platform/integration records, not portal/business data.
--
-- Deliberately narrower than most tables in this schema: admin gets READ
-- only, not full CRUD. No admin-facing UI writes to these tables in F4 —
-- the only writer is the server-side sync service via the service-role
-- key (which bypasses RLS entirely, the same guarantee 0009's header
-- comment documents and 0010/integration_jobs already relies on). If a
-- genuine admin-write need appears later (e.g. manually overriding an
-- organisation's status), add that policy explicitly then, scoped to
-- exactly what's needed, rather than granting broad admin_all up front.
-- ---------------------------------------------------------------------------

create policy organisations_admin_read on organisations
  for select to authenticated
  using (is_admin());

create policy iomad_company_mappings_admin_read on iomad_company_mappings
  for select to authenticated
  using (is_admin());

-- No insert/update/delete policy for anon or authenticated at all on
-- either table — writes happen only via the service-role key, calling
-- sync_iomad_company() below, which bypasses RLS. This is the same
-- pattern 0008 (admin_profiles) and 0010 (integration_jobs) already use.

-- ---------------------------------------------------------------------------
-- sync_iomad_company() — atomic find-or-create + rename + mark-synced.
--
-- F4 review fix: the original design performed a separate INSERT into
-- organisations, then a separate INSERT into iomad_company_mappings, as
-- two independent Supabase requests. If the second insert failed (network
-- blip, constraint violation, etc.), the first could succeed and leave an
-- orphan organisation with no mapping — and running the same sync again
-- would then create a SECOND organisation for the same Iomad company,
-- breaking the idempotency guarantee this table's unique iomad_company_id
-- constraint is supposed to provide. This function replaces both call
-- sites: create-new AND rename-existing-and-mark-synced both happen
-- inside this one function, so either the whole thing commits or none of
-- it does — there is no statement boundary between the two tables for a
-- partial failure to land in.
--
-- Concurrency: a transaction-scoped advisory lock, keyed by
-- iomad_company_id, serializes any two concurrent calls for the SAME
-- company so they cannot both take the "doesn't exist yet" branch and
-- race the unique constraint. The second caller blocks until the first
-- commits, then finds the row the first created and takes the
-- update/reuse branch instead — repeated or concurrent calls for the
-- same iomad_company_id return/reuse the same organisation+mapping, never
-- duplicates.
--
-- SECURITY INVOKER, not DEFINER — explicitly justified: the only intended
-- caller is the service-role key (netlify/functions/_lib/companySync/
-- SupabaseOrganisationSyncRepository.ts), which already bypasses RLS and
-- has full read/write access to both tables. DEFINER exists to let a
-- caller do something their own privileges wouldn't otherwise allow (see
-- is_admin() in 0008, which needs to read admin_profiles under a
-- restrictive caller context) — there is no such gap here, so DEFINER
-- would only add unnecessary privilege-escalation surface. INVOKER also
-- gives real defense in depth: if EXECUTE were ever mistakenly granted to
-- `authenticated`, this function would still fail for that caller,
-- because RLS still applies to an INVOKER function and neither table has
-- an authenticated-write policy — a DEFINER function would not have that
-- protection.
--
-- Never callable by anon/authenticated — see the revoke/grant below this
-- function. No Iomad write occurs; this only ever writes to
-- organisations/iomad_company_mappings.
-- ---------------------------------------------------------------------------

create or replace function sync_iomad_company(
  p_iomad_company_id text,
  p_display_name text
)
returns table (
  organisation_id uuid,
  organisation_name text,
  organisation_type text,
  organisation_status text,
  organisation_source text,
  organisation_created_at timestamptz,
  organisation_updated_at timestamptz,
  mapping_id uuid,
  mapping_sync_status text,
  mapping_last_synced_at timestamptz,
  mapping_last_error_code text,
  mapping_created_at timestamptz,
  mapping_updated_at timestamptz,
  was_created boolean,
  name_changed boolean
)
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_organisation_id uuid;
  v_mapping_id uuid;
  v_existing_name text;
  v_was_created boolean := false;
  v_name_changed boolean := false;
begin
  if p_iomad_company_id is null or length(trim(p_iomad_company_id)) = 0 then
    raise exception 'iomad_company_id_required';
  end if;
  if p_display_name is null or length(trim(p_display_name)) = 0 then
    raise exception 'display_name_required';
  end if;

  perform pg_advisory_xact_lock(hashtext('sync_iomad_company:' || p_iomad_company_id));

  select m.organisation_id, m.id, o.name
    into v_organisation_id, v_mapping_id, v_existing_name
  from iomad_company_mappings m
  join organisations o on o.id = m.organisation_id
  where m.iomad_company_id = p_iomad_company_id
  for update of m;

  if v_mapping_id is null then
    -- Never seen before — create both rows in this one transaction.
    -- Always 'unclassified': see the organisations.type comment above.
    insert into organisations (name, type, status, source)
    values (p_display_name, 'unclassified', 'active', 'iomad_sync')
    returning id into v_organisation_id;

    insert into iomad_company_mappings (organisation_id, iomad_company_id, sync_status, last_synced_at, last_error_code)
    values (v_organisation_id, p_iomad_company_id, 'synced', now(), null)
    returning id into v_mapping_id;

    v_was_created := true;
  else
    -- Already known — update the name only if it actually changed, and
    -- mark the mapping synced either way, in the same transaction.
    if v_existing_name is distinct from p_display_name then
      update organisations set name = p_display_name where id = v_organisation_id;
      v_name_changed := true;
    end if;

    update iomad_company_mappings
      set sync_status = 'synced', last_synced_at = now(), last_error_code = null
      where id = v_mapping_id;
  end if;

  return query
    select
      o.id, o.name, o.type, o.status, o.source, o.created_at, o.updated_at,
      m.id, m.sync_status, m.last_synced_at, m.last_error_code, m.created_at, m.updated_at,
      v_was_created, v_name_changed
    from organisations o
    join iomad_company_mappings m on m.organisation_id = o.id
    where o.id = v_organisation_id;
end;
$$;

revoke all on function sync_iomad_company(text, text) from public;
grant execute on function sync_iomad_company(text, text) to service_role;

comment on function sync_iomad_company(text, text) is
  'F4 — atomic find-or-create + rename + mark-synced for one Iomad
   company. See the header comment immediately above this function for
   the full rationale (atomicity, concurrency, SECURITY INVOKER
   justification). Server-side/service-role only — not granted to anon or
   authenticated. No Iomad write occurs.';
