-- 0016_course_persistence_and_organisation_allocations.sql
--
-- F5B — platform-side persistence for F5A's already-live-verified Iomad
-- course/company relationship. Iomad remains the LMS source of truth;
-- this migration only persists a read-through cache of it. Nothing in
-- this migration, and nothing in the application code that uses it, ever
-- writes back to Iomad.
--
--   Iomad company course allocations + course settings (F5A, live-verified)
--     → read-only sync
--     → courses (global — a course exists independently of which
--       organisation(s) can see it)
--     → iomad_course_mappings (the seam between a platform course and its
--       Iomad course — external identity link, never a merge)
--     → organisation_course_allocations (tenant-specific — which
--       organisation currently has access to which course, and under
--       what licensing/settings)
--
-- Domain rule (F5B brief): a course is global; an allocation is
-- tenant-specific. Losing access does not delete the course, and does
-- not delete the mapping — only the allocation is marked stale. See
-- mark_stale_organisation_course_allocations() below.
--
-- iomad_course_id is TEXT, not bigint/int as originally suggested —
-- deliberately consistent with 0015's iomad_company_id (also TEXT):
-- `IomadCourseSummary.externalCourseId`/`IomadCourseSettings.externalCourseId`
-- are already normalised to strings by the F5A response adapter
-- (../iomad/IomadResponseAdapters.ts) before they ever reach this schema,
-- and the exact underlying Iomad wire type is unverified beyond "it's
-- numeric on the wire, normalised to a string by our adapter" — the same
-- reasoning 0015 already documented for companies.
--
-- Does not modify 0001-0015. This is a new, additive migration only, and
-- has NOT been pushed to any Supabase project (local review only).

create table courses (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  status text not null default 'active'
    check (status in ('active', 'inactive')),

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create trigger courses_set_updated_at
  before update on courses
  for each row execute function set_updated_at();

create index idx_courses_status on courses (status);

alter table courses enable row level security;

comment on table courses is
  'Platform-owned course record (F5B). GLOBAL — a course exists
   independently of which organisation(s) currently have access to it;
   see organisation_course_allocations for the tenant-specific link. Never
   deleted when an organisation loses access — only its allocation is
   marked stale (see mark_stale_organisation_course_allocations()).
   Written only by sync_iomad_company_course() (below), called with the
   service-role key — no anon/authenticated write policy exists on this
   table.';

create table iomad_course_mappings (
  id uuid primary key default gen_random_uuid(),
  -- One course maps to at most one Iomad course for F5B.
  course_id uuid not null unique references courses(id) on delete cascade,

  -- The external identity. NEVER email/name — see F1 Ground rule 2
  -- (docs/SYSTEM_OF_RECORD.md). TEXT, not integer — see file header.
  iomad_course_id text not null unique check (iomad_course_id <> ''),

  sync_status text not null default 'pending'
    check (sync_status in ('pending', 'synced', 'failed', 'stale')),
  last_synced_at timestamptz,
  -- Safe error code only — never a raw message, never a stack trace,
  -- never response body content. See ../iomad/IomadErrors.ts.
  last_error_code text,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create trigger iomad_course_mappings_set_updated_at
  before update on iomad_course_mappings
  for each row execute function set_updated_at();

create index idx_iomad_course_mappings_sync_status on iomad_course_mappings (sync_status);

alter table iomad_course_mappings enable row level security;

comment on table iomad_course_mappings is
  'External-identity link between a platform course and an Iomad course
   (F5B). iomad_course_id is unique and is the only identity key used for
   sync matching. Rows are created/updated ONLY by
   sync_iomad_company_course() (below), called with the service-role key,
   which bypasses RLS. A course is never deleted from here just because
   one organisation loses access to it — see
   organisation_course_allocations and F5B''s domain rule (course is
   global; allocation is tenant-specific).';

create table organisation_course_allocations (
  id uuid primary key default gen_random_uuid(),
  organisation_id uuid not null references organisations(id) on delete cascade,
  course_id uuid not null references courses(id) on delete cascade,

  -- F5A live-verified settings snapshot. licensed/shared are booleans in
  -- the PLATFORM model regardless of Iomad's own wire representation
  -- (licensed is a genuine JSON boolean on the wire; shared is numeric,
  -- normalised via !== 0 — see docs/IOMAD_INTEGRATION_CONTRACT.md's F5A
  -- section) — the adapter has already done that normalisation before
  -- this table is ever written to.
  licensed boolean not null default false,
  shared boolean not null default false,

  valid_length_days integer not null default 0
    check (valid_length_days >= 0),
  warn_expire_days integer not null default 0
    check (warn_expire_days >= 0),
  warn_completion_days integer not null default 0
    check (warn_completion_days >= 0),
  notify_period_days integer not null default 0
    check (notify_period_days >= 0),

  sync_status text not null default 'pending'
    check (sync_status in ('pending', 'synced', 'failed', 'stale')),
  last_synced_at timestamptz,
  last_error_code text,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  -- One allocation per organisation+course pair. The SAME Iomad course
  -- (one row in courses/iomad_course_mappings) allocated to TWO
  -- organisations produces TWO allocation rows here, one per
  -- organisation — this is the multi-tenant case F5B explicitly requires
  -- to work, not an edge case to guard against.
  unique (organisation_id, course_id)
);

create trigger organisation_course_allocations_set_updated_at
  before update on organisation_course_allocations
  for each row execute function set_updated_at();

create index idx_org_course_allocations_organisation on organisation_course_allocations (organisation_id);
create index idx_org_course_allocations_course on organisation_course_allocations (course_id);
create index idx_org_course_allocations_status on organisation_course_allocations (sync_status);

alter table organisation_course_allocations enable row level security;

comment on table organisation_course_allocations is
  'Tenant-specific link between an organisation and a course it currently
   (or previously) had access to, plus the F5A-live-verified
   licensing/settings snapshot for that pairing (F5B). unique
   (organisation_id, course_id) enforces exactly one allocation row per
   pairing — re-syncing updates it in place, never duplicates it. A
   course missing from a later company-courses sync for this organisation
   is marked sync_status = ''stale'' here (see
   mark_stale_organisation_course_allocations() below) — the row is never
   deleted, and neither the course nor its iomad_course_mapping is
   touched. Written only by sync_iomad_company_course() and
   mark_stale_organisation_course_allocations(), both called with the
   service-role key.';

-- ---------------------------------------------------------------------------
-- RLS — internal platform/integration records, not portal/business data.
-- Same posture as 0015: admin gets READ only, not full CRUD. The only
-- writer for all three tables is the server-side sync service via the
-- service-role key (bypasses RLS), calling the RPCs below. No
-- anon/authenticated write policy exists on any of these tables. Admin
-- browser reads may be added in a future F5C — not part of this
-- migration.
-- ---------------------------------------------------------------------------

create policy courses_admin_read on courses
  for select to authenticated
  using (is_admin());

create policy iomad_course_mappings_admin_read on iomad_course_mappings
  for select to authenticated
  using (is_admin());

create policy organisation_course_allocations_admin_read on organisation_course_allocations
  for select to authenticated
  using (is_admin());

-- ---------------------------------------------------------------------------
-- sync_iomad_company_course() — atomic find-or-create course+mapping,
-- rename, and upsert-allocation-with-settings, for ONE course and ONE
-- organisation.
--
-- Called once per course by the TypeScript sync service
-- (netlify/functions/_lib/courseSync/), the same "one atomic RPC call per
-- entity, looped by the service" architecture 0015's
-- sync_iomad_company() already established — not a single giant
-- multi-course RPC, so each course's success/failure is independent (one
-- course failing does not abort the others, matching F4/F5's existing
-- "one failure does not corrupt all other records" posture).
--
-- Concurrency: a transaction-scoped advisory lock, keyed by
-- iomad_course_id, serializes concurrent calls for the SAME course so
-- two syncs (e.g. two organisations both allocating the same course for
-- the first time, run concurrently) cannot both take the
-- "course doesn't exist yet" branch and race the unique constraint on
-- iomad_course_mappings.iomad_course_id. The allocation upsert itself
-- doesn't need a separate advisory lock — organisation_id+course_id's
-- unique constraint plus `for update` on the pre-check select already
-- makes it safe.
--
-- SECURITY INVOKER, not DEFINER — same justification as
-- sync_iomad_company() in 0015: the only intended caller is the
-- service-role key, which already bypasses RLS and has full access:
-- there is no privilege gap for DEFINER to bridge, and INVOKER gives real
-- defense in depth if EXECUTE were ever mistakenly granted more broadly.
--
-- Never callable by anon/authenticated — see the revoke/grant below. No
-- Iomad write occurs; this only ever writes to courses/
-- iomad_course_mappings/organisation_course_allocations.
-- ---------------------------------------------------------------------------

-- Pre-deployment review fix: an existing allocation's return row now also
-- reports `allocation_status_changed` — true whenever the PREVIOUS
-- sync_status was anything other than 'synced' (e.g. 'stale' or
-- 'failed') and this call brings it back to 'synced'. Without this, a
-- course that reappears in Iomad with byte-for-byte identical settings
-- to what was last stored would be reported "unchanged" even though its
-- allocation just transitioned from stale/failed back to active — a
-- real, meaningful change the caller needs to know about. Kept as its
-- own flag rather than folded into `allocation_settings_changed`, so the
-- two distinct reasons for an "updated" outcome (values differ vs.
-- status transitioned) stay distinguishable if ever needed.

create or replace function sync_iomad_company_course(
  p_organisation_id uuid,
  p_iomad_course_id text,
  p_course_name text,
  p_licensed boolean,
  p_shared boolean,
  p_valid_length_days integer,
  p_warn_expire_days integer,
  p_warn_completion_days integer,
  p_notify_period_days integer
)
returns table (
  course_id uuid,
  course_name text,
  course_status text,
  mapping_id uuid,
  allocation_id uuid,
  was_course_created boolean,
  course_name_changed boolean,
  was_allocation_created boolean,
  allocation_settings_changed boolean,
  allocation_status_changed boolean
)
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_course_id uuid;
  v_mapping_id uuid;
  v_existing_course_name text;
  v_was_course_created boolean := false;
  v_course_name_changed boolean := false;

  v_allocation_id uuid;
  v_was_allocation_created boolean := false;
  v_settings_changed boolean := false;
  v_allocation_status_changed boolean := false;
  v_existing_licensed boolean;
  v_existing_shared boolean;
  v_existing_valid_length integer;
  v_existing_warn_expire integer;
  v_existing_warn_completion integer;
  v_existing_notify_period integer;
  v_existing_sync_status text;
begin
  if p_organisation_id is null then
    raise exception 'organisation_id_required';
  end if;
  if p_iomad_course_id is null or length(trim(p_iomad_course_id)) = 0 then
    raise exception 'iomad_course_id_required';
  end if;
  if p_course_name is null or length(trim(p_course_name)) = 0 then
    raise exception 'course_name_required';
  end if;

  perform pg_advisory_xact_lock(hashtext('sync_iomad_company_course:' || p_iomad_course_id));

  select m.course_id, m.id, c.name
    into v_course_id, v_mapping_id, v_existing_course_name
  from iomad_course_mappings m
  join courses c on c.id = m.course_id
  where m.iomad_course_id = p_iomad_course_id
  for update of m;

  if v_mapping_id is null then
    -- Never seen before — create both rows in this one transaction.
    insert into courses (name, status)
    values (p_course_name, 'active')
    returning id into v_course_id;

    insert into iomad_course_mappings (course_id, iomad_course_id, sync_status, last_synced_at, last_error_code)
    values (v_course_id, p_iomad_course_id, 'synced', now(), null)
    returning id into v_mapping_id;

    v_was_course_created := true;
  else
    -- Already known — update the name only if it actually changed, and
    -- mark the mapping synced either way, in the same transaction.
    if v_existing_course_name is distinct from p_course_name then
      update courses set name = p_course_name where id = v_course_id;
      v_course_name_changed := true;
    end if;

    update iomad_course_mappings
      set sync_status = 'synced', last_synced_at = now(), last_error_code = null
      where id = v_mapping_id;
  end if;

  -- Allocation upsert, scoped to (p_organisation_id, v_course_id). The
  -- SAME course allocated to a different organisation is an entirely
  -- separate row here — this select/branch only ever looks at this one
  -- organisation's allocation for this one course.
  select id, licensed, shared, valid_length_days, warn_expire_days, warn_completion_days, notify_period_days, sync_status
    into v_allocation_id, v_existing_licensed, v_existing_shared,
         v_existing_valid_length, v_existing_warn_expire, v_existing_warn_completion, v_existing_notify_period,
         v_existing_sync_status
  from organisation_course_allocations
  where organisation_id = p_organisation_id and course_id = v_course_id
  for update;

  if v_allocation_id is null then
    insert into organisation_course_allocations (
      organisation_id, course_id, licensed, shared,
      valid_length_days, warn_expire_days, warn_completion_days, notify_period_days,
      sync_status, last_synced_at
    ) values (
      p_organisation_id, v_course_id, p_licensed, p_shared,
      p_valid_length_days, p_warn_expire_days, p_warn_completion_days, p_notify_period_days,
      'synced', now()
    )
    returning id into v_allocation_id;

    v_was_allocation_created := true;
  else
    v_settings_changed :=
      v_existing_licensed is distinct from p_licensed
      or v_existing_shared is distinct from p_shared
      or v_existing_valid_length is distinct from p_valid_length_days
      or v_existing_warn_expire is distinct from p_warn_expire_days
      or v_existing_warn_completion is distinct from p_warn_completion_days
      or v_existing_notify_period is distinct from p_notify_period_days;

    -- Review fix #2: a status transition (e.g. 'stale' or 'failed' back
    -- to 'synced') is itself a meaningful change, independent of whether
    -- the settings VALUES changed. Without this, a course that reappears
    -- in Iomad with identical settings would be reported "unchanged"
    -- even though its allocation just went from stale/failed back to
    -- active — misleading. Captured as its OWN flag rather than folded
    -- into allocation_settings_changed, so callers can tell the two
    -- reasons for an "updated" outcome apart if they ever need to.
    v_allocation_status_changed := v_existing_sync_status is distinct from 'synced';

    update organisation_course_allocations
      set licensed = p_licensed,
          shared = p_shared,
          valid_length_days = p_valid_length_days,
          warn_expire_days = p_warn_expire_days,
          warn_completion_days = p_warn_completion_days,
          notify_period_days = p_notify_period_days,
          sync_status = 'synced',
          last_synced_at = now(),
          last_error_code = null
      where id = v_allocation_id;
  end if;

  return query
    select
      c.id, c.name, c.status, m.id, a.id,
      v_was_course_created, v_course_name_changed, v_was_allocation_created, v_settings_changed,
      v_allocation_status_changed
    from courses c
    join iomad_course_mappings m on m.course_id = c.id
    join organisation_course_allocations a on a.course_id = c.id and a.organisation_id = p_organisation_id
    where c.id = v_course_id;
end;
$$;

revoke all on function sync_iomad_company_course(
  uuid, text, text, boolean, boolean, integer, integer, integer, integer
) from public;
grant execute on function sync_iomad_company_course(
  uuid, text, text, boolean, boolean, integer, integer, integer, integer
) to service_role;

comment on function sync_iomad_company_course(
  uuid, text, text, boolean, boolean, integer, integer, integer, integer
) is
  'F5B — atomic find-or-create course+mapping, rename, and
   upsert-allocation-with-settings for ONE course and ONE organisation.
   See the header comment immediately above this function for the full
   rationale (atomicity, concurrency, SECURITY INVOKER justification).
   Server-side/service-role only — not granted to anon or authenticated.
   No Iomad write occurs.';

-- ---------------------------------------------------------------------------
-- mark_stale_organisation_course_allocations() — F5B §"removed from
-- company": after a full listCompanyCourses() pass for one organisation,
-- mark every allocation for that organisation whose course is NOT among
-- the Iomad course IDs just seen as 'stale'. Never deletes the
-- allocation, never touches the course or its iomad_course_mapping —
-- only demotes currently-synced/pending allocations. Mirrors
-- mark_stale on iomad_company_mappings for the same reason: temporary
-- API filtering or a transient source failure could make a course
-- disappear from one sync run without genuinely meaning access was
-- revoked forever.
-- ---------------------------------------------------------------------------

create or replace function mark_stale_organisation_course_allocations(
  p_organisation_id uuid,
  p_seen_iomad_course_ids text[]
)
returns integer
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_count integer;
begin
  if p_organisation_id is null then
    raise exception 'organisation_id_required';
  end if;

  with updated as (
    update organisation_course_allocations a
    set sync_status = 'stale'
    from iomad_course_mappings m
    where a.course_id = m.course_id
      and a.organisation_id = p_organisation_id
      and a.sync_status in ('synced', 'pending')
      and not (m.iomad_course_id = any (coalesce(p_seen_iomad_course_ids, array[]::text[])))
    returning a.id
  )
  select count(*) into v_count from updated;

  return v_count;
end;
$$;

revoke all on function mark_stale_organisation_course_allocations(uuid, text[]) from public;
grant execute on function mark_stale_organisation_course_allocations(uuid, text[]) to service_role;

comment on function mark_stale_organisation_course_allocations(uuid, text[]) is
  'F5B — marks every organisation_course_allocation for the given
   organisation whose course is NOT in p_seen_iomad_course_ids as
   ''stale''. Never deletes the allocation, the course, or the
   iomad_course_mapping — course is global, allocation is
   tenant-specific (F5B domain rule). Server-side/service-role only.';
