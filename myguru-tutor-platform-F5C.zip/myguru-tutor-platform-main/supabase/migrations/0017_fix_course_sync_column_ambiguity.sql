-- 0017_fix_course_sync_column_ambiguity.sql
--
-- F5B HOTFIX — forward-only. Migration 0016 is already deployed to
-- myguru-staging and is immutable; this migration does not edit it, and
-- does not edit any of 0001-0016. It only CREATE OR REPLACEs the single
-- existing function that had the defect, preserving its exact signature
-- and return shape.
--
-- LIVE DEFECT (exact error from myguru-staging):
--
--   ERROR: 42702: column reference "course_id" is ambiguous
--   DETAIL: It could refer to either a PL/pgSQL variable or a table
--   column.
--   Failing SQL:
--     select id, licensed, shared, valid_length_days,
--            warn_expire_days, warn_completion_days,
--            notify_period_days, sync_status
--     from organisation_course_allocations
--     where organisation_id = p_organisation_id
--       and course_id = v_course_id
--     for update
--   CONTEXT: PL/pgSQL function sync_iomad_company_course(...) line 68 at
--   SQL statement
--
-- ROOT CAUSE: `sync_iomad_company_course()` uses `returns table (course_id
-- uuid, ...)`. PL/pgSQL implicitly turns every RETURNS TABLE column into
-- an OUT-parameter-like variable that is in scope for the ENTIRE function
-- body. `course_id` is both one of those implicit variables AND an actual
-- column on `organisation_course_allocations` (and on
-- `iomad_course_mappings`). The one SQL statement in 0016's version of
-- this function that referenced `course_id` WITHOUT a table alias —
-- the allocation lookup's `where organisation_id = ... and course_id =
-- v_course_id` — is therefore genuinely ambiguous to the planner: it
-- cannot tell whether `course_id` means the table's column or the
-- function's own `course_id` output variable. Every other statement in
-- the function already qualified its `course_id` references with a table
-- alias (`m.course_id`, `a.course_id`) or used it only inside an INSERT
-- column-target list (which is always resolved as table columns, never
-- ambiguous) — which is exactly why only this one query ever raised the
-- error.
--
-- FIX: re-define the function with `organisation_course_allocations`
-- aliased as `oca` in the previously-unaliased lookup and its
-- corresponding update, so every column reference in those two
-- statements is explicitly qualified. Also defensively aliases the two
-- other single-table UPDATEs (`courses`, `iomad_course_mappings`) that
-- were already technically unambiguous (none of `id`, `name`,
-- `sync_status`, `licensed`, `shared`, or any of the four day-count
-- columns collide with a RETURNS TABLE output name), purely so every
-- statement in the function follows the same explicit-alias convention
-- and none of them are one future column-name choice away from
-- reintroducing this class of bug.
--
-- Nothing else changes: same 9 input parameters, same 10 output columns
-- (names, order, and types unchanged), same SECURITY INVOKER, same
-- transaction-scoped advisory lock, same idempotent course/allocation
-- reuse, same stale→synced handling, same missing-settings safeguard
-- (unchanged — that logic lives in the TypeScript service, not this
-- function), same multi-tenant behaviour, same service_role-only grant.
-- No Iomad write occurs — this function only ever touches
-- courses/iomad_course_mappings/organisation_course_allocations, exactly
-- as before.

create or replace function sync_iomad_company_course(
  p_organisation_id uuid,
  p_iomad_course_id text,
  p_course_name text,
  p_licensed boolean,
  p_shared boolean,
  p_valid_length_days integer,
  p_warn_expire_days integer,
  p_warn_completion_days integer,
  p_notify_period_days integer
)
returns table (
  course_id uuid,
  course_name text,
  course_status text,
  mapping_id uuid,
  allocation_id uuid,
  was_course_created boolean,
  course_name_changed boolean,
  was_allocation_created boolean,
  allocation_settings_changed boolean,
  allocation_status_changed boolean
)
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_course_id uuid;
  v_mapping_id uuid;
  v_existing_course_name text;
  v_was_course_created boolean := false;
  v_course_name_changed boolean := false;

  v_allocation_id uuid;
  v_was_allocation_created boolean := false;
  v_settings_changed boolean := false;
  v_allocation_status_changed boolean := false;
  v_existing_licensed boolean;
  v_existing_shared boolean;
  v_existing_valid_length integer;
  v_existing_warn_expire integer;
  v_existing_warn_completion integer;
  v_existing_notify_period integer;
  v_existing_sync_status text;
begin
  if p_organisation_id is null then
    raise exception 'organisation_id_required';
  end if;
  if p_iomad_course_id is null or length(trim(p_iomad_course_id)) = 0 then
    raise exception 'iomad_course_id_required';
  end if;
  if p_course_name is null or length(trim(p_course_name)) = 0 then
    raise exception 'course_name_required';
  end if;

  perform pg_advisory_xact_lock(hashtext('sync_iomad_company_course:' || p_iomad_course_id));

  select m.course_id, m.id, c.name
    into v_course_id, v_mapping_id, v_existing_course_name
  from iomad_course_mappings m
  join courses c on c.id = m.course_id
  where m.iomad_course_id = p_iomad_course_id
  for update of m;

  if v_mapping_id is null then
    -- Never seen before — create both rows in this one transaction.
    insert into courses (name, status)
    values (p_course_name, 'active')
    returning id into v_course_id;

    insert into iomad_course_mappings (course_id, iomad_course_id, sync_status, last_synced_at, last_error_code)
    values (v_course_id, p_iomad_course_id, 'synced', now(), null)
    returning id into v_mapping_id;

    v_was_course_created := true;
  else
    -- Already known — update the name only if it actually changed, and
    -- mark the mapping synced either way, in the same transaction.
    -- Aliased defensively (see file header) even though `id`/`name`
    -- don't collide with any RETURNS TABLE output name today.
    if v_existing_course_name is distinct from p_course_name then
      update courses c
        set name = p_course_name
        where c.id = v_course_id;
      v_course_name_changed := true;
    end if;

    update iomad_course_mappings m
      set sync_status = 'synced', last_synced_at = now(), last_error_code = null
      where m.id = v_mapping_id;
  end if;

  -- Allocation upsert, scoped to (p_organisation_id, v_course_id). The
  -- SAME course allocated to a different organisation is an entirely
  -- separate row here — this select/branch only ever looks at this one
  -- organisation's allocation for this one course.
  --
  -- HOTFIX: `organisation_course_allocations` is now aliased `oca`, and
  -- every column in this SELECT (including `course_id`, the one that
  -- actually caused the live "column reference ... is ambiguous" error)
  -- is explicitly qualified with it.
  select oca.id, oca.licensed, oca.shared, oca.valid_length_days,
         oca.warn_expire_days, oca.warn_completion_days, oca.notify_period_days, oca.sync_status
    into v_allocation_id, v_existing_licensed, v_existing_shared,
         v_existing_valid_length, v_existing_warn_expire, v_existing_warn_completion, v_existing_notify_period,
         v_existing_sync_status
  from organisation_course_allocations oca
  where oca.organisation_id = p_organisation_id
    and oca.course_id = v_course_id
  for update;

  if v_allocation_id is null then
    insert into organisation_course_allocations (
      organisation_id, course_id, licensed, shared,
      valid_length_days, warn_expire_days, warn_completion_days, notify_period_days,
      sync_status, last_synced_at
    ) values (
      p_organisation_id, v_course_id, p_licensed, p_shared,
      p_valid_length_days, p_warn_expire_days, p_warn_completion_days, p_notify_period_days,
      'synced', now()
    )
    returning id into v_allocation_id;

    v_was_allocation_created := true;
  else
    v_settings_changed :=
      v_existing_licensed is distinct from p_licensed
      or v_existing_shared is distinct from p_shared
      or v_existing_valid_length is distinct from p_valid_length_days
      or v_existing_warn_expire is distinct from p_warn_expire_days
      or v_existing_warn_completion is distinct from p_warn_completion_days
      or v_existing_notify_period is distinct from p_notify_period_days;

    -- F5B review fix #2 (unchanged by this hotfix): a status transition
    -- (e.g. 'stale' or 'failed' back to 'synced') is itself a meaningful
    -- change, independent of whether the settings VALUES changed.
    v_allocation_status_changed := v_existing_sync_status is distinct from 'synced';

    update organisation_course_allocations oca
      set licensed = p_licensed,
          shared = p_shared,
          valid_length_days = p_valid_length_days,
          warn_expire_days = p_warn_expire_days,
          warn_completion_days = p_warn_completion_days,
          notify_period_days = p_notify_period_days,
          sync_status = 'synced',
          last_synced_at = now(),
          last_error_code = null
      where oca.id = v_allocation_id;
  end if;

  return query
    select
      c.id, c.name, c.status, m.id, a.id,
      v_was_course_created, v_course_name_changed, v_was_allocation_created, v_settings_changed,
      v_allocation_status_changed
    from courses c
    join iomad_course_mappings m on m.course_id = c.id
    join organisation_course_allocations a on a.course_id = c.id and a.organisation_id = p_organisation_id
    where c.id = v_course_id;
end;
$$;

-- CREATE OR REPLACE FUNCTION preserves existing privileges automatically
-- (only DROP + CREATE would reset them) — these statements are included
-- anyway, redundantly but harmlessly, so this migration is self-contained
-- and does not rely on that assumption. Identical to 0016's grants.
revoke all on function sync_iomad_company_course(
  uuid, text, text, boolean, boolean, integer, integer, integer, integer
) from public;
grant execute on function sync_iomad_company_course(
  uuid, text, text, boolean, boolean, integer, integer, integer, integer
) to service_role;

comment on function sync_iomad_company_course(
  uuid, text, text, boolean, boolean, integer, integer, integer, integer
) is
  'F5B, hotfixed in 0017 — atomic find-or-create course+mapping, rename,
   and upsert-allocation-with-settings for ONE course and ONE
   organisation. See 0016''s original header comment for the full
   rationale (atomicity, concurrency, SECURITY INVOKER justification) and
   0017''s header comment for the column-ambiguity hotfix
   (organisation_course_allocations now aliased ''oca'' everywhere it is
   referenced, fixing a live "column reference course_id is ambiguous"
   runtime error). Signature and returned columns unchanged from 0016.
   Server-side/service-role only — not granted to anon or authenticated.
   No Iomad write occurs.';
