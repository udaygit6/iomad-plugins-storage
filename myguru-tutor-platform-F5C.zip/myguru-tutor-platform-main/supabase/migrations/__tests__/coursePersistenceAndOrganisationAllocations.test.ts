import { describe, it, expect } from 'vitest';
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { stripSqlComments, containsNormalized } from './sqlTestHelpers';

const MIGRATIONS_DIR = join(__dirname, '..');

function read(filename: string): string {
  return readFileSync(join(MIGRATIONS_DIR, filename), 'utf-8');
}

const sql = read('0016_course_persistence_and_organisation_allocations.sql');

describe('0016 — courses / iomad_course_mappings / organisation_course_allocations schema', () => {
  it('creates all three tables with UUID primary keys', () => {
    expect(containsNormalized(sql, 'create table courses (')).toBe(true);
    expect(containsNormalized(sql, 'create table iomad_course_mappings (')).toBe(true);
    expect(containsNormalized(sql, 'create table organisation_course_allocations (')).toBe(true);
    expect(sql.match(/id uuid primary key default gen_random_uuid\(\)/g)?.length).toBe(3);
  });

  it('courses has a status check constraint and no direct iomad_course_id column (kept in the mapping table)', () => {
    expect(containsNormalized(sql, "check (status in ('active', 'inactive'))")).toBe(true);
    const stripped = stripSqlComments(sql);
    const coursesBlock = stripped.slice(stripped.indexOf('create table courses ('), stripped.indexOf('create trigger courses_set_updated_at'));
    expect(coursesBlock).not.toMatch(/iomad_course_id/);
  });

  it('iomad_course_mappings uses iomad_course_id (text) as the unique external identity key, and course_id is unique (one mapping per course)', () => {
    expect(containsNormalized(sql, "iomad_course_id text not null unique check (iomad_course_id <> '')")).toBe(true);
    expect(containsNormalized(sql, 'course_id uuid not null unique references courses(id) on delete cascade')).toBe(true);
  });

  it('iomad_course_mappings has a sync_status check constraint including stale (never plain delete)', () => {
    const stripped = stripSqlComments(sql);
    const mappingBlock = stripped.slice(
      stripped.indexOf('create table iomad_course_mappings'),
      stripped.indexOf('create trigger iomad_course_mappings_set_updated_at'),
    );
    expect(mappingBlock).toContain("check (sync_status in ('pending', 'synced', 'failed', 'stale'))");
  });

  it('organisation_course_allocations has the F5A-live-verified settings columns with correct defaults', () => {
    const stripped = stripSqlComments(sql);
    const allocBlock = stripped.slice(
      stripped.indexOf('create table organisation_course_allocations'),
      stripped.indexOf('create trigger organisation_course_allocations_set_updated_at'),
    );
    expect(allocBlock).toContain('licensed boolean not null default false');
    expect(allocBlock).toContain('shared boolean not null default false');
    expect(allocBlock).toContain('valid_length_days integer not null default 0');
    expect(allocBlock).toContain('warn_expire_days integer not null default 0');
    expect(allocBlock).toContain('warn_completion_days integer not null default 0');
    expect(allocBlock).toContain('notify_period_days integer not null default 0');
  });

  it('review fix #3: the four day-count settings columns all have non-negative CHECK constraints', () => {
    const stripped = stripSqlComments(sql);
    const allocBlock = stripped.slice(
      stripped.indexOf('create table organisation_course_allocations'),
      stripped.indexOf('create trigger organisation_course_allocations_set_updated_at'),
    );
    expect(allocBlock).toContain('check (valid_length_days >= 0)');
    expect(allocBlock).toContain('check (warn_expire_days >= 0)');
    expect(allocBlock).toContain('check (warn_completion_days >= 0)');
    expect(allocBlock).toContain('check (notify_period_days >= 0)');
  });

  it('review fix #3: no upper limit was invented for any of the day-count columns', () => {
    const stripped = stripSqlComments(sql);
    const allocBlock = stripped.slice(
      stripped.indexOf('create table organisation_course_allocations'),
      stripped.indexOf('create trigger organisation_course_allocations_set_updated_at'),
    );
    expect(allocBlock).not.toMatch(/<=\s*\d/); // no "column <= N" upper-bound check anywhere in this table
  });

  it('organisation_course_allocations has a unique constraint on (organisation_id, course_id)', () => {
    expect(containsNormalized(sql, 'unique (organisation_id, course_id)')).toBe(true);
  });

  it('organisation_course_allocations references organisations(id) and courses(id) with cascade delete', () => {
    expect(containsNormalized(sql, 'organisation_id uuid not null references organisations(id) on delete cascade')).toBe(
      true,
    );
    expect(containsNormalized(sql, 'course_id uuid not null references courses(id) on delete cascade')).toBe(true);
  });

  it('never uses email or name as an identity/lookup key on iomad_course_mappings', () => {
    const stripped = stripSqlComments(sql);
    const mappingBlock = stripped.slice(
      stripped.indexOf('create table iomad_course_mappings'),
      stripped.indexOf('create trigger iomad_course_mappings_set_updated_at'),
    );
    expect(mappingBlock).not.toMatch(/\bemail\b/i);
  });

  it('all three tables get an updated_at trigger reusing the existing set_updated_at() helper', () => {
    expect(containsNormalized(sql, 'create trigger courses_set_updated_at')).toBe(true);
    expect(containsNormalized(sql, 'create trigger iomad_course_mappings_set_updated_at')).toBe(true);
    expect(containsNormalized(sql, 'create trigger organisation_course_allocations_set_updated_at')).toBe(true);
    expect(sql.match(/execute function set_updated_at\(\);/g)?.length).toBe(3);
  });

  it('has indexes on status/organisation/course columns', () => {
    expect(containsNormalized(sql, 'create index idx_courses_status on courses (status)')).toBe(true);
    expect(
      containsNormalized(sql, 'create index idx_iomad_course_mappings_sync_status on iomad_course_mappings (sync_status)'),
    ).toBe(true);
    expect(
      containsNormalized(
        sql,
        'create index idx_org_course_allocations_organisation on organisation_course_allocations (organisation_id)',
      ),
    ).toBe(true);
    expect(
      containsNormalized(sql, 'create index idx_org_course_allocations_course on organisation_course_allocations (course_id)'),
    ).toBe(true);
    expect(
      containsNormalized(sql, 'create index idx_org_course_allocations_status on organisation_course_allocations (sync_status)'),
    ).toBe(true);
  });
});

describe('0016 — RLS', () => {
  it('enables row level security on all three new tables', () => {
    expect(containsNormalized(sql, 'alter table courses enable row level security')).toBe(true);
    expect(containsNormalized(sql, 'alter table iomad_course_mappings enable row level security')).toBe(true);
    expect(containsNormalized(sql, 'alter table organisation_course_allocations enable row level security')).toBe(true);
  });

  it('grants admin READ ONLY via is_admin() on all three tables', () => {
    expect(containsNormalized(sql, 'create policy courses_admin_read on courses')).toBe(true);
    expect(containsNormalized(sql, 'create policy iomad_course_mappings_admin_read on iomad_course_mappings')).toBe(true);
    expect(
      containsNormalized(
        sql,
        'create policy organisation_course_allocations_admin_read on organisation_course_allocations',
      ),
    ).toBe(true);
    const stripped = stripSqlComments(sql);
    const policyForClauses = [...stripped.matchAll(/create policy[\s\S]*?\bfor\s+(\w+)/gi)].map((m) => m[1].toLowerCase());
    expect(policyForClauses.length).toBe(3);
    expect(policyForClauses.every((clause) => clause === 'select')).toBe(true);
  });

  it('does not grant anything to the anon role', () => {
    const stripped = stripSqlComments(sql);
    expect(stripped).not.toMatch(/\bgrant\b[^;]*\bto\s+anon\b/i);
  });
});

describe('0016 — sync_iomad_company_course() atomic RPC', () => {
  it('defines the function with all nine parameters and the full flattened return row', () => {
    expect(containsNormalized(sql, 'create or replace function sync_iomad_company_course(')).toBe(true);
    for (const param of [
      'p_organisation_id uuid,',
      'p_iomad_course_id text,',
      'p_course_name text,',
      'p_licensed boolean,',
      'p_shared boolean,',
      'p_valid_length_days integer,',
      'p_warn_expire_days integer,',
      'p_warn_completion_days integer,',
      'p_notify_period_days integer',
    ]) {
      expect(containsNormalized(sql, param)).toBe(true);
    }
    expect(containsNormalized(sql, 'was_course_created boolean,')).toBe(true);
    expect(containsNormalized(sql, 'was_allocation_created boolean,')).toBe(true);
    expect(containsNormalized(sql, 'allocation_settings_changed boolean,')).toBe(true);
    expect(containsNormalized(sql, 'allocation_status_changed boolean')).toBe(true);
  });

  it('is SECURITY INVOKER, not SECURITY DEFINER, with an explicit justification comment', () => {
    const stripped = stripSqlComments(sql);
    const fnStart = stripped.indexOf('create or replace function sync_iomad_company_course(');
    const fnBody = stripped.slice(fnStart, stripped.indexOf('$$;', fnStart) + 3);
    expect(fnBody).toContain('security invoker');
    expect(fnBody).not.toContain('security definer');
    expect(sql).toContain('SECURITY INVOKER, not DEFINER — same justification as');
  });

  it('sets search_path explicitly', () => {
    const occurrences = [...sql.matchAll(/set search_path = public/g)];
    expect(occurrences.length).toBeGreaterThanOrEqual(2); // both RPCs
  });

  it('serializes concurrent calls for the same course via a transaction-scoped advisory lock', () => {
    expect(sql).toContain("pg_advisory_xact_lock(hashtext('sync_iomad_company_course:' || p_iomad_course_id))");
  });

  it('locks the existing mapping row before deciding create vs. update (idempotent-under-concurrency)', () => {
    expect(containsNormalized(sql, 'for update of m')).toBe(true);
  });

  it('locks the existing allocation row before deciding create vs. update', () => {
    const stripped = stripSqlComments(sql);
    const fnStart = stripped.indexOf('create or replace function sync_iomad_company_course(');
    const fnBody = stripped.slice(fnStart, stripped.indexOf('$$;', fnStart) + 3);
    expect(fnBody).toMatch(/where organisation_id = p_organisation_id and course_id = v_course_id\s+for update/);
  });

  it('only updates the course name / allocation settings when they actually differ (is distinct from checks)', () => {
    expect(containsNormalized(sql, 'if v_existing_course_name is distinct from p_course_name then')).toBe(true);
    expect(sql).toContain('v_existing_licensed is distinct from p_licensed');
  });

  it("review fix #2: captures the allocation's previous sync_status and reports allocation_status_changed when it transitions back to synced", () => {
    expect(containsNormalized(sql, 'valid_length_days, warn_expire_days, warn_completion_days, notify_period_days, sync_status')).toBe(
      true,
    );
    expect(sql).toContain("v_allocation_status_changed := v_existing_sync_status is distinct from 'synced'");
  });

  it('review fix #2: allocation_status_changed is only ever computed on the EXISTING-allocation branch, never assumed true/false blindly on create', () => {
    const stripped = stripSqlComments(sql);
    const fnStart = stripped.indexOf('create or replace function sync_iomad_company_course(');
    const fnBody = stripped.slice(fnStart, stripped.indexOf('$$;', fnStart) + 3);
    // Declared false by default, only flipped inside the "else" (existing
    // allocation) branch — never set inside the "if v_allocation_id is
    // null" (newly-created) branch.
    expect(fnBody).toContain('v_allocation_status_changed boolean := false;');
    const createBranch = fnBody.slice(
      fnBody.indexOf('if v_allocation_id is null then'),
      fnBody.indexOf('v_was_allocation_created := true;') + 'v_was_allocation_created := true;'.length,
    );
    expect(createBranch).not.toContain('v_allocation_status_changed');
  });

  it('rejects empty/blank/null required inputs rather than silently writing incomplete rows', () => {
    expect(containsNormalized(sql, "raise exception 'organisation_id_required'")).toBe(true);
    expect(containsNormalized(sql, "raise exception 'iomad_course_id_required'")).toBe(true);
    expect(containsNormalized(sql, "raise exception 'course_name_required'")).toBe(true);
  });

  it('is revoked from PUBLIC and granted only to service_role', () => {
    expect(sql).toMatch(/revoke all on function sync_iomad_company_course\(/);
    expect(sql).toMatch(/grant execute on function sync_iomad_company_course\([\s\S]*?\) to service_role/);
    // Only check the actual `grant execute` statements, not prose
    // elsewhere (e.g. a comment legitimately saying "not granted to
    // anon or authenticated").
    const grantStatements = sql.match(/grant execute on function sync_iomad_company_course\([\s\S]*?;/g) ?? [];
    expect(grantStatements.length).toBeGreaterThan(0);
    for (const statement of grantStatements) {
      expect(statement).not.toMatch(/to\s+(anon|authenticated)\b/i);
    }
  });

  it('the RPC never references any Iomad write function or an Iomad HTTP call', () => {
    const stripped = stripSqlComments(sql);
    const fnStart = stripped.indexOf('create or replace function sync_iomad_company_course(');
    const fnEnd = stripped.indexOf('$$;', fnStart) + 3;
    const fnBody = stripped.slice(fnStart, fnEnd);
    expect(fnBody).not.toMatch(/block_iomad_company_admin_/);
    expect(fnBody).not.toMatch(/http|fetch|webservice/i);
  });
});

describe('0016 — mark_stale_organisation_course_allocations() RPC', () => {
  it('defines the function with organisation_id and seen-ids array parameters', () => {
    expect(containsNormalized(sql, 'create or replace function mark_stale_organisation_course_allocations(')).toBe(true);
    expect(containsNormalized(sql, 'p_organisation_id uuid,')).toBe(true);
    expect(containsNormalized(sql, 'p_seen_iomad_course_ids text[]')).toBe(true);
  });

  it('only ever sets sync_status to stale — never deletes a row', () => {
    const stripped = stripSqlComments(sql);
    const fnStart = stripped.indexOf('create or replace function mark_stale_organisation_course_allocations(');
    const fnEnd = stripped.indexOf('$$;', fnStart) + 3;
    const fnBody = stripped.slice(fnStart, fnEnd);
    expect(fnBody).toContain("set sync_status = 'stale'");
    expect(fnBody).not.toMatch(/delete\s+from/i);
  });

  it("scopes the update to the given organisation_id only — never touches another organisation's allocations", () => {
    expect(containsNormalized(sql, 'a.organisation_id = p_organisation_id')).toBe(true);
  });

  it('is revoked from PUBLIC and granted only to service_role', () => {
    expect(sql).toMatch(/revoke all on function mark_stale_organisation_course_allocations\(/);
    expect(sql).toMatch(/grant execute on function mark_stale_organisation_course_allocations\([\s\S]*?\) to service_role/);
  });
});

describe('0016 — does not touch existing migrations', () => {
  it('0001-0015 all still exist on disk, unmodified by this task (only 0016 was added)', () => {
    const expected = [
      '0001_extensions_and_helpers.sql',
      '0002_catalogue.sql',
      '0003_tutor_applications.sql',
      '0004_tutor_profiles.sql',
      '0005_tutor_verifications.sql',
      '0006_parent_student_matching.sql',
      '0007_enquiries.sql',
      '0008_admin_profiles.sql',
      '0009_row_level_security.sql',
      '0010_integration_jobs.sql',
      '0011_rate_limit_events.sql',
      '0012_public_submission_functions.sql',
      '0013_fix_tutor_application_slug_aliases.sql',
      '0014_tutor_profile_creation.sql',
      '0015_organisation_iomad_company_sync.sql',
    ];
    for (const filename of expected) {
      expect(() => read(filename)).not.toThrow();
    }
  });

  it('0016 references organisations(id) but does not alter, drop, or redefine any table from 0001-0015', () => {
    const stripped = stripSqlComments(sql).toLowerCase();
    const priorTables = [
      'admin_profiles',
      'integration_jobs',
      'tutor_profiles',
      'tutor_applications',
      'enquiries',
      'matching_requests',
      'students',
      'parent_contacts',
      'subjects',
      'education_levels',
      'tutor_verifications',
      'rate_limit_events',
      'iomad_company_mappings',
    ];
    for (const table of priorTables) {
      expect(stripped).not.toMatch(new RegExp(`alter table ${table}\\b`));
      expect(stripped).not.toMatch(new RegExp(`drop table[^;]*\\b${table}\\b`));
    }
    // organisations IS referenced (a foreign key), but never altered/dropped/redefined.
    expect(stripped).not.toMatch(/alter table organisations\b/);
    expect(stripped).not.toMatch(/drop table[^;]*\borganisations\b/);
    expect(stripped).not.toMatch(/create table organisations\b/);
  });

  it('the migrations directory contains at least the 16 numbered .sql files through 0016 (0017+ may exist from later phases)', () => {
    const files = readdirSync(MIGRATIONS_DIR).filter((f) => /^\d{4}_.*\.sql$/.test(f));
    expect(files.length).toBeGreaterThanOrEqual(16);
    expect(files).toContain('0016_course_persistence_and_organisation_allocations.sql');
  });
});
