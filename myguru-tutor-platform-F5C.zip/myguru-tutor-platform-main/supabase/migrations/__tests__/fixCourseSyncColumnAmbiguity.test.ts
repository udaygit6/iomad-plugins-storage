import { describe, it, expect } from 'vitest';
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { stripSqlComments, containsNormalized } from './sqlTestHelpers';

const MIGRATIONS_DIR = join(__dirname, '..');

function read(filename: string): string {
  return readFileSync(join(MIGRATIONS_DIR, filename), 'utf-8');
}

const sql017 = read('0017_fix_course_sync_column_ambiguity.sql');
const sql016 = read('0016_course_persistence_and_organisation_allocations.sql');

function fnBody(sql: string, fnStart: string): string {
  const start = sql.indexOf(fnStart);
  expect(start).toBeGreaterThan(-1);
  return sql.slice(start, sql.indexOf('$$;', start) + 3);
}

describe('0017 — exists as a new, forward-only migration', () => {
  it('migration 0017 exists on disk', () => {
    expect(() => read('0017_fix_course_sync_column_ambiguity.sql')).not.toThrow();
  });

  it('the migrations directory contains 0017 alongside 0001-0016 (17 files total)', () => {
    const files = readdirSync(MIGRATIONS_DIR).filter((f) => /^\d{4}_.*\.sql$/.test(f));
    expect(files.length).toBe(17);
    expect(files).toContain('0016_course_persistence_and_organisation_allocations.sql');
    expect(files).toContain('0017_fix_course_sync_column_ambiguity.sql');
  });

  it('0017 uses CREATE OR REPLACE FUNCTION (a forward fix), not a DROP or a rewrite of 0016', () => {
    expect(containsNormalized(sql017, 'create or replace function sync_iomad_company_course(')).toBe(true);
    expect(stripSqlComments(sql017).toLowerCase()).not.toMatch(/drop function/);
    expect(stripSqlComments(sql017).toLowerCase()).not.toMatch(/drop table/);
  });
});

describe('0017 — migration 0016 remains completely untouched', () => {
  it('0016 still exists on disk with its own original function definition', () => {
    expect(containsNormalized(sql016, 'create or replace function sync_iomad_company_course(')).toBe(true);
    expect(containsNormalized(sql016, 'create table courses (')).toBe(true);
    expect(containsNormalized(sql016, 'create table iomad_course_mappings (')).toBe(true);
    expect(containsNormalized(sql016, 'create table organisation_course_allocations (')).toBe(true);
  });

  it("0017 contains no ALTER/DROP statement referencing 0016's tables — it only replaces the one function", () => {
    const stripped = stripSqlComments(sql017).toLowerCase();
    for (const table of ['courses', 'iomad_course_mappings', 'organisation_course_allocations']) {
      expect(stripped).not.toMatch(new RegExp(`alter table ${table}\\b`));
      expect(stripped).not.toMatch(new RegExp(`drop table[^;]*\\b${table}\\b`));
    }
  });

  it('0017 does not redefine mark_stale_organisation_course_allocations() — only sync_iomad_company_course() is touched', () => {
    expect(stripSqlComments(sql017)).not.toMatch(/create (or replace )?function mark_stale_organisation_course_allocations/);
  });
});

describe('0017 — the reported ambiguity is fixed', () => {
  it('the previously-bare allocation lookup now aliases organisation_course_allocations as oca, with organisation_id and course_id both qualified', () => {
    expect(containsNormalized(sql017, 'from organisation_course_allocations oca')).toBe(true);
    expect(containsNormalized(sql017, 'where oca.organisation_id = p_organisation_id')).toBe(true);
    expect(containsNormalized(sql017, 'and oca.course_id = v_course_id')).toBe(true);
  });

  it('the allocation lookup SELECT qualifies every selected column with oca.', () => {
    const stripped = stripSqlComments(sql017);
    const selectStart = stripped.indexOf('select oca.id, oca.licensed');
    expect(selectStart).toBeGreaterThan(-1);
    const selectClause = stripped.slice(selectStart, stripped.indexOf('into v_allocation_id', selectStart));
    for (const column of [
      'id',
      'licensed',
      'shared',
      'valid_length_days',
      'warn_expire_days',
      'warn_completion_days',
      'notify_period_days',
      'sync_status',
    ]) {
      expect(selectClause).toContain(`oca.${column}`);
    }
  });

  it('the allocation UPDATE also aliases organisation_course_allocations as oca and qualifies its WHERE clause', () => {
    expect(containsNormalized(sql017, 'update organisation_course_allocations oca')).toBe(true);
    expect(containsNormalized(sql017, 'where oca.id = v_allocation_id')).toBe(true);
  });

  it('no executable SQL in 0017\'s function uses the ambiguous bare form "course_id = v_course_id" (unqualified by a table alias)', () => {
    const body = fnBody(sql017, 'create or replace function sync_iomad_company_course(');
    // A bare, unaliased reference would read literally "course_id = v_course_id" with a
    // word boundary immediately before "course_id" (i.e. NOT preceded by
    // "oca." or "a." or "m." etc.). This regex fails the test if such a
    // bare form is found anywhere in the function body.
    expect(body).not.toMatch(/(?<![.\w])course_id\s*=\s*v_course_id/);
    // Positive control: the fixed, qualified form must be present.
    expect(body).toContain('oca.course_id = v_course_id');
  });

  it('the courses and iomad_course_mappings single-table UPDATEs are also defensively aliased (c / m) and their WHERE clauses qualified', () => {
    expect(containsNormalized(sql017, 'update courses c')).toBe(true);
    expect(containsNormalized(sql017, 'where c.id = v_course_id')).toBe(true);
    expect(containsNormalized(sql017, 'update iomad_course_mappings m')).toBe(true);
    expect(containsNormalized(sql017, 'where m.id = v_mapping_id')).toBe(true);
  });
});

describe('0017 — preserved behaviour and security', () => {
  it('SECURITY INVOKER is preserved (not DEFINER)', () => {
    const body = fnBody(sql017, 'create or replace function sync_iomad_company_course(');
    expect(body).toContain('security invoker');
    expect(body).not.toContain('security definer');
  });

  it('the transaction-scoped advisory lock is preserved unchanged', () => {
    expect(sql017).toContain("pg_advisory_xact_lock(hashtext('sync_iomad_company_course:' || p_iomad_course_id))");
  });

  it('is revoked from PUBLIC and granted only to service_role', () => {
    const grantStatements = sql017.match(/grant execute on function sync_iomad_company_course\([\s\S]*?;/g) ?? [];
    expect(grantStatements.length).toBeGreaterThan(0);
    for (const statement of grantStatements) {
      expect(statement).toContain('to service_role');
      expect(statement).not.toMatch(/to\s+(anon|authenticated)\b/i);
    }
    expect(sql017).toMatch(/revoke all on function sync_iomad_company_course\(/);
  });

  it('idempotent course reuse is preserved: existing mapping branch does not re-insert', () => {
    const body = fnBody(sql017, 'create or replace function sync_iomad_company_course(');
    expect(body).toContain('if v_mapping_id is null then');
    expect(body).toContain('v_was_course_created := true;');
  });

  it('organisation allocation reuse is preserved: existing allocation branch does not re-insert', () => {
    const body = fnBody(sql017, 'create or replace function sync_iomad_company_course(');
    expect(body).toContain('if v_allocation_id is null then');
    expect(body).toContain('v_was_allocation_created := true;');
  });

  it('stale -> synced handling (allocation_status_changed) is preserved unchanged', () => {
    expect(sql017).toContain("v_allocation_status_changed := v_existing_sync_status is distinct from 'synced'");
  });

  it('no Iomad write occurs — the function never references an Iomad function or makes an HTTP call', () => {
    const body = fnBody(sql017, 'create or replace function sync_iomad_company_course(');
    expect(body).not.toMatch(/block_iomad_company_admin_/);
    expect(body).not.toMatch(/http|fetch|webservice/i);
  });

  it('multi-tenant behaviour is preserved: the allocation is scoped by (organisation_id, course_id), not by course alone', () => {
    expect(containsNormalized(sql017, 'unique (organisation_id, course_id)')).toBe(false); // that constraint lives in 0016's table DDL, not here
    expect(containsNormalized(sql017, 'oca.organisation_id = p_organisation_id')).toBe(true);
    expect(containsNormalized(sql017, 'oca.course_id = v_course_id')).toBe(true);
  });
});

describe('0017 — function signature and returned columns are unchanged from 0016', () => {
  const paramList =
    'p_organisation_id uuid, p_iomad_course_id text, p_course_name text, p_licensed boolean, p_shared boolean, p_valid_length_days integer, p_warn_expire_days integer, p_warn_completion_days integer, p_notify_period_days integer';

  it('the 9-parameter input signature is identical between 0016 and 0017', () => {
    expect(containsNormalized(sql016, paramList)).toBe(true);
    expect(containsNormalized(sql017, paramList)).toBe(true);
  });

  it('the 10-column RETURNS TABLE shape is identical between 0016 and 0017', () => {
    const returnList =
      'course_id uuid, course_name text, course_status text, mapping_id uuid, allocation_id uuid, was_course_created boolean, course_name_changed boolean, was_allocation_created boolean, allocation_settings_changed boolean, allocation_status_changed boolean';
    expect(containsNormalized(sql016, returnList)).toBe(true);
    expect(containsNormalized(sql017, returnList)).toBe(true);
  });

  it('the revoke/grant reference the exact same 9-type signature in both migrations', () => {
    const signatureTypes = 'uuid, text, text, boolean, boolean, integer, integer, integer, integer';
    expect(containsNormalized(sql016, `grant execute on function sync_iomad_company_course( ${signatureTypes}`)).toBe(
      true,
    );
    expect(containsNormalized(sql017, `grant execute on function sync_iomad_company_course( ${signatureTypes}`)).toBe(
      true,
    );
  });
});

describe('0017 — does not touch anything else', () => {
  it('0001-0016 all still exist on disk, unmodified by this task (only 0017 was added)', () => {
    const expected = [
      '0001_extensions_and_helpers.sql',
      '0002_catalogue.sql',
      '0003_tutor_applications.sql',
      '0004_tutor_profiles.sql',
      '0005_tutor_verifications.sql',
      '0006_parent_student_matching.sql',
      '0007_enquiries.sql',
      '0008_admin_profiles.sql',
      '0009_row_level_security.sql',
      '0010_integration_jobs.sql',
      '0011_rate_limit_events.sql',
      '0012_public_submission_functions.sql',
      '0013_fix_tutor_application_slug_aliases.sql',
      '0014_tutor_profile_creation.sql',
      '0015_organisation_iomad_company_sync.sql',
      '0016_course_persistence_and_organisation_allocations.sql',
    ];
    for (const filename of expected) {
      expect(() => read(filename)).not.toThrow();
    }
  });

  it('0017 does not add any new table, and does not grant anything to anon', () => {
    const stripped = stripSqlComments(sql017).toLowerCase();
    expect(stripped).not.toMatch(/create table/);
    expect(stripped).not.toMatch(/\bgrant\b[^;]*\bto\s+anon\b/i);
  });
});
