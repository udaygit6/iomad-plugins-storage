import { describe, it, expect } from 'vitest';
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { stripSqlComments, containsNormalized } from './sqlTestHelpers';

const MIGRATIONS_DIR = join(__dirname, '..');

function read(filename: string): string {
  return readFileSync(join(MIGRATIONS_DIR, filename), 'utf-8');
}

const sql = read('0015_organisation_iomad_company_sync.sql');

describe('0015 — organisations + iomad_company_mappings schema', () => {
  it('creates both tables with UUID primary keys', () => {
    expect(containsNormalized(sql, 'create table organisations (')).toBe(true);
    expect(containsNormalized(sql, 'create table iomad_company_mappings (')).toBe(true);
    expect(containsNormalized(sql, 'id uuid primary key default gen_random_uuid()')).toBe(true);
  });

  it('organisations has type/status/source check constraints, with unclassified as the default and first-listed type', () => {
    expect(
      containsNormalized(
        sql,
        "check (type in ('unclassified', 'myguru_franchise', 'corporate', 'school_future', 'internal'))",
      ),
    ).toBe(true);
    expect(containsNormalized(sql, "type text not null default 'unclassified'")).toBe(true);
    expect(containsNormalized(sql, "check (status in ('active', 'suspended', 'inactive'))")).toBe(true);
    expect(containsNormalized(sql, "check (source in ('iomad_sync', 'manual'))")).toBe(true);
  });

  it('iomad_company_mappings uses iomad_company_id as the unique external identity key', () => {
    expect(containsNormalized(sql, "iomad_company_id text not null unique check (iomad_company_id <> '')")).toBe(true);
  });

  it('iomad_company_mappings.organisation_id is unique (one mapping per organisation)', () => {
    expect(containsNormalized(sql, 'organisation_id uuid not null unique references organisations(id) on delete cascade')).toBe(
      true,
    );
  });

  it('iomad_company_mappings has a sync_status check constraint including stale (never plain delete)', () => {
    expect(containsNormalized(sql, "check (sync_status in ('pending', 'synced', 'failed', 'stale'))")).toBe(true);
  });

  it('never uses email or name as an identity/lookup key on iomad_company_mappings', () => {
    const stripped = stripSqlComments(sql);
    const mappingTableBlock = stripped.slice(
      stripped.indexOf('create table iomad_company_mappings'),
      stripped.indexOf('create trigger iomad_company_mappings_set_updated_at'),
    );
    expect(mappingTableBlock).not.toMatch(/\bemail\b/i);
  });

  it('both tables get an updated_at trigger reusing the existing set_updated_at() helper', () => {
    expect(containsNormalized(sql, 'create trigger organisations_set_updated_at')).toBe(true);
    expect(containsNormalized(sql, 'create trigger iomad_company_mappings_set_updated_at')).toBe(true);
    expect(sql).toContain('execute function set_updated_at();');
  });

  it('has indexes on organisations.status/type and iomad_company_mappings.sync_status', () => {
    expect(containsNormalized(sql, 'create index idx_organisations_status on organisations (status)')).toBe(true);
    expect(containsNormalized(sql, 'create index idx_organisations_type on organisations (type)')).toBe(true);
    expect(
      containsNormalized(sql, 'create index idx_iomad_company_mappings_sync_status on iomad_company_mappings (sync_status)'),
    ).toBe(true);
  });
});

describe('0015 — RLS', () => {
  it('enables row level security on both new tables', () => {
    expect(containsNormalized(sql, 'alter table organisations enable row level security')).toBe(true);
    expect(containsNormalized(sql, 'alter table iomad_company_mappings enable row level security')).toBe(true);
  });

  it('grants admin READ ONLY via is_admin() — not admin_all — on both tables', () => {
    expect(containsNormalized(sql, 'create policy organisations_admin_read on organisations')).toBe(true);
    expect(containsNormalized(sql, 'create policy iomad_company_mappings_admin_read on iomad_company_mappings')).toBe(true);
    expect(containsNormalized(sql, 'for select to authenticated')).toBe(true);
    expect(containsNormalized(sql, 'using (is_admin())')).toBe(true);
  });

  it('defines no insert/update/delete policy for anon or authenticated on either table', () => {
    const stripped = stripSqlComments(sql);
    // Only "for select" policies should exist anywhere in this file.
    const policyForClauses = [...stripped.matchAll(/create policy[\s\S]*?\bfor\s+(\w+)/gi)].map((m) => m[1].toLowerCase());
    expect(policyForClauses.length).toBeGreaterThan(0);
    expect(policyForClauses.every((clause) => clause === 'select')).toBe(true);
  });

  it('does not grant anything to the anon role', () => {
    const stripped = stripSqlComments(sql);
    // Checks actual GRANT statements only — prose describing what is NOT
    // granted (e.g. "not granted to anon or authenticated") legitimately
    // contains the substring "to anon" without being a grant.
    expect(stripped).not.toMatch(/\bgrant\b[^;]*\bto\s+anon\b/i);
  });
});

describe('0015 — sync_iomad_company() atomic RPC', () => {
  it('defines the function with both parameters and the full flattened return row', () => {
    expect(containsNormalized(sql, 'create or replace function sync_iomad_company(')).toBe(true);
    expect(containsNormalized(sql, 'p_iomad_company_id text,')).toBe(true);
    expect(containsNormalized(sql, 'p_display_name text')).toBe(true);
    expect(containsNormalized(sql, 'was_created boolean,')).toBe(true);
    expect(containsNormalized(sql, 'name_changed boolean')).toBe(true);
  });

  it('is SECURITY INVOKER, not SECURITY DEFINER, with an explicit justification comment', () => {
    const stripped = stripSqlComments(sql);
    const fnStart = stripped.indexOf('create or replace function sync_iomad_company(');
    const fnBody = stripped.slice(fnStart, stripped.indexOf('$$;', fnStart) + 3);
    expect(fnBody).toContain('security invoker');
    expect(fnBody).not.toContain('security definer');
    // The justification must actually be present in the file, not just implied.
    expect(sql).toContain('SECURITY INVOKER, not DEFINER');
  });

  it('sets search_path explicitly (same hardening as is_admin() in 0008)', () => {
    expect(containsNormalized(sql, 'set search_path = public')).toBe(true);
  });

  it('serializes concurrent calls for the same company via a transaction-scoped advisory lock', () => {
    expect(sql).toContain('pg_advisory_xact_lock(hashtext(');
  });

  it('locks the existing mapping row before deciding create vs. update (idempotent-under-concurrency, not just idempotent-when-sequential)', () => {
    expect(containsNormalized(sql, 'for update of m')).toBe(true);
  });

  it('always creates new organisations as unclassified inside the RPC, never inferring a type', () => {
    const stripped = stripSqlComments(sql);
    const insertBlock = stripped.slice(
      stripped.indexOf('insert into organisations (name, type, status, source)'),
      stripped.indexOf('returning id into v_organisation_id;'),
    );
    expect(insertBlock).toContain("'unclassified'");
    expect(insertBlock).not.toMatch(/myguru_franchise|corporate|school_future/);
  });

  it('only updates the organisation name when it actually differs (is distinct from check)', () => {
    expect(containsNormalized(sql, 'if v_existing_name is distinct from p_display_name then')).toBe(true);
  });

  it('rejects empty/blank required inputs rather than silently creating a blank-named organisation', () => {
    expect(containsNormalized(sql, 'raise exception')).toBe(true);
  });

  it('is revoked from PUBLIC and granted only to service_role — never callable by anon/authenticated', () => {
    expect(containsNormalized(sql, 'revoke all on function sync_iomad_company(text, text) from public')).toBe(true);
    expect(containsNormalized(sql, 'grant execute on function sync_iomad_company(text, text) to service_role')).toBe(
      true,
    );
    const stripped = stripSqlComments(sql);
    expect(stripped).not.toMatch(/grant execute on function sync_iomad_company[^;]*to\s+(anon|authenticated)/i);
  });

  it('the RPC never references any Iomad write function or an Iomad HTTP call — organisations/iomad_company_mappings only', () => {
    const stripped = stripSqlComments(sql);
    const fnStart = stripped.indexOf('create or replace function sync_iomad_company(');
    const fnEnd = stripped.indexOf('$$;', fnStart) + 3;
    const fnBody = stripped.slice(fnStart, fnEnd);
    expect(fnBody).not.toMatch(/block_iomad_company_admin_/);
    expect(fnBody).not.toMatch(/http|fetch|webservice/i);
  });
});

describe('0015 — does not touch existing migrations', () => {
  it('0001-0014 all still exist on disk, unmodified by this task (only 0015 was added)', () => {
    const expected = [
      '0001_extensions_and_helpers.sql',
      '0002_catalogue.sql',
      '0003_tutor_applications.sql',
      '0004_tutor_profiles.sql',
      '0005_tutor_verifications.sql',
      '0006_parent_student_matching.sql',
      '0007_enquiries.sql',
      '0008_admin_profiles.sql',
      '0009_row_level_security.sql',
      '0010_integration_jobs.sql',
      '0011_rate_limit_events.sql',
      '0012_public_submission_functions.sql',
      '0013_fix_tutor_application_slug_aliases.sql',
      '0014_tutor_profile_creation.sql',
    ];
    for (const filename of expected) {
      expect(() => read(filename)).not.toThrow();
    }
  });

  it('0010 (integration_jobs) still lists sync_company as a valid operation_type — F4 reuses it, does not replace it', () => {
    const integrationJobsSql = read('0010_integration_jobs.sql');
    expect(integrationJobsSql).toContain('sync_company');
  });

  it('0015 does not alter, drop, or redefine any table from 0001-0014', () => {
    const stripped = stripSqlComments(sql).toLowerCase();
    const priorTables = [
      'admin_profiles',
      'integration_jobs',
      'tutor_profiles',
      'tutor_applications',
      'enquiries',
      'matching_requests',
      'students',
      'parent_contacts',
      'subjects',
      'education_levels',
      'tutor_verifications',
      'rate_limit_events',
    ];
    for (const table of priorTables) {
      expect(stripped).not.toMatch(new RegExp(`alter table ${table}\\b`));
      expect(stripped).not.toMatch(new RegExp(`drop table[^;]*\\b${table}\\b`));
    }
  });

  it('the migrations directory contains at least the 15 numbered .sql files through 0015 (0016+ may exist from later phases)', () => {
    const files = readdirSync(MIGRATIONS_DIR).filter((f) => /^\d{4}_.*\.sql$/.test(f));
    expect(files.length).toBeGreaterThanOrEqual(15);
    expect(files).toContain('0015_organisation_iomad_company_sync.sql');
  });
});
