/**
 * Shared helpers for the SQL migration regression tests. Exist specifically
 * to make exact-sequence checks robust to how a file happens to be checked
 * out (CRLF vs LF) and to harmless re-wrapping/re-indentation of a SQL
 * statement's argument list — WITHOUT weakening what's actually being
 * proven. Every helper here still requires the exact token sequence to be
 * present; only insignificant whitespace (spacing, line breaks) is treated
 * as equivalent.
 */

/** Normalizes CRLF/CR line endings to LF. A `\r` left dangling at the end
 * of a naively `split('\n')`-ed line stops a `--.*$` comment-stripping
 * regex from reaching the true end of that line under JS regex semantics
 * (`.` doesn't match `\r`, and `$` without `/m` requires the absolute end
 * of the string) — normalizing first avoids that class of bug entirely. */
export function normalizeLineEndings(text: string): string {
  return text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
}

/** Strips `-- ...` line comments so pattern checks only see executable SQL,
 * not prose that legitimately discusses old parameter names, prior bugs,
 * etc. for documentation purposes. Line-ending-normalized first — see
 * normalizeLineEndings' doc comment for why that matters here specifically. */
export function stripSqlComments(text: string): string {
  return normalizeLineEndings(text)
    .split('\n')
    .map((line) => line.replace(/--.*$/, ''))
    .join('\n');
}

/**
 * Collapses insignificant whitespace so an exact-sequence check is robust
 * to CRLF vs LF and to a statement's argument list being wrapped across
 * multiple lines (e.g. a long REVOKE/GRANT signature reformatted after
 * deployment) — while still requiring every token, in order, to be
 * present. This is NOT a weakened substring check: reordering, omitting,
 * or changing a token still fails the comparison; only how much/what kind
 * of whitespace separates tokens is ignored, including whitespace
 * immediately inside parentheses (`( text` vs `(text`) and before commas.
 */
export function normalizeWhitespace(text: string): string {
  return normalizeLineEndings(text)
    .replace(/\s+/g, ' ')
    .replace(/\(\s+/g, '(')
    .replace(/\s+\)/g, ')')
    .replace(/\s+,/g, ',')
    .trim();
}

/** True if `haystack` contains `needle` as an exact token sequence, ignoring insignificant whitespace/line-ending differences in both. */
export function containsNormalized(haystack: string, needle: string): boolean {
  return normalizeWhitespace(haystack).includes(normalizeWhitespace(needle));
}
