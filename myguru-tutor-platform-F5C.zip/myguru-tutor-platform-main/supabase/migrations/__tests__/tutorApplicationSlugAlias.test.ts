import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { stripSqlComments, normalizeWhitespace, containsNormalized } from './sqlTestHelpers';

const MIGRATIONS_DIR = join(__dirname, '..');

function read(filename: string): string {
  return readFileSync(join(MIGRATIONS_DIR, filename), 'utf-8');
}

// Matches Postgres's ambiguous bare-alias pattern: `unnest(...) as slug`
// (or `as u(slug)` — naming the single derived column literally "slug"),
// which collides with any joined table's own `slug` column. This is
// exactly the pattern that caused the staging bug fixed in 0013.
const AMBIGUOUS_UNNEST_ALIAS = /unnest\([^)]*\)\s+as\s+(?:\w+\()?slug\b/i;

describe('0013 staging hotfix — ambiguous unnest(...) alias regression guard', () => {
  it('0013 no longer contains the ambiguous bare "slug" unnest alias in executable SQL', () => {
    const sql = stripSqlComments(read('0013_fix_tutor_application_slug_aliases.sql'));
    expect(sql).not.toMatch(AMBIGUOUS_UNNEST_ALIAS);
  });

  it('0013 uses explicit, non-colliding column aliases for both subject and education-level unnest calls', () => {
    const sql = read('0013_fix_tutor_application_slug_aliases.sql');
    expect(containsNormalized(sql, 'unnest(p_subject_slugs) as u(subject_slug)')).toBe(true);
    expect(containsNormalized(sql, 'unnest(p_education_level_slugs) as u(level_slug)')).toBe(true);
    // And every join/reference uses the qualified alias, not a bare "slug".
    expect(containsNormalized(sql, 's.slug = u.subject_slug')).toBe(true);
    expect(containsNormalized(sql, 'l.slug = u.level_slug')).toBe(true);
  });

  it('0013 preserves the function signature, SECURITY behaviour, and grants exactly (no redesign)', () => {
    // supabase/migrations/0013 is already deployed to staging and MUST NOT
    // be edited. The real deployed file wraps the REVOKE/GRANT argument
    // list across multiple lines (a cosmetic difference from how it was
    // first authored locally) — normalizeWhitespace makes this check
    // robust to that wrapping (and to CRLF vs LF) without weakening what
    // it actually proves: the exact 12-argument signature and exact grant
    // target must still be present, in order, unchanged.
    const sql = normalizeWhitespace(read('0013_fix_tutor_application_slug_aliases.sql'));
    expect(sql).toContain(normalizeWhitespace('create or replace function create_tutor_application('));
    expect(sql).toContain('returns uuid');
    expect(sql).toContain('language plpgsql');
    expect(sql).toContain('set search_path = public');
    expect(sql).toContain(
      normalizeWhitespace(
        'revoke execute on function create_tutor_application(text, text, text, text, text, text, text[], text[], text[], text, text, text) from public;',
      ),
    );
    expect(sql).toContain(
      normalizeWhitespace(
        'grant execute on function create_tutor_application(text, text, text, text, text, text, text[], text[], text[], text, text, text) to service_role;',
      ),
    );
  });

  it('0012 (already applied to staging) is left untouched — the bug is fixed forward, not by rewriting history', () => {
    const sql = read('0012_public_submission_functions.sql');
    // The original (buggy) pattern is still present in 0012 — confirming
    // this migration was not edited/rewritten, only superseded by 0013's
    // CREATE OR REPLACE.
    expect(sql).toMatch(AMBIGUOUS_UNNEST_ALIAS);
  });

  it('create_matching_request (0012) has no equivalent unnest ambiguity — it takes a single scalar slug, not an array', () => {
    const sql = read('0012_public_submission_functions.sql');
    const matchingRequestFn = sql.slice(sql.indexOf('function create_matching_request'), sql.indexOf('function create_tutor_application'));
    expect(matchingRequestFn).not.toContain('unnest(');
  });
});
