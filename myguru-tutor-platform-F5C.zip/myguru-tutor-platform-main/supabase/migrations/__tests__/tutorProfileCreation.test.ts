import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { stripSqlComments, containsNormalized } from './sqlTestHelpers';

const sql = readFileSync(join(__dirname, '..', '0014_tutor_profile_creation.sql'), 'utf-8');

describe('0014 — create_tutor_profile_from_application', () => {
  it('adds a unique index on tutor_application_id preventing duplicate profiles per application', () => {
    expect(sql).toContain('create unique index if not exists idx_tutor_profiles_application_id');
    expect(sql).toContain('on tutor_profiles (tutor_application_id)');
    expect(sql).toContain('where tutor_application_id is not null');
  });

  it('the RPC checks for an existing profile before creating one (fast-path idempotency)', () => {
    expect(sql).toContain('select id into v_existing_profile_id from tutor_profiles where tutor_application_id = p_application_id');
    expect(sql).toContain('if v_existing_profile_id is not null then');
    expect(sql).toContain('return v_existing_profile_id;');
  });

  it('the RPC rejects applications that are not approved', () => {
    expect(sql).toContain("if v_app.status <> 'approved' then");
    expect(sql).toContain("raise exception 'application_not_approved'");
  });

  it('the RPC copies only public-safe fields into tutor_profiles — never email, phone, admin_notes, or supporting_documents_note', () => {
    const insertBlock = sql.slice(sql.indexOf('insert into tutor_profiles ('), sql.indexOf(');', sql.indexOf('insert into tutor_profiles (')));
    expect(insertBlock).not.toContain('v_app.email');
    expect(insertBlock).not.toContain('v_app.phone');
    expect(insertBlock).not.toContain('admin_notes');
    expect(insertBlock).not.toContain('supporting_documents_note');
  });

  it('the RPC does not copy self-reported qualifications into the public qualifications_summary', () => {
    const insertBlock = sql.slice(sql.indexOf('insert into tutor_profiles ('), sql.indexOf(');', sql.indexOf('insert into tutor_profiles (')));
    expect(insertBlock).not.toContain('v_app.qualifications');
  });

  it('new profiles default accepting_students to false and status to draft — never auto-published', () => {
    const insertBlock = sql.slice(sql.indexOf('insert into tutor_profiles ('), sql.indexOf(');', sql.indexOf('insert into tutor_profiles (')));
    expect(insertBlock).toContain("false, 'draft'");
  });

  it('is granted to authenticated (admin session), not service_role — this is an admin-triggered operation, not a public write', () => {
    expect(containsNormalized(sql, 'grant execute on function create_tutor_profile_from_application(uuid) to authenticated;')).toBe(true);
    expect(containsNormalized(sql, 'grant execute on function create_tutor_profile_from_application(uuid) to service_role;')).toBe(false);
  });

  it('records a status-history row on creation, attributing it via auth.uid()', () => {
    expect(sql).toContain('insert into tutor_profile_status_history');
    expect(sql).toContain("'Created from approved application'");
    expect(
      containsNormalized(sql, "values (v_profile_id, null, 'draft', auth.uid(), 'Created from approved application');"),
    ).toBe(true);
  });

  it('AUDIT IDENTITY FIX: the function signature no longer accepts a caller-supplied p_changed_by', () => {
    // Robust to CRLF vs LF: a literal '\n' in the expected string only
    // matches an LF-checked-out file. normalizeWhitespace makes this
    // check equally strong regardless of line-ending style.
    expect(containsNormalized(sql, 'create or replace function create_tutor_profile_from_application(p_application_id uuid)')).toBe(true);
    expect(sql).not.toMatch(/create_tutor_profile_from_application\([^)]*p_changed_by/);
  });

  it('AUDIT IDENTITY FIX: changed_by is derived from auth.uid(), never a parameter, in executable SQL', () => {
    expect(sql).toContain('auth.uid()');
    // stripSqlComments normalizes line endings before splitting — without
    // that, a CRLF-checked-out file leaves a trailing \r on each split
    // line, which silently defeats the `--.*$` comment-stripping regex
    // (`.` never matches \r, so the comment is never actually removed) and
    // "p_changed_by" mentioned in this migration's own prose/comments
    // would incorrectly be counted as present in "executable SQL".
    expect(stripSqlComments(sql)).not.toContain('p_changed_by');
  });

  it('AUDIT IDENTITY FIX: revoke/grant signatures match the new single-argument function', () => {
    expect(containsNormalized(sql, 'revoke execute on function create_tutor_profile_from_application(uuid) from public;')).toBe(true);
    expect(stripSqlComments(sql)).not.toContain('create_tutor_profile_from_application(uuid, uuid)');
  });

  it('CONCURRENCY FIX: the profile insert is wrapped in an exception block catching unique_violation', () => {
    const fnBody = sql.slice(sql.indexOf('function create_tutor_profile_from_application'), sql.indexOf('function update_tutor_profile'));
    expect(fnBody).toContain('exception');
    expect(fnBody).toContain('when unique_violation then');
  });

  it('CONCURRENCY FIX: the exception handler checks the specific constraint name before treating it as a benign race', () => {
    const fnBody = sql.slice(sql.indexOf('function create_tutor_profile_from_application'), sql.indexOf('function update_tutor_profile'));
    expect(containsNormalized(fnBody, 'get stacked diagnostics v_constraint_name = constraint_name')).toBe(true);
    expect(containsNormalized(fnBody, "if v_constraint_name = 'idx_tutor_profiles_application_id' then")).toBe(true);
  });

  it('CONCURRENCY FIX: an unrelated unique violation is re-raised, never silently swallowed', () => {
    const fnBody = sql.slice(sql.indexOf('function create_tutor_profile_from_application'), sql.indexOf('function update_tutor_profile'));
    // "else" immediately followed by "raise;" as the next two tokens —
    // proves the fallback branch re-raises rather than silently
    // continuing or returning a bogus value, regardless of the exact
    // whitespace/line-break/indentation between them.
    expect(containsNormalized(fnBody, 'else raise;')).toBe(true);
  });

  it('CONCURRENCY FIX: on losing the race, the function returns the winning profile id rather than the caller\'s own (never-inserted) row', () => {
    const fnBody = sql.slice(sql.indexOf('function create_tutor_profile_from_application'), sql.indexOf('function update_tutor_profile'));
    // Robust to CRLF/indentation differences — still requires these two
    // statements to appear as an exact, consecutive token sequence: the
    // lookup by tutor_application_id immediately followed by returning
    // that (winning) profile id, not the caller's own.
    expect(
      containsNormalized(
        fnBody,
        'select id into v_profile_id from tutor_profiles where tutor_application_id = p_application_id; return v_profile_id;',
      ),
    ).toBe(true);
  });
});

describe('0014 — update_tutor_profile (added in E7 review)', () => {
  it('exists as its own function, distinct from profile creation', () => {
    expect(sql).toContain('create or replace function update_tutor_profile(');
  });

  it('validates subject and education-level slugs before writing anything', () => {
    const fnBody = sql.slice(sql.indexOf('function update_tutor_profile'));
    expect(fnBody).toContain("raise exception 'invalid_subject_slug'");
    expect(fnBody).toContain("raise exception 'invalid_education_level_slug'");
  });

  it('uses non-ambiguous unnest aliases (the same class of bug fixed in 0013)', () => {
    const fnBody = sql.slice(sql.indexOf('function update_tutor_profile'));
    expect(fnBody).toContain('unnest(p_subject_slugs) as u(subject_slug)');
    expect(fnBody).toContain('unnest(p_education_level_slugs) as u(level_slug)');
    expect(fnBody).not.toMatch(/unnest\([^)]*\)\s+as\s+(?:\w+\()?slug\b/);
  });

  it('updates only public-safe profile columns — never status or tutor_application_id', () => {
    const updateBlock = sql.slice(sql.indexOf('update tutor_profiles set'), sql.indexOf('where id = p_profile_id;'));
    expect(updateBlock).not.toContain('status');
    expect(updateBlock).not.toContain('tutor_application_id');
  });

  it('replaces both junction tables transactionally (delete then insert, within the same function body)', () => {
    const fnBody = sql.slice(sql.indexOf('function update_tutor_profile'));
    expect(fnBody).toContain('delete from tutor_profile_subjects where tutor_profile_id = p_profile_id;');
    expect(fnBody).toContain('delete from tutor_profile_levels where tutor_profile_id = p_profile_id;');
  });

  it('raises a clear error when the profile does not exist', () => {
    const fnBody = sql.slice(sql.indexOf('function update_tutor_profile'));
    expect(fnBody).toContain('if not found then');
    expect(fnBody).toContain("raise exception 'profile_not_found'");
  });

  it('is granted to authenticated, not service_role or public', () => {
    const fnBody = sql.slice(sql.indexOf('function update_tutor_profile'));
    expect(containsNormalized(fnBody, 'grant execute on function update_tutor_profile(')).toBe(true);
    expect(containsNormalized(fnBody, 'to authenticated;')).toBe(true);
  });
});
