-- seed.sql
-- LOCAL/DEV ONLY. Mirrors src/assets/mock/mockSubjects.ts exactly so the
-- eventual SupabaseSubjectRepository returns the same catalogue the mock
-- one does today. No fictional tutors/applications/matching requests are
-- seeded here — Phase D's mock tutor fixtures stay in application code
-- fixtures, not in a database anyone might mistake for real data.

insert into education_levels (slug, name, stage_headline, stage_description, display_order) values
  ('ks1', 'KS1', 'Build strong foundations', 'Early reading, writing and number skills, at their own pace.', 1),
  ('ks2', 'KS2', 'Strengthen the basics', 'Solidifying core skills ahead of the move to secondary school.', 2),
  ('ks3', 'KS3', 'Strengthen understanding', 'Closing gaps before subjects narrow and pace picks up at GCSE.', 3),
  ('gcse', 'GCSE', 'Prepare with confidence', 'Focused, exam-aware support in the subjects that need it most.', 4),
  ('a-level', 'A-Level', 'Master advanced subjects', 'Depth and independence for the step up to further study.', 5);

insert into subjects (slug, name, description, display_order) values
  ('maths', 'Maths', 'From times tables to A-Level calculus.', 1),
  ('english', 'English', 'Reading, writing and analysis skills.', 2),
  ('combined-science', 'Combined Science', null, 3),
  ('biology', 'Biology', null, 4),
  ('chemistry', 'Chemistry', null, 5),
  ('physics', 'Physics', null, 6),
  ('computer-science', 'Computer Science', null, 7),
  ('geography', 'Geography', null, 8),
  ('history', 'History', null, 9),
  ('french', 'French', null, 10),
  ('spanish', 'Spanish', null, 11),
  ('business', 'Business', null, 12),
  ('economics', 'Economics', null, 13);
