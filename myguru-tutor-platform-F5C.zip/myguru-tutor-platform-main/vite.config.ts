import { defineConfig, type Plugin } from 'vitest/config';
import react from '@vitejs/plugin-react';
import { siteConfig } from './src/config/siteConfig.ts';

/**
 * Injects siteConfig values into index.html's static <title>/meta tags at
 * build time, so the brand name/tagline has exactly one source (siteConfig)
 * even for the one part of the app (the initial HTML shell, before React
 * mounts) that can't read siteConfig at runtime.
 */
function siteConfigHtmlPlugin(): Plugin {
  return {
    name: 'site-config-html',
    transformIndexHtml(html) {
      return html
        .replace(/__SITE_TITLE__/g, `${siteConfig.brandName} — Online tutoring, Primary to A-Level`)
        .replace(
          /__SITE_TAGLINE_META__/g,
          `${siteConfig.brandName} — online tutoring, Primary to A-Level. Personalised tutor matching and a reviewed tutor directory.`,
        );
    },
  };
}

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), siteConfigHtmlPlugin()],
  test: {
    environment: 'jsdom',
    setupFiles: ['./src/test/setup.ts'],
    globals: true,
  },
});
